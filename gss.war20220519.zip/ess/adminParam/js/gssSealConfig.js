
var bills = new Map();
var sealInfos = new Map();
var smsSeals = new Map();//实物印章
var elecSeals = new Map();//电子印章
var model = false;
var checkedSeal = new Map();
$(function() {
	$("#list").trigger("reloadGrid");
	pageInit();
	
	$("#sealModeId").change();
});

function pageInit() {
	
	
	initApplyDialog();
	
	fetchSealApllyList();
		
	$("#submitForm").click(function() {
		$("#list").jqGrid("search", "#search");
	});
	
	$("#clearBtn").click(function() {
		$("#search")[0].reset();
	});
	
	shwo_hide();
	
	//通过凭证配置表获取 凭证模板编号 列表；通过对应交易码取值
	GPCache.remote({url:ctx +"/gss/billinfo/billInfoAction!fetch.action", callback:function(data){
		var datas = {};		
		//{交易码对应多个凭证模板编号，数组key
		//   1122:[{6768: }, 1212]
		//}
		for (var i = 0; i < data.length; i++) {
			if(!datas[data[i].tradeCode]) {
				datas[data[i].tradeCode] = [];//一个值都没有
			}
			//datas[data[i].tradeCode].push(data[i].billTplCode);
			datas[data[i].tradeCode].push({billTplCode:data[i].billTplCode, billName:data[i].billName});
			
		}
		return datas;
	},refresh:true
	}, GPCache.ESS, GPType.ESS_BILL_TPCODE);
	
	
	
}


function shwo_hide() {
	$("#sealModeId").change(function() {
		//用印模式                                      1 为实物用印
			$("#smsSealId").val("");
			$("#sms").show();
		
	});
}



function initApplyDialog() {
	
		//通过交易码信息表获取  交易码 列表 ，交易码页面已设置缓存
		GPCache.remote({url:ctx +"/gss/admintradeinfo/adminTradeInfoAction!fetch.action", callback:function(data){
			var datas = {};
			
			for (var i = 0; i < data.length; i++) {
				datas[data[i].tradeCode] = data[i].tradeName;
			}
			return datas;
		},refresh:true}, GPCache.ESS, GPType.ESS_TRADE_CODE);
		
		
		var options = "<option value=''>--请选择--</option>";		
		var objs = GPCache.get(GPCache.ESS, GPType.ESS_TRADE_CODE);
		for (var o in objs) {
			options += ("<option value=\"" + o + "\">" + o + "</option>");
		}
		$("#tradeCodeId").html(options);
			
		
		//获取实物印章列表
		GPCache.remote({url:ctx +"/sms/cache/sealType!fetch.action", callback:function(data){
			var datas = {};
			for (var i = 0; i < data.length; i++) {
				datas[data[i].type] = data[i].name;
			}
			
			
			return datas;
		}}, GPCache.SMS, GPType.SMS_SEAL_TYPE);
		
		var options = "";
		var objs = GPCache.get(GPCache.SMS, GPType.SMS_SEAL_TYPE);
		var index = 0;
		for (var o in objs) {
			index++;
			if(index%2==1){
				options += ("<div style='display: inline;'>"+objs[o] +"<input type='checkbox' name='realSeal' id='seal"+o+"' value=\"" + o + "\"/>&nbsp;&nbsp;</div>") ;
			}else{
				options += ("<div style='position:absolute;left: 300px;display: inline;'>"+objs[o] +"<input type='checkbox' name='realSeal' id='seal"+o+"' value=\"" + o + "\"/>&nbsp;&nbsp;</div></br>") ;
			}
		}
		
		options += "";
		$("#realSealType").html(options);
		
		
		//交易码改变时查询其相应实物章配置情况
		$("#tradeCodeId").change(function() {
			$("input[name='realSeal']").attr("checked",false);
			$("input[name='realSeal']").attr("disabled",false);
    		$.ajax({
    			url : top.ctx + "/gss/adminsealconfig/adminSealConfigAction!checkModel.action",
    			type : "POST",
    			data : {
    				"sealConfig.tradeCode" : $(this).val()
    			},
    			dataType : "json",//
    			success : function(result) {
    				if (result.responseMessage.success) {
    					var sealTypeStrs = result.responseMessage.message;
    					sealTypeStrs = sealTypeStrs.substr(0,sealTypeStrs.length-1);
    					var sealTypearr = new Array(); 
    					sealTypearr=sealTypeStrs.split(",");
    					for (var int = 0; int < sealTypearr.length; int++) {
							$("#seal"+sealTypearr[int]).attr("checked", true);
							$("#seal"+sealTypearr[int]).attr("disabled", true);
						}
    				}else {
    					alert("获取用印配置信息出错！");
    					return;
    				}
    			}
    		});
		});

		
		
	$("#addForm").dialog({
        autoOpen : false,
        height : 300,
        width : 600,
        resizable : false,
        modal : true,
        buttons : {
        	"保存" : function() {
        		
        		$("#billTypeId").removeAttr("disabled");
        		
        		$("#smsSealId").change();
        		
        		if ($("#tradeCodeId").val() == "") {
        			alert("请选择交易码！");
        			return;
        		}
        		var checkedSealStr = "";
    			$("input[name='realSeal']:checked").not("[disabled]").each(function(i){
    				checkedSeal.put(i, $(this).val());
    				checkedSealStr = checkedSealStr+ $(this).val()+",";
    			});
    			$("#elecSealId").val(checkedSealStr);
    			
        		if (checkedSealStr.length<1) {
        				alert("请选择要新增的实物印章类型");
        				return;
        		}else{
        			$.post(top.ctx + "/gss/adminsealconfig/adminSealConfigAction!save.action",	
        				$("#addForm").serializeForm(),function(data) {
        				
        			
        			if (data.responseMessage.success) {
        				$.success("保存成功");
        				
        				$("#addForm").dialog("close");
        				$("#list").trigger("reloadGrid");
        				$("#list").jqGrid("search", "#search");
        			} else {
        				$.error("保存失败: " + data.responseMessage.message);
        			}    	        			       	        			
        		});
        		
        		}
        	}
        },
        
    	close : function() {
			$("input[name='realSeal']").attr("checked",false);
			$("input[name='realSeal']").attr("disabled",false);
    		$("#addForm").validationEngine("hideAll");
    		$("#addForm")[0].reset();
    		//恢复默认界面
    	}

	});
	
	
	$("#addSealConfig").click(function(){
		$("#addForm").dialog("open");
	});
		
}

/**
 * 列表
 */
function fetchSealApllyList() {
	$("#list").jqGrid({
		caption : "用印配置信息查询",
		url : top.ctx + "/gss/adminsealconfig/adminSealConfigAction!list.action",
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "交易代码","用印模式","实物印章","操作" ],
		colModel : [ {
			name : "tradeCode",
			index : "tradeCode",
			width : 80

		}, {
			name : "sealMode",
			index : "sealMode",
			width : 120,
			formatter : function(value, options, rData) {
				return GPCache.get(GPCache.GSS, GPType.ESS_SEAL_MODE, value);
			}
		},{
			name : "sealTypeId",
			index : "sealTypeId",
			width : 120,
			formatter : function(value, options, rData) {
				return GPCache.get(GPCache.SMS, GPType.SMS_SEAL_TYPE,value);
			}
		}, {
			name : "autoId",
			index : "autoId",
			width : 120,
			formatter : function(value, options, rData) {
				return "<input type='button'  value='修改' onclick='openUpdateParamDLG(\"" + value + "\")'/>"+
				"<input type='button'  value='删除' onclick='delApplyInfo(\"" + value + "\")'/>";
			}
		}],
		pager : "#pager"
	});
}



function openUpdateParamDLG(autoId) {
	
	$.ajax({
		type : "POST",
		url : ctx + "/gss/adminsealconfig/adminSealConfigAction!find.action",
		data : {
			"sealConfig.autoId" : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				
				$("#addForm").dialog("open");
				
				$("input[name='sealConfig.autoId']").val(data.sealConfig.autoId);
				$("#tradeCodeId").val(data.sealConfig.tradeCode);
				$("#sealModeId").val(data.sealConfig.sealMode);
				
				$("#tradeCodeId").change();
				$("#sealModeId").change();
				$("#smsSealId").change();
				
				$("#smsSealId").val(data.sealConfig.sealTypeId);
				$("input[name='sealConfig.memo']").val(data.sealConfig.memo);
				
				
			} else {
				$.error("操作失败:" + data.responseMessage.message);
			}
		}
	});
}

function delApplyInfo(autoId) {
	if (confirm("确定删除信息？")) {
	$.ajax({
		type : "POST",
		url : ctx + "/gss/adminsealconfig/adminSealConfigAction!delete.action",
		data : {
			"sealConfig.autoId" : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				
				$.success("操作成功：用印配置信息删除成功!");
				$("#list").trigger("reloadGrid");
			}
			else {
				$.error("操作失败：" + data.responseMessage.message);
			}
		}

	});
	
	}
	return false;
}






