

$(function(){
	initDialog();
	initJGrid();
	$("#newSealType").click(function() {
		$("#sealTypeInfo").dialog("open");
	});
	
	$("#searchBtn").closest("form").css("margin-bottom", "10px").css("margin-top", "10px");
	
	$("#searchBtn").click(function(){
		$("#list").jqGrid("search", "#search");
	});
	
	$("#clearBtn").click(function(){
		$(this).closest("form")[0].reset();
	});
	
	$("#choseOrgNo").click(function(){
		$("#orgNoInput").dialogOrgTree("radio", top.loginPeopleInfo.orgNo, false, {
			filterOrgType : "1,2,6,7",
			isOrgNo : true
		}, null, function(event, treeId, treeNode) {
			if (treeNode) {
				$("#orgNoInput").val(treeNode.organizationNo);
			}
		});
	});
});


function initDialog() {
	$("#sealTypeInfo").dialog({
        autoOpen : false,
        height : 300,
        width : 380,
        resizable : false,
        modal : true,
        buttons : {
            "保存" : function() {
            	if (!$(this).validationEngine("validate")) {
                    return;
                 }
            	var _this = this;
            	var formData = $(this).serializeForm();
            	$.post(top.ctx+"/ess/param/elecParamSealTypeAction_checkParamSealType.action", formData, function(data) {
					if(data.responseMessage.success) {
						$.post(top.ctx+"/ess/param/elecParamSealTypeAction_save.action", formData
								, function(data) {
							if (data.responseMessage.success) {
								$.success("保存成功");
								$(_this).dialog("close");
								$("#list").jqGrid("search", "#search");
							} else {
								$.error("保存失败: " + data.responseMessage.message);
							}
							
						});
					} else {
						alert(data.responseMessage.message);
					}
				});
            	
            },
            "取消" : function() {
            	$(this).dialog("close");
            }
        },
        close : function() {
        	$(this).data("sealType", "");
            $("#sealTypeInfo").validationEngine("hideAll");
            $("#sealTypeInfo")[0].reset();
        },
        open : function() {
        	var _this = this;
        	var sealType = $(this).data("sealType");
        	if(sealType) {//更新
        		$.post(top.ctx+"/ess/param/elecParamSealTypeAction_findBySealType.action",
						{ "paramSealType.sealType" : sealType },
						function(data) {
							if (data.responseMessage.success) {
								$(_this).fillForm({paramSealType : data.paramSealType});
							}
						}
				);
        	}
        }
    });
	
	$("#sealTypeInfo").validationEngine({
        showOnMouseOver:true,
        validationEventTrigger:"keyup blur",
        promptPosition : "centerRight",
        autoPositionUpdate : true,
        onValidationComplete: function() {}
    });
}

function initJGrid() {
	$("#list").jqGrid({
		caption : "电子印章类型列表",
		url : top.ctx+"/ess/param/elecParamSealTypeAction_list.action",
		rowList:[10, 15, 20, 30],
		rowNum:15,
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "类型名称", "类型编号", "所属机构", "备注信息", "操作" ],
		colModel : [ {
			name : "sealTypeName",
			index : "sealTypeName",
			width : 180
		}, {
			name : "sealTypeCode",
			index : "sealTypeCode",
			width : 80
		}, {
			name : "orgNo",
			index : "orgNo",
			width : 120,
			formatter : function(value, options, rData) {
				if (value == "*") {
					return value;
				} else {
					return Organization.getOrganizationByOrgNo(value).organizationNameAndNo;
				}
			}
		}, {
			name : "memo",
			index : "memo",
			width : 180
		}, {
			name : "sealType",
			index : "sealType",
			width : 80,
			formatter : function(value, options, rData) {
				return addEditAndDelIcon(value, "editFn", "delFn");
			}
		}
		],
		pager : "#pager"
	});
	
	$("#list").navGrid("#pager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
}


function addEditAndDelIcon(value, editFnName, delFnName) {
	var html = "";
	if (editFnName) {
		html += "<div class='icon_edit' onclick='"+ editFnName +"(\"" + value + "\")' title='编辑' style='float:left;'></div>";
	} 
	if (delFnName) {
		html += "<div class='icon_delete' onclick='"+ delFnName +"(\"" + value + "\")' title='删除' style='float:left;'></div>";
	}
	return html;
	
}

function editFn(sealType) {
	$("#sealTypeInfo").data("sealType", sealType).dialog("open");
}


/**
 * 删除印章申请信息
 * @param autoId 主键sid
 */
function delFn(sealType) {
	$.del(top.ctx+"/ess/param/elecParamSealTypeAction_delete.action", {"paramSealType.sealType":sealType});
}