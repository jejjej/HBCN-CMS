/**
 * 
 * 创建于:2016-9-13<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 电子印章使用机构参数配置
 * 
 * @author chenhuang
 * @version 1.0.0
 */

var currentNode = null;
var currentOwnerOrg = null;

/**
 * 选择机构
 */
function choseOrganizationItem() {
	$("#operOrgNo_Item").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, {
		filterOrgType : "1,2,6,7"
	}, null, function(event, treeId, treeNode) {
		if (treeNode) {
			if (treeNode) {
				$("#operOrgNo_Item").val(treeNode.organizationName + "(" + treeNode.organizationNo + ")");
				$("#operOrgNo_Form").val(treeNode.organizationNo);
			}
		}
	});
}

function choseOrgNoInput() {
	$("#sealUsedOrgParamForm_operOrgNo").dialogOrgTree("radio", currentOwnerOrg, false, {
		filterOrgType : "1,2,6,7",
		isOrgNo : true
	}, null, function(event, treeId, treeNode) {
		if (treeNode) {
			$("#sealUsedOrgParamForm_operOrgNo").val(treeNode.organizationNo);
		}
	});
}

function query() {
	if ($("#elecSealInfo_sealSn_form").val() == "") {
		alert("印章编号不能为空!");
		return false;
	}
	$("#sealUsedOrgList").jqGrid("search", "#sealFormId");
}

function openAddParamDLG() {
	if ($("#elecSealInfo_sealSn_form").val() == "") {
		alert("印章编号不能为空!");
		return false;
	}
	$("#sealUsedOrgParamDLG").dialog("open");
	$("#addButtonDIV").show();
	$("#updateButtonDIV").hide();
	$("input[name='elecSealUsedOrgParam.elecSealInfo.sealSn']").val(currentNode.sealSn);
	$("input[name='elecSealUsedOrgParam.elecSealInfo.bankName']").val(currentNode.bankName);
	$("input[name='elecSealUsedOrgParam.elecSealInfo.sealName']").val(currentNode.sealName);
}

function openUpdateParamDLG(autoId) {
	$.ajax({
		type : "POST",
		url : ctx + "/ess/param/elecSealUsedOrgParamAction_queryParam.action",
		data : {
			"elecSealUsedOrgParam.autoId" : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$("input[name='elecSealUsedOrgParam.autoId']").val(data.elecSealUsedOrgParam.autoId);
				$("input[name='elecSealUsedOrgParam.elecSealInfo.sealSn']").val(
						data.elecSealUsedOrgParam.elecSealInfo.sealSn);
				$("input[name='elecSealUsedOrgParam.elecSealInfo.bankName']").val(
						data.elecSealUsedOrgParam.elecSealInfo.bankName);
				$("input[name='elecSealUsedOrgParam.elecSealInfo.sealName']").val(
						data.elecSealUsedOrgParam.elecSealInfo.sealName);
				$("input[name='elecSealUsedOrgParam.operOrgNo']").val(data.elecSealUsedOrgParam.operOrgNo);
				$("#sealConfigType").val(data.elecSealUsedOrgParam.state);
				$("#sealUsedOrgParamDLG").dialog("open");
				$("#addButtonDIV").hide();
				$("#updateButtonDIV").show();
			} else {
				$.error("操作失败:" + data.responseMessage.message);
			}
		}
	});
}

function resetForm() {
	$("#sealUsedOrgParamForm")[0].reset();
	$("#sealUsedOrgParamDLG").dialog("close");
}

function addParam() {

	if ($("#sealUsedOrgParamForm_operOrgNo").val() == "") {
		alert("操作机构不能为空!");
		return false;
	}
	$.ajax({
		type : "POST",
		url : ctx + "/ess/param/elecSealUsedOrgParamAction_addParam.action",
		data : {
			"elecSealUsedOrgParam.elecSealInfo.sealSn" : currentNode.sealSn,
			"elecSealUsedOrgParam.operOrgNo" : $.trim($("#sealUsedOrgParamForm_operOrgNo").val()),
			"elecSealUsedOrgParam.state" : $.trim($("#sealConfigType  option:selected").val())
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$.success("操作成功：参数添加成功!");
				$("#sealUsedOrgParamDLG").dialog("close");
				$("#sealUsedOrgList").trigger("reloadGrid");
			} else {
				$.error("操作失败：" + data.responseMessage.message);
			}
		}
	});
}

function updateParam() {
	if ($("#sealUsedOrgParamForm_operOrgNo").val() == "") {
		alert("操作机构不能为空!");
		return false;
	}
	$.ajax({
		type : "POST",
		url : ctx + "/ess/param/elecSealUsedOrgParamAction_updateParam.action",
		data : {
			"elecSealUsedOrgParam.autoId" : $("input[name='elecSealUsedOrgParam.autoId']").val(),
			"elecSealUsedOrgParam.elecSealInfo.sealSn" : $("input[name='elecSealUsedOrgParam.elecSealInfo.sealSn']")
					.val(),
			"elecSealUsedOrgParam.operOrgNo" : $.trim($("#sealUsedOrgParamForm_operOrgNo").val()),
			"elecSealUsedOrgParam.state" : $.trim($("#sealConfigType  option:selected").val())
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$.success("操作成功：参数更新成功!");
				$("#sealUsedOrgParamDLG").dialog("close");
				$("#sealUsedOrgList").trigger("reloadGrid");
			} else {
				$.error("操作失败：" + data.responseMessage.message);
			}
		}
	});
}
function deleteParam(autoId) {
	if (confirm("确定要删除该参数吗？")) {
		$.ajax({
			type : "POST",
			url : ctx + "/ess/param/elecSealUsedOrgParamAction_deleteParam.action",
			data : {
				"elecSealUsedOrgParam.autoId" : autoId
			},
			dataType : "json",
			async : false,
			success : function(data) {
				if (data && data.responseMessage && data.responseMessage.success) {
					$.success("操作成功：参数删除成功!");
					$("#sealUsedOrgList").trigger("reloadGrid");
				} else {
					$.error("操作失败：" + data.responseMessage.message);
				}
			}
		});
	}
}

function initGrid() {
	// 230是左侧机构树区域width
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	var pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	// 人员信息列表
	$("#sealUsedOrgList").jqGrid(
			{
				width : pageContentWidth,
				height : tableHeight,
				multiselect : false,
				autoLoad : false,
				url : ctx + "/ess/param/elecSealUsedOrgParamAction_list.action",
				rowNum : 20,
				rowList : [ 20, 50, 100 ],
				colNames : [ "印章名称", "印章所属机构", "印章行名", "操作机构号", "操作机构名", "配置模式", "操作" ],
				colModel : [
						{
							name : "ElecSealInfo.sealName",
							index : "ElecSealInfo.sealName",
							align : "center",
							sortable : false
						},
						{
							name : "ElecSealInfo.ownOrgNo",
							index : "ElecSealInfo.ownOrgNo",
							align : "center",
							sortable : false
						},
						{
							name : "ElecSealInfo.bankName",
							index : "ElecSealInfo.bankName",
							align : "center",
							sortable : false
						},
						{
							name : "operOrgNo",
							index : "operOrgNo",
							align : "center",
							sortable : false
						},
						{
							name : "operOrgName",
							index : "operOrgName",
							align : "center",
							sortable : false
						},
						{
							name : "state",
							index : "state",
							align : "center",
							sortable : false,
							formatter : function(value, options, rData) {
								return value == '0' ? "启用" : "停用";
							}
						},
						{
							name : "autoId",
							index : "autoId",
							align : "center",
							sortable : false,
							formatter : function(value, options, rData) {
								return "<input type='button'  value='修改' onclick='openUpdateParamDLG(\"" + value
										+ "\")'/><input type='button' value='删除' onclick='deleteParam(\"" + value
										+ "\")'  />";
							}
						} ],
				pager : "#sealUsedOrgListPager",
				gridComplete : function() {
				}
			});
}

/**
 * 初始化印章数据
 */
function initEssSealTree() {
	var setting = {
		view : {
			dblClickExpand : false,
			showLine : true,
			selectedMulti : false
		},
		data : {
			simpleData : {
				enable : true,
				idKey : "autoId",
				pIdKey : "pId",
				rootPId : null
			},
			key : {
				name : "showName"
			}
		},
		callback : {
			onClick : function(e, treeId, treeNode) {
				$("#elecSealInfo_sealSn_form").val(treeNode.sealSn);
				currentNode = treeNode;
				currentOwnerOrg = treeNode.ownOrgNo;
				$("#sealUsedOrgList").jqGrid("search", "#sealFormId");
			}
		}
	};
	$.ajax({
		type : "POST",
		url : ctx + "/ess/param/elecSealUsedOrgParamAction_initSealTree.action",
		data : {
			ownOrgNo : top.loginPeopleInfo.orgNo
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data.responseMessage.success) {
				zNodes = _formatSealData(data.elecSealInfos);
				$.fn.zTree.init($("#_sealTree_"), setting, zNodes);
			}
		}
	});
}

/**
 * 初始化参数DLG
 */
function initDialog() {
	$("#sealUsedOrgParamDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 300,
		width : 350,
		modal : true,
		buttons : {},
		close : function() {
			$("#sealUsedOrgParamForm")[0].reset();
		}
	});
};

/**
 * 格式化印章数据
 * 
 * @param sealInfos
 * @returns {Array}
 */
function _formatSealData(sealInfos) {
	var array = [];

	$.each(sealInfos, function(index, sealInfo) {
		array[index] = {
			autoId : sealInfo.autoId,
			sealName : sealInfo.sealName,
			bankName : sealInfo.bankName,
			sealSn : sealInfo.sealSn,
			ownOrgNo : sealInfo.ownOrgNo,
			moulageSn : sealInfo.moulageSn,
			showName : sealInfo.sealName + "(" + sealInfo.sealSn + ")",
			pId : null
		};
	});
	return array;
}