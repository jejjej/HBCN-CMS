/**
 * 
 * 创建于:2016-11-13<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 业务要素信息查询js
 * 
 * @author lxy
 * @version 1.0.0
 */

var bizInfos = new Map();

/** 根据命名空间及key获取wf缓存的值 */
function getParamFromWFCache(namespace, key) {
    try {
        //创建后台设置的命名空间
        var cacheSpace = top.WFCache.getCacheSpace(namespace);
        //获取该命名空间下的所有缓存值
        var cache = top.WFCache.getPageCache(cacheSpace);
        //根据key，获取该缓存下的某个值
        return cache.get(key);
    } catch (e) {
        return null;
    }
};

function pageInit() {
	var date1 = new Date();
    date1.setMonth(date1.getMonth()-1);
	$("#ge_applyTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
	
	$("#le_applyTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
	
    $("#operOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
	$("#operOrgNo_Form").val(top.loginPeopleInfo.orgNo);
	
	$("#d").dialog({
		autoOpen : false,
		resizable : false,
		closeOnEscape : false,
		height : 300,
		width : 300,
		modal : true,
		open : function(event, ui) {
		},
		close : function(){
			$("#de").html("");
			$(this)[0].reset();
		}
	});
	
	// 获取电子印章信息列表
	fetchBizElementList();

	$("#submitForm").click(function() {
		$("#list").jqGrid("search", "#search");
	});

	$("#clearForm").click(function() {
		$("#search")[0].reset();
		var date1 = new Date();
	    date1.setMonth(date1.getMonth()-1);
		$("#ge_applyTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
		
		$("#le_applyTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
		
	    $("#operOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
		$("#operOrgNo_Form").val(top.loginPeopleInfo.orgNo);
	});
	
	

}


/**
 * 获取验证码信息列表
 */
function fetchBizElementList() {
	$("#list").jqGrid({
		caption : "验证码查询信息列表",
		url : top.ctx + "/ess/bizelement/verificationCodeQueryAction!list.action",
		rowList:[10,15,20,30],
		rowNum:10,
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "交易代码",  "交易代码名称", "申请人" ,"申请机构","交易时间", "验证码", "是否补盖","申请用印数","已用印数","详情"],
		colModel : [ {
			name : "tradeCode",
			index : "tradeCode",
			width : 100
		}, {
			name : "tradeCodeName",
			index : "tradeCodeName",
			width : 100
		}, {
			name : "applyPeopleName",
			index : "applyPeopleName",
			width : 160,
			formatter : function(value, options, rData) {
				return value+"("+rData.applyPeopleCode+")";
			}
		},{
			name : "applyOrgName",
			index : "applyOrgName",
			width : 180,
			formatter : function(value, options, rData) {
				return value+"("+rData.applyOrgNo+")";
			}
		},  {
			name : "applyTime",
			index : "applyTime",
			width : 160
		},  {
			name : "checkCode",
			index : "checkCode",
			width : 180
		} ,	 {
			name : "isCovered",
			index : "isCovered",
			width : 80,
			formatter : function(value, options, rData) {
				return value=="1"?"已补盖":"未补盖";
			}
		}, {
			name : "applyNum",
			index : "applyNum",
			width : 60
		}, {
			name : "usedNum",
			index : "usedNum",
			width : 60
		}, 	{
			name : "autoId",
			index : "autoId",
			align : "center",
			sortable : false,
		    formatter : function(value, options, rData) {
			if (null == rData.checkCode || rData.checkCode == "") {
				return "无要素";
			}else {
				return "<input type='button'  value='要素' onclick='getBizElementDetail(\"" + rData.checkCode + "\")'/>";
			}
		}
		}],
		pager : "#pager"
	});
}

/**
* 获取验证码详情
*/
function getBizElementDetail(checkCode) {
	
	$("#d").dialog("open");
	//alert(tradeCode);
	$.ajax({
		
		type : "POST",
		url : ctx + "/ess/bizElement/bizElementInfoQueryAction!check.action",
		data : {
			"bizElementInfo.checkCode" : checkCode
		},
		dataType : "json",
		async : false,
		success : function(data) {
			var table_list = "";
			if (data && data.responseMessage && data.responseMessage.success) {
				
				for(var i=0;i<data.bizElementInfos.length;i++) {
					var bizInfo = data.bizElementInfos[i];
					bizInfos.put(bizInfo.elementName, bizInfo.elementValue);					
					table_list += "<tr><td>"+bizInfo.elementName+":"+bizInfo.elementValue+"</td></tr>";
					//alert(bizInfo.elementName+bizInfo.elementValue);
				}
							
			}
			$("#de").html(table_list);
		}
		
		
	});
	}
	
function resetForm() {
	$("#bizElementDetailForm")[0].reset();
	$("#bizElementDetail").dialog("close");
}

/**
 * 选择机构
 */
function choseOrganizationItem() {
	$("#operOrgNo_Item").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, {
		filterOrgType : "1,2,6,7"
	}, null, function(event, treeId, treeNode) {
		if (treeNode) {
			if (treeNode) {
				$("#operOrgNo_Item").val(treeNode.organizationName + "(" + treeNode.organizationNo + ")");
				$("#operOrgNo_Form").val(treeNode.organizationNo);
			}
		}
	});
}

function resetForm() {
	$("#sealInfoDetailForm")[0].reset();
	$("#sealInfoDetail").dialog("close");
}


/**
 * 用印类型格式化
 * 
 * @param value
 * @returns {String}
 */
function essSealModeFmt(value) {
    return GPCache.get(GPCache.GSS, GPType.ESS_SEAL_MODE, value);
}
