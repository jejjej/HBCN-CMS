/**
 * 
 * 创建于:2016-9-27<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 电子印章审批日志查询js
 * 
 * @author LiuXiangyu
 * @version 1.0.0
 */

/** 根据命名空间及key获取wf缓存的值 */
function getParamFromWFCache(namespace, key) {
	try {
		// 创建后台设置的命名空间
		var cacheSpace = top.WFCache.getCacheSpace(namespace);
		// 获取该命名空间下的所有缓存值
		var cache = top.WFCache.getPageCache(cacheSpace);
		// 根据key，获取该缓存下的某个值
		return cache.get(key);
	} catch (e) {
		return null;
	}
};

function sealApplyAduitLogpageInit() {
	$("#sealAuditOperInfoDetail").dialog({
		autoOpen : false,
		resizable : false,
		height : 360,
		width : 875,
		modal : true,
		buttons : {},
		close : function() {
			$("#sealAuditOperInfoForm").validationEngine("hideAll");
			$("#sealAuditOperInfoForm")[0].reset();
		}
	});

	var bizTypeContent = "";
	var objs = GPCache.get(GPCache.GSS, GPType.ESS_BIZ_TYPE);
	for (var i = 0; i < objs.length; i++) {
    	bizTypeContent += "<option value='" + objs[i].paramKey + "'>" + objs[i].paramValue + "</option>";
	}
	bizTypeContent = "<option value=' '>全部</option>" + bizTypeContent;
	$("#bizType").html(bizTypeContent);
	
	var date1 = new Date();
    date1.setMonth(date1.getMonth()-1);
	$("#ge_operTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
	
	$("#le_operTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
	
    $("#operOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
	$("#operOrgNo_Form").val(top.loginPeopleInfo.orgNo);
	

	// 获取电子印章信息列表
	fetchSealApplyAduitQueryList();

	$("#submitForm").click(function() {
		$("#sealApplyAduitQuerylist").jqGrid("search", "#search");
	});

	$("#clearForm").click(function() {
		$("#search")[0].reset();
		var date1 = new Date();
	    date1.setMonth(date1.getMonth()-1);
		$("#ge_operTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
		
		$("#le_operTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
		
	    $("#operOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
		$("#operOrgNo_Form").val(top.loginPeopleInfo.orgNo);
	});
}

/**
 * 获取电子印章信息列表
 */
function fetchSealApplyAduitQueryList() {
	$("#sealApplyAduitQuerylist")
			.jqGrid(
					{
						caption : "电子印章操作日志列表",
						url : top.ctx
								+ "/ess/sealaduitlog/elecSealAduitLogAction!list.action",
						rowList : [ 10, 15, 20, 30 ],
						rowNum : 10,
						rownumbers : true,
						altRows : true,// 就是隔行用不同的背景色区分开
						colNames : [ "印章编号", "印章名称", "印章类型", "行名", "印章所属机构",
								"业务类型", "操作机构", "操作时间", "操作详情" ],
						colModel : [
								{
									name : "sealSn",
									index : "sealSn",
									width : 120
								},
								{
									name : "sealName",
									index : "sealName",
									width : 160
								},
								{
									name : "moulageType",
									index : "moulageType",
									width : 80,
									sortable : false,
									formatter : moulageTypeFmt
								},
								{
									name : "bankName",
									index : "bankName",
									sortable : false,
									width : 160
								},
								{
									name : "orgName",
									index : "orgName",
									sortable : false,
									width : 180
								},
								{
									name : "bizType",
									index : "bizType",
									width : 80,
									formatter : applyTypeFmt
								},
								{
									name : "operOrgNo",
									index : "operOrgNo",
									width : 180,
									formatter : function(value, options, rData) {
										return Organization
												.getOrganizationByOrgNo(value).organizationNameAndNo;
									}
								},
								{
									name : "operTime",
									index : "operTime",
									width : 160
								},
								{
									name : "autoId",
									index : "autoId",
									align : "center",
									sortable : false,
									width : 80,
									formatter : function(value, options, rData) {
										return "<input type='button'  value='详情' onclick='viewSealInfoDetail(\""
												+ rData.refId
												+ "\",\""
												+ rData.sealSn + "\")'/>";
									}
								} ],
						pager : "#sealApplyAduitQueryPager"
					});
	$("#sealApplyAduitQuerylist").navGrid("#sealApplyAduitQueryPager",{edit:false,add:false,del:false,search:false,refresh: true, excel: ctx + "/ess/sealaduitlog/elecSealAduitLogAction!report.action"});
}

/**
 * 获取电子印章申请操作详细信息
 */
var queryFlag = false;// 解决再次打开对话框还是用以前的检索条件完成查询操作
function viewSealInfoDetail(refId, sealSn) {
	if (queryFlag) {
		$("#sealAuditOperDetaillist").jqGrid('setGridParam', { url : top.ctx
			+ "/ess/sealaduitlog/elecSealAduitLogAction!listsealAduitDetail.action?refId=" + refId }).trigger("reloadGrid");
	} else {
		queryFlag = true;
		$("#sealAuditOperDetaillist")
				.jqGrid(
						{
							url : top.ctx
									+ "/ess/sealaduitlog/elecSealAduitLogAction!listsealAduitDetail.action?refId=" + refId,
							width : 850,
							height : 270,
							rownumbers : true,
							altRows : true,// 就是隔行用不同的背景色区分开
							colNames : [ "操作人员", "操作人员机构", "操作时间", "业务类型",
									"操作类型", "操作结果", "操作备注" ],
							colModel : [
									{
										name : "operPeopleCode",
										index : "operPeopleCode",
										width : 80,
										formatter : function(value, options,
												rData) {
											return rData.operPeopleName + "("
													+ value + ")";
										}
									},
									{
										name : "operOrgNo",
										index : "operOrgNo",
										width : 80,
										formatter : function(value, options,
												rData) {
											return rData.operOrgName + "("
													+ value + ")";
										}
									}, {
										name : "operTime",
										index : "operTime",
										width : 80
									}, {
										name : "bizType",
										index : "bizType",
										width : 80,
										formatter : applyTypeFmt
									}, {
										name : "operType",
										index : "operType",
										width : 80,
										formatter : OperTypeFmt
									}, {
										name : "operResult",
										index : "operResult",
										width : 80,
										formatter : OperResultFmt
									}, {
										name : "operMemo",
										index : "operMemo",
										width : 80
									} ],
							pager : "#sealAuditOperDetailPager"
						});
	}
	$('#sealAuditOperInfoDetail').dialog("option", "title",
			"电子印章操作日志详情").dialog('open');
}

/**
 * 选择机构
 */
function choseOrganizationItem() {
	$("#operOrgNo_Item").dialogOrgTree(
			"radio",
			top.loginPeopleInfo.orgSid,
			false,
			{
				filterOrgType : "1,2,6,7"
			},
			null,
			function(event, treeId, treeNode) {
				if (treeNode) {
					if (treeNode) {
						$("#operOrgNo_Item").val(
								treeNode.organizationName + "("
										+ treeNode.organizationNo + ")");
						$("#operOrgNo_Form").val(treeNode.organizationNo);
					}
				}
			});
}

/**
 * 电子印章类型格式化
 * 
 * @param value
 * @returns {String}
 */
function moulageTypeFmt(value) {
	return GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE, value);
}

/**
 * 电子印章业务操作类型
 * 
 * @param value
 * @returns {String}
 */
function applyTypeFmt(value) {
	return GPCache.get(GPCache.GSS, GPType.ESS_BIZ_TYPE, value);
}

/**
 * 电子印章日志操作类型
 * 
 * @param value
 * @returns {String}
 */
function OperTypeFmt(value) {
	return GPCache.get(GPCache.GSS, GPType.ESS_OPER_TYPE, value);
}

/**
 * 电子印章日志操作结果类型
 * 
 * @param value
 * @returns {String}
 */
function OperResultFmt(value) {
	return GPCache.get(GPCache.GSS, GPType.ESS_OPER_RESULT, value);
}
