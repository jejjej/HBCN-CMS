/**
 * 
 * 创建于:2016-9-13<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 电子印章(新章申请)
 * 
 * @author HuangKunping
 * @version 1.0.0
 */


/** sealModelSn-->sealModelInfo*/
var sealModelInfos = new Map();
$(function() {
	
	if(!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, top.ctx+'/activex/api/', 'run', 1, 1)){
		alert("初始化通用控件失败");
	}
	
	$("#searchBtn").closest("form").css("margin-bottom", "10px").css("margin-top", "10px");
	
	fetchSealModelInfos();
	
	initDialog();
	
	fetchSealApplyInfos();
	
	EssUI.moulageTypeList("#moulageTypeList", "<option value=\"\">全部</option>");
	
	$("#searchBtn").click(function(){
		$("#list").jqGrid("search", "#search");
	});
	
	$("#clearBtn").click(function(){
		$(this).closest("form")[0].reset();
	});
});

/**
 * 根据机构号获取印模列表信息
 */
function fetchSealModelInfos() {
	$.post(top.ctx + "/ess/moulage/elecSealMoulageAction!findSealModelInfoByCurrOrg.action", {}, function(data) {
		var options = "<option value=\"\"></option>";
		if (data.responseMessage.success) {
			for (var i = 0, len = data.sealModelInfos.length; i <len; i++) {
				var sealModelInfo = data.sealModelInfos[i];
				
				sealModelInfos.put(sealModelInfo.moulageNo, sealModelInfo);
				options += "<option value=\""+ sealModelInfo.moulageNo +"\" title=\""+ sealModelInfo.moulageName +"\">" + sealModelInfo.moulageName + "</option>";
			}
		} 
		$("#moulageSnSelect").html(options);
	});
}


function initDialog() {
	
	EssUI.sealColorList("#sealColor");
	
	$("#moulageSnSelect").change(function(){
		var sealModel = sealModelInfos.get($(this).val());
		if (sealModel) {
			$("#sealColor").removeAttr("disabled");
			$("#moulageType").val(sealModel.moulageType);
			$("#moulageTypeName").val(GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE, sealModel.moulageType));
			$("#moulageSn1,#moulageSn2").val(sealModel.moulageNo);
			$("#moulageName").val(sealModel.moulageName);
			$("#sealData").val(sealModel.moulageData);
			$("#bankName1,#bankName2").val(sealModel.bankName);
			$("#moulageOwnOrgName").val(sealModel.orgName);
			$("#moulageOwnOrgNo").val(sealModel.orgNo);
			$("#seal").showSeal(sealModel.moulageData);
			$("#strSealInfo").val(sealModel.elecSealJson);
			$("#strTextInfo").val(sealModel.modelEditableProp);
			$("#sealColor").val(0);
		} else {
			$("#applyInfo").validationEngine("hideAll");
            $("#applyInfo")[0].reset();
            $("#seal").showSeal();
            $("#sealColor").attr("disabled", "disabled");
		}
	});
	
	$("#sealColor").change(function(){
		if ($("#moulageSnSelect").val()) {
			var sealData = genSealData($(this).val(), $("#strSealInfo").val(), $("#strTextInfo").val());
			$("#seal").showSeal(sealData);
			$("#sealData").val(sealData);
		}
	});
	
	$("#applyInfo").dialog({
        autoOpen : false,
        height : 450,
        width : 730,
        resizable : false,
        modal : true,
        buttons : {
            "保存" : function() {
            	if($("#moulageSnSelect").val() == "") {
            		alert("请选择印模名称！");
            		return;
            	}
            	if (!$(this).validationEngine("validate")) {
                    return;
                 }
            	var _this = this;
            	$.post(top.ctx + "/ess/sealapply/elecSealApplyAction!save.action", 
            			$(this).serializeForm(), function(data) {
            		if (data.responseMessage.success) {
            			$.success("保存成功");
            			$(_this).dialog("close");
               		 	$("#list").jqGrid("search", "#search");
					} else {
						$.error("保存失败: " + data.responseMessage.message);
					}
            		 
            	});
            },
            "提交" : function() {
            	if($("#moulageSnSelect").val() == "") {
            		alert("请选择印模名称！");
            		return;
            	}
            	if (!$(this).validationEngine("validate")) {
                    return;
                 }
            	var _this = this;
            	$.post(top.ctx + "/ess/task/essBaseTaskAction_createTask.action?processDefKey=ESS_APPLY&&flowType=" + flowType, 
            			$(this).serializeForm(), function(data) {
        			$(_this).dialog("close");
           		 	$("#list").jqGrid("search", "#search");
            	});
            }
        },
        close : function() {
        	$(this).data("autoId", "");
            $("#applyInfo").validationEngine("hideAll");
            $("#applyInfo")[0].reset();
        },
        open : function() {
        	var _this = this;
        	var autoId = $(this).data("autoId");
        	if(autoId) {//更新
        		$.post(
        				top.ctx + "/ess/sealapply/elecSealApplyAction!find.action",
						{ "sealApplyInfo.autoId" : autoId },
						function(data) {
							if (data.responseMessage.success) {
								$(_this).fillForm(data);
								var sealModel = sealModelInfos.get(data.sealApplyInfo.moulageSn);
								$("#moulageOwnOrgName").val(sealModel.orgName);
								$("#moulageOwnOrgNo").val(sealModel.orgNo);
								$("#moulageTypeName").val(GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE, sealModel.moulageType));
								$("#seal").showSeal(data.sealApplyInfo.sealData);
							}
						}
				);
        	} else {//新建
        		$("#applyOrgName").val(top.loginPeopleInfo.orgName);
            	$("#applyPeopleName").val(top.loginPeopleInfo.peopleName);
        		$("#seal").showSeal();
        	}
        }
    });
	
	$("#newSealApply").click(function(){
		$("#applyInfo").dialog("open");
	});
	
	$("#applyInfo").validationEngine({
        showOnMouseOver:true,
        validationEventTrigger:"keyup blur",
        promptPosition : "centerRight",
        autoPositionUpdate : true,
        onValidationComplete: function() {}
    });
}
/**
 * 获取电子印章信息列表
 */
function fetchSealApplyInfos() {
	$("#list").jqGrid({
		caption : "申请列表",
		url : top.ctx + "/ess/sealapply/elecSealApplyAction!list.action",
		postData: {
			"queryBean.params.eq_nodeStatus" : nodeStatus,
			"queryBean.params.eq_applyPeopleCode" : top.loginPeopleInfo.peopleCode
		},
		rowList:[10, 15, 20, 30],
		rowNum:15,
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "印章名称", "印章编号", "印模名称", "印模编号", "印模类型", "印章颜色", "申请机构", "操作" ],
		colModel : [ {
			name : "sealName",
			index : "sealName",
			width : 200
		}, {
			name : "sealSn",
			index : "sealSn",
			width : 120
		}, {
			name : "moulageName",
			index : "moulageName",
			width : 140
		}, {
			name : "moulageSn",
			index : "moulageSn",
			width : 120
		}, {
			name : "moulageType",
			index : "moulageType",
			width : 120,
			formatter : function(value, options, rData) {
				return GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE, value);
			}
		}, {
			name : "sealColor",
			index : "sealColor",
			width : 60,
			formatter : function(value, options, rData) {
				return GPCache.get(GPCache.GSS, GPType.ESS_SEAL_COLOR, value);
			}
		}, {
			name : "applyOrgNo",
			index : "applyOrgNo",
			width : 160,
			formatter : function(value, options, rData) {
				return rData.applyOrgName + "(" + value + ")";
			}
		}, {
			name : "autoId",
			index : "autoId",
			width : 60,
			formatter : function(value, options, rData) {
				return addEditAndDelIcon(value, "editApplyInfo", "delApplyInfo");
			}
		} ],
		pager : "#pager"
	});
	$("#list").navGrid("#pager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
}

function addEditAndDelIcon(value, editFnName, delFnName) {
	var html = "";
	if (editFnName) {
		html += "<div class='icon_edit' onclick='"+ editFnName +"(\"" + value + "\")' title='编辑' style='float:left;'></div>";
	} 
	if (delFnName) {
		html += "<div class='icon_delete' onclick='"+ delFnName +"(\"" + value + "\")' title='删除' style='float:left;'></div>";
	}
	return html;
	
}

function editApplyInfo(autoId) {
	$("#applyInfo").data("autoId", autoId).dialog("open");
}


/**
 * 删除印章申请信息
 * @param autoId 主键sid
 */
function delApplyInfo(autoId) {
	$.del(top.ctx + "/ess/sealapply/elecSealApplyAction!delete.action", {"sealApplyInfo.autoId":autoId});
}

function genSealData(color, strSealInfo, strTextInfo) {
	OCX_Moulage.SetRunMode(1);
	OCX_Moulage.SetColor(color);
	OCX_Moulage.SetSealData(strSealInfo, strTextInfo);
	var imgType = GPCache.get(GPCache.GSS, GPType.ESS_SEAL_PROP, "fileType");
	if (!imgType) {
		imgType = ".png";
	}
	var strImagePath = tempDir + new Date().getTime() + imgType;
	OCX_Moulage.GeneratePic(strImagePath);
	return OCX_Base64.encodeBase64(strImagePath).data;
}
