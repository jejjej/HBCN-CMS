/**
 * 
 * 创建于:2016-9-21<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 电子印章停用信息查询js
 * 
 * @author LiuXiangyu
 * @version 1.0.0
 */


/** 根据命名空间及key获取wf缓存的值 */
function getParamFromWFCache(namespace, key) {
    try {
        //创建后台设置的命名空间
        var cacheSpace = top.WFCache.getCacheSpace(namespace);
        //获取该命名空间下的所有缓存值
        var cache = top.WFCache.getPageCache(cacheSpace);
        //根据key，获取该缓存下的某个值
        return cache.get(key);
    } catch (e) {
        return null;
    }
};

function sealApplyQuerypageInit() {
	
	$("#sealDisableModelInfoDetail").dialog({
		autoOpen : false,
		resizable : false,
		height : 350,
		width : 780,
		modal : true,
		buttons : {},
		close : function() {
			$("#sealDisableModelInfoForm").validationEngine("hideAll");
			$("#sealDisableModelInfoForm")[0].reset();
		}
	});
	
	$("#sealDisableOperInfoDetail").dialog({
		autoOpen : false,
		resizable : false,
		height : 360,
		width : 875,
		modal : true,
		buttons : {},
		close : function() {
			$("#sealDisableOperInfoForm").validationEngine("hideAll");
			$("#sealDisableOperInfoForm")[0].reset();
		}
	});
	
    var approvalBizContent = "";
    var objs = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE);
    for ( var key in objs) {
	approvalBizContent += "<option value='" + key + "'>" + objs[key] + "</option>";
    }
    approvalBizContent = "<option value=' '>全部</option>" + approvalBizContent;
    $("#moulageTypestr").html(approvalBizContent);
    
	var date1 = new Date();
    date1.setMonth(date1.getMonth()-1);
	$("#ge_applyTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
	
	$("#le_applyTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
    
	// 获取电子印章信息列表
	fetchSealDisableQueryList();

	$("#submitForm").click(function() {
		$("#sealDisableQuerylist").jqGrid("search", "#search");
	});

	$("#clearForm").click(function() {
		$("#search")[0].reset();
		var date1 = new Date();
	    date1.setMonth(date1.getMonth()-1);
		$("#ge_applyTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
		
		$("#le_applyTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
	});
	
	

}

/**
 * 获取电子印章信息列表
 */
function fetchSealDisableQueryList() {
	$("#sealDisableQuerylist").jqGrid({
		caption : "我的电子印章停用操作查询",
		url : top.ctx + "/ess/sealdisablequery/elecSealDisableQueryAction!list.action",
		postData:{
			"queryBean.params.eq_applyPeopleCode" :top.loginPeopleInfo.peopleCode
		},
		rowList:[10,15,20,30],
		rowNum:15,
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "印章编号", "印章类型",  "电子印章名称" , "申请机构名称" , "申请时间" ,"申请原因"
		             ,"下一处理人或机构","当前状态", "操作"],
		colModel : [ {
			name : "sealSn",
			index : "sealSn",
			width : 80
		}, {
			name : "moulageType",
			index : "moulageType",
			width : 100,
			formatter : moulageTypeFmt
		}, {
			name : "sealName",
			index : "sealName",
			width : 140
		}, {
			name : "applyOrgNo",
			index : "applyOrgNo",
			width : 140,
			formatter : function(value, options, rData) {
				return rData.applyOrgName + "(" + value + ")";
			}
		} , {
			name : "applyTime",
			index : "applyTime",
			width : 120
		} , {
			name : "applyReason",
			index : "applyReason",
			width : 140
		} ,  {
			name : "nextOperHandler",
			index : "nextOperHandler",
			sortable : false,
			width : 140,
			formatter : function(value, options, rData) {
				return Organization.getOrganizationByOrgNo(value).organizationNameAndNo;
			}
		}, {
			name : "nodeStatus",
			index : "nodeStatus",
			width : 140,
			formatter : function(value, options, rData) {
				return GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE,  value)+"("+GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE, rData.nodeStatus)+")";
			}
		} ,	{
			name : "autoId",
			index : "autoId",
			align : "center",
			sortable : false,
			width : 200,
			formatter : function(value, options, rData) {
				return "<input type='button'  value='详情' onclick='viewSealInfoDetail(\""+ value + "\",\"" + rData.sealSn+ "\")'/>" +
				"<input type='button' value='印模' onclick='viewSealModel(\"" + rData.sealSn
					+ "\")'  />";
			}
		}],
		pager : "#sealDisableQueryPager"
	});
}


/**
 * 获取电子印章印模
 */
function viewSealModel(sealSn) {
	$.ajax({
		type : "POST",
		url : top.ctx + "/ess/sealdisablequery/elecSealDisableQueryAction!querySealInfoDetailBySealNo.action",
		data : {
			"elecSealInfo.sealSn" : sealSn
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$("#sealtypestr").val(GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE, data.elecSealModelInfo.moulageType));
				$("#sealSnstr").val(data.elecSealInfo.sealSn);
				$("#sealNamestr").val(data.elecSealInfo.sealName);
				$("#lastEnableTimestr").val(data.elecSealInfo.lastEnableTime);
				$("#lastDisableTimestr").val(data.elecSealInfo.lastDisableTime);
				$("#destroyTimestr").val(data.elecSealInfo.destroyTime);
				$("#sealStatestr").val(GPCache.get(GPCache.ESS,GPType.ESS_SEAL_STATE,data.elecSealInfo.processStatus)+"("+GPCache.get(GPCache.ESS,GPType.ESS_SEAL_STATE, data.elecSealInfo.nodeStatus)+")");
				$("#sealOrgstr").val(data.elecSealModelInfo.orgName);
				$("#sealViews").showSeal(data.elecSealInfo.sealData);
				$("#sealDisableModelInfoDetail").dialog("open");
			} else {
				alert("失败:" + data.responseMessage.message);
			}
		}
	})
}

function resetForm() {
	$("#sealDisableModelInfoForm")[0].reset();
	$("#sealDisableModelInfoDetail").dialog("close");
}


/**
 * 获取电子印章申请操作详细信息
 */
var queryFlag =false;
function viewSealInfoDetail(refId,sealSn) {
	if (queryFlag) {
//		$("#sealDisableOperDetaillist").jqGrid("search", "#sealDisableOperInfoForm");
		$("#sealDisableOperDetaillist").jqGrid('setGridParam', { url : top.ctx
			+ "/ess/sealdisablequery/elecSealDisableQueryAction!listsealDisableDetail.action?refId=" + refId }).trigger("reloadGrid");
		 } else {
		 queryFlag = true;
	$("#sealDisableOperDetaillist").jqGrid({
		url : top.ctx + "/ess/sealdisablequery/elecSealDisableQueryAction!listsealDisableDetail.action?refId=" + refId,
		width : 850,
		height : 270,
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [   "操作人员", "操作人员机构", "操作时间", "业务类型" , "操作类型" ,"操作结果" , "操作备注"
		             ],
		colModel : [ {
			name : "operPeopleCode",
			index : "operPeopleCode",
			width : 80,
			formatter : function(value, options, rData) {
				return rData.operPeopleName + "(" + value + ")";
			}
		}, {
			name : "operOrgNo",
			index : "operOrgNo",
			width : 80,
			formatter : function(value, options, rData) {
				return rData.operOrgName + "(" + value + ")";
			}
		}, {
			name : "operTime",
			index : "operTime",
			width : 80
		}, {
			name : "bizType",
			index : "bizType",
			width : 80,
			formatter : applyTypeFmt
		} , {
			name : "operType",
			index : "operType",
			width : 80,
			formatter : OperTypeFmt
		} , {
			name : "operResult",
			index : "operResult",
			width : 80,
			formatter : OperResultFmt
		} , {
			name : "operMemo",
			index : "operMemo",
			width : 80
		}],
		pager:"#sealDisableOperDetailPager"
	});
		 }
	$('#sealDisableOperInfoDetail').dialog("option","title", "电子印章操作日志详情").dialog('open'); 
}

/**
 * 选择查询机构
 */
function choseOrgNoCondition() {
	$("##orgNoCondition").dialogOrgTree("radio",top.loginPeopleInfo.orgSid,false,null,null,
			function(event, treeId, treeNode) {
				if (treeNode) {
					$("#orgNoCondition").val(treeNode.organizationNo);
				}
			});
}


/**
 * 电子印章印油格式化
 * 
 * @param value
 * @returns {String}
 */
function sealColorFmt(value) {
	if (value == "0") {
		return "<font color='red'>红色</font>";
	} else if (value == "1") {
		return "<font color='black'>黑色</font>";
	} else if (value == "2") {
		return "<font color='blue'>蓝色</font>";
	} else {
		return "未知参数";
	}
}

/**
 * 电子印章类型格式化
 * 
 * @param value
 * @returns {String}
 */
function moulageTypeFmt(value) {
    var objs = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE);
    return GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE, value)
}

/**
 * 电子印章申请状态格式化
 * 
 * @param value
 * @returns {String}
 */
function elecDisableStateFmt(value) {
    var objs = GPCache.get(GPCache.ESS,GPType.ESS_SEAL_STATE);
    return GPCache.get(GPCache.ESS,GPType.ESS_SEAL_STATE, value);
}

/**
 * 电子印章业务操作类型
 * 
 * @param value
 * @returns {String}
 */
function applyTypeFmt(value) {
    var objs = GPCache.get(GPCache.GSS, GPType.ESS_BIZ_TYPE);
    return GPCache.get(GPCache.GSS, GPType.ESS_BIZ_TYPE, value)
}

/**
 * 电子印章日志操作类型
 * 
 * @param value
 * @returns {String}
 */
function OperTypeFmt(value) {
    var objs = GPCache.get(GPCache.GSS, GPType.ESS_OPER_TYPE);
    return GPCache.get(GPCache.GSS, GPType.ESS_OPER_TYPE, value)
}

/**
 * 电子印章日志操作结果类型
 * 
 * @param value
 * @returns {String}
 */
function OperResultFmt(value) {
    var objs = GPCache.get(GPCache.GSS, GPType.ESS_OPER_RESULT);
    return GPCache.get(GPCache.GSS, GPType.ESS_OPER_RESULT, value)
}