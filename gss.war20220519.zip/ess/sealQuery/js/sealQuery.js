/**
 * 
 * 创建于:2016-9-13<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 电子印章信息查询js
 * 
 * @author HuangKunping
 * @version 1.0.0
 */


/** 根据命名空间及key获取wf缓存的值 */
function getParamFromWFCache(namespace, key) {
    try {
        //创建后台设置的命名空间
        var cacheSpace = top.WFCache.getCacheSpace(namespace);
        //获取该命名空间下的所有缓存值
        var cache = top.WFCache.getPageCache(cacheSpace);
        //根据key，获取该缓存下的某个值
        return cache.get(key);
    } catch (e) {
        return null;
    }
};

function pageInit() {
	
	$("#sealInfoDetail").dialog({
		autoOpen : false,
		resizable : false,
		height : 350,
		width : 780,
		modal : true,
		buttons : {},
		close : function() {
			$("#sealInfoDetailForm").validationEngine("hideAll");
			$("#sealInfoDetailForm")[0].reset();
		}
	});
	
	var bizTypeContent = "";
	var objs = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE);
	for (var i = 0; i < objs.length; i++) {
		if(objs[i].paramKey>100){
    	bizTypeContent += "<option value='" + objs[i].paramKey + "'>" + objs[i].paramValue + "</option>";
		}
	}
	bizTypeContent = "<option value=' '>全部</option>" + bizTypeContent;
	$("#processStatus").html(bizTypeContent);
    
    
    var nodeStatusContent = "";
    var objs = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE);
	for (var i = 0; i < objs.length; i++) {
		if(objs[i].paramKey < 100){
			nodeStatusContent += "<option value='" + objs[i].paramKey + "'>" + objs[i].paramValue + "</option>";
		}
	}
    nodeStatusContent = "<option value=' '>全部</option>" + nodeStatusContent;
    $("#nodeStatus").html(nodeStatusContent);
    
	var date1 = new Date();
    date1.setMonth(date1.getMonth()-1);
	$("#ge_applyTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
	
	$("#le_applyTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
	
    $("#operOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
	$("#operOrgNo_Form").val(top.loginPeopleInfo.orgNo);
    
	// 获取电子印章信息列表
	fetchSealInfoList();

	$("#submitForm").click(function() {
		$("#list").jqGrid("search", "#search");
		$("#sealInfoDetail").dialog("close");
	});

	$("#clearForm").click(function() {
		$("#search")[0].reset();
		var date1 = new Date();
	    date1.setMonth(date1.getMonth()-1);
		$("#ge_applyTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
		
		$("#le_applyTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
		
	    $("#operOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
		$("#operOrgNo_Form").val(top.loginPeopleInfo.orgNo);
	});
	
	

}

function getNodeStatus(){
	var processStatus = $("#processStatus").val();
	if(processStatus == '201'){
	    var nodeStatusContent = "";
	    var objs = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE);
	    $("#nodeStatus").html("");
	    for ( var i = 0; i < objs.length; i++) {
	    if(objs[i].paramKey=='00'|| objs[i].paramKey=='01' || objs[i].paramKey=='02' || objs[i].paramKey=='03' || objs[i].paramKey=='04'){
	    	nodeStatusContent += "<option value='" + objs[i].paramKey + "'>" + objs[i].paramValue + "</option>";
	    }
	    }
	    nodeStatusContent = "<option value=' '>全部</option>" + nodeStatusContent;
	    $("#nodeStatus").html(nodeStatusContent);
	}else if(processStatus == '202'){
	    var nodeStatusContent = "";
	    var objs = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE);
	    $("#nodeStatus").html("");
	    for ( var i = 0; i < objs.length; i++) {
	    if(objs[i].paramKey=='05'){
	    	nodeStatusContent += "<option value='" + objs[i].paramKey + "'>" + objs[i].paramValue + "</option>";
	    }
	    }
	    nodeStatusContent = "<option value=' '>全部</option>" + nodeStatusContent;
	    $("#nodeStatus").html(nodeStatusContent);
	}else if(processStatus == '203'){
	    var nodeStatusContent = "";
	    var objs = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE);
	    $("#nodeStatus").html("");
	    for ( var i = 0; i < objs.length; i++) {
	    if(objs[i].paramKey=='06'){
	    	nodeStatusContent += "<option value='" + objs[i].paramKey + "'>" + objs[i].paramValue + "</option>";
	    }
	    }
	    nodeStatusContent = "<option value=' '>全部</option>" + nodeStatusContent;
	    $("#nodeStatus").html(nodeStatusContent);
	}else if(processStatus == '204'){
	    var nodeStatusContent = "";
	    var objs = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE);
	    $("#nodeStatus").html("");
	    for ( var i = 0; i < objs.length; i++) {
	    if(objs[i].paramKey=='07' || objs[i].paramKey=='08' || objs[i].paramKey=='09'){
	    	nodeStatusContent += "<option value='" + objs[i].paramKey + "'>" + objs[i].paramValue + "</option>";
	    }
	    }
	    nodeStatusContent = "<option value=' '>全部</option>" + nodeStatusContent;
	    $("#nodeStatus").html(nodeStatusContent);
	}else if(processStatus == '205'){
	    var nodeStatusContent = "";
	    var objs = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE);
	    $("#nodeStatus").html("");
	    for ( var i = 0; i < objs.length; i++) {
	    if(objs[i].paramKey=='10'){
	    	nodeStatusContent += "<option value='" + objs[i].paramKey + "'>" + objs[i].paramValue + "</option>";
	    }
	    }
	    nodeStatusContent = "<option value=' '>全部</option>" + nodeStatusContent;
	    $("#nodeStatus").html(nodeStatusContent);
	}else if(processStatus == '206'){
	    var nodeStatusContent = "";
	    var objs = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE);
	    $("#nodeStatus").html("");
	    for ( var i = 0; i < objs.length; i++) {
	    if(objs[i].paramKey=='11' || objs[i].paramKey=='12' || objs[i].paramKey=='13'){
	    	nodeStatusContent += "<option value='" + objs[i].paramKey + "'>" + objs[i].paramValue + "</option>";
	    }
	    }
	    nodeStatusContent = "<option value=' '>全部</option>" + nodeStatusContent;
	    $("#nodeStatus").html(nodeStatusContent);
	}else if(processStatus == '207'){
	    var nodeStatusContent = "";
	    var objs = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE);
	    $("#nodeStatus").html("");
	    for ( var i = 0; i < objs.length; i++) {
	    if(objs[i].paramKey=='14' || objs[i].paramKey=='15' || objs[i].paramKey=='16'){
	    	nodeStatusContent += "<option value='" + objs[i].paramKey + "'>" + objs[i].paramValue + "</option>";
	    }
	    }
	    nodeStatusContent = "<option value=' '>全部</option>" + nodeStatusContent;
	    $("#nodeStatus").html(nodeStatusContent);
	}else if(processStatus == '208'){
	    var nodeStatusContent = "";
	    var objs = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE);
	    $("#nodeStatus").html("");
	    for ( var i = 0; i < objs.length; i++) {
	    if(objs[i].paramKey=='17'){
	    	nodeStatusContent += "<option value='" + objs[i].paramKey + "'>" + objs[i].paramValue + "</option>";
	    }
	    }
	    nodeStatusContent = "<option value=' '>全部</option>" + nodeStatusContent;
	    $("#nodeStatus").html(nodeStatusContent);
	}else if(processStatus == ' '){
	    var nodeStatusContent = "";
	    var objs = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE);
	    for ( var i = 0; i < objs.length; i++) {
	    if(objs[i].paramKey<100){
	    	nodeStatusContent += "<option value='" + objs[i].paramKey + "'>" + objs[i].paramValue + "</option>";
	    }
	    }
	    nodeStatusContent = "<option value=' '>全部</option>" + nodeStatusContent;
	    $("#nodeStatus").html(nodeStatusContent);
	}
	
}

/**
 * 获取电子印章信息列表
 */
function fetchSealInfoList() {
	$("#list").jqGrid({
		caption : "电子印章信息列表",
		url : top.ctx + "/ess/sealquery/elecSealInfoAction!list.action",
		rowList:[10,15,20,30],
		rowNum:10,
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "印章编号",  "行名", "印章名称" ,"所属机构","印章颜色", "印章状态","申请时间" , "操作"],
		colModel : [ {
			name : "sealSn",
			index : "sealSn",
			width : 120
		}, {
			name : "bankName",
			index : "bankName",
			width : 120
		}, {
			name : "sealName",
			index : "sealName",
			width : 160
		}, {
			name : "ownOrgNo",
			index : "ownOrgNo",
			width : 160,
			formatter : function(value, options, rData) {
				return Organization.getOrganizationByOrgNo(value).organizationNameAndNo;
			}
		} ,  {
			name : "sealColor",
			index : "sealColor",
			width : 120,
			formatter : function(value, options, rData) {
				return GPCache.get(GPCache.GSS, GPType.ESS_SEAL_COLOR, value);
			}
		}, {
			name : "processStatus",
			index : "processStatus",
			width : 120,
			formatter : function(value, options, rData) {
				return GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE, value)+"("+GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE, rData.nodeStatus)+")";
			}
		},{
			name : "applyTime",
			index : "applyTime",
			width : 100
		} ,	{
			name : "autoId",
			index : "autoId",
			align : "center",
			sortable : false,
			formatter : function(value, options, rData) {
				return "<input type='button'  value='详情' onclick='openSealInfoDetail(\""+ value + "\")'/>";
			}
		}],
		pager : "#pager"
	});
}

/**
 * 获取电子印章详细信息
 */
function openSealInfoDetail(autoId) {
	$.ajax({
		type : "POST",
		url : top.ctx + "/ess/sealquery/elecSealInfoAction!querySealInfoDetail.action",
		data : {
			"elecSealInfo.autoId" : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$("#sealtypestr").val(GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE, data.elecSealModelInfo.moulageType));
				$("#sealSnstr").val(data.elecSealInfo.sealSn);
				$("#sealNamestr").val(data.elecSealInfo.sealName);
				$("#lastEnableTimestr").val(data.elecSealInfo.lastEnableTime);
				$("#lastDisableTimestr").val(data.elecSealInfo.lastDisableTime);
				$("#destroyTimestr").val(data.elecSealInfo.destroyTime);
				$("#sealStatestr").val(GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE, data.elecSealInfo.processStatus)+"("+GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE, data.elecSealInfo.nodeStatus)+")");
				$("#sealOrgstr").val(data.elecSealModelInfo.orgName);
				$("#sealViews").showSeal(data.elecSealInfo.sealData);
				$("#sealInfoDetail").dialog("open");
			} else {
				alert("失败:" + data.responseMessage.message);
			}
		}
	})
}

/**
 * 选择机构
 */
function choseOrganizationItem() {
	$("#operOrgNo_Item").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, {
		filterOrgType : "1,2,6,7"
	}, null, function(event, treeId, treeNode) {
		if (treeNode) {
			if (treeNode) {
				$("#operOrgNo_Item").val(treeNode.organizationName + "(" + treeNode.organizationNo + ")");
				$("#operOrgNo_Form").val(treeNode.organizationNo);
			}
		}
	});
}

function resetForm() {
	$("#sealInfoDetailForm")[0].reset();
	$("#sealInfoDetail").dialog("close");
}

/**
 * 电子印章印油格式化
 * 
 * @param value
 * @returns {String}
 */
function sealColorFmt(value) {
	if (value == "0") {
		return "<font color='red'>红色</font>";
	} else if (value == "1") {
		return "<font color='black'>黑色</font>";
	} else if (value == "2") {
		return "<font color='blue'>蓝色</font>";
	} else {
		return "未知参数";
	}
}

/**
 * 电子印章状态
 */
function processStatusFmt(value) {
    var objs = GPCache.get(GPCache.ESS,GPType.ESS_SEAL_STATE);
    return GPCache.get(GPCache.ESS,GPType.ESS_SEAL_STATE, value);
}

/**
 * 电子印章类型格式化
 * 
 * @param value
 * @returns {String}
 */
function moulageTypeFmt(value) {
    var objs = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE);
    return GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE, value);
}
