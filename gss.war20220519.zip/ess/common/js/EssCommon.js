﻿var FN_JQGRID = $.fn.jqGrid;

var SEALINFO_COLNAMES = ["印章名称", "印章编号", "印章颜色", "银行名称", "所属机构", "印章状态" ];
var SEALINFO_COLMODEL = [{
	name : "sealName",
	index : "sealName",
	width : 120
}, {
	name : "sealSn",
	index : "sealSn",
	width : 120
}, {
	name : "sealColor",
	index : "sealColor",
	width : 120,
	formatter : function(value, options, rData) {
		return GPCache.get(GPCache.GSS, GPType.ESS_SEAL_COLOR, value);
	}
}, {
	name : "bankName",
	index : "bankName",
	width : 120
}, {
	name : "ownOrgNo",
	index : "ownOrgNo",
	width : 160,
	formatter : function(value, options, rData) {
		return Organization.getOrganizationByOrgNo(value).organizationNameAndNo;
	}
}, {
	name : "processStatus",
	index : "processStatus",
	width : 100,
	formatter : function(value, options, rData) {
		return GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE, value);
	}
} ];


var SEALAPPLY_COLNAMES = ["印章名称", "印章编号", "印模类型", "印章颜色", "申请机构", "申请人", "申请时间", "印章状态" ];
var SEALAPPLY_COLMODEL = [{
	name : "sealName",
	index : "sealName",
	width : 150
}, {
	name : "sealSn",
	index : "sealSn",
	width : 110
}, {
	name : "MOUGALE_TYPE",
	index : "MOUGALE_TYPE",
	width : 80,
	formatter : function(value, options, rData) {
		return GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE, rData.extMap.MOULAGE_TYPE);
	}
}, {
	name : "sealColor",
	index : "sealColor",
	width : 70,
	formatter : function(value, options, rData) {
		return GPCache.get(GPCache.GSS, GPType.ESS_SEAL_COLOR, value);
	}
}, {
	name : "APPLY_ORGNO",
	index : "APPLY_ORGNO",
	width : 150,
	formatter : function(value, options, rData) {
		return Organization.getOrganizationByOrgNo(rData.extMap.APPLY_ORGNO).organizationNameAndNo;
	}
},{
	name : "APPLY_PEOPLECODE",
	index : "APPLY_PEOPLECODE",
	width : 140,
	formatter : function(value, options, rData) {
		return Personnel.getPersonnelByPersonnelCode(rData.extMap.APPLY_PEOPLECODE).personnelNameAndCode;
	}
},{
	name : "APPLY_TIME",
	index : "APPLY_TIME",
	width : 100,
	formatter : function(value, options, rData) {
		return rData.extMap.APPLY_TIME;
	}
},{
	name : "processStatus",
	index : "processStatus",
	width : 80,
	formatter : function(value, options, rData) {
    return GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE, value)+"("+GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE, rData.nodeStatus)+")";

	}
}];



$.fn.jqGrid = function(pin) {
	if (typeof pin == 'string') {
		var fn = $.jgrid.getAccessor(FN_JQGRID, pin);
		if (!fn) {
			throw ("jqGrid - No such method: " + pin);
		}
		var args = $.makeArray(arguments).slice(1);
		return fn.apply(this, args);
	}

	var colNames = null, colModel = null;
	if (pin.colType == "sealInfo") {
		colNames = SEALINFO_COLNAMES;
		colModel = SEALINFO_COLMODEL;
	} else if (pin.colType == "sealApply") {
		colNames = SEALAPPLY_COLNAMES;
		colModel = SEALAPPLY_COLMODEL;
	}

	if (colNames) {
		for ( var i = colNames.length - 1; i >= 0; i--) {
			pin.colNames.splice(0, 0, colNames[i]);
		}
	}
	if (colModel) {
		for ( var i = colModel.length - 1; i >= 0; i--) {
			pin.colModel.splice(0, 0, colModel[i]);
		}
	}

	var ret = FN_JQGRID.call(this, pin);

	// this.navGrid(pin.pager);

	return ret;
};

$.fn.getTask = function(url,param, callback) {
	$(this).data("taskSealSn", null);
	$(this).validationEngine("hideAll");
	$(this).dialog("open");
	var _this = this;
	if ("undefined" == url || "" == url || null == url || url.length <= 0) {
		url = $.getContextPath() + "/ess/task/essBaseTaskAction_gainTask.action";
		return;
	}
	$.post(url, param, function(data) {
		if (data.responseMessage.success) {
			var bizInfo = data.bizInfo;
			if (bizInfo == null) {
				alert("此任务正在处理或者已处理");
				$(_this).dialog("close");
				return;
			}
			$(_this).data("taskSealSn", param.sealSn);
			$(_this).data("autoId", param["bizInfo.autoId"]);
			callback(data);
		} else {
			$.error("读取数据出错: " + data.responseMessage.message);
		}
	});
};

$.fn.getTaskList = function(param) {
	var defaultparam = {
		caption : "",
		url : "",
		urlParam : "",
		operName : "操作",
		pager : "#pager",
		colType : param.colType || "sealInfo",
		operMethod : [],
		result : ""
	};
	param = $.extend(defaultparam, param);
	for ( var i = 0; i < param.operMethod.length; i++) {
		var defaultopermethod = {
			name : "",
			method : "",
			icon : "edit"
		};
		param.operMethod[i] = $.extend(defaultopermethod, param.operMethod[i]);
	}
	var jqGridParam = {
		caption : param.caption,
		url : param.url,
		postData : param.urlParam,
		rowList:[10, 15, 20, 30],
		rowNum:15,
		rownumbers : true,
		multiselect : param.multiselect,
		colType : param.colType,
		pager : param.pager,
		colNames : [],
		colModel : []
	};

	if (param.operMethod.length > 0) {
		jqGridParam.colNames.push(param.operName);
		jqGridParam.colModel.push({
			name : "sealSn",
			index : "sealSn",
			width : 80,
			align : "center",
			formatter : function(value, options, rData) {
				var html = "<center><div>";
				$.each(param.operMethod, function(i, d) {
					if (d.method) {
						html += "<div class='icon_" + d.icon + "' onclick='"
								+ d.method + "(\"" + value + "\", \""
								+ rData.node + "\", \"" + options.rowId
								+ "\",\"" + param.result + "\", \"" + d.name
								+ "\", \"" + param.fetchType + "\", \"" +  rData.autoId + "\" )' title='"
								+ d.name + "' style='float:left;'></div>";
					} else if (d.form) {
						html += "<div class='icon_" + d.icon
								+ "' onclick='FN_GETTASKLIST_SHOWFORM(\""
								+ d.form + "\", \"" + rData.autoId + "\", \""
								+ value + "\", \"" + rData.node + "\", \""
								+ d.name + "\", \"" + param.result + "\", \""
								+ param.fetchType + "\", \"" + d.url
								+ "\")' title='" + d.name
								+ "' style='float:left;'></div>";
					} else if (d.url) {

					}
				});
				html += "</div></center>";
				return html;
			}
		});
	}

	$(this).jqGrid(jqGridParam);
	var nav = $.extend({
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	}, param.nav);
	$(this).navGrid(param.pager, nav);

	$(":submit,:button").button();
	$("body").css("visibility", "visible");
};

function FN_GETTASKLIST_SHOWFORM(form, autoId, sealSn, node, title, result,
		fetchType, url) {
	$(form).fillTask(autoId, sealSn, node, title, result, fetchType, "", url);
}

$.fn.winform = function(param, listId) {
	listId = listId || "#list";

	$(this).each(function() {
		var dialogParam = preform(param, listId, this);
	});
};

$.fn.form = function(param, listId) {
	listId = listId || "#list";

	$(this).each(function() {
		var dialogParam = preform(param, listId, this);
		$(this).dialog(dialogParam);
	});

};

function preform(param, listId, form) {
	$(form).data("param", param);
	var dialogParam = {
		autoOpen : false,
		height : $(form).attr("height") || param.height || 490,
		width : $(form).attr("width") || param.width || 730,
		beforeclose : param.beforeclose,
		open : param.open,
		modal : true,
		buttons : {},
		defaultclose : function() {
			if ($(form).data("taskSealSn")) {
				$.post($.getContextPath() + "/ess/task/essBaseTaskAction_unlockTask.action", {
					"bizInfo.autoId" : $(form).data("autoId")
				}, function(data) {
				});
			}
			$(form).validationEngine("hideAll");
			$(form)[0].reset();
			$(form).find("input[type=hidden]").val("");
		}
	};

	dialogParam.close = function() {
		if (param.close) {
			param.close();
		}
		dialogParam.defaultclose();
	};
	$.each(param.submit || [], function(i, d) {
		dialogParam.buttons[d.name] = function(event) {
			if (d.beforeSubmit) {
				if (d.beforeSubmit() == false) {
					return;
				}
			}
			smssubmit(event, d.url, form, listId, param.callback, d.data);
		};
	});
	if (param.check) {
		dialogParam.buttons["同意"] = function(event) {
			$("#checkResult").val("yes");
			smssubmit(event, param.check, form, listId, param.callback);
		};
		dialogParam.buttons["拒绝"] = function(event) {
			if ($.trim($("#checkOption").val()) == "") {
				alert("审核意见不能为空！");
				$("#checkOption").focus();
				return;
			}
			$("#checkResult").val("no");
			smssubmit(event, param.check, form, listId, param.callback);
		};
	}
	if (param.batchCheck) {
		dialogParam.buttons["同意"] = function(event) {
			$("#batchCheckResult").val("yes");
			smssubmit(event, param.batchCheck, form, listId, param.callback);
		};
		dialogParam.buttons["拒绝"] = function(event) {
			if ($.trim($("#batchCheckOption").val()) == "") {
				alert("审核意见不能为空！");
				$("#batchCheckOption").focus();
				return;
			}
			$("#batchCheckResult").val("no");
			smssubmit(event, param.batchCheck, form, listId, param.callback);
		};
	}
	if (param.recheck) {
		dialogParam.buttons["同意"] = function(event) {
			$("#reCheckResult").val("yes");
			smssubmit(event, param.recheck, form, listId, param.callback);
		};
		dialogParam.buttons["拒绝"] = function(event) {
			if ($.trim($("#reCheckOption").val()) == "") {
				alert("复核意见不能为空！");
				$("#reCheckOption").focus();
				return;
			}
			$("#reCheckResult").val("no");
			smssubmit(event, param.recheck, form, listId, param.callback);
		};
	}
	if (param.batchRecheck) {
		dialogParam.buttons["同意"] = function(event) {
			$("#batchRecheckResult").val("yes");
			smssubmit(event, param.batchRecheck, form, listId, param.callback);
		};
		dialogParam.buttons["拒绝"] = function(event) {
			if ($.trim($("#batchRecheckOption").val()) == "") {
				alert("复核意见不能为空！");
				$("#batchRecheckOption").focus();
				return;
			}
			$("#batchRecheckResult").val("no");
			smssubmit(event, param.batchRecheck, form, listId, param.callback);
		};
	}
	//增加初审
	if (param.initcheck) {
		dialogParam.buttons["同意"] = function(event) {
			$("#initCheckResult").val("yes");
			smssubmit(event, param.initcheck, form, listId, param.callback);
		};
		dialogParam.buttons["拒绝"] = function(event) {
			if ($.trim($("#initCheckOption").val()) == "") {
				alert("初审意见不能为空！");
				$("#initCheckOption").focus();
				return;
			}
			$("#initCheckResult").val("no");
			smssubmit(event, param.initcheck, form, listId, param.callback);
		};
	}
	if (param.ok) {
		dialogParam.buttons["确定"] = function(event) {
			if($.trim($("#applyReason").val()) == ""){
				alert("申请意见不能为空");
				$("#applyReason").focus();
				return;
			}
			$("#checkResult").val("yes");
			smssubmit(event, param.ok, form, listId, param.callback);
		};
		dialogParam.buttons["取消"] = function(event) {
			$(form).dialog("close");
			if (param.callback) {
				param.callback();
			}
		};
	}
	if (param.cancel) {
		dialogParam.buttons["取消"] = function(event) {
			$(form).dialog("close");
			if (param.callback) {
				param.callback();
			}
		};
	}
	if (param.buttons) {
		$.extend(true, dialogParam.buttons, param.buttons);
	}

	$(form).data("seal", param.seal);

	$(form).validationEngine({
		showOnMouseOver : true,
		validationEventTrigger : "blur",
		promptPosition : "topLeft",
		showArrow : true,
		autoPositionUpdate : true,
		onValidationComplete : function() {
			return;
		}
	});

	return dialogParam;

}

function smssubmit(event, url, form, listId, callback, data) {
	var btnName = $(event.target).find("span").text();
	var verifyMethods = "";
	if ("同意" == btnName || "拒绝" == btnName || "确定" == btnName
			|| "同意收妥" == btnName) {
		var sealId = "#seal";
		if ($(form).data("param")
				&& ($(form).data("param").batchRecheck
						|| $(form).data("param").batchCheck || $(form).data(
						"param").needBatchVerify)) {
			sealId = "#batchSeal";
		}
	}
	verifyMethods = verifyMethods.substring(0, verifyMethods.length - 1);

	if (!$(form).validationEngine("validate")) {
		return;
	}
	data = data ? data() : $(form).serializeForm();
	data["verifyMethods"] = verifyMethods;

	if ($(form).data("param") && $(form).data("param").beforeSubmit) {
		if (!$(form).data("param").beforeSubmit(data)) {
			return;
		}
	}

	$(event.target).post(
			url,
			data,
			function(data) {
				if (data.responseMessage.success) {
					var message = "";
					try {
						var _data = eval("("+ data.responseMessage.data + ")");
						if (_data && _data.hasOwnProperty("processStatus") && _data.hasOwnProperty("nodeStatus")) {
							var processStatus = _data["processStatus"];
							var nodeStatus = _data["nodeStatus"];
							if(processStatus == "202" && nodeStatus == "05"//启用
								//|| processStatus == "203" && nodeStatus == "06"//作废
								|| processStatus == "205" && nodeStatus == "10"//停用
									|| processStatus == "208" && nodeStatus == "17") {//销毁
								message = "：此电子印章已成功" + GPCache.get(GPCache.ESS, GPType.ESS_SEAL_STATE, nodeStatus);
							}
						}
					} catch (e) {
					}
					$.success("操作成功" + message);					
					$(listId).trigger("reloadGrid");
					$(form).dialog("close");
					if (callback) {
						callback(data);
					}
				} else {
					$.error("操作失败: " + data.responseMessage.message);
				}
			});
}

$.del = function(url, param, callback) {
	if (confirm("是否要删除?")) {
		$.post(url, param, function(data) {
			if (data.responseMessage.success) {
				$.success("删除成功");
				$("#list").trigger("reloadGrid");
				if (callback) {
					callback(data);
				}
			} else {
				$.error("删除失败: " + data.responseMessage.message);
			}
		});
	}
};

$.fn.fillTask = function(autoId, sealSn, node, title, result, fetchType, lock,
		url) {
	var _this = this;
	$(_this).dialog("open");
	if (title) {
		$(_this).dialog("option", "title", title);
	}
	$(_this).getTask(url,{
		"bizInfo.autoId" : autoId,
		"sealSn" : sealSn,
		"node" : node,
		"query" : result,
		"lock" : lock},
		function(data) {
			if ($("#seal").length > 0 && data.bizInfo) {
				$.post($.getContextPath() + "/ess/moulage/elecSealMoulageAction!findSealModelInfoByMoulageNo.action", {
					"sealModelInfo.moulageNo" : data.bizInfo.moulageSn
				}, function(response) {
//					$("#seal").showSeal(response.sealModelInfo.moulageData);
					$("#seal").showSeal(data.bizInfo.sealData);
					var moulageTypeName = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE, response.sealModelInfo.moulageType);
					response.sealModelInfo.moulageTypeName = moulageTypeName;
					data.bizInfo.moulageTypeName = moulageTypeName;
					$(_this).fillForm({
						bizInfo : data.bizInfo,
						sealModelInfo:response.sealModelInfo,
						checkInfo : data.checkInfo,
						sealApplyInfo : data.sealApplyInfo,
						sealDisableInfo : data.sealDisableInfo,
						sealEnableInfo : data.sealEnableInfo,
						sealDestroyInfo : data.sealDestroyInfo
					});
					if ($(_this).data("param")
							&& $(_this).data("param").loadComplete) {
						$(_this).data("param").loadComplete(data);
					}
				});
			}
	});
};

$(function() {
	$(":submit,:button").button();
});
