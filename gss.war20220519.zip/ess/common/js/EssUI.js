/**
 * 
 * 创建于:2016-9-20<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 电子印章相关的UI
 * 依赖于jquery/GssGlobalParamCache.js
 * 
 * @author HuangKunping
 * @version 1.0.0
 */

;(function(root, factory) {
	if (typeof define === 'function' && define.amd) {
		define(['exports'], factory);
	} else if (typeof exports === 'object') {
		factory(exports);
	} else {
		factory(root.EssUI = {});
	}
})(this, function(EssUI) {
	"use strict";
	
	var self = EssUI;
	
	EssUI.sealColorList = function(id, defaultOption) {
		var options = "";
		if (defaultOption) {
			options = defaultOption;
		}
		var sealColors = GPCache.get(GPCache.GSS, GPType.ESS_SEAL_COLOR);
		for (var i = 0; i < sealColors.length; i++) {
			if (sealColors[i]) {
				options += ("<option value=\"" + sealColors[i].paramKey + "\">" + sealColors[i].paramValue + "</option>");
			}
		}
		$(id).html(options);
	}
	
	EssUI.moulageTypeList = function(id, defaultOption) {
		var options = "";
		if (defaultOption) {
			options = defaultOption;
		}
		var moulageTypes = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE);
		for (var o in moulageTypes) {
			options += ("<option value=\"" + o + "\">" + moulageTypes[o] + "</option>");
		}
//		for (var i = 0; i < moulageTypes.length; i++) {
//			if (moulageTypes[i]) {
//				options += ("<option value=\"" + moulageTypes[i].paramKey + "\">" + moulageTypes[i].paramValue + "</option>");
//			}
//		}
		$(id).html(options);
	}
	
	EssUI.sealShapeList = function(id, defaultOption) {
		var options = "";
		if (defaultOption) {
			options = defaultOption;
		}
		var sealShapes = GPCache.get(GPCache.GSS, GPType.ESS_SEAL_SHAPE);
		for (var i = 0; i < sealShapes.length; i++) {
			if (sealShapes[i]) {
				options += ("<option value=\"" + sealShapes[i].paramKey + "\">" + sealShapes[i].paramValue + "</option>");
			}
		}
		$(id).html(options);
	}
	
	//用印模式与凭证类型
	EssUI.sealModeList = function(id, defaultOption) {
		var options = "";
		if (defaultOption) {
			options = defaultOption;
		}
		var sealModes = GPCache.get(GPCache.GSS, GPType.ESS_SEAL_MODE);
		for (var i = 0; i < sealModes.length; i++) {
			if (sealModes[i]) {
				options += ("<option value=\"" + sealModes[i].paramKey + "\">" + sealModes[i].paramValue + "</option>");
			}
		}
		$(id).html(options);
	}
	
	EssUI.billTypeList = function(id, defaultOption) {
		var options = "";
		if (defaultOption) {
			options = defaultOption;
		}
		var billTypes = GPCache.get(GPCache.GSS, GPType.ESS_BILL_TYPE);
		for (var i = 0; i < billTypes.length; i++) {
			if (billTypes[i]) {
				options += ("<option value=\"" + billTypes[i].paramKey + "\">" + billTypes[i].paramValue + "</option>");
			}
		}
		$(id).html(options);
	}
	
	//用印类型与用印状态
	EssUI.sealTypeList = function(id, defaultOption) {
		var options = "";
		if (defaultOption) {
			options = defaultOption;
		}
		var sealTypes = GPCache.get(GPCache.GSS, GPType.ESS_USE_TYPE);
		for (var i = 0; i < sealTypes.length; i++) {
			if (sealTypes[i]) {
				options += ("<option value=\"" + sealTypes[i].paramKey + "\">" + sealTypes[i].paramValue + "</option>");
			}
		}
		$(id).html(options);
	}
	
	EssUI.sealStateList = function(id, defaultOption) {
		var options = "";
		if (defaultOption) {
			options = defaultOption;
		}
		var sealStates = GPCache.get(GPCache.GSS, GPType.ESS_USE_STATE);
		for (var i = 0; i < sealStates.length; i++) {
			if (sealStates[i]) {
				options += ("<option value=\"" + sealStates[i].paramKey + "\">" + sealStates[i].paramValue + "</option>");
			}
		}
		$(id).html(options);
	}
	
});
