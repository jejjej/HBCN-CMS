﻿/**
 * 创建于:2016-9-20<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * GSS参数缓存服务
 * 
 * @author HuangKunping
 * @version 1.0.0
 */

/** 默认临时目录 */
var tempDir = "C:/yzjgss/temp/";
/** 默认生成电子印章图片文件类型*/
var sealImgType = ".png";

(function($) {
	
	function doShowSeal(img, redSealPath) {
		var image = img.find("img");
		var vimage = null;
		if(!top.IE) {
			var sealData = OCX_Base64.encodeBase64(redSealPath).data
			//IE8下，base64长度大于32KB采用本地路径显示，不通过base64去显示
			if(navigator.userAgent.indexOf("MSIE 8.0") > 0 && sealData.length > 32740) {
				image.attr("src", redSealPath + "?_t=" + new Date().getTime());
			} else {
				image.attr("src", "data:image/jpeg;base64," + sealData).css("visibility", "visible");
			}
		} else {
			image.attr("src", redSealPath + "?_t=" + new Date().getTime());
		}
		if(top.IE6) {
			setTimeout(function() {
				vimage = img.find("div[name=vimage]");
				if(vimage.length == 0) {
					document.namespaces.add("v", 'urn:schemas-microsoft-com:vml');
					vimage = $("<div name='vimage'></div>");
					img.prepend(vimage);
				}
				var width = image.width();
				var height = image.height();
				vimage[0].innerHTML = '<v:image src="file://' + redSealPath + '" class="vml" style="display: block; width: ' + width + 'px; height: ' + height + 'px; " />';
				image.css("display", "none");
			}, 1);
		}
		img.closest("form").one("reset", function() {
			if(vimage) {
				vimage[0].innerHTML = "";
			}
		});
	}
	
	// 展示
	$.fn.showSeal = function(sealData) {
		var img, imgDiv, sealDataInput;
		$(this).html("");
		img = $('<div style="text-align: center; display: none; cursor: pointer;" title="点击查看大图"><img height="160"></img></div>');
		imgDiv = $('<div style="height: 162px; border: 1px solid white; background-color: white; width: 450px; float: left;"></div>');
		sealDataInput = $('<input id="sealData" type="hidden"  name="sealInfo.sealData,bizInfo.sealData,sealApplyInfo.sealData,sealDestroyInfo.sealData"/>');
		$(this).closest("td").css("height", "165px");
		imgDiv.append(img);
		$(this).append(imgDiv).append(sealDataInput);
		img.bind("click", pri_showBigSeal);
		$(this).data("img", img).data("imgDiv",imgDiv).data("sealDataInput",sealDataInput);
		imgDiv.css("border-color", "white");
		img.css("display", "none");
		if (sealData) {
			var tp = tempDir + new Date().getTime() + sealImgType;
			sealDataInput.val(sealData);
			OCX_Base64.decodeBase64(sealData, tp);
			doShowSeal(img, tp);
			img.css("display", "");
		}
	};
	
	
	function pri_showBigSeal(e) {
		var win = window.open("", "", "width=800,height=600,location=0,top=50,left=100");
		win.document.write("<html><head><title>查看印模</title></head><body><img src='" + e.target.src + "' /></body></html>");
	}
	
})(jQuery);

$(function(){
	if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, top.ctx+'/activex/api/', 'run', 1, 1)) {
		alert("初始化通用控件失败");
		return;
	}
	if (!ocxObject.initOcx(ocxObject.OCX_Base64, document.body, top.ctx+'/activex/api/', 'run', 1, 1)) {
		alert("初始化加密控件失败");
		return;
	}
	tempDir = OCX_Tools.readIni(top.yzjgssRootPath + "/yzjgss/config/gss.ini", "CONFIG", "ESS_TEMP_DIR", "C:/yzjgss/temp/").data;
	if(tempDir) {
		WTFileUtil.createMultiLevelFolder(tempDir);
	}
	var imgType = GPCache.get(GPCache.GSS, GPType.ESS_SEAL_PROP, "fileType");
	if (imgType) {
		sealImgType = imgType;
	}
	
});

$(window).unload(function(){
	if(tempDir) {
		var filePaths = WTFileUtil.listFolder(tempDir);
		for (var i = 0; i < filePaths.length; i++) {
			WTFileUtil.deleteFile(filePaths[i].Path);
		}
	}
});