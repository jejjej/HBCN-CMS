/**
 * 创建于:2016-11-14<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 一体化打印（新）
 * 
 * @author listen
 * @version 1.0.0
 */


var flagTradeCode = false;
// new
// 业务要素列表
var bizElementInfo;
// 电子印章保存路径
var sealPath = "C:\\yzjgss\\resources\\3x\\img\\integratedSeal.jpg";
// td数量
var tdNum = 0;
// 用印类型
var sealType;

var tradeInfos = {};	
/**
 * 初始化
 */
$(function() {
	var path = ctx + "/activex/api/";

	if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, path, "run")) {
		alert("通用控件初始化失败");
	}
	if (!ocxObject.initOcx(ocxObject.OCX_Print, document.body, path, "run")) {
		alert("模板打印控件初始化失败");
	}
	if (!ocxObject.initOcx(ocxObject.OCX_Base64, document.body, path, "run")) {
		alert("解码控件初始化失败");
	}
	
	$("#printBtn").attr("disable", true);
	$(".bill").hide();
	
	// 新建表单提交数据验证
	$("#form").validationEngine({
		showOnMouseOver : true,
		validationEventTrigger : "keyup blur",
		promptPosition : "centerRight",
		autoPositionUpdate : true,
		onValidationComplete : function() {
		}
	});

	$("#printBtn").click(function(event) {
		event.preventDefault();
		if ($("#accNo").val() == ""&& $("#cardNo").val() == "") {
			show("账号与卡号不能都为空");
			$("#printBtn").val("");
			return;
		}
		if (!$("#form").validationEngine("validate")|| !flagTradeCode) {
			$("#printBtn").val("");
			return;
		}
		if (!flagTradeCode) {
			$("#printBtn").val("");
			return;
		}
		
		printElecSeal();
	});

	$("#resetBtn").click(function(event) {
		event.preventDefault();
		reset();
	});

	$("#tradeCode").blur(function() {
		var tradeCode = $("#tradeCode").val();
		var reg = /^[0-9](\d{3})$/;
		if (reg.test(tradeCode)) {
			createBillSelect(tradeCode);
			if ($(".bill").is(':hidden')) {
				queryTradeCode();
			}
		}

	});

	

	// 初始化表单
	initPrintElecSealForm();
	
	if (!initTradeInfo()) {
		$("#printBtn").attr("disable", false);
	}
	
	$("#billCodeId").change(function(){
		var val = $(this).val();
		if (val) {
			destroyTr();
			queryTradeCode();
		} else {
			clearData();
		}
	});
});


function createBillSelect(tradeCode) {
	var billInfos = tradeInfos[tradeCode];
	if (billInfos) {
		var options = "<option value=''>--请选择--</option>";			
		for (var i = 0; i < billInfos.length; i++){
			options += ("<option value=\"" + billInfos[i].billTplCode + "\">" + billInfos[i].billTplCode + "</option>");
		}
		$("#billCodeId").html(options);
		$(".bill").show();
		flagTradeCode = true;
		$("#tradeCode").attr("disabled", true);
	} else {
		$(".bill").hide();
	}
}


function initTradeInfo() {
	var result = false;
	$.ajax({
		type : "POST",
		url : ctx + "/gss/sealconfig/sealConfigAction!listAll.action",
		data : {},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				var data = data.sealConfigs;
				for (var i = 0; i < data.length; i++) {
					if (data[i].sealMode == "0") {
						if(!tradeInfos[data[i].tradeCode]) {
							tradeInfos[data[i].tradeCode] = [];
						}
						tradeInfos[data[i].tradeCode].push({billTplCode:data[i].billTplCode, billName:data[i].billName});
					}
				}
				result = true;
			} else {
				$.error("操作失败：" + data.responseMessage.message);
			}
		}
	});
	return result;
}
/**
 * 初始化表单
 */
function initPrintElecSealForm() {
	var url = ctx+ "/ess/print/integratedPrintAction_initForm.action";
	var data = tool.ajaxRequest(url, '');
	if (data.success) {
		if (data.response.webResponseJson.state == "normal") {
			$("#districtCode").val("000");
			$("#orgNo").val(data.response.webResponseJson.data.orgNo);
			$("#peopleCode").val(data.response.webResponseJson.data.peopleCode);
		} else {
			show("服务器响应失败");
		}
	} else {
		show("服务器响应失败：" + data.response);
	}
};

function clearData() {
	$("#bizType").val("");
	$("#sealName").val("");
	$("#sealCount").val("");
	$("#sealMode").val("");
	destroyTr();
}

/**
 * 交易代码查询业务信息
 */
function queryTradeCode() {
	var url = ctx + "/ess/print/integratedPrintAction_queryByTradeCodeAfterBillTplCode.action";
	var formData = {
		"tradeCode" : $("#tradeCode").val(),
		"billTplCode" : $("#billCodeId").val() ||"",
		"sealMode" : "0"// 电子印章
	};
	var data = tool.ajaxRequest(url, formData);
	if (data.success) {
		if (data.response.webResponseJson.state == "normal") {
			// 临时代码，后续会合并，不存在单独判断
			if (data.response.webResponseJson.data.useType != "1") {
				show("此交易非一体化用印业务，请使用印章用印");
				return;
			}
			flagTradeCode = true;
			$("#bizType").val(data.response.webResponseJson.data.bizTypeInfo.bizName);
			$("#sealName").val(data.response.webResponseJson.data.sealName);
			$("#sealCount").val(data.response.webResponseJson.data.useType);
			$("#sealMode").val(data.response.webResponseJson.data.sealMode);
			$("#sealSn").val(data.response.webResponseJson.data.sealSn);
			sealType = data.response.webResponseJson.data.sealMode;
			bizElementInfo = $.parseJSON(data.response.webResponseJson.data.bizTypeInfo.bizElemts);
			if (bizElementInfo != null) {
				showBizInfoElementData();
			} else {
				show("没有获取到业务要素");
			}
			$("#tradeCode").attr("disabled", true);
		} else {
			$("#bizType").val("");
			$("#sealType").val("");
			$("#sealCount").val("");
			show(data.response.webResponseJson.data);
			flagTradeCode = false;
			reset();
		}
	} else {
		show("服务器响应失败：" + data.response);
	}
};

function checkSealIsUsed() {
	var result = false;
	var sealSn = $("#sealSn").val();
	var orgNo = top.loginPeopleInfo.orgNo;
	$.ajax({
		type : "POST",
		url : ctx + "/ess/param/elecSealUsedOrgParamAction_checkSealIsUsed.action",
		data : {orgNo:orgNo, sealSn:sealSn},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				result = data.responseMessage.data;
			} else {
				$.error("操作失败：" + data.responseMessage.message);
			}
		}
	});
	return result;
}

/**
 * 一体化申请用印
 */
function printElecSeal() {
	if (!$(".bill").is(':hidden') && !$("#billCodeId").val()) {
		alert("请选择凭证模板名称!");
		return;
	}

	if (sealType == 0) {// 电子印章
		
		if (!checkSealIsUsed()) {
			alert("当前电子印章无使用权限.");
			return;
		}
		
		$("button").attr("disabled",true);
		
		var bizElementInfos = genElementValue();
		var data = {
			"bizTypeName" : $("#bizType").val(),
			"tradeCode" : $("#tradeCode").val(),
			"billTplCode" : $("#billCodeId").val() ||"",
			"bizElementInfo" : $.toJSON(bizElementInfos)
		};
		var url = ctx + "/ess/print/integratedPrintAction_printSeal.action";
		data = tool.ajaxRequest(url, data);
		if (data.success) {
			// 按钮恢复可用
			// dijit.byId("printBtn").cancel();
			if (data.response.webResponseJson.state == "normal") {
				// 打印
				var printObject = data.response.webResponseJson.data;
				genSealPic(printObject.sealData);
				var ret = OCX_Print._startPrint(printObject.printTemplate,printObject.printData, printFail, printSuccess);
				if (ret.code != "1001") {
					alert(ret.data);
				}
			} else {
				show(data.response.webResponseJson.data);
			}
		} else {
			$("#printBtn").attr("disable", false);
			show("用印失败：" + data.response);
		}
	} else {
		// 机控印章
		show("机控印章无一体化打印");
		return;
	}
};
/**
 * 生成印章图片
 */
function genSealPic(sealData) {
	OCX_Base64.decodeBase64(sealData, sealPath);
};

/**
 * 用印成功
 */
function printSuccess() {
	$("#printBtn").attr("disable", false);
	var url = ctx+ "/ess/print/integratedPrintAction_initForm.action";
	var data = tool.ajaxRequest(url, '');
	if (data.success) {
		if (data.response.webResponseJson.state == "normal") {
			show("用印成功");
			reset();
			$("button").attr("disabled",false);
		} else {
			showMessage(response.webResponseJson.data);
		}
	} else {
		showMessage("更新用印状态服务器响应失败：" + data.response);
	}
};

/**
 * 用印失败
 */
function printFail() {
	show("用印失败");
	$("#printBtn").attr("disable", false);
};

// 根据业务要素，显示界面
function showBizInfoElementData() {
	var trNode;
	// 排序
	bizElementInfo.sort(function(a, b) {
		return a.order - b.order;
	});
	// 循环显示
	$.each(bizElementInfo, function(index, element) {
		// 创建两个td
		if (tdNum % 3 == 0) {
			trNode = $('<tr id="tr' + parseInt(tdNum / 3)
					+ '" class="form_row_height_40"></tr>');
			$("#table").append(trNode);
		}
		tdNum++;
		// label
		var tdNod = $('<td class="form_label_100">' + element.elementName
				+ "</td>");
		$(trNode).append(tdNod);
		tdNode = $('<td></td>');
		divNode = $('<div class="form_textfiled_160"></div>');

		$(tdNode).append(divNode);
		$(trNode).append(tdNode);
		var node = $('<input id="' + element.elementValue + '" name="'
				+ element.elementValue + '"></input>');
		// var node = $('<input id="' + element.elementValue + '" name="'
		// + element.elementValue + '" value="'+element.elementValue+'"
		// ></input>');
		divNode.prepend(node);

	});
};
// 数据录入
function saveElementValue() {
	var bizElementInfos = genElementValue();
	var url = ctx
			+ "/ess/print/integratedPrintAction_saveBizElementInfo.action";
	var formData = {
		"bizElementInfos" : $.toJSON(bizElementInfos),
		"sealMode" : $("#sealMode").val()
	};
	var data = tool.ajaxRequest(url, formData);
	if (data.success) {
		if (data.response.webResponseJson.state == "normal") {
			show(data.response.webResponseJson.data);
		} else {
			show(data.response.webResponseJson.data);
		}
	}
}

// 匹配界面数据的要素
function searchElement(data, key) {
	var rd = null;
	$.each(data, function(index) {
		if (data[index].name == key) {
			rd = data[index];
		}
	});
	return rd;
}

// 生成要素数据
function genElementValue() {
	var data = $('#form').serializeArray();
	var bizElementInfos = new Array();
	$.each(bizElementInfo, function(index, element) {
		var find = searchElement(data, element.elementValue);
		if (find != null) {
			bizElementInfos.push({
				tradeCode : $("#tradeCode").val(),
				elementKey : element.elementValue,
				elementName : element.elementName,
				elementValue : find.value,
				orderid : element.order,
				isShow : element.isShow
			});
		}
		;
	});
	return bizElementInfos;
}

/**
 * 删除生成的tr
 */
function destroyTr() {
	if (tdNum == 0) {
		return;
	}

	$.each(bizElementInfo, function(index, element) {
		$("#" + element.elementValue).remove();
	});

	for (var i = 0; i <= parseInt((tdNum - 1) / 3); i++) {

		$("#tr" + i).remove();
	}
};

/**
 * 重置
 */
function reset() {
	$("#form")[0].reset();
	destroyTr();
	tdNum = 0;
	flagTradeCode = false;
	inputParam = 0;
	$("#tradeCode").attr("disabled", false);
	$(".bill").hide();
	
	$("#tradeCode").blur(function() {
		var tradeCode = $("#tradeCode").val();
		var reg = /^[0-9](\d{3})$/;
		if (reg.test(tradeCode)) {
			createBillSelect(tradeCode);
			if ($(".bill").is(':hidden')) {
				queryTradeCode();
			}
		}

	});
};