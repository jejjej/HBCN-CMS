
/** 根据命名空间及key获取wf缓存的值 */
/*function getParamFromWFCache(namespace, key) {
    try {
        //创建后台设置的命名空间
        var cacheSpace = top.WFCache.getCacheSpace(namespace);
        //获取该命名空间下的所有缓存值
        var cache = top.WFCache.getPageCache(cacheSpace);
        //根据key，获取该缓存下的某个值
        return cache.get(key);
    } catch (e) {
        return null;
    }
};
*/

$(function() {
	
	pageInit();
});

function pageInit() {
	
	var date1 = new Date();
    date1.setMonth(date1.getMonth()-1);
	$("#ge_operTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
	
	$("#le_operTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
	
    $("#operOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
	$("#operOrgNo_Form").val(top.loginPeopleInfo.orgNo);
	
	initApplyDialog();
	
	fetchSealApllyList();
	
	search();
	
	$("#clearForm").click(function() {
		$("#search")[0].reset();
		var date1 = new Date();
	    date1.setMonth(date1.getMonth()-1);
		$("#ge_operTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
		
		$("#le_operTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
		
	    $("#operOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
		$("#operOrgNo_Form").val(top.loginPeopleInfo.orgNo);
	});
	
    // 默认本机构
    $("#operOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
	$("#operOrgNo_Form").val(top.loginPeopleInfo.orgNo);
	
    // 默认查询一个月以内
	var nowDate = new Date();
	var now = nowDate.pattern("yyyy-MM-dd hh:mm:ss");
	var oldDate = new Date(nowDate.setMonth((new Date().getMonth()-1)));
	var old = oldDate.pattern("yyyy-MM-dd hh:mm:ss");
	$("#ge_operTime").val(old);
	$("#le_applyTime").val(now);
	
}

function search(){
	$("#list").jqGrid("search", "#search");
};
function initApplyDialog() {
	
	$("#moulageInfo").validationEngine({
        showOnMouseOver:true,
        validationEventTrigger:"keyup blur",
        promptPosition : "centerRight",
        autoPositionUpdate : true,
        onValidationComplete: function() {}
        
    });
	
	GPCache.remote({url:ctx +"/ess/cache/sealType!fetch.action", callback:function(data){
		var datas = {};
		for (var i = 0; i < data.length; i++) {
			datas[data[i].type] = data[i].name;
		}
		return datas;
	}}, GPCache.SMS, GPType.SMS_SEAL_TYPE);
	
	var options = "";		
	var objs = GPCache.get(GPCache.SMS, GPType.SMS_SEAL_TYPE);
	for (var o in objs) {
		options += ("<option value=\"" + o + "\">" + objs[o] + "</option>");
	}
	$("#moulageType").html("<option value=''>全部</option>" + options);
	
}
/**
 * 列表
 */

function fetchSealApllyList() {
	$("#list").jqGrid({
		caption : "印模操作日志",
		url : top.ctx + "/ess/moulagelog/elecMoulageOperLogAction!list.action",
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "印模编号", "印模名称","印模类型", "银行名称", "印模形状", "所属机构","操作人","操作人机构","操作时间","操作类型"],
		colModel : [ {
			name : "moulageNo",
			index : "moulageNo",
			width : 100
		}, {
			name : "moulageName",
			index : "moulageName",
			width : 100
		}, {
			name : "moulageType",
			index : "moulageType",
			width : 100,
			formatter:moulageTypeFmt
		},{
			name : "bankName",
			index : "bankName",
			width : 150		
		}, {
			name : "moulageShape",
			index : "moulageShape",
			width : 100,
			formatter:SealShapeFmt
		}, {
			name : "orgNo",
			index : "orgNo",
			width : 120,
			formatter : function(value, options, rData) {
				return rData.orgName + "(" + value + ")";
			}
		},{
			name : "operPeopleCode",
			index : "operPeopleCode",
			width : 120,
			formatter : function(value, options, rData) {
				return rData.operPeopleName + "(" + value + ")";
			}
		},{
			name : "operOrgNo",
			index : "operOrgNo",
			width : 120,
			formatter : function(value, options, rData) {
				return rData.operOrgName + "(" + value + ")";
			}
		},{
			name : "operTime",
			index : "operTime",
			width : 120
		},{
			name : "operType",
			index : "operType",
			width : 100,
            formatter:moulageOperTypeFmt
		}],
		pager : "#pager"
	});
	$("#list").navGrid("#pager",{edit:false,add:false,del:false,search:false,refresh: true, excel: ctx + "/ess/moulagelog/elecMoulageOperLogAction!report.action"});
};


/**
 * 选择机构
 */
function choseOrganizationItem() {
	$("#operOrgNo_Item").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, {
		filterOrgType : "1,2,6,7"
	}, null, function(event, treeId, treeNode) {
		if (treeNode) {
			if (treeNode) {
				$("#operOrgNo_Item").val(treeNode.organizationName + "(" + treeNode.organizationNo + ")");
				$("#operOrgNo_Form").val(treeNode.organizationNo);
			}
		}
	});
}



/**
 * 电子印章申请状态格式化
 * 
 * @param value
 * @returns {String}
 */
function elecApplyStateFmt(value) {
    return GPCache.get(GPType.ESS_SEAL_STATE, value);
}

/**
 * 印模参数格式化
 * 
 * @param value
 * @returns {String}
 */
function SealShapeFmt(value) {
    return GPCache.get(GPCache.GSS, GPType.ESS_SEAL_SHAPE, value);
}

/**
 * 电子印章类型格式化
 * 
 * @param value
 * @returns {String}
 */
function moulageTypeFmt(value) {
    return GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE, value);
}
/**
 * 电子印模操作类型格式化
 * 
 * @param value
 * @returns {String}
 */
function moulageOperTypeFmt(value) {
    return GPCache.get(GPCache.GSS, GPType.ESS_MOULAGE_OPER_TYPE, value);
}
