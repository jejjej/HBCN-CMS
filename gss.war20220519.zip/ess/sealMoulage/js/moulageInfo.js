
var strImagePath = "C:/yzjgss/temp/";
$(function() {
	pageInit();
	
	
});

function pageInit() {
	
	if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, top.ctx+'/activex/api/', 'run', 1, 1)) {
		alert("初始化通用控件失败");
		return;
	}
	if (!ocxObject.initOcx(ocxObject.OCX_Base64, document.body, top.ctx+'/activex/api/', 'run', 1, 1)) {
		alert("初始化加密控件失败");
		return;
	}
	
	initApplyDialog();
	
	fetchSealApllyList();
	
	strImagePath = OCX_Tools.readIni(top.yzjgssRootPath + "/yzjgss/config/gss.ini", "CONFIG", "ESS_TEMP_DIR", "C:/yzjgss/temp/").data;
	if(strImagePath) {
		WTFileUtil.createMultiLevelFolder(strImagePath);
	}
	
	$(".finalOrgLevel").change(function(){
		var ownOrgType = $("#ownOrgType").val();
		var finalOrgType = $(this).val();
		if (!ownOrgType) {
			$(this).val(5);
			alert("请选择印模所属机构!");
			return false;
		} 
		if (parseInt(ownOrgType) > parseInt(finalOrgType) ) {
			$(this).val(5);
			var label = $(this).closest("tr").children("th:eq(0)").children("nobr").html();
			var msg = label.split(":").join('').split("：").join('');
			alert(msg + "必须大于等于印模所属机构级别!");
			return false;
		}
	});
	
	$("#submitForm").click(function() {
		$("#list").jqGrid("search", "#search");
	});
	
	$("#clearForm").click(function() {
		$("#search")[0].reset();
	});
	
}

//预设印模信息
function oxc_moulage() {
	
	var strSealInfos = [];
	var strTextInfos = [];
	
	
	strSealInfos[0] = GPCache.get(GPCache.GSS, GPType.ESS_MOULAGE_DATA,"DiamondSealInfo");
	strTextInfos[0] = GPCache.get(GPCache.GSS, GPType.ESS_MOULAGE_DATA,"DiamondSealText");
	strSealInfos[1] = GPCache.get(GPCache.GSS, GPType.ESS_MOULAGE_DATA,"TriangleSealInfo");
	strTextInfos[1] = GPCache.get(GPCache.GSS, GPType.ESS_MOULAGE_DATA,"TriangleSealText");
	strSealInfos[2] = GPCache.get(GPCache.GSS, GPType.ESS_MOULAGE_DATA,"RectangleSealInfo");
	strTextInfos[2] = GPCache.get(GPCache.GSS, GPType.ESS_MOULAGE_DATA,"RectangleSealText");
	strSealInfos[3] = GPCache.get(GPCache.GSS, GPType.ESS_MOULAGE_DATA,"RoundSealInfo");
	strTextInfos[3] = GPCache.get(GPCache.GSS, GPType.ESS_MOULAGE_DATA,"RoundSealText");
	strSealInfos[4] = GPCache.get(GPCache.GSS, GPType.ESS_MOULAGE_DATA,"EllipseSealInfo");
	strTextInfos[4] = GPCache.get(GPCache.GSS, GPType.ESS_MOULAGE_DATA,"EllipseSealText");
	
	OCX_Moulage.SetRunMode(1);
	
	OCX_Moulage.SetPicDir(strImagePath);
		
	var imageType = GPCache.get(GPCache.GSS, GPType.ESS_SEAL_PROP,"fileType");
	
	//OCX_Moulage.SetPicType(imageType);
	
  if (imageType == ".1bmp") {
		OCX_Moulage.SetImageType(1);
	}
	else if (imageType == ".32bmp") {
		OCX_Moulage.SetImageType(2);
	}
	else if (imageType == ".jpg") {
		OCX_Moulage.SetImageType(3);
	}
	else if (imageType == ".gif") {
		OCX_Moulage.SetImageType(4);
	}
	else if (imageType == ".tif") {
		OCX_Moulage.SetImageType(5);
	}
	else {//默认
		OCX_Moulage.SetImageType(0);
	}
	
	
	for (var i = 0, len = strSealInfos.length; i < len; i++) {
		OCX_Moulage.SetSealData(strSealInfos[i], strTextInfos[i]);
	}
	
	$("#mm").focus();
	
	
	
}
$(window).unload(function(){
	if(strImagePath) {
		var filePaths = WTFileUtil.listFolder(strImagePath);
		for (var i = 0; i < filePaths.length; i++) {
			WTFileUtil.deleteFile(filePaths[i].Path);
		}
	}
});
function initApplyDialog() {
	
	$("#moulageInfo").validationEngine({
        showOnMouseOver:true,
        validationEventTrigger:"keyup blur",
        promptPosition : "centerRight",
        autoPositionUpdate : true,
        onValidationComplete: function() {}
    });
	
		//获取（印章类型）印模类型
		GPCache.remote({url:ctx +"/ess/cache/sealType!fetch.action", callback:function(data){
			var datas = {};
			for (var i = 0; i < data.length; i++) {
				datas[data[i].sealType] = data[i].sealTypeName;
			}
			return datas;
		}}, GPCache.ESS, GPType.ESS_SEAL_TYPE);
		
		var options = "";		
		var objs = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE);
		for (var o in objs) {
			options += ("<option value=\"" + o + "\">" + objs[o] + "</option>");
		}
		$("#moulageTypeList").html(options);
		$("#moulageTypeSearch").html("<option value=''>全部</option>" + options); 
		
	
//保存页面信息，控件按钮处理。保留	
	$("#moulageInfo").dialog({
        autoOpen : false,
        height : 630,
        width : 830,
        resizable : false,
        modal : true,
        close : function() {
            $("#moulageInfo")[0].reset();
        },
        open: function() {
        	//20161103修改，修复兼容模式以及IE6下页面问题
        	appendOcx();
        }
    });
	
	$("#addMoulage").click(function(){
		$("#moulageInfo").dialog("open");
		oxc_moulage();
	});
	
	//导出印模信息，格式excel
	
}

/**
 * 列表
 */
function fetchSealApllyList() {
	$("#list").jqGrid({
		caption : "印模信息查询",
		url : top.ctx + "/ess/moulage/elecSealMoulageAction!list.action",
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "印模编号", "印模名称", "印模类型", "印章形状", "所属机构", "行名","录入日期","操作" ],
		colModel : [ {
			name : "moulageNo",
			index : "moulageNo",
			width : 80
		}, {
			name : "moulageName",
			index : "moulageName",
			width : 120
		}, {
			name : "moulageType",
			index : "moulageType",
			width : 100,
			formatter : function(value, options, rData) {
				return GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE, value);
			}
			
		}, {
			name : "sealShape",
			index : "sealShape",
			width : 90,
			formatter : function(value, options, rData) {
				return GPCache.get(GPCache.GSS, GPType.ESS_SEAL_SHAPE, value);
			}

		}, {
			name : "orgNo",
			index : "orgNo",
			width : 90,
			formatter : function(value, options, rData) {
				return rData.orgName + "(" + value + ")";
			}

		},{
			name : "bankName",
			index : "bankName",
			width : 150

		},{
			name : "createTime",
			index : "createTime",
			width : 150
			
		},{
			name : "autoId",
			index : "autoId",
			width : 120,
			formatter : function(value, options, rData) {
				return "<input type='button'  value='修改' onclick='openUpdateParamDLG(\"" + value + "\")'/>"+
				"<input type='button'  value='删除' onclick='delApplyInfo(\"" + value + "\")'/>";
			}
		}],
		pager : "#pager"
	});
}



function openUpdateParamDLG(autoId) {
	
	$.ajax({
		type : "POST",
		url : ctx + "/ess/moulage/elecSealMoulageAction!find.action",
		data : {
			"sealModelInfo.autoId" : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$("input[name='sealModelInfo.autoId']").val(data.sealModelInfo.autoId);
				$("input[name='sealModelInfo.moulageName']").val(data.sealModelInfo.moulageName);
				$("input[name='sealModelInfo.moulageNo']").val(data.sealModelInfo.moulageNo);
				$("input[name='sealModelInfo.orgNo']").val(data.sealModelInfo.orgNo);
				$("input[name='sealModelInfo.orgName']").val(data.sealModelInfo.orgName);
				$("input[name='sealModelInfo.bankName']").val(data.sealModelInfo.bankName);
				$("input[name='sealModelInfo.createTime']").val(data.sealModelInfo.createTime);
				$("input[name='sealModelInfo.sealShape']").val(data.sealModelInfo.sealShape);
				
				$("#moulageOrgNo").val(data.sealModelInfo.orgNo);
			    $("#moulageOrgNameId, #moulageOrgName").val(data.sealModelInfo.orgName);
				
				$("#moulageTypeList").val(data.sealModelInfo.moulageType);
				
				$("#ap_or").val(data.sealModelInfo.applyFinalOrgLevel);
				$("#di_or").val(data.sealModelInfo.disableFinalOrgLevel);
				$("#en_or").val(data.sealModelInfo.enableFinalOrgLevel);
				$("#de_or").val(data.sealModelInfo.destoryFinalOrgLevel);
				
				$("#ap_re").val(data.sealModelInfo.applyReCheck);
				$("#di_re").val(data.sealModelInfo.disableReCheck);
				$("#en_re").val(data.sealModelInfo.enableReCheck);
				$("#de_re").val(data.sealModelInfo.destoryReCheck);
								
				$("#ownOrgType").val(OrgType.getOrganizationTypeByOrgNo(data.sealModelInfo.orgNo));
				appendOcx();
				OCX_Moulage.SetSealData(data.sealModelInfo.elecSealJson,data.sealModelInfo.modelEditableProp);
				$("#moulageInfo").dialog("open");
				$("#mm").focus();
			} else {
				$.error("操作失败:" + data.responseMessage.message);
			}
		}
	});
}

function appendOcx() {
	if (!$("#moulageInfo").data("init")) {
		$("<object classid='clsid:6E48C719-29D9-467E-A1B7-70EC09E224BD' id='ocx_elecmoulage' height='390' width='790'></object><br>").insertBefore("#moulageForm");
		$("#moulageInfo").data("init", true);
	}
}

function delApplyInfo(autoId) {
	if (confirm("确定删除印模信息？")) {
	$.ajax({
		type : "POST",
		url : ctx + "/ess/moulage/elecSealMoulageAction!delete.action",
		data : {
			"sealModelInfo.autoId" : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$.success("操作成功：印模信息删除成功!");
				$("#list").trigger("reloadGrid");
			}
			else {
				$.error("操作失败：" + data.responseMessage.message);
			}
		}

	});
	}
	return false;
}


function moulageOrg(){
    $("#moulageOrgName").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false,{filterOrgType : "1,2,6,7"}, null,
	    function(event, treeId, treeNode) {
			if (treeNode) {
			    $("#moulageOrgNo").val(treeNode.organizationNo);
			    $("#moulageOrgNameId, #moulageOrgName").val(treeNode.organizationName);
			    $("#ownOrgType").val(treeNode.organizationType);
			}
    	}, function(){
    		$("#ocx_elecmoulage").css("visibility", "hidden");
    	}, function(){
    		$("#ocx_elecmoulage").css("visibility", "");
		
	    });
    $(".finalOrgLevel").val(5);
}


function OnPicOutEx(strImagePath, strSealInfo, strTextInfo){
	$("#confirm").val();
	$("#level").val();
	var sealShape = strSealInfo.match(/type:"(\S*)";frame/)[1];

	$("input[name='sealModelInfo.sealShape']").val(sealShape),
	
	$("input[name='sealModelInfo.moulageData']").val(OCX_Base64.encodeBase64(strImagePath).data),
	$("input[name='sealModelInfo.elecSealJson']").val(strSealInfo),
	$("input[name='sealModelInfo.modelEditableProp']").val(strTextInfo);
	
	var ownOrgType = $("#ownOrgType").val();
	var checkResult = true;
	$(".finalOrgLevel").each(function(){
		var finalOrgType = $(this).val();
		if (!ownOrgType) {
			checkResult = false;
			$(this).val(5);
			alert("请选择印模所属机构!");
			return false;
		} 
		if (parseInt(ownOrgType) > parseInt(finalOrgType) ) {
			checkResult = false;
			$(this).val(5);
			var label = $(this).closest("tr").children("th:eq(0)").children("nobr").html();
			var msg = label.split(":").join('').split("：").join('');
			alert(msg + "必须大于等于印模所属机构级别!");
			return false;
		}
		
	});
	
	
	if (checkResult) {
		
		if ($("#mm").val() == "") {
			alert("印模名称不能为空！");
			return;
		}
		
		if ($("#bn").val() == "") {
			alert("行名不能为空！");
			return;
		}
		
		$.post(top.ctx + "/ess/moulage/elecSealMoulageAction!save.action",	
				$("#moulageInfo").serializeForm(),function(data) {
			if (data.responseMessage.success) {
				$.success("保存成功");
				$("#moulageInfo").dialog("close");
				$("#list").jqGrid("search", "#search");
			} else {
				$.error("保存失败: " + data.responseMessage.message);
			}
		});
	}
};


