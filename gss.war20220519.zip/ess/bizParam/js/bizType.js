/**
* 创建于:2016-9-13<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 电子印章业务类型信息
 * 
 * @author guoliesheng
 * @version 1.0.0
 */
//现在选择的要素
var curSelectElement=null;
//现在点击编辑的要素
var elementTree_edit=null;
//计数
var newCount = 1;
//初始要素长度
var initElementLen=0;



/**
 * 初始化界面
 */
function bizTypeParamInit() {
	GPCache.remote({url:ctx +"/base/gssBizTypeInfoAction_fetch.action", callback:function(data){
		var datas = {};
		
		for (var i = 0; i < data.length; i++) {
			datas[data[i].bizCode] = data[i].bizName;
		}
		return datas;
	},refresh:true}, GPCache.ESS, GPType.ESS_BIZ_CODE);
	
	
	$("#bizTypeParamDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 400,
		width : 370,
		modal : true,
		buttons : {},
		close : function() {
			$("#modifyParamForm")[0].reset();
		}
	});
	
//	var pageHeaderHeight = $(".pageHeader").css("height");
//	var pageContentWidth = $(".pageContent").width() - 2;
//	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
//	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	$("#bizTypeParamsTable").jqGrid(
			{
//				width : pageContentWidth,
//				height : tableHeight + "px",
				url : ctx + "/base/gssBizTypeInfoAction_list.action",
				multiselect : false,
				rowNum : 20,
				rownumbers : true,
				rowList : [ 20, 50, 100 ],
				colNames : [ "业务类型代码", "业务类型名称", "业务要素", "备注" ,"操作" ],
				colModel : [
						{
							name : "bizCode",
							index : "bizCode",
							align : "center",
							sortable : false
						},
						{
							name : "bizName",
							index : "bizName",
							align : "center",
							sortable : false
						},
						{
							name : "bizElemts",
							index : "bizElemts",
							align : "center",
							sortable : false
						},
						{
							name : "memo",
							index : "memo",
							align : "center",
							sortable : false
						},
						{
							name : "autoId",
							index : "autoId",
							align : "center",
							sortable : false,
							formatter : function(value, options, rData) {
								return "<input type='button'  value='修改' onclick='openUpdateParamDLG(\""+value+"\",\""+rData.bizCode+"\")'/>" +
										"<input type='button' value='删除' onclick='deleteBizTypeInfo(\""+value+"\",\""+rData.bizCode+"\")'  />";
							}
						}  ],
				pager : "#bizTypeParamsTablePager"
			});
	elementTree_edit=$("#elementTree_edit");
	$("#elementTree_edit_name").bind("keypress",function(event){ if(event.keyCode=="13"||event.keyCode=="108"){ updateNode(); };});
    $("#elementTree_edit_value").bind("keypress",function(event){ if(event.keyCode=="13"||event.keyCode=="108"){ updateNode(); };});
    $("#elementTree_check_show").bind("keypress",function(event){ if(event.keyCode=="13"||event.keyCode=="108"){ updateNode(); };});
};

//查询数据
function queryList() {
	$("#bizTypeParamsTable").jqGrid("search", "#bizTypeQueryForm");
};

//打开新增业务类型界面
function openAddParamDLG() {
	$("#bizTypeParamDLG").dialog("open");
	document.getElementById('idtr').style.display = "none";
	document.getElementById('updateButtonDIV').style.display = "none";
	document.getElementById('addButtonDIV').style.display = "";
	document.getElementById('idItem').setAttribute('disabled', 'disabled');
	listElementTree();
};

//打开修改业务类型界面
function openUpdateParamDLG(id,bizCode){
	var result = findeTradeInfoByBizTypeCode(bizCode);
	if(result){
		alert("该业务类型已被关联,不能修改!");
		return;
	}
	$.ajax({
		type : "POST",
		url : $.getContextPath() + "/base/gssBizTypeInfoAction_queryByAutoId.action",
		data : {
			"bizTypeInfo.autoId" : id
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				document.getElementById('idtr').style.display = "none";
				$("#idItem").val(data.bizTypeInfo.autoId);
				$("#bizCode").val(data.bizTypeInfo.bizCode);
				$("#bizName").val(data.bizTypeInfo.bizName);
				$("#bizElemts").val(data.bizTypeInfo.bizElemts);
				$("#memo").val(data.bizTypeInfo.memo);
				$("#bizTypeParamDLG").dialog("open");
				document.getElementById('updateButtonDIV').style.display = "";
				document.getElementById('addButtonDIV').style.display = "none";
				document.getElementById('idItem').removeAttribute('disabled');
				listElementTree();
			} else {
				alert("获取业务类型失败:" + data.responseMessage.message);
			}
		}
	});
};

////打开操作业务类型要素界面
//function openBizTypeElementDLG(){
//	$("#bizTypeElementDLG").dialog("open");
//	listElementTree();
//};
////关闭操作业务类型要素界面
//function closeBizTypeElementDLG(){
//	$("#bizTypeElementDLG").dialog("close");
//	clearElementInput();
//}
/**
 *根据业务类型代码查找交易信息 
 * 
 * */
function findeTradeInfoByBizTypeCode(bizCode){
	var result = false;
	$.ajax({
		type : "POST",
		url : ctx + "/gss/tradeinfo/tradeInfoAction!findeTradeInfoByBizTypeCode.action",
		data : {"bizTypeCode":bizCode},
		dataType : "json",
		async : false,
		success : function(data) {	if (data && data.responseMessage) {
			result = data.responseMessage.success;
		}else{
			alert("网络问题");
		}}
	});
	return result;
}

//添加业务类型
function addBizTypeInfo(){
	if (checkBizTypeData()) {
		$.ajax({
			type : "POST",
			url : $.getContextPath()
					+ "/base/gssBizTypeInfoAction_addBizTypeInfo.action",
			data : {
				"bizTypeInfo.bizCode" : $.trim($("#bizCode").val()),
				"bizTypeInfo.bizName" : $.trim($("#bizName").val()),
				"bizTypeInfo.bizElemts" : $.trim($("#bizElemts").val()),
				"bizTypeInfo.memo" : $.trim($("#memo").val())
			},
			dataType : "json",
			asyn : false,
			success : function(data) {
				if (data && data.responseMessage
						&& data.responseMessage.success) {
					$("#bizTypeParamDLG").dialog("close");
					$("#bizTypeParamsTable").trigger("reloadGrid");
				} else {
					alert(data.responseMessage.message);
				}
			}
		});
	};
};
//删除业务类型
function deleteBizTypeInfo(id,bizCode){
	var b = confirm("确定要删除该业务类型吗？");
    if (b) {
    	var result = findeTradeInfoByBizTypeCode(bizCode);
    	if(result){
    		alert("该业务类型已被关联,不能删除!");
    		return;
    	}
		$.ajax({
			type:"POST",
			url:$.getContextPath()+"/base/gssBizTypeInfoAction_deleteBizTypeInfo.action",
			data:{
				"bizTypeInfo.autoId":id
			},
			dataType:"json",
			asyn:false,
			success:function(data){
				if (data && data.responseMessage && data.responseMessage.success) {
					$("#bizTypeParamDLG").dialog("close");
					$("#bizTypeParamsTable").trigger("reloadGrid");
				} else {
					alert(data.responseMessage.message);
				}
			}
		});
    };
};
//更新业务类型
function updateBizTypeInfo(){
	if (checkBizTypeData()) {
	$.ajax({
		type:"POST",
		url:$.getContextPath()+"/base/gssBizTypeInfoAction_updateBizTypeInfo.action",
		data:{
			"bizTypeInfo.bizCode":$.trim($("#bizCode").val()),
			"bizTypeInfo.bizName":$.trim($("#bizName").val()),	
			"bizTypeInfo.bizElemts":$.trim($("#bizElemts").val()),
			"bizTypeInfo.memo":$.trim($("#memo").val())
		},
		dataType:"json",
		asyn:false,
		success:function(data){
			if (data && data.responseMessage && data.responseMessage.success) {
				$("#bizTypeParamDLG").dialog("close");
				$("#bizTypeParamsTable").trigger("reloadGrid");
			} else {
				alert(data.responseMessage.message);
			}
		}
	});
	};
};
//取消添加
function cancelAdd() {
	$("#bizTypeParamDLG").dialog("close");
};

//生成要素树
function listElementTree(){
	newCount=1;
	var elementJson = $("#bizElemts").val();

	var array = [];
	array[0]={
			id:0,
			pId:0,
			name:"业务要素列表",
			open:true,
			icon:"../../../gss/common/images/pms/text-grid.png"
	};
	var setting = {
		view : {
			addHoverDom: addHoverDom,
			removeHoverDom: removeHoverDom,
			selectedMulti : false
		},
		edit: {
			drag: {
				autoExpandTrigger: true,
				prev: true,
				inner: false,
				next: true
			},
			enable: true,
			editNameSelectAll: true,
			showRemoveBtn: false,
			showRenameBtn:false,
			renameTitle:"编辑",
			removeTitle:"删除"
		},
		data : {
			simpleData : {
				enable : true
			}
		},
		callback : {
			//onClick : treeNodeOnClick
			//beforeRename:beforeRename,
			//beforeEditName:beforeEditName
		}
	};
	if (elementJson != null && elementJson != "") {
		var elementObj = $.parseJSON(elementJson);
		//var elementObj = JSON.parse(elementJson);
		$.each(elementObj, function(index, jsonObj) {
//			for ( var key in jsonObj) {
//				if (key == null) {
//					continue;
//				}
				array[index+1] = {
					id : index+1,
					pId:0,
					name : jsonObj.elementName + " : " + jsonObj.elementValue + "("+ (jsonObj.isShow== "1" ? "显示" : "不显示")+ ")",
					elementName : jsonObj.elementName,
					elementValue : jsonObj.elementValue,
					isShow:jsonObj.isShow
				};
			//}
			//;
		});
		
	}
	initElementLen=array.length;
	$.fn.zTree.init($("#elementTree"), setting, array);
	
};

//设置节点否显示删除节点功能（包括重命名）
function showRemoveBtn(treeId, treeNode) {
	if(treeNode.id==0){
		return false;
	}else{
		return true;
	}

}

function addHoverDom(treeId, treeNode) {
	var sObj = $("#" + treeNode.tId + "_span");
	if (treeNode.editNameFlag || $("#addBtn_"+treeNode.tId).length>0) return;
	var addStr ="";
	if(treeNode.id==0){
		addStr = "<span class='button add' id='addBtn_" + treeNode.tId
		+ "' title='新增要素' onfocus='this.blur();'></span>";
		sObj.after(addStr);
		var btn = $("#addBtn_" + treeNode.tId);
		if (btn)btn.bind("click", function() {
				var zTree = $.fn.zTree.getZTreeObj("elementTree");
				var addNode={
						id : initElementLen+newCount+1,
						pId : treeNode.id,
						name : "新要素(请编辑)_" + (newCount++),
						elementName : "",
						elementValue: "",
						isShow:1
						
					};
				zTree.addNodes(treeNode, addNode);
				return false;
			});
	}else{
		
		var delStr = "<span class='button remove' id='delBtn_" + treeNode.tId
		+ "' title='删除' onfocus='this.blur();'></span>";
		sObj.after(delStr);
		var delBtn = $("#delBtn_" + treeNode.tId);
		if (delBtn)delBtn.bind("click", function() {
				var zTree = $.fn.zTree.getZTreeObj("elementTree");
				zTree.removeNode(treeNode, false);
				return false;
			});
		
		var modStr = "<span class='button edit' id='modBtn_" + treeNode.tId
		+ "' title='修改' onfocus='this.blur();'></span>";
		sObj.after(modStr);
		var modBtn = $("#modBtn_" + treeNode.tId);
		if(modBtn) modBtn.bind("click",function(){modNode(treeNode); return false;});
		
		addStr = "<span class='button add' id='addBtn_" + treeNode.tId
		+ "' title='向下新增要素' onfocus='this.blur();'></span>";
		sObj.after(addStr);
		var addBtn = $("#addBtn_" + treeNode.tId);
		if (addBtn)addBtn.bind("click", function() {
				var zTree = $.fn.zTree.getZTreeObj("elementTree");
				var copyNode={
						id : initElementLen+newCount+1,
						pId:0,
						name : "新要素(请编辑)_" + (newCount++),
						elementName : "",
						elementValue: "",
						isShow:1
					};
				//copyNode.name="新要素(请重新编辑，用分号分隔)_" + (newCount++);
				zTree.copyNode(treeNode,copyNode,"next" );
				return false;
			});
		
	}
	
};

function removeHoverDom(treeId, treeNode) {
	$("#addBtn_"+treeNode.tId).unbind().remove();
	$("#modBtn_"+treeNode.tId).unbind().remove();
	$("#delBtn_"+treeNode.tId).unbind().remove();
};



function modNode(treeNode){
	var zTree = $.fn.zTree.getZTreeObj("elementTree");
	$("elementTree_edit span").show();
	var tmpA=$("#"+treeNode.tId+"_a");
	zTree.selectNode(treeNode);
	var t=tmpA.position().top;   
    var l=tmpA.position().left; 
    elementTree_edit.css({"top":t+"px", "left":l-18+"px", "visibility":"visible"});
    
    $("#elementTree_edit_name").focus();
	
    $("#elementTree_edit_name").val(treeNode.elementName);
    $("#elementTree_edit_value").val(treeNode.elementValue);
    $("#elementTree_check_show").attr("checked",(treeNode.isShow=="1"?true:false));
    $("body").bind("mousedown", onBodyMouseDown);
}

function onBodyMouseDown(event) {
	if (!(event.target.id == "elementTree_edit" || $(event.target).parents("#elementTree_edit").length > 0)) {
		
		elementTree_edit.css({"visibility" : "hidden"});
		
	}
}

function updateNode(){
	var zTree = $.fn.zTree.getZTreeObj("elementTree");
	var tmpNodes=zTree.getSelectedNodes();
	var treeNode=tmpNodes[0];
	var elementName=$("#elementTree_edit_name").val();
	if(elementName==null||elementName==""){
		alert("要素名称不能为空");
		$("#elementTree_edit_name").focus();
		return ;
	}
	var elementvalue=$("#elementTree_edit_value").val();
	if(elementvalue==null||elementvalue==""){
		alert("要素值不能为空");
		$("#elementTree_edit_value").focus();
		return ;
	}
	var chkValue=$("#elementTree_check_show").attr("checked");
	treeNode.name = elementName + " : " + elementvalue+"("+(chkValue=="checked"?"显示":"不显示")+")";
	treeNode.elementName = elementName;
	treeNode.elementValue=elementvalue;;
	treeNode.isShow = (chkValue == "checked" ? "1" : "0");
	var zTree = $.fn.zTree.getZTreeObj("elementTree");
	zTree.updateNode(treeNode);
	elementTree_edit.css({"visibility" : "hidden"});
}




//检查要素数据
function checkElementData() {
	var treeObj = $.fn.zTree.getZTreeObj("elementTree");
	var allNodes = treeObj.getNodes();

	var jsStr = "";
	var parentNode = allNodes[0];
	var childrenNodes = parentNode.children;
	var elementList=new Array(); 
	if (childrenNodes) {
		for (var i = 0; i < childrenNodes.length; i++) {
			if (childrenNodes[i].elementName == null
					|| childrenNodes[i].elementName == "") {
				alert("要素[" + childrenNodes[i].name + "]值为空");
				return false;
			}
			if(elementList.contains(childrenNodes[i].elementName)){
				alert("要素[" + childrenNodes[i].elementName + "]存在多条数据，请检查要素列表");
				return false;
			}
			elementList.push(childrenNodes[i].elementName);
			i == childrenNodes.length - 1 ? jsStr = jsStr + "{\"elementName\":\""+ childrenNodes[i].elementName + "\",\"elementValue\":\""+ childrenNodes[i].elementValue 
					+ "\",\"isShow\":"+childrenNodes[i].isShow+",\"order\":"+(i+1)+"}" 
					: jsStr = jsStr+ "{\"elementName\":\""+ childrenNodes[i].elementName + "\",\"elementValue\":\""+ childrenNodes[i].elementValue 
					+ "\",\"isShow\":"+childrenNodes[i].isShow+",\"order\":"+(i+1)+"}," ;
		}
		jsStr = "[" + jsStr + "]";
		$("#bizElemts").val(jsStr);
	}
	else{
		alert("业务类型要素列表不能为空");
		return false;
	}
	return true;
};
// 检查业务类型数据
function checkBizTypeData(){
	var tmpBizCode=$("#bizCode").val();
	if(tmpBizCode==null||tmpBizCode==""){
		alert("业务类型编号不能为空");
		$("#bizCode").focus();
		return false;
	}
	var tmpBizName=$("#bizName").val();
	if(tmpBizName==null||tmpBizName==""){
		alert("业务类型名称不能为空");
		$("#bizName").focus();
		return false;
	}
	
	if(!checkElementData()){
		return false; 
	}
	return true;
};
//清除要素操作界面的值
function clearElementInput(){
	$("#elementName").val("");
	$("#elementValue").val("");
	$("#elementName").focus();
};
//判断数组中包含element元素 
Array.prototype.contains = function (element) { 

  for (var i = 0; i < this.length; i++) { 
      if (this[i] == element) { 
          return true; 
      }; 
  } 
  return false; 
};

//离开页面，刷新后台缓存
$(window).unload(function(){
	GPCache.remote({url:ctx +"/base/gssBizTypeInfoAction_fetch.action", callback:function(data){
		var datas = {};
		
		for (var i = 0; i < data.length; i++) {
			datas[data[i].bizCode] = data[i].bizName;
		}
		return datas;
	},refresh:true}, GPCache.ESS, GPType.ESS_BIZ_CODE);
	
	//GPCache.refresh(GPCache.ESS, GPType.ESS_BIZ_CODE);
});