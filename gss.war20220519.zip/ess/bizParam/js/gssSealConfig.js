
var bills = new Map();
var sealInfos = new Map();
var smsSeals = new Map();//实物印章
var elecSeals = new Map();//电子印章
var model = false;
$(function() {
	$("#list").trigger("reloadGrid");
	pageInit();
	
	$("#sms").hide();//默认电子用印，实物用印印章类型 初始化隐藏
	$("#smsPos").hide();//默认电子用印，实物用印位置 初始化隐藏
	$("#billId").show();
	$("#codePos").hide();
	$("#reSeal").show();
	$("#reSealType1").hide();
	$("#sealModeId").change();
});

function pageInit() {
	
	
	initApplyDialog();
	
	fetchSealApllyList();
		
	$("#submitForm").click(function() {
		$("#list").jqGrid("search", "#search");
	});
	
	$("#clearBtn").click(function() {
		$("#search")[0].reset();
	});
	
	shwo_hide();
	
	//通过凭证配置表获取 凭证模板编号 列表；通过对应交易码取值
	GPCache.remote({url:ctx +"/gss/billinfo/billInfoAction!fetch.action", callback:function(data){
		var datas = {};		
		//{交易码对应多个凭证模板编号，数组key
		//   1122:[{6768: }, 1212]
		//}
		for (var i = 0; i < data.length; i++) {
			if(!datas[data[i].tradeCode]) {
				datas[data[i].tradeCode] = [];//一个值都没有
			}
			//datas[data[i].tradeCode].push(data[i].billTplCode);
			datas[data[i].tradeCode].push({billTplCode:data[i].billTplCode, billName:data[i].billName});
			
		}
		return datas;
	},refresh:true
	}, GPCache.ESS, GPType.ESS_BILL_TPCODE);
	
	
	
}


function shwo_hide() {
	$("#sealModeId").change(function() {
		$("#billTplCodeId").val("");
		$("#billTplNameId").val("");
		if ($("#sealModeId").val() == "1") {//用印模式                   0 为电子用印（默认）                         1 为实物用印

			$("#sealSelect").val("");//实物用印时，清空电子印章信息并隐藏			
			$("#sealNameId,#sealNameId2").val("");//
			$("#smsSealId").val("");
			$("#reSealCheck").removeAttr("checked");
			$("#reSealType").val("");
			$(".essSeal").hide();
			$("#reSeal").hide();
			$("#codePos").show();
			$("#sms").show();
			$("#smsPos").show();
			
			
		}
		else if ($("#sealModeId").val() == "0") {	
			
			$("#billNoPosXStart").val("");
			$("#billNoPosXEnd").val("");
			$("#billNoPosYStart").val("");
			$("#billNoPosYEnd").val("");
			
			$("#codePosXStart").val("");
			$("#codePosXEnd").val("");
			$("#codePosYStart").val("");
			$("#codePosYEnd").val("");
			
			$("#sms").hide();
			$("#smsPos").hide();
			$("#codePos").hide();
			$("#billTplNameId").val("");
			$(".essSeal").show();		
			$("#reSeal").show();
			
		}
		
		//不能交叉用印
/*		var tradeCode = $("#tradeCodeId").val();
		var sealMode = $("#sealModeId").val();//模式
		var sealConfig_Id = $("#sealConfigId").val();//主键值
		$.ajax({
			url : top.ctx + "/gss/sealconfig/sealConfigAction!checkModel.action",
			type : "POST",
			data : {
				"sealConfig.tradeCode" : tradeCode,
				"sealConfig.autoId" : sealConfig_Id,
				"sealConfig.sealMode" : sealMode
			},
			dataType : "json",//
			success : function(result) {
				if (result.responseMessage.success) {
					model = true;
				}
				else {
					
					model = false;
				}
			}
		});*/
		
	});
	

	$("#billTypeId").change(function() {    //凭证类型   0 重控凭证 （默认）   1 非重控凭证
		
		if ($("#billTypeId").val() == "0") {
			$("#billTplNameId").val("");
			$("#billId").show();
			$("#billTplNameId").attr("disabled",true);
			
			
		}
		else if ($("#billTypeId").val() == "1") {
			$("#billTplNameId").removeAttr("disabled");
			$("#billTplNameId").val("");
			$("#billTplCodeId").val("");
			$("#billId").hide();
		}
		
	});
	
	
	
	$("#reSealCheck").change(function(){
		var checked = $(this).is(":checked");
		if (checked) {
			$("#reSealType1").show();
		} else {
			$("#reSealType").val("");
			$("#reSealType1").hide();			
		}
	});
	
}






function initApplyDialog() {
	
		//通过交易码信息表获取  交易码 列表 ，交易码页面已设置缓存
		GPCache.remote({url:ctx +"/gss/tradeinfo/tradeInfoAction!fetch.action", callback:function(data){
			var datas = {};
			
			for (var i = 0; i < data.length; i++) {
				datas[data[i].tradeCode] = data[i].tradeName;
			}
			return datas;
		},refresh:true}, GPCache.ESS, GPType.ESS_TRADE_CODE);
		
		
		var options = "<option value=''>--请选择--</option>";		
		var objs = GPCache.get(GPCache.ESS, GPType.ESS_TRADE_CODE);
		for (var o in objs) {
			options += ("<option value=\"" + o + "\">" + o + "</option>");
		}
		$("#tradeCodeId").html(options);
			
		
		//获取实物印章列表
		GPCache.remote({url:ctx +"/sms/cache/sealType!fetch.action", callback:function(data){
			var datas = {};
			for (var i = 0; i < data.length; i++) {
				datas[data[i].type] = data[i].name;
			}
			
			
			return datas;
		}}, GPCache.SMS, GPType.SMS_SEAL_TYPE);
		
		var options = "<option value=''>--请选择--</option>";		
		var objs = GPCache.get(GPCache.SMS, GPType.SMS_SEAL_TYPE);
		for (var o in objs) {
			options += ("<option value=\"" + o + "\">" + objs[o] + "</option>");
		}
		$("#smsSealId").html(options);
		$("#reSealType").html(options);
		//实物印章类型码及名称
		$("#smsSealId").change(function() {
			var sealType = $("#smsSealId").val();
			$("#elecSealId").val(sealType);
			var sealTypeName = GPCache.get(GPCache.SMS, GPType.SMS_SEAL_TYPE,sealType)
			$("#sealTypeNameId").val(sealTypeName);
		});
		
		
		
		//通过凭证配置表获取 设置凭证模板编号 列表
		$("#tradeCodeId").change(function() {
				
		var  tradeCode = $("#tradeCodeId").val();			
		var options = "<option value=''>--请选择--</option>";			
		var objs = GPCache.get(GPCache.ESS, GPType.ESS_BILL_TPCODE,tradeCode);
		for (var i = 0; i < objs.length; i++){
			options += ("<option value=\"" + objs[i].billTplCode + "\">" + objs[i].billTplCode + "</option>");
			//options += ("<option value=\"" + objs[i] + "\">" + objs[i] + "</option>");
			bills.put(objs[i].billTplCode, objs[i].billName);
						
		}
		$("#billTplCodeId").html(options);		
		$("#billTplCodeId").change(function() {
			var code = $("#billTplCodeId").val();
			$("#billTplCodeId1").val(code);//替换select赋值
			$("#billTplNameId,#billTplNameId1").val(bills.get(code));
			
		});
						
		});
			
		
		//获取并设置电子印章编号列表
		$.post(top.ctx + "/ess/sealquery/elecSealInfoAction!fetch.action", {}, function(data) {
			var options = "<option value=''>--请选择--</option>";	
			if (data.responseMessage.success) {
				
				for (var i = 0, len = data.elecSealInfos.length; i <len; i++) {
					var sealInfo = data.elecSealInfos[i];
					sealInfos.put(sealInfo.sealSn, sealInfo);
					options += "<option value=\""+ sealInfo.sealSn +"\">" + sealInfo.sealSn + "</option>";
				}
			} 
			$("#sealSelect").html(options);
		});
		//根据电子印章号显示电子印章名称
		$("#sealSelect").change(function() {
			var sealModel = sealInfos.get($(this).val());
			
			if (sealModel) {				
				$("#sealSelect").val(sealModel.sealSn);
				$("#sealNameId, #sealNameId2").val(sealModel.sealName);		
				
				//电子印章类型码
				var moulageNo = sealModel.moulageSn;
				$.ajax({
					url : top.ctx + "/ess/moulage/elecSealMoulageAction!findSealModelInfoByMoulageNo.action",
					type : "POST",
					data : {"sealModelInfo.moulageNo" : moulageNo},
					dataType : "json",
					async : false,
					success : function(data) {
						if (data && data.responseMessage && data.responseMessage.success) {
							var sealType = data.sealModelInfo.moulageType;
							$("#elecSealId").val(sealType);
							
							var sealTypeName = GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE,sealType);
							$("#sealTypeNameId").val(sealTypeName);
							
						}
					}
				});
				
			}
			
		});
		
		
		//凭证模板编号不能重复
		var re = false;
		$("#billTplCodeId").change(function(){
			var billTplCode = $("#billTplCodeId,#billTplCodeId1").val();
			var sealConfig_Id = $("#sealConfigId").val();//主键值
			$.ajax({
				url : top.ctx + "/gss/sealconfig/sealConfigAction!check.action",
				type : "POST",
				data : {
					"sealConfig.billTplCode" : billTplCode,
					"sealConfig.autoId" : sealConfig_Id
				},
				dataType : "json",//
				success : function(result) {
					if (result.responseMessage.success) {
						re = true;
					}
					else {
						
						re = false;
					}
				}
			});
		});
	
		//不能交叉配置用印模式
/*		var model = false;
		$("#sealModeId").change(function(){
			var tradeCode = $("#tradeCodeId").val();
			var sealMode = $("#sealModeId").val();//模式
			$.ajax({
				url : top.ctx + "/gss/sealconfig/sealConfigAction!checkModel.action",
				type : "POST",
				data : {
					"sealConfig.tradeCode" : tradeCode,
					"sealConfig.sealMode" : sealMode
				},
				dataType : "json",//
				success : function(result) {
					if (result.responseMessage.success) {
						model = true;
					}
					else {
						//alert("不能交叉配置用印模式！");
						model = false;
					}
				}
			});
		});*/
		
		
		
		

		
	$("#addForm").dialog({
        autoOpen : false,
        height : 300,
        width : 600,
        resizable : false,
        modal : true,
        buttons : {
        	"保存" : function() {
        		
        		$("#billTypeId").removeAttr("disabled");
        		
        		$("#smsSealId").change();
        		$("#sealSelect").change();
        		
        		if ($("#tradeCodeId").val() == "") {
        			alert("请选择交易码！");
        			return;
        		}
        		
        		if ($("#billTplNameId").val() == "") {
        			alert("凭证名称不能为空");
        			return;
        		}
        		
        		
        		if ($("#billTypeId").val() == "0" && !re) {
                	alert("凭证模板编号不能重复！");
                	return;
        		}
        		
/*        		if (!model) {
                	alert("不能交叉配置用印模式！");
                	return;
        		}*/
        		
        		
        		if ($("#sealModeId").val() == "0") {
        			if ($("#sealSelect").val() == "") {
        				alert("请选择电子印章编号");
        				return;
        			}
        		}
        		
        		if ($("#sealModeId").val() == "1") {
        			if ($("#smsSealId").val() == "") {
        				alert("请选择实物印章类型");
        				return;
        			}
        		}
        		
        		if ( $("#reSealCheck").is(":checked")) {
        			if ($("#reSealType").val() == "") {
        				alert("请选择补盖实物印章类型");
        				return;
        			}
        		}
        		
        		if ($("#sealPosX").val() == "" || $("#sealPosY").val() == "") {
        			alert("盖章位置不能为空");
        			return;
        		}
        		//if ($("#sealModeId").val() == "1" && $("#billTypeId").val() == "0") {
        		if ($("#sealModeId").val() == "1") {
        			if ($("#billNoPosXStart").val() == "" || $("#billNoPosXEnd").val() == "" || $("#billNoPosYStart").val() == "" || $("#billNoPosYEnd").val() == ""
        				|| $("#codePosXStart").val() == "" || $("#codePosXEnd").val() == "" || $("#codePosYStart").val() =="" || $("#codePosYEnd").val() == "") {
        				alert("识别码与验证码位置不能为空");
        				return;
        			}
        		}
        		
        		
        		if ($("#billTypeId").val() == "1") {      			
        			$("input[name='sealConfig.billTplName']").val($("#billTplNameId,#billTplNameId1").val());     			
        		}
        		
    			
/*        		var datass = $("#addForm").serializeForm();
        		for ( var d in datass) {
					$("#testMsg").append(d + ", " + datass[d] + "======>");
				}*/
        		
        		var r = /^(0|\+?[1-9][0-9]*)$/;
        		if (!r.test($("#sealPosX").val()) || !r.test($("#sealPosY").val())) {
        			alert("坐标位置只能是正整数！");
        			return;
        		}
        		if ($("#billNoPosXStart").val() != "" && !r.test($("#billNoPosXStart").val()) ) {
        			alert("坐标位置只能是正整数！");
        			return;
        		}
        		if ($("#billNoPosXEnd").val() != "" && !r.test($("#billNoPosXEnd").val()) ) {
        			alert("坐标位置只能是正整数！");
        			return;
        		}
        		if ($("#billNoPosYStart").val() != "" && !r.test($("#billNoPosYStart").val()) ) {
        			alert("坐标位置只能是正整数！");
        			return;
        		}
        		if ($("#billNoPosYEnd").val() != "" && !r.test($("#billNoPosYEnd").val()) ) {
        			alert("坐标位置只能是正整数！");
        			return;
        		}
        		if ($("#codePosXStart").val() != "" && !r.test($("#codePosXStart").val()) ) {
        			alert("坐标位置只能是正整数！");
        			return;
        		}
        		if ($("#codePosXEnd").val() != "" && !r.test($("#codePosXEnd").val()) ) {
        			alert("坐标位置只能是正整数！");
        			return;
        		}
        		if ($("#codePosYStart").val() != "" && !r.test($("#codePosYStart").val()) ) {
        			alert("坐标位置只能是正整数！");
        			return;
        		}
        		if ($("#codePosYEnd").val() != "" && !r.test($("#codePosYEnd").val()) ) {
        			alert("坐标位置只能是正整数！");
        			return;
        		}
        		
        		if (parseInt($("#billNoPosXStart").val()) > parseInt($("#billNoPosXEnd").val()) ) {
        			$("#billNoPosXEnd").css("background-color","red");
        			alert("坐标结束位置不能小于起始位置！");
        			return;
        		}
        		if (parseInt($("#billNoPosYStart").val()) > parseInt($("#billNoPosYEnd").val()) ) {
        			$("#billNoPosYEnd").css("background-color","red");
        			alert("坐标结束位置不能小于起始位置！");
        			return;
        		}
        		if (parseInt($("#codePosXStart").val()) > parseInt($("#codePosXEnd").val()) ) {
        			$("#codePosXEnd").css("background-color","red");
        			alert("坐标结束位置不能小于起始位置！");
        			return;
        		}
        		if (parseInt($("#codePosYStart").val()) > parseInt($("#codePosYEnd").val()) ) {
        			$("#codePosYEnd").css("background-color","red");
        			alert("坐标结束位置不能小于起始位置！");
        			return;
        		}
        		
        		
        		
        		
        		
        		
        		var jsonSealPosStr = {startX:$("#sealPosX").val(),startY:$("#sealPosY").val()};
        		var jsonBillNoPosStr = {startX:$("#billNoPosXStart").val(),endX:$("#billNoPosXEnd").val(),startY:$("#billNoPosYStart").val(),endY:$("#billNoPosYEnd").val()};
        		var jsonCodePosStr = {startX:$("#codePosXStart").val(),endX:$("#codePosXEnd").val(),startY:$("#codePosYStart").val(),endY:$("#codePosYEnd").val()};
        		
        		
        		var valueJSON = {sealPos:jsonSealPosStr,billNoPos:jsonBillNoPosStr,codePos:jsonCodePosStr};
        		
        		$('#allPos').val(JSON.stringify(valueJSON));
        		
        		var tradeCode = $("#tradeCodeId").val();
        		var sealMode = $("#sealModeId").val();//模式
        		var sealConfig_Id = $("#sealConfigId").val();//主键值
        		$.ajax({
        			url : top.ctx + "/gss/sealconfig/sealConfigAction!checkModel.action",
        			type : "POST",
        			data : {
        				"sealConfig.tradeCode" : tradeCode,
        				"sealConfig.autoId" : sealConfig_Id,
        				"sealConfig.sealMode" : sealMode
        			},
        			dataType : "json",//
        			success : function(result) {
        				if (result.responseMessage.success) {
        					
        	        		$.post(top.ctx + "/gss/sealconfig/sealConfigAction!save.action",	
        	        				$("#addForm").serializeForm(),function(data) {
        	        			
        	        				
        	        			
        	        			if (data.responseMessage.success) {
        	        				$.success("保存成功");
        	        				
        	        				$("#billNoPosXEnd").css("background-color","");
        	        				$("#billNoPosYEnd").css("background-color","");
        	        				$("#codePosXEnd").css("background-color","");
        	        				$("#codePosYEnd").css("background-color","");
        	        				
        	        				$("#addForm").dialog("close");
        	        				$("#list").trigger("reloadGrid");
        	        				$("#list").jqGrid("search", "#search");
        	        			} else {
        	        				$.error("保存失败: " + data.responseMessage.message);
        	        			}    	        			       	        			
        	        		});
        				}
        				else {
        					alert("不能交叉配置用印模式！");
        					return;
        				}
        			}
        		});
        		
/*        		$.post(top.ctx + "/gss/sealconfig/sealConfigAction!save.action",	
        				$("#addForm").serializeForm(),function(data) {
        			
        				
        			
        			if (data.responseMessage.success) {
        				$.success("保存成功");
        				
        				$("#billNoPosXEnd").css("background-color","");
        				$("#billNoPosYEnd").css("background-color","");
        				$("#codePosXEnd").css("background-color","");
        				$("#codePosYEnd").css("background-color","");
        				
        				$("#addForm").dialog("close");
        				$("#list").trigger("reloadGrid");
        				$("#list").jqGrid("search", "#search");
        			} else {
        				$.error("保存失败: " + data.responseMessage.message);
        			}
        			
        			
        			
        		});*/
        		
        		
        		
        	}
        },
        
    	close : function() {
    		$("#addForm").validationEngine("hideAll");
    		$("#addForm")[0].reset();
    		//恢复默认界面
			$("#sms").hide();
			$("#smsPos").hide();
			$("#codePos").hide();
			$("#billId").show();
			$(".essSeal").show();
			$("#essPos").show();
			$("#billTypeId").removeAttr("disabled");
			$("#reSealCheck").attr("checked",false);
			$("#reSeal").show();
			$("#reSealType1").hide();
			$("#billTplCodeId,#billTplCodeId1").val("");
			
			$("#billNoPosXEnd").css("background-color","");
			$("#billNoPosYEnd").css("background-color","");
			$("#codePosXEnd").css("background-color","");
			$("#codePosYEnd").css("background-color","");
    	}

	});
	
	
	$("#addSealConfig").click(function(){
		
		
		$("#addForm").dialog("open");
		
		
	});
		
}

/**
 * 列表
 */
function fetchSealApllyList() {
	$("#list").jqGrid({
		caption : "用印配置信息查询",
		url : top.ctx + "/gss/sealconfig/sealConfigAction!list.action",
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "交易代码","用印模式","凭证模板编号","凭证名称","操作" ],
		colModel : [ {
			name : "tradeCode",
			index : "tradeCode",
			width : 80

		}, {
			name : "sealMode",
			index : "sealMode",
			width : 120,
			formatter : function(value, options, rData) {
				return GPCache.get(GPCache.GSS, GPType.ESS_SEAL_MODE, value);
			}
		}, {
			name : "billTplCode",
			index : "billTplCode",
			width : 100		
		}, {
			name : "billTplName",
			index : "billTplName",
			width : 90
		}, {
			name : "autoId",
			index : "autoId",
			width : 120,
			formatter : function(value, options, rData) {
				return "<input type='button'  value='修改' onclick='openUpdateParamDLG(\"" + value + "\")'/>"+
				"<input type='button'  value='删除' onclick='delApplyInfo(\"" + value + "\")'/>";
			}
		}],
		pager : "#pager"
	});
}



function openUpdateParamDLG(autoId) {
	
	$.ajax({
		type : "POST",
		url : ctx + "/gss/sealconfig/sealConfigAction!find.action",
		data : {
			"sealConfig.autoId" : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$("#billTypeId").attr("disabled",true);
				
				
				$("#addForm").dialog("open");
				var positionObj = JSON.parse(data.sealConfig.position);
				
				$("#sealPosX").val(positionObj.sealPos.startX);
				$("#sealPosY").val(positionObj.sealPos.startY);
				
				$("#billNoPosXStart").val(positionObj.billNoPos.startX);
				$("#billNoPosXEnd").val(positionObj.billNoPos.endX);
				$("#billNoPosYStart").val(positionObj.billNoPos.startY);
				$("#billNoPosYEnd").val(positionObj.billNoPos.endY);
				
				$("#codePosXStart").val(positionObj.codePos.startX);
				$("#codePosXEnd").val(positionObj.codePos.endX);
				$("#codePosYStart").val(positionObj.codePos.startY);
				$("#codePosYEnd").val(positionObj.codePos.endY);
				
				
				
				
				$("input[name='sealConfig.autoId']").val(data.sealConfig.autoId);
				$("#tradeCodeId").val(data.sealConfig.tradeCode);
				$("#sealModeId").val(data.sealConfig.sealMode);
				$("#billTypeId").val(data.sealConfig.billType);
				
				$("#tradeCodeId").change();
				$("#sealModeId").change();
				$("#billTypeId").change();
				$("#billTplCodeId").change();
				$("#smsSealId").change();
				
				if (data.sealConfig.reSealTypeId != null && data.sealConfig.reSealTypeId != "") {
					$("#reSealCheck").attr("checked",true);
					$("#reSealType1").show();
				}
				
				$("#billTplCodeId,#billTplCodeId1").val(data.sealConfig.billTplCode);				
				$("#billTplNameId,#billTplNameId1").val(data.sealConfig.billTplName);
				$("#smsSealId").val(data.sealConfig.sealTypeId);
				$("#reSealType").val(data.sealConfig.reSealTypeId);
				$("#sealSelect").val(data.sealConfig.sealSn);
				$("#sealNameId,#sealNameId2").val(data.sealConfig.sealName);
				$("input[name='sealConfig.position']").val(data.sealConfig.position);
				$("input[name='sealConfig.memo']").val(data.sealConfig.memo);
				//$("#sealTypeNameId").val(data.sealConfig.sealTypeName);
				
				
			} else {
				$.error("操作失败:" + data.responseMessage.message);
			}
		}
	});
}

function delApplyInfo(autoId) {
	if (confirm("确定删除信息？")) {
	$.ajax({
		type : "POST",
		url : ctx + "/gss/sealconfig/sealConfigAction!delete.action",
		data : {
			"sealConfig.autoId" : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				
				$.success("操作成功：用印配置信息删除成功!");
				$("#list").trigger("reloadGrid");
			}
			else {
				$.error("操作失败：" + data.responseMessage.message);
			}
		}

	});
	
	}
	return false;
}






