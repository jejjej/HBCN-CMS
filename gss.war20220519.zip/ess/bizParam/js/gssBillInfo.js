
$(function() {
	
	
	initApplyDialog();
	
	fetchSealApllyList();
		
	$("#submitForm").click(function() {
		$("#list").jqGrid("search", "#search");
	});
	
	$("#clearBtn").click(function() {
		$("#search")[0].reset();
	});
	
});


function initApplyDialog() {
	//在上一页面设置缓存
	GPCache.remote({url:ctx +"/gss/tradeinfo/tradeInfoAction!fetch.action", callback:function(data){
		var datas = {};
		//<tradeCode, tradeName>
		for (var i = 0; i < data.length; i++) {
			datas[data[i].tradeCode] = data[i].tradeName;
		}
		return datas;
	},refresh:true}, GPCache.ESS, GPType.ESS_TRADE_CODE);
	
	
	var options = "<option value=''>--请选择--</option>";		
	var objs = GPCache.get(GPCache.ESS, GPType.ESS_TRADE_CODE);
	for (var o in objs) {
		options += ("<option value=\"" + o + "\">" + o + "</option>");
	}

	$("#tradeCodeId").html(options);
	
	
	
	$("#billInfo").dialog({
        autoOpen : false,
        height : 200,
        width : 600,
        resizable : false,
        modal : true,
        buttons : {
        	"保存" : function() {     
        		
        		if ($("#tradeCodeId").val() == "") {
        			alert("请选择交易码！");
        			return;
        		}
        		
        		
        		if ($("#billTplCodeId").val() == "") {
        			alert("凭证模板编号不能为空");
        			return;
        		}
        		       		
        		if ($("#billNameId").val() == "") {
        			alert("凭证名称不能为空");
        			return;
        		}
        		
        		$.ajax({
        			url : top.ctx + "/gss/billinfo/billInfoAction!check.action",
        			type : "POST",
        			data : {
        				"billInfo.billTplCode" : $("#billTplCodeId").val(),
        				"billInfo.autoId" : $("#billInfoId").val()
        			},
        			dataType : "json",//
        			success : function(result) {
        				if (result.responseMessage.success) {
        					
        	        		$.post(top.ctx + "/gss/billinfo/billInfoAction!save.action",	
        	        				$("#billInfo").serializeForm(),function(data) {
        	        			if (data.responseMessage.success) {
        	        				$.success("保存成功");
        	        				$("#billInfo").dialog("close");       	
        	        				$("#list").jqGrid("search", "#search");      	        				
        	        			} else {
        	        				$.error("保存失败: " + data.responseMessage.message);
        	        			}
        	        			
        	        		});
        					
        				}
        				else {
        					alert("凭证模板编号不能重复！");
        					
        					return;
        				}
        			}
        		});   		
        		
/*        		$.post(top.ctx + "/gss/billinfo/billInfoAction!save.action",	
        				$("#billInfo").serializeForm(),function(data) {
        			if (data.responseMessage.success) {
        				$.success("保存成功");
        				$("#billInfo").dialog("close");
        				$("#list").trigger("reloadGrid");
        				$("#list").jqGrid("search", "#search");
        				location.reload();
        			} else {
        				$.error("保存失败: " + data.responseMessage.message);
        			}
        			
        		});*/
        	}
        },
    	close : function() {
    		$("#billInfo").validationEngine("hideAll");
    		$("#billInfo")[0].reset();   		
    	}

	});
	
	$("#addBillInfo").click(function(){
		
		$("#billInfo").dialog("open");
		
	});
		
}

/**
 * 列表
 */
function fetchSealApllyList() {
	$("#list").jqGrid({
		caption : "凭证配置信息查询",
		url : top.ctx + "/gss/billinfo/billInfoAction!list.action",
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "交易代码","凭证模板编号","凭证名称","操作" ],
		colModel : [ {
			name : "tradeCode",
			index : "tradeCode",
			width : 80//,
			
//			formatter : function(value, options, rData) {
//				return rData.tradeName+"("+value+")";
//			}
		}, {
			name : "billTplCode",
			index : "billTplCode",
			width : 100		
		}, {
			name : "billName",
			index : "billName",
			width : 90
		}, {
			name : "autoId",
			index : "autoId",
			width : 120,
			formatter : function(value, options, rData) {
				return "<input type='button'  value='修改' onclick='openUpdateParamDLG(\"" + value + "\")'/>"+
				"<input type='button'  value='删除' onclick='delApplyInfo(\"" + value + "\")'/>";
			}
		}],
		pager : "#pager"
	});
}



function openUpdateParamDLG(autoId) {
	
	$.ajax({
		type : "POST",
		url : ctx + "/gss/billinfo/billInfoAction!find.action",
		data : {
			"billInfo.autoId" : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
								
				$("#billInfo").dialog("open");
				$("input[name='billInfo.autoId']").val(data.billInfo.autoId);
				$("#tradeCodeId").val(data.billInfo.tradeCode);
				$("#billTplCodeId").val(data.billInfo.billTplCode);
				$("input[name='billInfo.billName']").val(data.billInfo.billName);
				$("input[name='billInfo.memo']").val(data.billInfo.memo);
				
			} else {
				$.error("操作失败:" + data.responseMessage.message);
			}
		}
	});
}

function delApplyInfo(autoId) {
	if (confirm("确定删除信息？")) {
	$.ajax({
		type : "POST",
		url : ctx + "/gss/billinfo/billInfoAction!delete.action",
		data : {
			"billInfo.autoId" : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				
				$.success("操作成功：凭证配置信息删除成功!");
				$("#list").trigger("reloadGrid");
			}
			else {
				$.error("操作失败：" + data.responseMessage.message);
			}
		}

	});
	
	}
	return false;
}

//离开页面，刷新后台缓存
$(window).unload(function(){
	
	//通过凭证配置表获取 凭证模板编号 列表；通过对应交易码取值
	GPCache.remote({url:ctx +"/gss/billinfo/billInfoAction!fetch.action", callback:function(data){
		var datas = {};		
		//{交易码对应多个凭证模板编号，数组key
		//   1122:[{6768: }, 1212]
		//}
		for (var i = 0; i < data.length; i++) {
			if(!datas[data[i].tradeCode]) {
				datas[data[i].tradeCode] = [];//一个值都没有
			}
			//datas[data[i].tradeCode].push(data[i].billTplCode);
			datas[data[i].tradeCode].push({billTplCode:data[i].billTplCode, billName:data[i].billName});
			
		}
		return datas;
	},refresh:true
	}, GPCache.ESS, GPType.ESS_BILL_TPCODE);
	
});



