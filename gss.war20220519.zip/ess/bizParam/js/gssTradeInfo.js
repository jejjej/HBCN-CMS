

$(function(){
	
	initDialog();
	
	initList();
	
	$("#searchBtn").click(function() {
		$("#list").jqGrid("search", "#search");
	});
	
	$("#clearBtn").click(function() {
		$("#search")[0].reset();
	});
	
	
	
});



function initDialog() {
	
	//通过业务类型信息表获取    业务类型码列表
	GPCache.remote({url:ctx +"/base/gssBizTypeInfoAction_fetch.action", callback:function(data){
		var datas = {};
		
		for (var i = 0; i < data.length; i++) {
			datas[data[i].bizCode] = data[i].bizName;
		}
		return datas;
	},refresh:true}, GPCache.ESS, GPType.ESS_BIZ_CODE);
	
	var options = "<option value=''>--请选择--</option>";		
	var objs = GPCache.get(GPCache.ESS, GPType.ESS_BIZ_CODE);
	for (var o in objs) {
		options += ("<option value=\"" + o + "\">" + o + "</option>");
	}
	$("#bizTypeCodeId").html(options);
	
	
	
	
	
	
	
	
	var re = false;
	$("#tradeCodeId").blur(function(){
		var tradeCode = $("#tradeCodeId").val();
		var tradeInfo_Id = $("#tradeInfoId").val();//主键值
		$.ajax({
			url : top.ctx + "/gss/tradeinfo/tradeInfoAction!check.action",
			type : "POST",
			data : {
				"tradeInfo.tradeCode" : tradeCode,
				"tradeInfo.autoId" : tradeInfo_Id
			},
			dataType : "json",//
			success : function(result) {
				if (result.responseMessage.success) {
					re = true;
				}
				else {
					//alert("交易码不能重复！");
					re = false;
				}
				
				
/*				if (tradeInfo_Id) {// 修改
					// 说明没取到和校验码相同的对象
					if (result.tradeInfo == null
							|| tradeInfo_Id == result.tradeInfo.autoId) {
						re = true;
					} else {
						alert("交易码不能重复！");
						re = false;
					}
				} else {// 新增
					if (result.tradeInfo == null) {
						re = true;
					} else {
						alert("交易码不能重复！");
						re = false;
					}
				}*/
				
				
			}
		});
	});
	
	
	

	
	$("#devManger").dialog({
        autoOpen : false,
        height : 240,
        width : 650,
        resizable : false,
        modal : true,
        buttons : {
        	"保存":function(){
        		
        		if (!re) {
                	alert("交易码不能重复！");
                	return;
        		}
        		
        		if ($("#tradeCodeId").val() == "") {
        			alert("交易码不能为空");
        			return;
        		}
        		
        		if ($("#tradeNameId").val() == "") {
        			alert("交易名称不能为空");
        			return;
        		}
        		
        		if ($("#bankNoId").val() == "") {
        			alert("分行号不能为空");
        			return;
        		}
        		
        		
        		
            	$.post(top.ctx + "/gss/tradeinfo/tradeInfoAction!save.action", 
            			$("#devManger").serializeForm(), function(data) {
           		            		           		          		
            		if (data.responseMessage.success) {
            			          			           			
            			$.success("保存成功");
            			$("#devManger").dialog("close");
               		 	$("#list").jqGrid("search", "#search");
               		    
					} else {
						$.error("保存失败: " + data.responseMessage.message);
					}
            		 
            	}); 
            	
        	},
		"关闭" : function() {
			$("#devManger").dialog("close");
    		$("#devManger").validationEngine("hideAll");
    		$("#devManger")[0].reset();
 
    		
		 }
      },
	
    	close : function() {
    		$("#devManger").validationEngine("hideAll");
    		$("#devManger")[0].reset();
    		

    }
	
	});
	
	$("#newDevice").click(function(){
		
		$("#devManger").dialog("open");	
		
		
	});
	
	
}



function initList() {
	$("#list").jqGrid({
		caption : "交易代码信息列表",
		url : top.ctx+"/gss/tradeinfo/tradeInfoAction!list.action",
		rowList:[10, 15, 20, 30],
		rowNum:15,
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "交易代码", "交易名称", "分行号", "业务类型码", "操作" ],
		colModel : [ {
			name : "tradeCode",
			index : "tradeCode",
			width : 200
		}, {
			name : "tradeName",
			index : "tradeName",
			width : 200
		}, {
			name : "bankNo",
			index : "bankNo",
			width : 200
		}, {
			name : "bizTypeCode",
			index : "bizTypeCode",
			width : 200
		}, {
			name : "autoId",
			index : "autoId",
			width : 200,
			formatter : function(value, options, rData) {
				return "<input type='button'  value='修改' onclick='openUpdateTradeInfo(\"" + value + "\")'/>"+
				"<input type='button'  value='删除' onclick='delTradeInfo(\"" + value + "\")'/>";
			}
		}
		],
		pager : "#pager"
	});
}


function openUpdateTradeInfo(autoId) {
		
	$.ajax({
		
		type : "POST",
		url : top.ctx + "/gss/tradeinfo/tradeInfoAction!find.action",
		data : {
			"tradeInfo.autoId" : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$("#devManger").dialog("open");
				$("input[name='tradeInfo.autoId']").val(data.tradeInfo.autoId);
				$("input[name='tradeInfo.tradeCode']").val(data.tradeInfo.tradeCode);
				$("input[name='tradeInfo.tradeName']").val(data.tradeInfo.tradeName);
				$("input[name='tradeInfo.bankNo']").val(data.tradeInfo.bankNo);
				$("#bizTypeCodeId").val(data.tradeInfo.bizTypeCode);
				$("input[name='tradeInfo.state']").val(data.tradeInfo.state);
				$("input[name='tradeInfo.memo']").val(data.tradeInfo.memo);
				
                			
			} else {
				$.error("操作失败:" + data.responseMessage.message);
			}
		}
	});
}

function delTradeInfo(autoId) {
	if (confirm("确定删除信息？")) {
	$.ajax({
		type : "POST",
		url : ctx + "/gss/tradeinfo/tradeInfoAction!delete.action",
		data : {
			"tradeInfo.autoId" : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {			
				$.success("操作成功：交易代码信息删除成功!");
				$("#list").trigger("reloadGrid");
				location.reload();
			}
			else {
				$.error("操作失败：" + data.responseMessage.message);
			}
		}

	});
	
	}
	return false;
}

//离开页面，刷新后台缓存
$(window).unload(function(){
	GPCache.remote({url:ctx +"/gss/tradeinfo/tradeInfoAction!fetch.action", callback:function(data){
		var datas = {};
		
		for (var i = 0; i < data.length; i++) {
			datas[data[i].tradeCode] = data[i].tradeName;
		}
		return datas;
	},refresh:true}, GPCache.ESS, GPType.ESS_TRADE_CODE);
	
});

