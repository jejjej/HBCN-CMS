
//数据导出JS

(function($) {
	$.fn.reportExcel  = function(form,reportURL){
		window.open(reportURL + "?" + form.serialize());
	};
})(jQuery);