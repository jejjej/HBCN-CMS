//系统基本路径
webAppName = null;
//含有IP与端口系统基本路径
webBasePath = null;
//当前登录用户
curLoginPeople = null;
function setWebAppName(){
	var strFullPath = window.document.location.href;
	var strPath = window.document.location.pathname;
	var pos = strFullPath.indexOf(strPath);
	var prePath = strFullPath.substring(0, pos);
	var postPath = strPath.substring(0, strPath.substr(1).indexOf('/') + 1);
	webAppName = postPath;
	webBasePath = prePath + postPath;
}
$(document).ready(function($) {
	setWebAppName();
});