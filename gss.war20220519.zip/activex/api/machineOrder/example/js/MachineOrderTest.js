/**
 * 创建于:2014-9-26<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 印控机测试脚本
 * 
 * @author 黄有坚
 * @version 1.0
 */

var testTimes = 0;
//INI配置文件
var iniPath ="c:/yzjgss/config/3x/gss.ini";
/**
 * 初始化设备
 */
function initMachine() {
	showResult("初始化设备",_initMachine().msg);
}

/**
 * 打开纸板
 */
function openPaperDoor() {
	showResult("打开纸板：",_openPaperDoor(checkPaperDoor).msg);
}

function checkPaperDoor(checkresult) {
	showResult("监测纸板", getOCXMsg(checkresult.code));
}

function queryBackDoor(){
	showResult("查询侧门状态：",getOCXMsg(OCX_MachineOrder.queryBackDoor().code));
}

function openBackDoor(){
	showResult("打开侧门：",getOCXMsg(OCX_MachineOrder.openBackDoor().code));
}

/**
 * 开始用印
 */
function startSeal() {
	var angle = window.document.getElementById("angle").value;
	var xPos = window.document.getElementById("xPos").value;
	var yPos = window.document.getElementById("yPos").value;
	var sealNum = window.document.getElementById("sealNum").value;
	showResult("开始用印", _startSeal(false,angle, xPos,
					yPos, sealNum, waitSeal).msg);
}

function waitSeal(status) {
	showResult("监测用印" , getOCXMsg(status.code));
}

/**
 * 关闭设备
 */
function closeMachine() {
	_closeMachine();
	showResult("关闭设备","设备已关闭");
}

function MachineTest(){
	showResult("压力测试","功能未完善，敬请期待！")
}




var interval_paperdoor;

var interval_getsealstatus;

var interval_sidedooropen;

var interval_sidedoorclose;


/**
 * 初始化设备
 * 
 * @returns 0 成功，其他 失败, 见方法machineOrder.getReturnCodeMsg
 */
function _initMachine() {
	// 定义控件,需根据控件的定义修改
	var initResult, i;

	var commType = OCX_Tools.readIni(iniPath, "gss", "commType", "0").data;
	OCX_MachineOrder.setCommType(commType);
	if (OCX_MachineOrder.openCom().data != "1"){
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._initMachine}--印控机初始化设备[initMachine][OpenCom][失败]openCom().data:"+OCX_MachineOrder.openCom().data);
		return OCXResult(OCX_MachineOrder, "9211", "");
	};
	if(OCX_MachineOrder.queryPaperDoor().data != "2"){
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._initMachine}--印控机初始化设备[initMachine][QueryPaperDoor][失败]OCX_MachineOrder.queryPaperDoor().data:"+OCX_MachineOrder.queryPaperDoor().data);
		OCX_MachineOrder.closeCom();
		return OCXResult(OCX_MachineOrder, "9223", "");
	};
	for (i = 0; i < 3; i++) {
		initResult = OCX_MachineOrder.getCalParam().data;
		if (initResult == "1")
			break;
	};
	if (initResult != "1") {
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._initMachine}--印控机初始化设备[initMachine][GetCalParam][失败]OCX_MachineOrder.getCalParam().data:"+initResult);
		OCX_MachineOrder.closeCom();
		return OCXResult(OCX_MachineOrder, "9212", "");
	};
	// initResult = machineorder.MachineLoginIn();
	// if (initResult != "1"){
	// machineorder.CloseCom();
	// return false;
	// }

	for (i = 0; i < 3; i++) {
		initResult = OCX_MachineOrder.queryMachineNumOne().data
				+ OCX_MachineOrder.queryMachineNumTwo().data;
		if (initResult != "11") {
			break;
		};
	};
	initResult = OCX_MachineOrder.queryMachineNumOne().data
				+ OCX_MachineOrder.queryMachineNumTwo().data;
	if (initResult == "11") {
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._initMachine}--印控机初始化设备[initMachine][QueryMachineNumOne&&QueryMachineNumTwo][失败]");
		OCX_MachineOrder.closeCom();
		return OCXResult(OCX_MachineOrder, "9213", "");
	};
	if (OCX_MachineOrder.openLight().data != 1){
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._initMachine}--印控机初始化设备[initMachine][OpenLight][失败]");
		OCX_MachineOrder.closeCom();
		return OCXResult(OCX_MachineOrder, "9222", "");
	};
	
	// 判断设备状态
	var machineStatus = OCX_MachineOrder.queryError();
	if("1011" != machineStatus.code){
	    OCX_MachineOrder.closeCom();
	    return machineStatus;
	}
	
	return OCXResult(OCX_MachineOrder, "1001", "");
};

/**
 * 打开纸板
 * 
 * @param callbackPaperDoorIn
 *                纸板门关闭回调函数，回调参数0 成功，其他失败，详见machineOrder.getReturnCodeMsg
 * @returns 0 成功，其他 失败, 见方法machineOrder.getReturnCodeMsg
 */
function _openPaperDoor(callbackPaperDoorIn) {
	var initResult = OCX_MachineOrder.queryMachineNumOne().data
			+ OCX_MachineOrder.queryMachineNumTwo().data;
	if (initResult == "11") {
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._openPaperDoor}--印控机打开纸板[openPaperDoor][QueryMachineNumOne&&QueryMachineNumTwo][失败]");
		return OCXResult(OCX_MachineOrder, "9213", "");
	};
	var isOpen = OCX_MachineOrder.openPaperDoor();
	OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._openPaperDoor}--印控机打开纸板[openPaperDoor][OpenPaperDoor][" + isOpen.data + "]");
	function queryDoorStatus() {
		var status = OCX_MachineOrder.queryPaperDoor().data;
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._openPaperDoor}--印控机打开纸板[openPaperDoor][QueryPaperDoor][" + status + "]");
		if (status == "2") {// 关闭
			callbackPaperDoorIn(OCXResult(OCX_MachineOrder, "1001", ""));
		} else if (status == "1") {// 未关闭
			window.setTimeout(queryDoorStatus, 1000);
		} else {// 异常
			callbackPaperDoorIn(OCXResult(OCX_MachineOrder, "9420", ""));
		};
	};
	if (isOpen.code == "1001") {// 启动定时器监测纸板门是否关闭
		interval_paperdoor = window.setTimeout(queryDoorStatus, 1000);
		return isOpen;
	} else {
		return isOpen;
	};
};



/**
 * 开始用印
 * 
 * @param isAcrossPageSeal
 *                骑缝盖章模式 true/false
 * @param sealAngle
 *                旋转角度 1~360
 * @param xPos
 *                用印X坐标(800×600分辨率下的像素坐标，右上角为坐标原点)
 * @param yPos
 *                用印Y坐标(800×600分辨率下的像素坐标，右上角为坐标原点)
 * @param sealNum
 *                印章号 1~6
 * @param callback
 *                回调函数 0 用印完成，其他用印异常，详见方法machineOrder.getReturnCodeMsg
 */
function _startSeal(isAcrossPageSeal, sealAngle, xPos, yPos, sealNum, callback) {
	try{
		var orderResult = OCX_MachineOrder.queryMachineNumOne().data
				+ OCX_MachineOrder.queryMachineNumTwo().data;
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][QueryMachineNumOne&&QueryMachineNumTwo][" + orderResult + "]");
		if (orderResult == "11") {
			OCX_MachineOrder.closeCom();
			return OCXResult(OCX_MachineOrder, "9213", "");
		};
		// 设置本次盖骑缝章,本次有效
		if(isAcrossPageSeal){
			var setAcross = OCX_MachineOrder.setAcrossPageSeal();
			OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SetAcrossPageSeal][" + setAcross.data + "]");
			if (setAcross.code != "1001"){
				OCX_MachineOrder.closeCom();
				return setAcross;
			};
		};
		
		// 设置旋转角度
		var setAngle = OCX_MachineOrder.setAngle(sealAngle);
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SetAngle][" + setAngle.code + "]");
		if (setAngle.code != "1001"){
			OCX_MachineOrder.closeCom();
			return setAngle;
		};
		// 设置印章号
		var sendSeal;
		for ( var i = 0; i < 3; i++) {
			sendSeal = OCX_MachineOrder.sendSealNum(sealNum).data;
			OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SendSealNum][" + sendSeal + "]");
			if (sendSeal == 1 || sendSeal == 3) {
				break;
			};
		};
		if (sendSeal != 1 && sendSeal != 3){
			OCX_MachineOrder.closeCom();
			return OCXResult(OCX_MachineOrder, "9217", "");
		};
		
		// 根据像素坐标计算盖章坐标
		var calMachPos = OCX_MachineOrder.calMachinePos(xPos, yPos).data;
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][calMachinePos][" + calMachPos + "]");
		if(calMachPos != null && calMachPos != ""){
			var points = calMachPos.split(",");
			if(points.length == 2){
				xPos  = points[0];
				yPos = points[1];
				OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._startSeal}--根据像素坐标转换为盖章X坐标(0.1毫米)："+xPos);
				OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._startSeal}--根据像素坐标转换为盖章Y坐标(0.1毫米)："+yPos);
			}else{
				OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][calMachinePos][返回非正常格式]");
				OCX_MachineOrder.closeCom();
				return OCXResult(OCX_MachineOrder, "9224", "");
			};
		}else{
			OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][calMachinePos][返回空值]");
			OCX_MachineOrder.closeCom();
			return OCXResult(OCX_MachineOrder, "9224", "");
		};
		var reStr;
		reStr = OCX_MachineOrder.sendX(xPos);
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SendX]["+reStr+"]");
		if (reStr.code != "1001"){
			OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SendX][失败]");
			OCX_MachineOrder.closeCom();
			return reStr;
		};
		reStr = OCX_MachineOrder.sendY(yPos);
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SendY]["+reStr+"]");
		if (reStr.code != "1001"){
			OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SendY][失败]");
			OCX_MachineOrder.closeCom();
			return reStr;
		};
		reStr = OCX_MachineOrder.sealStart();
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SealStart]["+reStr.code+"]");
		if (reStr.code != "1001"){
			OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SealStart][失败]");
			OCX_MachineOrder.closeCom();
			return reStr;
		};
		
		function querySealStatus() {
			var status = OCX_MachineOrder.sealQuery().data;
			OCX_Logger.error(LOGGER._3X,"{MachineOrderTest.querySealStatus}--开始用印[startSeal][SealQuery]["+status+"]");
			if (status == "0") {// 用印完成
				callback(OCXResult(OCX_MachineOrder, "1001", ""));
			} else if (status == "2" || status == "1") {// 用印中
				window.setTimeout(querySealStatus, 500);
			} else if (status == "4") {// 用印异常
				OCX_MachineOrder.closeCom();
				callback(OCXResult(OCX_MachineOrder, "9421", ""));
			} else if(status == "3"){
				OCX_MachineOrder.closeCom();
		    	callback(OCXResult(OCX_MachineOrder, "9000", ""));
			}else {// 异常
				OCX_MachineOrder.closeCom();
				callback(OCXResult(OCX_MachineOrder, "9421", ""));
			};
		};
		
		interval_paperdoor = window.setTimeout(querySealStatus, 500);
		return OCXResult(OCX_MachineOrder, "1001", "");
	}catch(e){
		OCX_Logger.info(LOGGER._3X,"{MachineOrderTest.querySealStatus}--机控用印异常："+e.message);
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest.querySealStatus}--开始用印[startSeal][catch][JS异常:"+e.message+"]");
		window.clearInterval(interval_paperdoor);
		OCX_MachineOrder.closeCom();
		return OCXResult(OCX_MachineOrder, "9422", "");
	};
};


/**
 * 关闭设备
 * 
 * @returns 无
 */
function _closeMachine() {
	OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._closeMachine}--关闭设备[closeMachine][关闭设备]");
	OCX_MachineOrder.closeLight();
	OCX_MachineOrder.closeCom();
};


