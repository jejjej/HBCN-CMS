/**
 * 创建于:2015-10-28<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 印控机控件 
 * @author 叶慧雄
 * @version 1.0
 */


//定义印控机控件封装对象
var OCX_MachineOrder = new Object();

/**
 * 获取印控机控件封装对象
 */
OCX_MachineOrder.getObj = function() {
	return OCXElement[ocxObject.OCX_MachineOrder["content"]["id"]];
};

OCX_MachineOrder.getAlias = function() {
	 return "MO";
};


// 印控机配置文件
OCX_MachineOrder.iniPath = "MachineOrder.ini";


/********************控件封装**************************************/

/**
 * 写INI文件
 * 参数 filePath ini文件的全路径，如C:\\a.ini
 * @param section ini中的段
 * @param key ini中的key名
 * @param value ini中key对应的value
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-26
 */
OCX_MachineOrder.writeIni = function(section, key, value) {
	try{
		//result 0：成功； 其他：失败
		var result = this.getObj().SetMachineOrder(section, key, value);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 读INI文件
 * 参数 filePath ini文件的全路径，如C:\\a.ini
 * @param section ini中的段
 * @param key ini中的key名
 * @param defaultValue ini中无值的时候赋予的默认值
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-26
 */
OCX_MachineOrder.readIni = function(section, key, defaultValue) {
	try{
		//result 0：成功； 其他：失败
		var result = this.getObj().ReadMachineOrder(section,key);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 旋转图像 V2.0
 * 输出旋转后的图像文件，覆盖输入的图像文件
 * @param imagePath 输入原始图像文件，旋转后覆盖此文件
 * @param dAngle 输入旋转角度
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @author HuangKunping
 */
OCX_MachineOrder.rotateImage = function(imagePath,dAngle){
	try{
		//result 0：成功； 其他：失败
		var result = this.getObj().RotateImage(imagePath,dAngle);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 1
 * G3X
 * 打开纸板
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.openPaperDoor = function(){
	try{
		//result 3-打开成功；其他失败
		var result = this.getObj().OpenPaperDoor();
		if(result == 3){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9214",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 2
 * G3X
 * 查询纸板状态
 * @returns obj(code,data,msg)
 * 			obj.code:"1002",纸板打开;"1003",纸板未打开;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息; 
 * @date 2015-10-21
 */
OCX_MachineOrder.queryPaperDoor = function(){
	try{
		//result 1-纸板打开；2-纸板未打开；其他失败
		var result = this.getObj().QueryPaperDoor();
		OCX_Logger.info(LOGGER._ROOT,"{OCX_MachineOrder.queryPaperDoor}--查询纸板状态[queryPaperDoor][QueryPaperDoor][" + result + "]");
		if(result == 1){
			return OCXResult(this,"1065",result);
		}else if(result == 2){
			return OCXResult(this,"1066",result);
		}else{
			return OCXResult(this,"9420",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 3
 * G3X
 * 发送盖印X坐标
 * @param X轴用印位置，单位0.1mm
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.sendX = function(x) {
	try{
		//result 1-成功；0-失败
		var result = this.getObj().SendX(x);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9218",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 4
 * G3X
 * 发送盖印y坐标
 * @param y轴用印位置，单位0.1mm
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.sendY = function(y) {
	try{
		//result 1-成功；0-失败
		var result = this.getObj().SendY(y);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9219",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 5
 * G3X & G1X
 * 发送用印编号。
 * @param sealNum 印章编号
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.sendSealNum = function(sealNum) {
	try{
		//result 1或3成功；0-失败
		var result = this.getObj().SendSealNum(sealNum);
		if(result == 1 || result == 3){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 6
 * G3X
 * 开始用印
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.sealStart = function(){
	try{
		//result 1-成功；0-失败
		var result = this.getObj().SealStart();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9220",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 7
 * G3X
 * 查询用印完成
 * @returns obj(code,data,msg)
 * 			obj.code:"1004",用印完成;"1005",正在用印;1006",用印不成功;"1007",用印不成功，已盖章;1008",用印结束;"9000",通讯异常;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.sealQuery = function(){
	try{
		//result 1-用印完成；2-正在用印；4-用印不成功；5-用印不成功，已盖章；0-用印结束；3-通讯异常
		var result = this.getObj().SealQuery();
		OCX_Logger.info(LOGGER._ROOT,"{OCX_MachineOrder.sealQuery}--获取设备状态[getMachineStatus][SealQuery]["+ result +"]");
		if(result == 1){
			return OCXResult(this,"1004",result);
		}else if(result == 2){
			return OCXResult(this,"1005",result);
		}else if(result == 4){
			return OCXResult(this,"1006",result);
		}else if(result == 5){
			return OCXResult(this,"1007",result);
		}else if(result == 0){
			return OCXResult(this,"1008",result);
		}else{
			return OCXResult(this,"9000",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 8
 * G3X
 * 取消用印(如果已发送用印命令后, 在印章没有落下之前，可以取消本次盖印，或超过规定时间不用印将自动取消)
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9000",通讯异常;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.sealCancel = function(){
	try{
		//result 1-取消成功；2-取消失败；0-通讯异常
		var result = this.getObj().SealCancel();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else if(result == 2){
			return OCXResult(this,"9200",result);
		}else{
			return OCXResult(this,"9000",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 9
 * G3X & G1X
 * 打开（后）门锁
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.openBackDoor = function(){
	try{
		//result 1-成功；0-失败
		var result = this.getObj().OpenBackDoor();
		OCX_Logger.info(LOGGER._ROOT,"{OCX_MachineOrder.openBackDoor}--获取设备状态[openBackDoor][OpenBackDoor]["+ result +"]");
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9225",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 10
 * G3X & G1X
 * 查询后门锁状态
 * @returns obj(code,data,msg)
 * 			obj.code:"1009",已打开;"1010",未打开;"9000",通讯异常;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.queryBackDoor = function(){
	try{
		//result 1-已打开；2-未打开；0-通讯异常
		var result = this.getObj().QueryBackDoor();
		OCX_Logger.info(LOGGER._ROOT,"{OCX_MachineOrder.queryBackDoor}--查询侧门状态[queryBackDoor][QueryBackDoor]["+ status +"]");
		if(result == 1){
			return OCXResult(this,"1067",result);
		}else if(result == 2){
			return OCXResult(this,"1068",result);
		}else{
			return OCXResult(this,"9000",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 11
 * G3X & G1X
 * 机器执行初始化，本初始化只是机器运行一周，对各个运动部件的检测，最后回原点的一个流程，不会对机器参数进行初始化，只是一个机器运行正常的判断
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.initialization = function(){
	try{
		//result 1-成功；0-失败
		var result = this.getObj().Initialization();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 12
 * G3X & G1X
 * 查询机器状态
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",初始化完成;"1012",正在初始化;"9000",通讯异常;"9100",16位字符串，故障码;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.queryError = function(){
	try{
		//result 1，初始化完成；2，正在初始化；-1，-2通讯异常；16位字符串，故障码
		var result = this.getObj().QueryError();
		if(result == 1){
			return OCXResult(this,"1011",result);
		}else if(result == 2){
			return OCXResult(this,"1012",result);
		}else if(result == -1 || result == -2){
			return OCXResult(this,"9000",result);
		}else{
			return OCXResult(this,"9100",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 13
 * G3X & G1X
 * 打开照明灯
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9000",通讯异常;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.openLight = function(){
	try{
		//result 1，成功；0，通讯异常
		var result = this.getObj().OpenLight();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9000",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 14
 * G3X & G1X
 * 关闭照明灯
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9000",通讯异常;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.closeLight = function(){
	try{
		//result 1，成功；0，通讯异常
		var result = this.getObj().CloseLight();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9000",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 15
 * G3X
 * 设置纸板打开延时时间
 * @param timevalue 延时时间（秒）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.setOpenDoorTime = function(timevalue){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().SetOpenDoorTime(timevalue);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 16
 * G3X
 * 查询纸板打开延时时间
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:>0，实际的延时时间（秒）；0，失败;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.queryOpenDoorTime = function(){
	try{
		//result >0，实际的延时时间（秒）；0，失败
		var result = this.getObj().QueryOpenDoorTime();
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 17
 * G3X & G1X
 * 设置门锁打开延时时间
 * @param timevalue 延时时间（秒）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.setBackDoorTime = function(timevalue){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().SetBackDoorTime(timevalue);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 18
 * G3X  & G1X
 * 查询门锁打开延时时间
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:>0，实际的延时时间（秒）；0，失败;
 *			obj.msg:提示信息;
 * @date 2015-10-27
 */
OCX_MachineOrder.queryBackDoorTime = function(){
	try{
		//result >0，实际的延时时间（秒）；0，失败
		var result = this.getObj().QueryBackDoorTime();
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 19
 * G3X 
 * 设置用印延时取消时间(超过此时间没用印将取消用印)
 * @param timevalue 延时时间（秒）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.setSealCancelTime = function(timevalue){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().SetSealCancelTime(timevalue);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 20
 * G3X
 * 查询用印延时取消时间
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:>0，实际的延时时间（秒）；0，失败;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.querySealCancelTime = function(){
	try{
		//result >0，实际的延时时间（秒）；0，失败
		var result = this.getObj().QuerySealCancelTime();
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 31
 * G3X & G1X
 * 机器编号设置1 （50）
 * 机器编号设置说明
 * 编号规则：分两次传送（机器类别+年份+机器生产序号）
 * 第一次：01 06 50 xx xxxx CRC（记录机器类别和年份）
 * 第二次：01 06 51 xx xxxx CRC（记录机器生产序号）
 * @param machinetype 机器类别
 * @param year        年份
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.setMachineNumOne = function(machinetype,year){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().SetMachineNumOne(machinetype,year);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 32
 * G3X & G1X
 * 机器编号查询1 （52）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"1013",未设置值;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:1，错误；0，未设置值。6位字符串，机器类别+年份;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.queryMachineNumOne = function(){
	try{
		//result 1，错误；0，未设置值。6位字符串，机器类别+年份
		var result = this.getObj().QueryMachineNumOne();
		if(result == 1){
			return OCXResult(this,"9200",result);
		}else if(result == 0){
			return OCXResult(this,"1013",result);
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 33
 * G3X & G1X
 * 机器编号查询2（53）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"1013",未设置值;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:1，错误；0，未设置值。8位字符串，机器生产序列号;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.queryMachineNumTwo = function(){
	try{
		//result 1，错误；0，未设置值。8位字符串，机器生产序列号
		var result = this.getObj().QueryMachineNumTwo();
		if(result == 1){
			return OCXResult(this,"9200",result);
		}else if(result == 0){
			return OCXResult(this,"1013",result);
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 34
 * G3X & G1X
 * 单片机软件版本查询(只能查询，版本号在烧程序时一起存入)（54）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"1013",未设置值;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:1，错误；0，未设置值。11位字符串，通讯类别(2)+软件类别(2)+修改号;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.queryDVersion = function(){
	try{
		//result 1，错误；0，未设置值。11位字符串，通讯类别(2)+软件类别(2)+修改号
		var result = this.getObj().QueryDVersion();
		if(result == 1){
			return OCXResult(this,"9200",result);
		}else if(result == 0){
			return OCXResult(this,"1013",result);
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 35
 * G3X & G1X
 * 上位机软件版本设置(由上位机软件定义)
 * @param machinetype 通讯类别 值<256
 * @param softtype 软件类别 值<256
 * @param alternum 修改号 值<256
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.setSoftVersion = function(machinetype,softtype,alternum){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().SetSoftVersion(machinetype,softtype,alternum);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 36
 * G3X & G1X
 * 上位机软件版本查询
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:0，错误； 6位字符串，通讯类别(2)+软件类别(2)+修改号;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.querySoftVersion = function(){
	try{
		//result 0，错误； 6位字符串，通讯类别(2)+软件类别(2)+修改号
		var result = this.getObj().QuerySoftVersion();
		if(result == 0){
			return OCXResult(this,"9200",result);
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 37
 * G3X & G1X
 * 设置机器生成序列号
 * @param machinenum 机器序列号（<16777215）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.setMachineNumTwo = function(machinenum){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().SetMachineNumTwo(machinenum);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 38
 * G3X & G1X
 * 机器时间设置（年）
 * @param year 年（2012- 9999）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.setYear = function(year){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().SetYear(year);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 39
 * G3X & G1X
 * 机器时间查询（年）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:0，失败；其他为实际年份;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.queryYear = function(){
	try{
		//result 0，失败；其他为实际年份
		var result = this.getObj().QueryYear();
		if(result == 0){
			return OCXResult(this,"9200",result);
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 40
 * G3X & G1X
 * 机器时间设置（月，日）
 * @param month 月（1-12）
 * @param day 日（1-31）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.setMD = function(month,day){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().SetMD(month,day);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 41
 * G3X & G1X
 * 机器时间查询（月，日）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:0，失败；其他为实际月日;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.queryMD = function(){
	try{
		//result 0，失败；其他为实际月日
		var result = this.getObj().QueryMD();
		if(result == 0){
			return OCXResult(this,"9200",result);
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 42
 * G3X & G1X
 * 机器时间设置（时，分，秒）
 * @param hour 时（0-23）
 * @param minute 分（0-59）
 * @param second 秒（0-59）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.setTime = function(hour,minute,second){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().SetTime(hour,minute,second);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 43
 * G1X
 * 获取机器时间（时，分，秒）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2016-01-04
 */
OCX_MachineOrder.queryTime = function(){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().QueryTime();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 45
 * G3X & G1X
 * 系统登陆(单向发送)。使用系统前需先调用
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.machineLoginIn = function(){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().MachineLoginIn();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 46
 * G3X & G1X
 * 系统退出
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.machineLoginOut = function(){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().MachineLoginOut();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 48
 * G3X & G1X
 * 删除本地系统指定的目录
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.deleteDir = function(DirName){
	try{
		//result 无意义
		var result = this.getObj().MachineLoginOut();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 49
 * G3X & G1X
 * 打开通讯口
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.openCom = function(){
	try{
		//result 1，成功；其他，失败
		var result = this.getObj().OpenCom();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 50
 * G3X & G1X
 * 关闭通讯口
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.closeCom = function(){
	try{
		//result 无意义
		var result = this.getObj().CloseCom();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 51
 * G3X 
 * 印章状态设置
 * @param forbidState 启用状态（1，启用；2，禁用）
 * @param sealNum 印章编号
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.forBidSealNum = function(forbidState,sealNum){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().ForBidSealNum(forbidState,sealNum);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 58
 * G3X
 * 盖印最远距离测量
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.farDistance = function(){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().FarDistance();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 59
 * G3X
 * 查询X轴的最远盖印距离,调用此接口需先调用FarDistance
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9400",异常;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:0，异常；>0，实际距离（mm）;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.xFarDistance = function(){
	try{
		//result 0，异常；>0，实际距离（mm）
		var result = this.getObj().XFarDistance();
		if(result == 0){
			return OCXResult(this,"9400",result);
		}else if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 60
 * G3X
 * 查询y轴的最远盖印距离,调用此接口需先调用FarDistance
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9400",异常;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:0，异常；>0，实际距离（mm）;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.yFarDistance = function(){
	try{
		//result 0，异常；>0，实际距离（mm）
		var result = this.getObj().YFarDistance();
		if(result == 0){
			return OCXResult(this,"9400",result);
		}else if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 67
 * G1X
 * 执行盖印操作
 * @param userInfo 用户信息（0-65535） 
 * @returns obj(code,data,msg)
 * 			obj.code:"1017",用印正常;"9000",通讯异常;"1014",机器发生断电重启;"1015",取消用印;"9100",机器故障;"1016",需要拍照确认;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:0，-1，通讯异常。101，机器发生断电重启；100，取消用印；102，机器故障；201，需要拍照确认。1，用印正常;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.sealStartForLGAddInfo = function(userInfo){
	try{
		//result 0，-1，通讯异常。101，机器发生断电重启；100，取消用印；102，机器故障；201，需要拍照确认。1，用印正常。
		var result = this.getObj().SealStartForLGAddInfo(userInfo);
		if(result == 1){
			return OCXResult(this,"1017",result);
		}else if(result == 0 || result == -1){
			return OCXResult(this,"9000",result);
		}else if(result == 101){
			return OCXResult(this,"1014",result);
		}else if(result == 100){
			return OCXResult(this,"1015",result);
		}else if(result == 102){
			return OCXResult(this,"9100",result);
		}else if(result == 201){
			return OCXResult(this,"1016",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 75
 * G1X
 * 柜员号设置查询
 * SetLoginPeople(peopleCode)
 * @param peopleCode 9位字符串，不足9位坐补空格，超过9位只取前9位 
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",设置成功;"9000",通讯异常;"1014",机器发生断电重启;"1015",取消用印;"9100",机器故障;"1016",需要拍照确认;"9300",调用控件方法异常;
 * 			obj.data:1，设置成功。 100，取消用印；101，机器发生过断电重启；102，机器故障；201，需要拍照确认。0，通讯异常，失败。
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.setLoginPeople = function(peopleCode){
	try{
		//result 1，设置成功。 100，取消用印；101，机器发生过断电重启；102，机器故障；201，需要拍照确认。0，通讯异常，失败。
		var result = this.getObj().SetLoginPeople(peopleCode);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else if(result == 100){
			return OCXResult(this,"1015",result);
		}else if(result == 101){
			return OCXResult(this,"1014",result);
		}else if(result == 102){
			return OCXResult(this,"9100",result);
		}else if(result == 201){
			return OCXResult(this,"1016",result);
		}else{
			return OCXResult(this,"9000",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 78
 * G1X
 * 用印编号查询(按键查询)
 * @returns obj(code,data,msg)
 * 			obj.code:"9000",通讯异常;"1014",机器发生断电重启;"1015",取消用印;"9100",机器故障;"1018",没按键发生;"1016",需要拍照确认;
 * 					 "1001",1-6对应的按键编号被按下;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:0，通讯异常。100，取消用印；101，机器发生过断电重启；102，机器故障；104，没按键发生；201，需要拍照确认。 1-6对应的按键编号被按下;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.getSealNumber = function(){
	try{
		//result 0，通讯异常。100，取消用印；101，机器发生过断电重启；102，机器故障；104，没按键发生；201，需要拍照确认。 1-6对应的按键编号被按下
		var result = this.getObj().GetSealNumber();
		if(result == 0){
			return OCXResult(this,"9000",result);
		}else if(result == 100){
			return OCXResult(this,"1015",result);
		}else if(result == 101){
			return OCXResult(this,"1014",result);
		}else if(result == 102){
			return OCXResult(this,"9100",result);
		}else if(result == 104){
			return OCXResult(this,"1018",result);
		}else if(result == 201){
			return OCXResult(this,"1016",result);
		}else if(result == 1 || result == 2 || result == 3 || result == 4 || result == 5 || result == 6){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 79
 * G1X
 * 用印日志查询
 * @returns obj(code,data,msg)
 * 			obj.code:"9000",通讯异常;"1014",机器发生断电重启;"1015",取消用印;"9100",机器故障;"1005",正在用印;"1016",需要拍照确认;
 * 					 "1025",无日志;"9400",异常;"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:0，通讯异常；1，无日志。100，取消用印；101，机器发生过断电重启；102，机器故障；103，正在用印；201，需要拍照确认。-1，异常返回值。正确有记录时返回为68位字符串，其中的意义为：日志编号（8）+日期（8，年月日）+开始时间（6，时分秒）+印章编号（2）+结束日期（6，时分秒）+用印状态（2）+发送状态（2）+当天用印次数（5）+用户信息（5）+柜员号（9）+印章编号（12）+拍照状态（3），共计68位。
 *					 用印状态(1字节)：1.用印完成 2.挂起未用印 3.取消用印 4.用印失败故障
 *					 发送状态(1字节)：3.未发送  2.已发送给上位机
 *			obj.msg:提示信息;
 * @date 2015-10-21
 * @date 2015-10-21
 */
OCX_MachineOrder.getSealRecord = function(){
	try{
		//result 0，通讯异常；1，无日志。100，取消用印；101，机器发生过断电重启；102，机器故障；103，正在用印；201，需要拍照确认。-1，异常返回值。正确有记录时返回为68位字符串
		var result = this.getObj().GetSealRecord();
		if(result == 0){
			return OCXResult(this,"9000",result);
		}else if(result == 1){
			return OCXResult(this,"1025",result);
		}else if(result == 100){
			return OCXResult(this,"1015",result);
		}else if(result == 101){
			return OCXResult(this,"1014",result);
		}else if(result == 102){
			return OCXResult(this,"9100",result);
		}else if(result == 103){
			return OCXResult(this,"1005",result);
		}else if(result == 201){
			return OCXResult(this,"1016",result);
		}else if(result == -1){
			return OCXResult(this,"9400",result);
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 80
 * G1X
 * 执行盖印操作
 * @param userInfo 用户信息。（0-65536）
 * @return 1，成功；100，取消用印；101，机器发生过断电重启；102，机器故障；201，需要拍照确认。0，-1失败。
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"1014",机器发生断电重启;"1015",取消用印;"9100",机器故障;"1016",需要拍照确认;
 * 					 "9200",失败;"9300",调用控件方法异常;
 * 			obj.data:1，成功；100，取消用印；101，机器发生过断电重启；102，机器故障；201，需要拍照确认。0，-1失败。
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.startSeal = function(userInfo){
	try{
		//result 1，成功；100，取消用印；101，机器发生过断电重启；102，机器故障；201，需要拍照确认。0，-1失败。
		var result = this.getObj().StartSeal(userInfo);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else if(result == 100){
			return OCXResult(this,"1015",result);
		}else if(result == 101){
			return OCXResult(this,"1014",result);
		}else if(result == 102){
			return OCXResult(this,"9100",result);
		}else if(result == 201){
			return OCXResult(this,"1016",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 81
 * G1X
 * 取消用印状态清除。（即确认取消按键按下事件已收到）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.receiveCanCelSuccess = function(){
	try{
		//result 1，成功；0，-1，失败
		var result = this.getObj().ReceiveCanCelSuccess();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 82
 * G3X & G1X
 * 设置配置文件路径（此路径不存放控件相关的配置信息）
 * @param strFilePath 文件全路径
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9500",文件不存在;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.setProfilePath = function(strFilePath){
	try{
		//result 0，成功；其他，文件不存在（异常码）
		var result = this.getObj().SetProfilePath(strFilePath);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9500",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 83
 * G3X & G1X
 * 在配置文件中存储信息
 * @param strsection 节点
 * @param strkey 键值
 * @param strvalue 值
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9400",异常;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.saveInfoInProFile = function(strSection,strKey,strValue){
	try{
		//result 0，正常。其他异常码
		var result = this.getObj().SaveInfoInProFile(strSection,strKey,strValue);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9400",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 84
 * G3X & G1X
 * 取配置文件中相应的键值
 * @param strSection 节点
 * @param strKey 键值
 * @param strDefult 缺省值
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:实际取到的值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.getValueInProfile = function(strSection,strKey,strDefault){
	try{
		//result 实际取到的值
		var result = this.getObj().GetValueInProfile(strSection,strKey,strDefault);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 85
 * G1X
 * 日志接收回送。系统成功接收到日志后，必须发送此指令才能做下一步操作，否则下次取到的日志依旧会是前一条的。
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.recordSuccess = function(){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().RecordSuccess();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 90
 * G3X & G1X
 * 打开指定的通讯口。当机器使用串口通讯时，可使用此接口直接打开指定的串口。当为USB通讯时，参数无效
 * @param iComm 串口编号
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.openCommN = function(iComm){
	try{
		//result 1，成功；0，失败
		var result = this.getObj().OpenCommN(iComm);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 91
 * G3X
 * 设置校准参数
 * @param angH
 * @param angV
 * @param ImageOriX
 * @param ImageOriY
 * @param disRadio
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.setCalParam = function(angH,angV,ImageOriX,ImageOriY,disRadio){
	try{
		//result 1，成功；其他，失败
		var result = this.getObj().SetCalParam(angH,angV,ImageOriX,ImageOriY,disRadio);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 92
 * G3X
 * 取校准相关参数。在计算校准位置前必须保证已经成功调用过此接口
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.getCalParam = function(){
	try{
		//result 1，成功；其他，失败
		var result = this.getObj().GetCalParam();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 93
 * G3X
 * 计算实际的盖章位置。
 * @param iPosX，iPosY为800*600图上取得的坐标。
 * @param iPosX，iPosY为800*600图上取得的坐标。
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:”XXX，XXX”。分别为实际的x，y轴坐标，将其发送给盖章机盖章即可;
 *			obj.msg:提示信息;
 * @date 2015-10-21
 */
OCX_MachineOrder.calMachinePos = function(iPosX,iPosY){
	try{
		//result ”XXX，XXX”。分别为实际的x，y轴坐标，将其发送给盖章机盖章即可
		var result = this.getObj().CalMachinePos(iPosX,iPosY);
		OCX_Logger.info(LOGGER._ROOT,"{OCX_MachineOrder.calMachinePos}--计算实际的盖章位置[calMachinePos][CalMachinePos][" + result + "]");
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 94
 * G3X
 * 印章放回章库
 * @returns obj(code,data,msg)
 * 			obj.code:"1026",有印章需要放回;"10276",章已放回章库;"9000",通讯异常;"9300",调用控件方法异常;
 * 			obj.data:1，有印章需要放回；2，章已放回章库；0，通讯异常;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.sealBack = function(){
	try{
		//result 1，有印章需要放回；2，章已放回章库；0，通讯异常
		var result = this.getObj().SealBack();
		if(result == 1){
			return OCXResult(this,"1026",result);
		}else if(result == 2){
			return OCXResult(this,"1027",result);
		}else{
			return OCXResult(this,"9000",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 95
 * G3X & G1X
 * 设置机器类别。此接口会导致配置文件的的类型无效
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.setMachineType = function(iMType){
	try{
		this.getObj().SetMachineType(iMType);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 96
 * G3X & G1X
 * 银行设备编号设置
 * @param strsn 编号字符串。超过20位截断
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.setMachineSN = function(strsn){
	try{
		//result 0，成功；其他，失败
		var result = this.getObj().SetMachineSN(strsn);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9230",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 97
 * G3X & G1X
 * 银行设备编号查询
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9400",异常;"9300",调用控件方法异常;
 * 			obj.data:-1，-2异常； 其他实际的编号字串;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.queryMachineSN = function(){
	try{
		//result -1，-2异常； 其他实际的编号字串
		var result = this.getObj().QueryMachineSN();
		if(result == -1 || result == -2){
			return OCXResult(this,"9400",result);
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 102
 * G1X
 * 印章编号设置
 * @param strSealsn 印章编号。超过12位截断
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.setSealSN = function(strSealsn){
	try{
		//result 0，成功；其他，失败
		var result = this.getObj().SetSealSN(strSealsn);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 103
 * G1X
 * 印章编号查询
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9000",通讯异常;"9300",调用控件方法异常;
 * 			obj.data:-1，-2通讯异常；其他字符串，实际的印章编号;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.querySealSN = function(){
	try{
		//result -1，-2通讯异常；其他字符串，实际的印章编号
		var result = this.getObj().QuerySealSN();
		if(result == -1 || result == -2){
			return OCXResult(this,"9000",result);
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 104
 * G1X
 * 取印章模块
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.getStampModule = function(){
	try{
		//result 1，成功；其他，失败
		var result = this.getObj().GetStampModule();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 105
 * G1X
 * 单片机软件类别查询
 * @returns obj(code,data,msg)
 * 			obj.code:"1028",代表机器种类为G1100;
 * 					 "1029",代表机器种类为G1200;
 * 					 "1030",代表机器种类为G1300;
 * 					 "1031",代表机器种类为G1400;
 * 					 "1032",代表机器种类为G1500;
 * 					 "1033",代表机器种类为G1600;
 * 					 "1034",代表机器种类为G2100;
 * 					 "9200",失败;"9300",调用控件方法异常;
 * 			obj.data:<=0 ，失败； >0 软件类别。;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.getMachineType = function(){
	try{
		//result <=0 ，失败； >0 软件类别。具体返回值（yy）如下：
		//			yy = 11//代表机器种类为G1100
		//		 	yy = 12//代表机器种类为G1200
		// 			yy = 13//代表机器种类为G1300
		//  		yy = 14//代表机器种类为G1400
		//  		yy = 15//代表机器种类为G1500
		//  		yy = 16//代表机器种类为G1600
		//  		yy = 21//代表机器种类为G2100
		var result = this.getObj().GetMachineType();
		if(result == 11){
			return OCXResult(this,"1028",result);
		}else if(result == 12){
			return OCXResult(this,"1029",result);
		}else if(result == 13){
			return OCXResult(this,"1030",result);
		}else if(result == 14){
			return OCXResult(this,"1031",result);
		}else if(result == 15){
			return OCXResult(this,"1032",result);
		}else if(result == 16){
			return OCXResult(this,"1033",result);
		}else if(result == 21){
			return OCXResult(this,"1034",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 106
 * G1X
 * 拍照回应。当其他返回需要拍照时需回送此指令清除拍照标志
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.photoFinishReply = function(){
	try{
		//result 0，成功；其他，失败
		var result = this.getObj().PhotoFinishReply();
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 107
 * G1X
 * 查询机器（印章模块）回原点，用于判断是否可以拍照。
 * @return <0  通讯异常；成功返回值，组成 x * 100 + y  其中X=3 不再原点， =5 在原点。
 * 				Y取值：  0---表示断电重启 >=1---表示没有断电重启
 * 					    2---表示正常回应  4---表示取消用印
 * 						5—故障标志	6—正在用印 7—拍照异常
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9000",通讯异常;"9300",调用控件方法异常;
 * 			obj.data:<0  通讯异常；成功返回值，组成 x * 100 + y  其中X=3 不再原点， =5 在原点。
 * 					 Y取值：  0---表示断电重启 >=1---表示没有断电重启
 * 					     	 2---表示正常回应  4---表示取消用印
 * 							 5—故障标志	6—正在用印 7—拍照异常;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.queryMachinePos = function(){
	try{
		//result <0  通讯异常；成功返回值
		var result = this.getObj().QueryMachinePos();
		if(result <0){
			return OCXResult(this,"9000",result);
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 108
 * G3X & G1X
 * 设置机器使用的通讯接口方式
 * @param  iType 1为usb通讯；0为串口通讯，默认为0；
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.setCommType = function(iType){
	try{
		this.getObj().SetCommType(iType);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 114
 * G3X 
 * 设置盖章时需要旋转的角度。
 * @param iAngle 角度值（度）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.setAngle = function(iAngle){
	try{
		//result 0，成功；其他，失败
		var result = this.getObj().SetAngle(iAngle);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9216",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 115
 * G3X
 * 设置使用盖骑缝章，设置后只使用一次，如果再次使用需重新设置
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.setAcrossPageSeal = function(){
	try{
		//result 0，成功；其他，失败
		var result = this.getObj().SetAcrossPageSeal();
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9215",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 116
 * G1X
 * 获取纸板感应开关状态
 * @returns obj(code,data,msg)
 * 			obj.code:"1035",有纸遮挡;"1036",无纸遮挡;"9000",通讯异常;"9300",调用控件方法异常;
 * 			obj.data:1有纸遮挡；2无纸遮挡； <0 ,通讯异常;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.getPaperSensorStatus = function(){
	try{
		//result 1有纸遮挡；2无纸遮挡； <0 ,通讯异常
		var result = this.getObj().GetPaperSensorStatus();
		if(result == 1){
			return OCXResult(this,"1035",result);
		}else if(result == 2){
			return OCXResult(this,"1036",result);
		}else {
			return OCXResult(this,"9000",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 120
 * G1X
 * 软件编号查询
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:空失败 正常返回值 类似 G1610..... 共11长度字符串;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.queryChipSoftVersion = function(){
	try{
		//result 空失败 正常返回值 类似 G1610..... 共11长度字符串
		var result = this.getObj().QueryChipSoftVersion();
		if(/^\s*$/g.test(result)){
			return OCXResult(this,"9200","");
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 121
 * G3X & G1X
 * 获取灯亮度
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:0-8，成功；其他失败;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.getBrightness = function(){
	try{
		//result 0-8，成功；其他失败
		var result = this.getObj().GetBrightness();
		if(0<=result && 8>=result){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 122
 * G3X & G1X
 * 设置灯亮度
 * @param lBright 亮度值（1-8）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.setBrightness = function(lBright){
	try{
		//result 0，成功；其他，失败
		var result = this.getObj().SetBrightness(lBright);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9229",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 126
 * G1X
 * 运行模式。此接口给农总行开发使用。
 * @param iMode  1，可以接收外部控制；0，不接受外部控制
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.setRunningMode = function(iMode){
	try{
		this.getObj().SetRunningMode(iMode);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 127
 * G1X
 * 纸板电磁铁控制
 * @param iStatus 1打开（压纸）；2关闭（取消压纸）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.setPressboard = function(iStatus){
	try{
		//result 0，成功；其他，失败
		var result = this.getObj().SetPressboard(iStatus);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 128
 * G3X & G1X
 * 延时
 * @param  lTime 延时时间（毫秒）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.ocxSleep = function(lTime){
	try{
		this.getObj().OcxSleep(lTime);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 130
 * G1X
 * 设置骑缝章角度
 * @param lAngle
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.setPagingSealAngle = function(lAngle){
	try{
		//result 0，成功；其他，失败
		var result = this.getObj().SetPagingSealAngle(lAngle);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 131
 * G1X
 * 印章数量设置
 * @param lnum 实际可使用的印章数量
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.setSealNum = function(lnum){
	try{
		//result 0，成功；其他，失败
		var result = this.getObj().SetSealNum(lnum);
		OCX_Logger.info(LOGGER._ROOT,"{OCX_MachineOrder.setSealNum}--开始用印[startSeal][SetSealNum][" + result + "]");
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 132
 * G1X
 * 印章数量查询
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:<0，失败；>0，设置的印章数量;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.querySealNum = function(){
	try{
		//result <0，失败；>0，设置的印章数量
		var result = this.getObj().QuerySealNum();
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 133
 * G1X
 * 激光头指示灯控制
 * @param lSeq，(=1号激光头，=2号激光头)
 * @param lStatus (1打开，2关闭)
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.setLaserLampStatus = function(lSeq,lStatus){
	try{
		//result 0，成功；其他，失败
		var result = this.getObj().SetLaserLampStatus(lSeq,lStatus);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 145
 * G3X
 * 获取印章详细信息
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:-1，失败；成功返回字符串：槽位号：章号，槽位号：章号….  例（ 1：2，2：1……）;
 *			obj.msg:提示信息;
 * @date 2015-10-27
 */
OCX_MachineOrder.getSealInfo = function(){
	try{
		//result -1，失败；成功返回字符串：槽位号：章号，槽位号：章号….  例（ 1：2，2：1……）
		var result = this.getObj().GetSealInfo();
		if(result == -1){
			return OCXResult(this,"9226",result);
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 147
 * G3X
 * 修改盖骑缝章摆动振幅的个数
 * @param iNum 振幅个数（2-50)
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-27
 */
OCX_MachineOrder.setAmplitudeNum = function(iNum){
	try{
		//result <0失败；0成功
		var result = this.getObj().SetAmplitudeNum(iNum);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9227",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 165
 * G3X
 * 异常时打开纸板
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.openBackDoorAbnormal = function(){
	try{
		//result 1 成功，0 失败
		var result = this.getObj().OpenBackDoorAbnormal();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 166
 * G3X
 * 关闭外置照明灯
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.closeOutLayLight = function(){
	try{
		//result 1 成功，0 失败
		var result = this.getObj().CloseOutLayLight();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 167
 * G3X
 * 设置外置照明灯亮度
 * @param valum 亮度值（1-5，1为最亮，5为最暗）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.setOutLayLight = function(valum){
	try{
		//result 1 成功，0 失败
		var result = this.getObj().SetOutLayLight(valum);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 168
 * G3X
 * 查询外置照明灯亮度
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:照明灯亮度（1-5，1为最亮，5为最暗）;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.queryOutLayLight = function(){
	try{
		//result 照明灯亮度（1-5，1为最亮，5为最暗）
		var result = this.getObj().QueryOutLayLight();
		if(result >=1 && result <=5){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 169
 * G3X
 * X轴距离采集执行
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.disCollectX = function(){
	try{
		//result 1 成功，0 失败
		var result = this.getObj().DisCollectX();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 170
 * G3X
 * Y轴距离采集执行
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.disCollectY = function(){
	try{
		//result 1 成功，0 失败
		var result = this.getObj().DisCollectY();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 171
 * G3X
 * 初始化机器Flash参数
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.initMachineFlash = function(){
	try{
		//result 1 成功，0 失败
		var result = this.getObj().InitMachineFlash();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 172
 * G3X
 * 设置盖印位置校准参数
 * @param num功能号	1 ：X像素值；2 ：Y像素值
 *					3 ：X毫米值；4 ：Y毫米值
 *					5 ：X区间值(像素)；6 ：Y区间值(像素)
 * @param Value ：为相应的值
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.calibrationStampPos = function(num,value){
	try{
		//result 1 成功，0 失败
		var result = this.getObj().CalibrationStampPos(num,value);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 173
 * G3X
 * 查询盖印位置校准参数
 * @param num功能号	1 ：X像素值；2 ：Y像素值
 *					3 ：X毫米值；4 ：Y毫米值
 *					5 ：X区间值(像素)；6 ：Y区间值(像素)
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回对应项的值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.longQueryStampPos = function(num){
	try{
		//result 对应项的值
		var result = this.getObj().longQueryStampPos(num);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 174
 * G3X
 * 清除盖印位置校准参数
 * @param num功能号	1 ：X像素值；2 ：Y像素值
 *					3 ：X毫米值；4 ：Y毫米值
 *					5 ：X区间值(像素)；6 ：Y区间值(像素)
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.clearStamoPos = function(num){
	try{
		//result 1 成功，0 失败
		var result = this.getObj().ClearStamoPos(num);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 175
 * G3X
 * 查询单片机故障
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:4个8位构成32位数据记入当前故障状态。机器关机恢复无故障，具体如下：
 * 				0x00000001	//X轴原点限位故障
 * 				0x00000002	//X轴终点限位故障
 * 				0x00000004	//X轴电机故障
 * 				0x00000008	//Y轴原点限位故障
 * 				0x00000010	//Y轴终点限位故障
 * 				0x00000020	//Y轴电机故障
 * 				0x00000040	//Z轴原点限位故障
 * 				0x00000080	//Z轴终点限位故障
 * 				0x00000100	//Z轴电机故障
 * 				0x00000200	//盖章过程中门打开了
 * 				0x00000800	//没有印油盒
 * 				0x00001000	//抓章故障,当前章库无此章
 * 				0x00002000	//盖章故障
 * 				0x00004000	//抓章过程中,未将章抓出,章号识别为0
 * 				0x00008000	//抓章过程中,章识别故障,或者传感器错误,章号识别为7
 * 				0x00010000	//用印超时
 * 				0x00020000	//初始化的时候识别章头的号为7
 * 				0x00040000	//盖章过程章章号识别不稳定错误
 * 				0x00080000	//盖章结束后,章号识别为0
 * 				0x00100000	//盖章结束后,章识别故障,或者传感器错误,章号识别为7
 * 				0x00200000	//上次抓章没有放过去,初始化检测的时候抓章头上的章和没放换回去的章不相符
 * 				0x00400000	//从来没有执行初始化,没有读到章库中装了什么章号
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.querySCMFault = function(){
	try{
		//result 当前故障状态
		var result = this.getObj().QuerySCMFault();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 176
 * G3X
 * 印章号禁用读取
 * @param sealNum 印章号
 * @returns obj(code,data,msg)
 * 			obj.code:"1037",启用;"1038",禁用;"9400",异常;"9300",调用控件方法异常;
 * 			obj.data:0 异常，1 启用，2 禁用;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.readForbidStampNum = function(sealNum){
	try{
		//result 0 异常，1 启用，2 禁用
		var result = this.getObj().ReadForbidStampNum(sealNum);
		if(result == 1){
			return OCXResult(this,"1037",result);
		}else if(result == 2){
			return OCXResult(this,"1038",result);
		}else{
			return OCXResult(this,"9400",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 177
 * G1X
 * 当天盖印次数查询
 * @param sealnum 印章号
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:-1失败，其他值为盖印次数;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.querySealNumOneDay = function(sealnum){
	try{
		//result -1失败，其他值为盖印次数
		var result = this.getObj().QuerySealNumOneDay(sealnum);
		if(result != -1 ){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 178
 * G1X
 * 日志查询状态
 * @returns obj(code,data,msg)
 * 			obj.code:"1039",空闲;"1040",正在查找;"1041",查找完毕，没有相关数据;"1042",超出查找范围;"1043",系统正忙;
 * 					 "1044",数据查完已发送;"1045",错误;"9300",调用控件方法异常;
 * 			obj.data:1 空闲；2 正在查找；3 查找完毕，没有相关数据；4 超出查找范围；5 系统正忙；6 数据查完已发送；0 错误;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.readLogStatus = function(){
	try{
		//result 1 空闲；2 正在查找；3 查找完毕，没有相关数据；4 超出查找范围；5 系统正忙；6 数据查完已发送；0 错误
		var result = this.getObj().ReadLogStatus();
		if(result == 1){
			return OCXResult(this,"1039",result);
		}else if(result == 2){
			return OCXResult(this,"1040",result);
		}else if(result == 3){
			return OCXResult(this,"1041",result);
		}else if(result == 4){
			return OCXResult(this,"1042",result);
		}else if(result == 5){
			return OCXResult(this,"1043",result);
		}else if(result == 6){
			return OCXResult(this,"1044",result);
		}else{
			return OCXResult(this,"1045",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 179
 * G3X
 * 返回控件运行路径
 * @return 返回控件运行路径字符串
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:返回控件运行路径字符串;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.instanceRunPath = function(){
	try{
		//result 返回控件运行路径字符串
		var result = this.getObj().InstanceRunPath();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 180
 * G3X
 * 查询后门打开时间
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:年月日字符串（2015-09-31）;-1、-2查询失败;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.querryBackDoorOpenTime = function(){
	try{
		//result 年月日字符串（2015-09-31）;-1、-2查询失败
		var result = this.getObj().QuerryBackDoorOpenTime();
		if(result != -1 && result != -2 ){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 181
 * G3X
 * 清除后门打开时间
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.clearOpenBackDoorTime = function(){
	try{
		//result 1 成功，0 失败
		var result = this.getObj().ClearOpenBackDoorTime();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 182
 * G3X
 * 查询后门关闭时间
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:年月日字符串（2015-09-31）;-1、-2查询失败;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.querryBackDoorCloseTime = function(){
	try{
		//result 年月日字符串（2015-09-31）;-1、-2查询失败
		var result = this.getObj().QuerryBackDoorCloseTime();
		if(result != -1 && result != -2 ){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 183
 * G3X
 * 清除后门关闭时间
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.clearBackDoorCloseTime = function(){
	try{
		//result 1 成功，0 失败
		var result = this.getObj().ClearBackDoorCloseTime();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 184
 * G3X
 * 打开指定的PID_VID通讯口
 * @param DeviceName:PID_VID字符串
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.openComString = function(DeviceName){
	try{
		//result 1，成功；其他，失败
		var result = this.getObj().OpenComString(DeviceName);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 185
 * G3X
 * 生成指定目录
 * @param sDirName：需生成目录的路径
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.createDirectoryFun = function(sDirName){
	try{
		//result TRUE：成功 。FALSE：不成功
		var result = this.getObj().CreateDirectoryFun(sDirName);
		if(result){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 186
 * G3X
 * 生成指定的strFileName文件，并将数据strData写入文件
 * @param strData：需写入的数据
 * @param strFileName:存储数据文件全路径
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9501",指定文件的路径错误;"9502",没有指定文件名或者没有后缀名;"9503",写入数据失败;
 * 					 "9200",失败;"9300",调用控件方法异常;
 * 			obj.data:"0":成功 。 "1":指定文件的路径错误。 "2":没有指定文件名或者没有后缀名。 "3":写入数据失败。;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.writeDatainFile = function(strData,strFileName){
	try{
		//result "0":成功 。 "1":指定文件的路径错误。 "2":没有指定文件名或者没有后缀名。 "3":写入数据失败。
		var result = this.getObj().WriteDatainFile(strData,strFileName);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else if(result == 1){
			return OCXResult(this,"9501",result);
		}else if(result == 2){
			return OCXResult(this,"9502",result);
		}else if(result == 3){
			return OCXResult(this,"9503",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 187
 * G3X
 * 复制指定文件全路径到指定文件夹
 * @param srcFile：需复制的源文件全路径。
 * @param desDir：目标目录（注：如果是同一级目录则生成复件，如果传入的是目录下文件则将会把源文件的内容复制到目标文件
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.copyFileToDir = function(srcFile,desDir){
	try{
		//result "0"：复制成功；"1": 失败。
		var result = this.getObj().CopyFileToDir(srcFile,desDir);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 188
 * G3X
 * 删除文件夹及文件夹内容
 * @param srcDir： 需删除的文件夹路径
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * @date 2015-10-22
 */
OCX_MachineOrder.removeDirA = function(srcDir){
	try{
		//result "0"：复制成功；"1": 失败。
		var result = this.getObj().RemoveDirA(srcDir);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 切片处理
 * @param strImagePath:图片路径
 * @param strSubPath：切片保存目录（jpg）
 * @param left 	坐
 * @param top	上
 * @param right	右
 * @param bottom下
 * @date 2015-10-22
 */
OCX_MachineOrder.getRectImage = function(strImagePath, strSubPath, left, top, right, bottom) {
	try{
		this.getObj().GetRectImage(strImagePath,  strSubPath, left, top, right, bottom);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 查询印章是否蘸印油（0：蘸印油 1:不蘸印油）
 *  -1:读取数据失败 -2:查询失败 
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9512",读取数据失败;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;(如：“010101”,第一位”0”：一号章蘸印油,第二位”1”：二号章不蘸印油,...... ; -1:读取数据失败 -2:查询失败 )
 *			obj.msg:提示信息;
 */
OCX_MachineOrder.querySealNoOil = function(){
	try{
		var result = this.getObj().QuerySealNoOil();
		if(result == -1){
			return OCXResult(this,"9512",result);
		}else if(result == -2){
			return OCXResult(this,"9200",result);
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置印章是否蘸印油（默认蘸印油）
 * @param s1 1号章 （0：蘸印油 1:不蘸印油。）
 * @param s2 2号章 （0：蘸印油 1:不蘸印油。）
 * @param s3 3号章 （0：蘸印油 1:不蘸印油。）
 * @param s4 4号章 （0：蘸印油 1:不蘸印油。）
 * @param s5 5号章 （0：蘸印油 1:不蘸印油。）
 * @param s6 6号章 （0：蘸印油 1:不蘸印油。）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9512",读取数据失败;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_MachineOrder.setSealNoOil = function(s1, s2, s3, s4, s5, s6){
	try{
		var result = this.getObj().SetSealNoOil(s1, s2, s3, s4, s5, s6);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else if(result == -1){
			return OCXResult(this,"9512",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置印章不蘸印油，在每次发选择章号命令前发送不要蘸印油接口命令，机器就不会蘸印油盖章，只有一次有效，下次必须设定才能生效，默认不发命令是蘸印油的
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_MachineOrder.notSealOil = function(){
	try{
		var result = this.getObj().NotSealOil();
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 打开外置照明灯
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_MachineOrder.sealStartForLG = function(){
	try{
		this.getObj().SealStartForLG();
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 关闭外置照明灯
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_MachineOrder.closeOutLayLight = function(){
	try{
		this.getObj().CloseOutLayLight();
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置外置照明灯亮度
 * @param 亮度值1-5  1最亮 5最暗
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_MachineOrder.setOutLayLight = function(val){
	try{
		this.getObj().SetOutLayLight(val);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取控件版本号
 * 
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_MachineOrder.queryChipSoftVersion = function(){
	try{
		var result = this.getObj().QueryChipSoftVersion();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 清空目录
 * @param dir 本地目录地址
 */
OCX_MachineOrder.deletedir = function(dir){
	try{
		this.getObj().Deletedir(dir);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 控制滚轴，0停止 1开始 
 */
OCX_MachineOrder.SetPaperRoll = function(iStatus){
	return this.getObj().SetPaperRoll(iStatus);
}

/**
 * 设置滚轴速度，默认260
 */
OCX_MachineOrder.SetPaperRollSpeed = function(iSpeed){
	return this.getObj().SetPaperRollSpeed(iSpeed);
}

/**
 * 获取印章校准参数ex
 * 
 * @returns obj(code,data,msg)
 * 						obj.code:"10:"1001",失败;"9300",调用控件方法异常;
 * 						obj.data:控件原:控件原始返回值;
 *						obj.msg:提示信:提示信息;
 */
OCX_MachineOrder.getCalParamEx = function(sealNum){
	try{
		var result = this.getObj().GetCalParamEx(sealNum);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};



/**
 * 计算坐标位置ex
 * 
 * @returns obj(code,data,msg)
 * 						obj.code:"10:"1001",失败;"9300",调用控件方法异常;
 * 						obj.data:控件原:控件原始返回值;
 *						obj.msg:提示信:提示信息;
 */
OCX_MachineOrder.calMachinePosEx = function(sealNum,iPosX,iPosY){
	try{
		var result =this.getObj().CalMachinePosEx(sealNum,iPosX,iPosY);
		OCX_Logger.info("计算实际的盖章位置[calMachinePos][CalMachinePos][" + result + "]", "gsshd");
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

