/**
 * 创建于:2015-10-28<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 验印控件js封装 
 * @author 叶慧雄
 * @version 1.0
 */

// 定义验印控件封装对象
var OCX_SealRecog = new Object();

/**
 * 获取验印控件封装对象
 */
OCX_SealRecog.getObj = function() {
	return OCXElement[ocxObject.OCX_SealRecog["content"]["id"]];
};

OCX_SealRecog.getAlias = function() {
	 return "SR";
};
/**
 * 控件初始化
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_SealRecog.initCtrl = function(){
	try{
		var result = this.getObj().InitCtrl();
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 控件反初始化
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_SealRecog.unInitCtrl = function(){
	try{
		this.getObj().UnInitCtrl();
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 根据传入的文件路径加载图像
 * @param lspImagePath 文件路径，支持jpg，bmp，tif图像，图像位深支持黑白1位，灰度8位，彩色24位
 * @param lType lType =0, BMP
 * 				lType =1, JPG
 * 				lType =2, TIF
 * 				lType =3,其它
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，图像句柄，使用完毕后需要使用FreeImage进行资源释放。0为调用失败，>0为调用成功;
 *			obj.msg:提示信息;
 */
OCX_SealRecog.loadImage = function(lspImagePath, lType){
	try{
		var result = this.getObj().LoadImage(lspImagePath, lType);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 验印严格性参数设置
 * @param lImagePtr  传入图像句柄
 * @param lspImagePath 图像保存绝对路径
 * @param lType lType =0, BMP
 * 				lType =1, JPG
 * 				lType =2, TIF
 * @param lQuality 压缩质量(1-100)
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_SealRecog.saveImage = function(lImagePtr, lspImagePath, lType, lQuality){
	try{
		var result = this.getObj().SaveImage(lImagePtr, lspImagePath, lType, lQuality);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 释放图像资源
 * @param lImagePtr  图像句柄，如LoadImage返回的图像句柄
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * 注意：一个图像句柄调用函数AddImageForList加入一个图像链表后，则不能使用FreeImage释放，必须使用FreeImageList进行释放，且不能再加入另外一个链表了。如果需要使用该图像加入另外一个链表，可以使用CopyImage拷贝一份加入即可。
 */
OCX_SealRecog.freeImage = function(lImagePtr){
	try{
		var result = this.getObj().FreeImage(lImagePtr);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 拷贝图像资源
 * @param lImagePtr  需要Copy的图像句柄
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，图像句柄，使用完毕后需要使用FreeImage进行资源释放。0为调用失败，>0为调用成功;
 *			obj.msg:提示信息;
 */
OCX_SealRecog.freeImage = function(lImagePtr){
	try{
		var result = this.getObj().FreeImage(lImagePtr);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 验印严格性参数设置
 * @param lImageListPtr 传入图像列表句柄
 * 						如果lImageListPtr = 0，则创建的列表以lImagePtr为列表头，且没有发生内存的拷贝
 * 						如果lImageListPtr > 0，新增到列表最后
 * @param lImagePtr 需要加入列表的图像句柄，追加在列表最后
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，新的图像列表句柄。0为调用失败，>0为调用成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.addImageForList = function(lImageListPtr, lImagePtr){
	try{
		var result = this.getObj().AddImageForList(lImageListPtr, lImagePtr);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取图像列表中包含的图像个数
 * @param lImageListPtr 传入图像列表句柄
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，图像个数。0为调用失败，>0为调用成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.getImageListCount = function(lImageListPtr){
	try{
		var result = this.getObj().GetImageListCount(lImageListPtr);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取图像列表中指定的图像句柄
 * @param lImageListPtr 传入图像列表句柄
 * @param lImageIndex 需要获取的图像的索引值，从0开始
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，图像句柄，列表中的单个图像不需要单独释放，因为已经有列表释放函数。。0为调用失败，>0为调用成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.getImageListPtr = function(lImageListPtr, lImageIndex){
	try{
		var result = this.getObj().GetImageListPtr(lImageListPtr, lImageIndex);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 释放图像列表资源
 * @param lImageListPtr 传入图像列表句柄
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，0为成功，其它为失败。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.freeImageList = function(lImageListPtr){
	try{
		var result = this.getObj().FreeImageList(lImageListPtr);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 针对印鉴颜色进行图像二值化
 * @param lImagePtr 传入需要二值化的彩色图像句柄
 * @param lColorType 印鉴颜色，0红，1蓝，2黑
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，二值图像句柄。0为调用失败，>0为调用成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.getBinImage = function(lImagePtr, lColorType){
	try{
		var result = this.getObj().GetBinImage(lImagePtr, lColorType);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 针对印鉴颜色进行图像二值化，扫描仪与拍照设备分开处理。
 * @param lImagePtr 传入需要二值化的彩色图像句柄
 * @param lColorType 印鉴颜色，0红，1蓝，2黑
 * @param lThres 扫描仪传入-100，拍照设备传入-400
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，二值图像句柄。0为调用失败，>0为调用成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.getBinImageEx = function(lImagePtr, lColorType, lThres){
	try{
		var result = this.getObj().GetBinImageEx(lImagePtr, lColorType, lThres);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 根绝输入的坐标，对图像进行剪切。
 * @param lImagePtr 需要剪切的图像的句柄，可以将彩色印章切割出来
 * @param lLeft 坐标左边
 * @param lTop 坐标上边
 * @param lRight 坐标右边
 * @param lBottom 坐标下边
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，图像句柄。0为调用失败，>0为调用成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.getRectImage = function(lImagePtr, lLeft, lTop, lRight, lBottom){
	try{
		var result = this.getObj().GetRectImage(lImagePtr, lLeft, lTop, lRight, lBottom);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 旋转图像
 * @param lImagePtr 传入图像句柄
 * @param dfAngle 旋转角度
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，旋转后的图像句柄。0为调用失败，>0为调用成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.rotateImage = function(lImagePtr , dfAngle){
	try{
		var result = this.getObj().RotateImage(lImagePtr, dfAngle);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 图像缩放
 * @param lImagePtr 传入图像句柄，24位和8位
 * @param dfZoom 缩放因子
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，二值化后的图像句柄。0为调用失败，>0为调用成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.scaleImage = function(lImagePtr, dfZoom){
	try{
		var result = this.getObj().ScaleImage(lImagePtr, dfZoom);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 自动寻找印章位置 建模使用
 * @param lImagePtr 传入的待建模二值化图像句柄
 * @param lScale 等级，默认传4
 *               对于无边框的章 或者虚边框的章子,在自动建模的时候 有时候会不能自动完整提取. 这种情况下,需要在界面上选择一下 印章包含无边框 或者 虚边框 类型 然后 调用函数  AutoCutColorSeal2( binBuf ,   4 , seal_rect , MAX_SEAL_N); 
 *               时候 ， 参数4 可以设置大比如 6 7 8 等等 ， 这样 就可以完整提取了
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为CString型，坐标字符串。
 * 					 字符串为空表示失败，如果不为空则表示成功。
 * 					 字符串格式为：左,上,右,下, 左,上,右,下,左,上,右,下,左,上,右,下…..
 *			obj.msg:提示信息;
 */
OCX_SealRecog.autoCutColorSeal2 = function(lImagePtr, lScale){
	try{
		var result = this.getObj().AutoCutColorSeal2(lImagePtr, lScale);
		if(/^\s*$/g.test(result)){
			return OCXResult(this,"9200","");
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 针对每个印章的彩色图像，将自动测量印章的姿态，并且将建模的印章转到水平位置，同时返回/印章类型和旋转后的彩色图像，二值图像。
 * @param lImagePtr 传入图像句柄
 * @param lColorType 印鉴颜色，0红，1蓝，2黑
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，图像列表句柄。
 * 					 0为调用失败，>0为调用成功。
 * 					 返回值为图像列表句柄，这个列表可以是n个图像，不过这里返回的是一个彩色图像和一个黑白图像。
 *			obj.msg:提示信息;
 * 相关函数FreeImageList，GetImageListCount，GetImageListPtr，AddImageForList
 */
OCX_SealRecog.getBestSealWithRotate = function(lImagePtr, lColorType){
	try{
		var result = this.getObj().GetBestSealWithRotate(lImagePtr, lColorType);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 针对每个印章的彩色图像，将自动测量印章的姿态，并且将建模的印章转到水平位置，
 * 同时返回/印章类型和旋转后的彩色图像，二值图像。得到水平位置的印章,并且缩紧
 * 外部空白区域 建模时候使用，替换原先的GetBestSealWithRotate
 * @param lImagePtr 传入图像句柄
 * @param lColorType 印鉴颜色，0红，1蓝，2黑
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，图像列表句柄。
 * 					 0为调用失败，>0为调用成功。
 * 					 返回值为图像列表句柄，这个列表可以是n个图像，不过这里返回的是一个彩色图像和一个黑白图像。
 *			obj.msg:提示信息;
 *相关函数FreeImageList，GetImageListCount，GetImageListPtr，AddImageForList
 */
OCX_SealRecog.getBestSealWithRotatePacked = function(lImagePtr, lColorType){
	try{
		var result = this.getObj().GetBestSealWithRotatePacked(lImagePtr, lColorType);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 增加一个函数,针对建模时候印章进行二值化,这个函数只能用作建模时候没有任何干扰环境下
 * 的印章可以替换GetBestSealWithRotate函数输出的二值化印章和原来的二值化比较,这个函
 * 数对于颜色要求更低 颜色不红关系也不大 保留的细节应该更多具体使用需要根据印模卡和印
 * 章颜色以及用户感官要求决定。
 * @param lImagePtr 传入图像句柄，单个印章
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，二值化后的图像句柄。
 * 					 0为调用失败，>0为调用成功
 *			obj.msg:提示信息;
 */
OCX_SealRecog.binarizeRedSealSample = function(lImagePtr){
	try{
		var result = this.getObj().BinarizeRedSealSample(lImagePtr);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 使用同BinarizeRedSealSample，在建立印模时候,如果印章淡,清晰度低,颜色不正的时候,
 * 需要过滤一些黑色等等的方法时候,可以采用此方法试验。
 * @param lImagePtr 传入图像句柄，单个印章
 * @param lMethod 方法选择 0 -3
 * 				  0: 针对颜色淡,模糊的,不过滤黑色
 * 				  1: 在0基础上过滤黑色
 * 				  2: 在0基础上,不增强色彩的过滤黑色,不用
 * 				  3: 在0基础上使用去除签字函数
 * 				  
 * 				  关于验印控件建库3个选项：
 * 				  1.无干扰（高质量）
 * 				  2.太淡
 * 				  3.去签字
 * 				  
 * 				  如果勾选了1，则不能同时勾选2或3
 * 				  如果勾选了2或3，则不能同时勾选1
 * 				  2和3可以同时勾选
 * 				  
 * 				  如果勾选了1，则调用BinarizeRedSealSample
 * 				  如果勾选了2，没勾选3，则调用BinarizeRedSealSample4，参数method=0
 * 				  如果勾选了2，同时勾选3，则调用BinarizeRedSealSample4
 * 				  如果勾选了3，没勾选2，则调用BinarizeRedSealSampleByReMoveS，参数method=1或3
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，二值化后的图像句柄。
 * 					 0为调用失败，>0为调用成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.binarizeRedSealSample4 = function(lImagePtr, lMethod){
	try{
		var result = this.getObj().BinarizeRedSealSample4(lImagePtr, lMethod);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 使用同BinarizeRedSealSample，在建立印模时候,如果出现黑色文字,此函数可以排除部分
 * 黑色文字的干扰,使用位置和BinarizeRedSeal_Sample类似.在建立印模时候使用。
 * @param lImagePtr 传入图像句柄，单个印章
 * @param blackremovelevel 用于控制黑色文字去除强度的, 取值范围1-9, 缺省应该使用6；
 * @param blackfilllevel 黑色去除后的补充等级 参数 0 - 2 , 0 不补充, 1 补充 2 补充更完整(会带入黑色笔划)
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，二值化后的图像句柄。
 * 					 0为调用失败，>0为调用成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.binarizeRedSealSampleByReMoveS = function(lImagePtr, blackremovelevel, blackfilllevel){
	try{
		var result = this.getObj().BinarizeRedSealSampleByReMoveS(lImagePtr, blackremovelevel, blackfilllevel);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取印章类型。
 * @param lImagePtr 传入二值图像句柄
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，印章类型值。
 * 					 <0为失败，>0为成功。
 * 					 印章类型值枚举如下：
 * 					 0表示矩形
 * 					 1表示圆形
 * 					 2表示椭圆
 * 					 3表示三角
 * 					 4表示多边
 * 					 5表示综合
 *			obj.msg:提示信息;
 */
OCX_SealRecog.getSealShape = function(lImagePtr){
	try{
		var result = this.getObj().GetSealShape(lImagePtr);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 初始化识别字典。
 * @param lspDictFilePath 字典名称
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，字典句柄，使用完毕后需要使用FreeOCREngine2进行资源释放。
 * 					 0为调用失败，>0为调用成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.initOCREngine2 = function(lspDictFilePath){
	try{
		var result = this.getObj().InitOCREngine2(lspDictFilePath);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 释放OCR识别字典。
 * @param lOCREngineHandle 字典句柄，由Init_OCREngine2的返回值
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，0为成功，其它为失败。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.freeOCREngine2 = function(lOCREngineHandle){
	try{
		var result = this.getObj().FreeOCREngine2(lOCREngineHandle);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 验印严格性参数设置。
 * @param Level 小于0 （-1）,用缺省参数，综合等级判断，判断全局 和 局部 笔划重合程度
 * 				的度量  0 , 1, 2, 3, 4 越大越松，通过率越高，范围-1~10
 * @param iblk_b 控制待测印章缺少的图像大小的阈值 就是缺少的像素点
 * 				0 不使用，20 30 40 等等 越大越松
 * @param iblk_e 控制待测印章多出的图像的大小阈值,就是多余出来的像素点
 * 				0 不使用，20 30 40 等等 越大越松
 * @param iblk_d1 与iblk_d2联合起来使用 控制错字的像素点数, 缺省都取40
 * @param iblk_d2 与iblk_d1联合起来使用 控制错字的像素点数, 缺省都取40
 * @param ibig_thick 二值化系统误差容忍设置, 这个参数越大,验印严格度越松 
 * 					取 0 1 2 3 4 ,缺省设置1 ,生产可以放到3 4,范围0~4
 * @param iblank_err 最大整字缺失 越大越松 一般用200 控制缺失一个字的时候使用
 * @param iblk_s 笔画偏差的长度控制 一般不使用，缺省0
 * @returns 输出值为long型，0为成功，其它为失败。
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，0为成功，其它为失败。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.setSealVerifyParam = function(Level, iblk_b, iblk_e, iblk_d1, iblk_d2, ibig_thick, iblank_err, iblk_s){
	try{
		var result = this.getObj().SetSealVerifyParam(Level, iblk_b, iblk_e, iblk_d1, iblk_d2, ibig_thick, iblank_err, iblk_s);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 验印严格性参数设置，其它设置
 * @param lspParamString 验印配置字符串，每个选项以逗号分开。
 * 						 字符串格式：
 * 						 综合等级判断，缺少的像素点，多余的像素点，错字像素点数1，错字像素点数2，二值化误差容忍，最大整字缺失，笔画偏差的长度，错误区间最多显示个数，是否印章发黑二次识别，色彩校正等级，是否进行红线檫除，是否进行增强红线檫除
 * 
 * 						 综合等级判断:小于0 （-1）,用缺省参数，综合等级判断，判断全局 和 局部 笔划重合程度的度量
 *									0 , 1, 2, 3, 4 越大越松，通过率越高，范围-1~10
 * 						 缺少的像素点:控制待测印章缺少的图像大小的阈值 就是缺少的像素点
 *									0 不使用，20 30 40 等等 越大越松
 * 						 多余的像素点:控制待测印章多出的图像的大小阈值,就是多余出来的像素点
 * 									0 不使用，20 30 40 等等 越大越松
 * 						 错字像素点数1:与iblk_d2联合起来使用 控制错字的像素点数, 缺省都取40
 * 						 错字像素点数2:与iblk_d1联合起来使用 控制错字的像素点数, 缺省都取40
 * 						 二值化误差容忍:二值化系统误差容忍设置, 这个参数越大,验印严格度越松 取 0 1 2 3 4 ,缺省设置1 ,生产可以放到3 4,范围0~4
 * 						 最大整字缺失:最大整字缺失 越大越松 一般用200 控制缺失一个字的时候使用
 * 						 笔画偏差的长度:笔画偏差的长度控制 一般不使用，缺省0
 * 						 错误区间最多显示个数:范围0-10，默认3
 * 						 是否印章发黑二次识别:0-否，1-是，默认0
 * 						 色彩校正等级: 二次识别，范围是0-7,色彩校正等级，默认0
 * 						 是否进行红线檫除:0-否，1-是，默认0
 * 						 是否进行增强红线檫除: 0-否，1-是，默认0
 * 两组参数：第一组参数为正常参数；第二组参数为测试用参数，用于非我司拍照设备进行拍照验印；两组参数以分号(;)分割
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，0为成功，其它为失败。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.setSealVerifyParamString = function(lspParamString){
	try{
		var result = this.getObj().SetSealVerifyParamString(lspParamString);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 验印识别
 * @param lImagePtr 待识别图像句柄
 * @param lImageListPtr 预留印章图像列表句柄
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，0为成功，其它为失败。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.sealVerify1 = function(lImagePtr, lImageListPtr){
	try{
		var result = this.getObj().SealVerify1(lImagePtr, lImageListPtr);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取指定预留印鉴验印识别结果
 * GetSealVerifyResult(lSealIndex);
 * @param lSealIndex 预留印鉴索引，从0开始
 * @returns obj(code,data,msg)
 * 			obj.code:"1053",未通过;"1052",通过;"1054",未找到印章;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，验印识别结果
 * 					 1为通过，0为未通过，-2为未找到印章。其它为失败
 *			obj.msg:提示信息;
 */
OCX_SealRecog.getSealVerifyResult = function(lSealIndex){
	try{
		var result = this.getObj().GetSealVerifyResult(lSealIndex);
		if(result == 0){
			return OCXResult(this,"1053",result);
		}else if(result == 1){
			return OCXResult(this,"1052",result);
		}else if(result == -2){
			return OCXResult(this,"1054",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取指定预留印鉴验印详细识别结果
 * GetSealVerifyResultDetailResult(lSealIndex);
 * @param lSealIndex 预留印鉴索引，从0开始
 * @returns obj(code,data,msg)
 * 			obj.code:"1055",自动通过;"1056",无细节错误,但是整体误差超标;"1057",印章很不相同;
 * 					 "1058",笔画出现偏差;"1059",笔画出现多余;"1060",笔画出现缺失;
 * 					 "1061",可能出现错字;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，验印详细识别结果
 *					 4=自动通过
 *					 10=无细节错误,但是整体误差超标
 *					 11=印章很不相同
 *					 12=笔画出现偏差
 *					 13=笔画出现多余
 *					 14=笔画出现缺失
 *					 15=可能出现错字
 *					 16=其它原因失败
 *			obj.msg:提示信息;
 */
OCX_SealRecog.getSealVerifyResultDetailResult = function(lSealIndex){
	try{
		var result = this.getObj().GetSealVerifyResultDetailResult(lSealIndex);
		if(result == 4){
			return OCXResult(this,"1055",result);
		}else if(result == 10){
			return OCXResult(this,"1056",result);
		}else if(result == 11){
			return OCXResult(this,"1057",result);
		}else if(result == 12){
			return OCXResult(this,"1058",result);
		}else if(result == 13){
			return OCXResult(this,"1059",result);
		}else if(result == 14){
			return OCXResult(this,"1060",result);
		}else if(result == 15){
			return OCXResult(this,"1061",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取指定索引印鉴验印识别结果图列表，包含预留印鉴和待识别印鉴图像
 * @param lSealIndex 预留印鉴索引，从0开始
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为long型，图像列表句柄。
 * 					  0为调用失败，>0为调用成功。
 * 					  返回值为图像列表句柄，这个列表可以是n个图像，不过这里返回的是一个预留印鉴二值图像和一个待识别印鉴二值图像。
 *			obj.msg:提示信息;
 * 			相关函数FreeImageList，GetImageListCount，GetImageListPtr，AddImageForList
 */
OCX_SealRecog.getSealVerifySealPair = function(lSealIndex){
	try{
		var result = this.getObj().GetSealVerifySealPair(lSealIndex);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 用于识别后，获取原图中的彩色图像，是没有旋转过的图。
 * @param lSealIndex 预留印鉴索引，从0开始
 * @returns 输出值为long型，图像列表句柄。
 * 			0为调用失败，>0为调用成功。
 * 			返回值为图像列表句柄，这个列表可以是n个图像，不过这里返回的是一个新的预留印鉴二值图像和一个待识别印鉴彩色图像。
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为long型，图像列表句柄。
 * 					  0为调用失败，>0为调用成功。
 * 					  返回值为图像列表句柄，这个列表可以是n个图像，不过这里返回的是一个新的预留印鉴二值图像和一个待识别印鉴彩色图像。
 *			obj.msg:提示信息;
 * 			相关函数FreeImageList，GetImageListCount，GetImageListPtr，AddImageForList
 */
OCX_SealRecog.getSealVerifyOriginalImage = function(lSealIndex){
	try{
		var result = this.getObj().GetSealVerifyOriginalImage(lSealIndex);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 提取矩形印章中的小字坐标，需要人工先框选出小字行区域，对于矩形区域,程序能够自动找到
 * 一行数字的每个字位置,如果需要两行,则需要使用两个矩形区间 . 以此类推。
 * @param lImageColorPtr 传入的彩色印章图像句柄
 * 						 建库的时候：这个图像由函数GetBestSealWithRotate或者BinarizeRedSealSample进行获取
 * @param lImageBinPtr 传入的二值印章图像句柄
 * @param ROILeft 传入的小字行区域左边
 * @param ROITop 传入的小字行区域上边
 * @param ROIRight 传入的小字行区域右边
 * @param ROIBottom 传入的小字行区域下边
 * @param ocr_num 输入,是设定的需要找到的数字个数,如果ocr_num 设置为<0,比如-1,则函数
 * 				  自动寻找数字的个数,但是这时候没有知道ocr_num的可靠性好
 * @param manual 输入,手工辅助时候使用非0,如果自动状态,manual设置为0.一般如果自动没成功,
 * 				 改变manual值,调用这个函数,有时可以自动找到,特别是人机交互时候,第一次自
 * 				 动没成功,这是如果让用户自己选择可能不合适,这时候可以用这种方式设定manual
 * 				 值manual 值 manual越大,自动寻找出来的内容就越多,但是字可能被打断
 *@returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出结果同函数GetSampleSealOCREclipsePos
 *					  输出值为CString型，坐标字符串。
 *					  字符串为空表示失败，如果不为空则表示成功。
 *					  字符串格式为：左,上,右,下, degree, 左,上,右,下, degree,左,上,右,下, degree,左,上,右,下, degree…..
 *					  degree表示区域的倾斜等级，建库的时候需要保存，用于小字OCR时使用。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.getSampleSealOCRRectLine = function(lImageColorPtr, lImageBinPtr, ROILeft, ROITop, ROIRight, ROIBottom, ocr_num, manual){
	try{
		var result = this.getObj().GetSampleSealOCRRectLine(lImageColorPtr, lImageBinPtr, ROILeft, ROITop, ROIRight, ROIBottom, ocr_num, manual);
		if(/^\s*$/g.test(result)){
			return OCXResult(this,"9200","");
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 对于圆形或者椭圆形,沿外轮廓分布的数字
 * 程序提供了针对沿着圆形和椭圆形外轮廓分布数字的提取方法.注意,椭圆形在建模阶段
 * 需要水平放置,否则建模会失败.
 * 能够提取的数字有以下特点：
 * a 数字的个数已知;
 * b 数字沿着外轮廓弧形分布,如果水平分布，使用前一个方法进行;
 * c 数字间隔基本相同。
 * @param lImageColorPtr 传入的彩色印章图像句柄
 * 						 建库的时候：这个图像由函数GetBestSealWithRotate或者BinarizeRedSealSample进行获取。
 * @param lImageBinPtr 传入的二值印章图像句柄
 * @param ocr_num 输入,是设定的需要找到的数字个数,如果ocr_num 设置为<0,比如-1,则函数自动
 * 				  寻找数字的个数,但是这时候没有知道ocr_num的可靠性好
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出结果同函数GetSampleSealOCRRectLine
 *					  输出值为CString型，坐标字符串。
 *					  字符串为空表示失败，如果不为空则表示成功。
 *					  字符串格式为：左,上,右,下, degree, 左,上,右,下, degree,左,上,右,下, degree,左,上,右,下, degree…..
 *					  degree表示区域的倾斜等级，建库的时候需要保存，用于小字OCR时使用。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.getSampleSealOCREclipsePos = function(lImageColorPtr, lImageBinPtr, ocr_num){
	try{
		var result = this.getObj().GetSampleSealOCREclipsePos(lImageColorPtr, lImageBinPtr, ocr_num);
		if(/^\s*$/g.test(result)){
			return OCXResult(this,"9200","");
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 对于圆形或者椭圆形,沿外轮廓分布的数字
 * 程序提供了针对沿着圆形和椭圆形外轮廓分布数字的提取方法.注意,椭圆形在建模阶段
 * 需要水平放置,否则建模会失败.
 * 能够提取的数字有以下特点：
 * a 数字的个数已知;
 * b 数字沿着外轮廓弧形分布,如果水平分布，使用前一个方法进行;
 * c 数字间隔基本相同。
 * @param lImageColorPtr 传入的彩色印章图像句柄
 * 						 建库的时候：这个图像由函数GetBestSealWithRotate或者BinarizeRedSealSample进行获取。
 * @param lImageBinPtr 传入的二值印章图像句柄
 * @param ocr_num 输入,是设定的需要找到的数字个数,如果ocr_num 设置为<0,比如-1,则函数自动
 * 				  寻找数字的个数,但是这时候没有知道ocr_num的可靠性好
 * @param method 输入,方法设置，
 * 				 初始值method = 0
 * 				 method|=0x1
 * 				 能较好地排除边的干扰,特别是小数字和边靠的比较近的时候. 
 * 				 method|=0x2
 * 				 可以对二值化淡的小数字加强后寻找,但是如果小数字间距很小,不能设置此方法;
 * 				 method|=0x4
 * 				 排除小数字和内侧字的粘连,此方法实际效果不好,一般不使用. 目前如果小数字和外部边框粘连,程序一
 * 				 般可以处理,但是和内部文字发生粘连或者靠的很近,程序目前不能处理.
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出结果同函数GetSampleSealOCRRectLine
 *					  输出值为CString型，坐标字符串。
 *					  字符串为空表示失败，如果不为空则表示成功。
 *					  字符串格式为：左,上,右,下, degree, 左,上,右,下, degree,左,上,右,下, degree,左,上,右,下, degree…..
 *					  degree表示区域的倾斜等级，建库的时候需要保存，用于小字OCR时使用。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.getSampleSealOCREclipsePos2 = function(lImageColorPtr, lImageBinPtr, ocr_num, method){
	try{
		var result = this.getObj().GetSampleSealOCREclipsePos2(lImageColorPtr, lImageBinPtr, ocr_num, method);
		if(/^\s*$/g.test(result)){
			return OCXResult(this,"9200","");
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 印章OCR
 * @param lImageColorPtr 传入的彩色印章图像句柄
 *						 建库的时候：这个图像由函数GetBestSealWithRotate或者BinarizeRedSealSample进行获取。
 *						 识别的时候：这个图像由函数GetSealVerifyOriginalImage进行获取。
 * @param lImageBinPtr 传入的二值印章图像句柄，建库后的二值图
 * @param hOCREngineHandle OCR识别模块句柄，InitOCREngine2返回值
 * @param lspOcrRects 坐标字符串，字符串格式为：
 * 					  左,上,右,下, degree, 左,上,右,下, degree,左,上,右,下, degree,左,上,右,下, degree…..
 * 					  degree表示区域的倾斜等级，建库的时候已经保存
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为CString型，OCR识别结果字符串。
 * 					  字符串为空表示失败，如果不为空则表示成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.sealVerifyByOCREnNum = function(lImageColorPtr, lImageBinPtr, hOCREngineHandle, lspOcrRects){
	try{
		var result = this.getObj().SealVerifyByOCREnNum(lImageColorPtr, lImageBinPtr, hOCREngineHandle, lspOcrRects);
		if(/^\s*$/g.test(result)){
			return OCXResult(this,"9200","");
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 印章细节识别
 * @param lImageColorPtr 传入的彩色印章图像句柄
 *						 建库的时候：这个图像由函数GetBestSealWithRotate或者BinarizeRedSealSample进行获取。
 *						 识别的时候：这个图像由函数GetSealVerifyOriginalImage进行获取。
 * @param lImageBinPtr 传入的二值印章图像句柄，建库后的二值图
 * @param lspDetailRects 坐标字符串，字符串格式为：
 * 					  左,上,右,下, degree, 左,上,右,下, degree,左,上,右,下, degree,左,上,右,下, degree…..
 * 					  degree表示区域的倾斜等级，建库的时候已经保存
 * @returns 输出值为CString型，细节识别结果字符串。
 * 			字符串为空表示失败，如果不为空则表示成功。
 * 			坐标字符串，字符串格式为：
 * 			flag, bmissing, wmissing, max_dif_point, difrate, flag, bmissing, wmissing, max_dif_point, difrate, flag, bmissing, wmissing, max_dif_point, difrate,…..
 * 			flag 用于标示识别结果 0 通过 ，1 失败 目前使用非常简单的算法， bmissing>0.45 或difrate>0.2为不通过；
 * 			bmissing 表示黑色点的错误比例；
 * 			wmissing 表示白色点错误比例；
 * 			max_dif_point 差异笔画面积点数;
 * 			difrate 差异笔画占总笔画的比例;
 * 			应用程序可以利用bmissing 和wmissing在外部根据实际情况进行判别。
 * 			这个结构今后很有可能改变，需要特别注意。特别是需要通过一定数量的试验确定相对可靠的是参数和识别方法。
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为CString型，细节识别结果字符串。
 * 					  字符串为空表示失败，如果不为空则表示成功。
 * 					  坐标字符串，字符串格式为：
 * 					  flag, bmissing, wmissing, max_dif_point, difrate, flag, bmissing, wmissing, max_dif_point, difrate, flag, bmissing, wmissing, max_dif_point, difrate,…..
 * 					  flag 用于标示识别结果 0 通过 ，1 失败 目前使用非常简单的算法， bmissing>0.45 或difrate>0.2为不通过；
 * 					  bmissing 表示黑色点的错误比例；
 * 					  wmissing 表示白色点错误比例；
 * 					  max_dif_point 差异笔画面积点数;
 * 					  difrate 差异笔画占总笔画的比例;
 * 					  应用程序可以利用bmissing 和wmissing在外部根据实际情况进行判别。
 * 					  这个结构今后很有可能改变，需要特别注意。特别是需要通过一定数量的试验确定相对可靠的是参数和识别方法。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.sealVerifyByDetailBinImageLevel = function(lImageColorPtr, lImageBinPtr, lspDetailRects){
	try{
		var result = this.getObj().SealVerifyByDetailBinImageLevel(lImageColorPtr, lImageBinPtr, lspDetailRects);
		if(/^\s*$/g.test(result)){
			return OCXResult(this,"9200","");
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 人工验印多种图像颜色设置
 * @param lType 传入人工验印图像种类
 * 				0-	三色图
 * 				1-	镂空图
 * 				2-	折角图
 * 				3-	旋转图
 * 				4-	抖动图
 * 				5-	同屏右侧镂空图
 * @param lColor1 传入的颜色值，如lColor1 = RGB(255,0,0)表示红色,各种值解释如下（lColor1简称C1）：
 * 				  0-	三色图：C1背景色，C2重合，C3预留多余，C4待识别多余
 * 				  1-	镂空图：C1背景色，C2待识别镂空
 * 				  2-	折角图：C1背景色，C2待识别
 * 				  3-	旋转图：C1背景色，C2待识别
 * 				  4-	抖动图：C1背景色，C2前景色
 * @param lColor2 同lColor1
 * @param lColor3 同lColor1
 * @param lColor4 同lColor1
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为long型，0为成功，其它为失败
 *			obj.msg:提示信息;
 */
OCX_SealRecog.sealManualWorkSetColor = function(lType, lColor1, lColor2, lColor3, lColor4){
	try{
		var result = this.getObj().SealManualWorkSetColor(lType, lColor1, lColor2, lColor3, lColor4);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 人工验印。
 * @param lImageListPtr1 传入的图像列表句柄，包含一个预留印鉴图像和一个待识别印鉴图像。
 * 						 这2个图像由函数GetSealVerifySealPair进行获取。
 * @param lImageListPtr2 传入的图像列表句柄，包含一个新的预留印鉴二值图像和一个待识别
 * 						 印鉴彩色图像。这2图像列表由函数GetSealVerifyOriginalImageMatch进行获取。
 * @param lAutoPass 通过GetSealVerifyResultDetailResult获取
 * 					4=自动通过
 * 					10=无细节错误,但是整体误差超标
 * 					11=印章很不相同
 * 					12=笔画出现偏差
 * 					13=笔画出现多余
 * 					14=笔画出现缺失
 * 					15=可能出现错字
 * 					16=其它原因失败
 * @param 手动通过时需要切换的次数
 * @returns obj(code,data,msg)
 * 			obj.code:"1062",此印鉴为无效;"1063",此印鉴为有效;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为long型，印鉴手工判断结果。
 * 					  0表示此印鉴为无效，1表示此印鉴为有效。其它失败
 * 					  图像种类：三色，镂空，八角/折角，旋转，抖动，同屏，轮廓，矩形，覆盖。
 * 					  操作种类：旋转，移动。
 * 					  快捷键小键盘：
 * 					  <5>切换显示图像种类
 * 					  <7><9>旋转
 * 					  <4><6><8><2>移动
 * 					  <Enter>切换折角图
 * 					  <0>判断印鉴无效
 * 					  <1>判断印鉴有效
 *			obj.msg:提示信息;
 */
OCX_SealRecog.sealManualWork = function(lImageListPtr1, lImageListPtr2, lAutoPass, lCount){
	try{
		var result = this.getObj().SealManualWork(lImageListPtr1, lImageListPtr2, lAutoPass, lCount);
		if(result == 0){
			return OCXResult(this,"1062",result);
		}else if(result == 1){
			return OCXResult(this,"1063",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 查找文件是否存在
 * @param lspFilePath 文件绝对全路径
 * @returns obj(code,data,msg)
 * 			obj.code:"1064",存在;"9500",文件不存在;"9300",调用控件方法异常;
 * 			obj.data: 输出值为long型，1为存在，0为不存在。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.findFile = function(lspFilePath){
	try{
		var result = this.getObj().FindFile(lspFilePath);
		if(result == 1){
			return OCXResult(this,"1064",result);
		}else{
			return OCXResult(this,"9500",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 删除文件
 * DeleteFile(lspFilePath);
 * @param lspFilePath 文件绝对全路径
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为long型，1为成功，0为不成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.deleteFile = function(lspFilePath){
	try{
		var result = this.getObj().DeleteFile(lspFilePath);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 复制文件
 * CopyFile (lspFilePath, lspFilePathNew);
 * @param lspFilePath 文件绝对全路径
 * @param lspFilePathNew 文件绝对全路径,复制后的
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为long型，1为成功，0为不成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.copyFile = function(lspFilePath, lspFilePathNew){
	try{
		var result = this.getObj().CopyFile(lspFilePath, lspFilePathNew);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 创建目录
 * @param lspDirPath 文件夹绝对全路径
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为long型，1为成功，0为不成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.createDir = function(lspDirPath){
	try{
		var result = this.getObj().CreateDir(lspDirPath);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 删除目录
 * @param lspDirPath 文件夹绝对全路径
 * @param lDeleteSelf 是否删除本身文件夹
 * 					  lDeleteSelf = 1删除本身和其下所有子目录和文件
 * 					  lDeleteSelf = 0只删除其下所有子目录和文件
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为long型，1为成功，0为不成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.deleteDir = function(lspDirPath, lDeleteSelf){
	try{
		var result = this.getObj().DeleteDir(lspDirPath, lDeleteSelf);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 将黑白图像转换为彩色图像
 * @param lImagePtr 传入二值图像句柄，为1位黑白图像
 * @param lClrBK 背景色，如lClrBK = RGB(255,0,0)
 * @param lClrFG 前景色，如lClrFG = RGB(0,0,255)
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为long型，彩色化后的图像句柄，为24位彩色图像。
 * 					  0为调用失败，>0为调用成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.binToClrImage = function(lImagePtr, lClrBK, lClrFG){
	try{
		var result = this.getObj().BinToClrImage(lImagePtr, lClrBK, lClrFG);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 计算红色和蓝色的点数和img面积的比例,如果大于img面积*thr 返回1 否则返回0
 * @param lImagePtr 传入彩色图像句柄，为24位彩色图像
 * @param redorblue 输入，0:红色 1蓝色
 * @param thr 判断阈值 可以设置为0.005
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为long型，彩色化后的图像句柄，为24位彩色图像。
 * 					  0为调用失败，>0为调用成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.isRedOrBluePointEnough = function(lImagePtr, redorblue, thr){
	try{
		var result = this.getObj().IsRedOrBluePointEnough(lImagePtr, redorblue, thr);
		if(result > 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 将文件进行Base64编码
 * EncodeBase64(lspFilePath) 
 * @param lspFilePath 传入待处理的文件
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data: 输出值为String 形，为执行编码后的字符串。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.encodeBase64 = function(lspFilePath){
	try{
		var result = this.getObj().EncodeBase64(lspFilePath);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 字符串进行Base64解码
 * @param lpImgStr 待解码的字符串
 * @param lspFilePath 要保存文件的路径
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为String 形，1表示成功，0表示失败。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.decodeBase64 = function(lpImgStr, lspFilePath){
	try{
		var result = this.getObj().DecodeBase64(lpImgStr, lspFilePath);
		if(result == 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 字符串进行Base64解码，返回解码图像句柄
 * @param lpImgStr 待解码的字符串
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为long型，图像句柄，使用完毕后需要使用FreeImage进行资源释放。
 * 					  0为调用失败，>0为调用成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.decodeBase64ToImagePtr = function(lpImgStr){
	try{
		var result = this.getObj().DecodeBase64ToImagePtr(lpImgStr);
		if(result >0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 识别后，获取印章在原图中的坐标。
 * @param lSealIndex 预留印鉴索引，从0开始
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为CString型，坐标字符串。
 * 					  字符串为空表示失败，如果不为空则表示成功。
 * 					  字符串格式为：左,上,右,下。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.getSealVerifyOrigImageAndRect = function(lSealIndex){
	try{
		var result = this.getObj().GetSealVerifyOrigImageAndRect(lSealIndex);
		if(/^\s*$/g.test(result)){
			return OCXResult(this,"9200","");
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置识别模式，设置处理时彩色模式还是灰度模式。
 * 需要在识别之前进行设置。
 * @param lMode 0-	彩色模式，即红色模式
 *				1-	灰度模式，即混合模式
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data: "";
 *			obj.msg:提示信息;
 */
OCX_SealRecog.setImageColorMode = function(lMode){
	try{
		this.getObj().SetImageColorMode(lMode);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取人工验印折角看图次数。
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data: 输出值为long型，折角看图次数。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.getManualWorkCount = function(){
	try{
		var result = this.getObj().GetManualWorkCount();
		if(result >= 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 为了使得程序接口简单,如果遇到处理蓝色印章的时候,可以通过这个函数将蓝色印章转变成红色印章,进行处理.注意这时候
 * lImagePtr里面的内容发生了改变. 二次调用该函数能够回到原始的数据状态. 如果imgBuf需要在原始状态下使用,须备份或
 * 者在使用完lImagePtr后,再次调用此函数恢复。
 * @param lImagePtr 传入需要转换的彩色图像句柄
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:输出值为long型，二值图像句柄。
 * 					 0为调用失败，>0为调用成功。
 *			obj.msg:提示信息;
 */
OCX_SealRecog.clrImageBlueToRed = function(lImagePtr){
	try{
		var result = this.getObj().ClrImageBlueToRed(lImagePtr);
		if(result >0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取当前调用控件的进程所在的路径，以”\”结尾。
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:输出值为BSTR型，当前调用控件的进程所在的路径，以”\”结尾
 *			obj.msg:提示信息;
 */
OCX_SealRecog.getCurProcPath = function(){
	try{
		var result = this.getObj().GetCurProcPath();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};




