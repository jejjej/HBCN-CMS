/**
 * 创建于:2015-10-28<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 拍照控件 JS 封装
 * 
 * @author 叶慧雄
 * @version 1.0
 */

// 定义拍照控件封装对象
var OCX_XUSBVideo = new Object();

/**
 * 获取拍照控件对象
 */
OCX_XUSBVideo.getObj = function() {
	return OCXElement[ocxObject.OCX_XUSBVideo["content"]["id"]];
};

OCX_XUSBVideo.getAlias = function() {
	return "XV";
};

/**
 * ************************************ 控件参数设置
 * ******************************************
 */

/**
 * 2.1 纠偏剪裁开关
 * 
 * @param deskew
 *            boolean
 */
OCX_XUSBVideo.setDeskew = function(deskew) {
	this.getObj().Deskew = deskew;
};

/**
 * 2.2 文字方向矫正开关，deskew为true生效
 * 
 * @param textdirect
 *            boolean
 */
OCX_XUSBVideo.setTextdirect = function(textdirect) {
	this.getObj().Textdirect = textdirect;
};

/**
 * 2.3 宽幅符号，表示图像正放时，宽大于高。该属性在做图像文字方向矫正时使用，作为文字方向矫正的辅助
 * 
 * @param wideFormat
 *            boolean
 */
OCX_XUSBVideo.setWideFormat = function(wideFormat) {
	this.getObj().WideFormat = wideFormat;
};

/**
 * 2.4 摄像头亮度，必须在BindDevice后设置
 * 
 * @param brgihtness
 */
OCX_XUSBVideo.setBrgihtness = function(brgihtness) {
	this.getObj().Brgihtness = brgihtness;
};

/**
 * 2.5 摄像头对比度，必须在BindDevice后设置
 * 
 * @param contrast
 */
OCX_XUSBVideo.setContrast = function(contrast) {
	this.getObj().Contrast = contrast;
};

/**
 * 2.6 摄像头色调，必须在BindDevice后设置
 * 
 * @param hue
 */
OCX_XUSBVideo.setHue = function(hue) {
	this.getObj().Hue = hue;
};

/**
 * 2.7 摄像头饱和度，必须在BindDevice后设置
 * 
 * @param saturation
 */
OCX_XUSBVideo.setSaturation = function(saturation) {
	this.getObj().Saturation = saturation;
};

/**
 * 2.8 摄像头锐度，必须在BindDevice后设置
 * 
 * @param sharpness
 */
OCX_XUSBVideo.setSharpness = function(sharpness) {
	this.getObj().Sharpness = sharpness;
};

/**
 * 2.9 摄像头伽马值，必须在BindDevice后设置
 * 
 * @param gamma
 */
OCX_XUSBVideo.setGamma = function(gamma) {
	this.getObj().Gamma = gamma;
};

/**
 * 2.10 摄像头白平衡，必须在BindDevice后设置
 * 
 * @param whiteBalance
 */
OCX_XUSBVideo.setWhiteBalance = function(whiteBalance) {
	this.getObj().WhiteBalance = whiteBalance;
};

/**
 * 2.11 摄像头曝光值，必须在BindDevice后设置
 * 
 * @param exposure
 */
OCX_XUSBVideo.setExposure = function(exposure) {
	this.getObj().Exposure = exposure;
};

/**
 * 2.12 摄像头自动白平衡，必须在BindDevice后设置
 * 
 * @param autoWhiteBalance
 *            boolean类型
 */
OCX_XUSBVideo.setAutoWhiteBalance = function(autoWhiteBalance) {
	this.getObj().AutoWhiteBalance = autoWhiteBalance;
};

/**
 * 2.13 摄像头自动曝光，必须在BindDevice后设置
 * 
 * @param autoExposure
 *            boolean类型
 */
OCX_XUSBVideo.setAutoExposure = function(autoExposure) {
	this.getObj().AutoExposure = autoExposure;
};

/**
 * 2.14 录制Asf文件比特率
 * 
 * @param asfBitRate
 */
OCX_XUSBVideo.setAsfBitRate = function(asfBitRate) {
	this.getObj().AsfBitRate = asfBitRate;
};

/**
 * 2.15 选框显示模式： enum RECTSHOWMODE { RECTSHOW_NONE = 0, RECTSHOW_A4 = 0x01,
 * RECTSHOW_CROP = 0x02, }; 可以使用或运算组合显示多种选框
 * 
 * @param rectShowMode
 */
OCX_XUSBVideo.setRectShowMode = function(rectShowMode) {
	this.getObj().RectShowMode = rectShowMode;
};

/**
 * 2.16 图像位深模式： enum IMAGEBITDEPTH { IMAGEBPP_BINARY = 0, IMAGEBPP_GRAY,
 * IMAGEBPP_RBG24, };
 * 
 * @param imageBpp
 */
OCX_XUSBVideo.setImageBpp = function(imageBpp) {
	this.getObj().ImageBpp = imageBpp;
};

/**
 * 2.17 Jpeg压缩质量，0~100之间，该值越大，jpeg图像质量越好，占用空间越大
 * 
 * @param jpegQuality
 */
OCX_XUSBVideo.setJpegQuality = function(jpegQuality) {
	this.getObj().JpegQuality = jpegQuality;
};

/**
 * ************************************ 控件接口封装
 * ******************************************
 */

/**
 * 3.1 获取已连接的摄像头个数
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:摄像头个数; obj.msg:提示信息;
 */
OCX_XUSBVideo.getDevicesCount = function() {
	try {
		// result 摄像头个数
		var result = this.getObj().GetDevicesCount();
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.2 获取摄像头的硬件ID
 * 
 * @param cameraIndex
 *            摄像头序号
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:摄像头的硬件ID; obj.msg:提示信息;
 */
OCX_XUSBVideo.getDevicesID = function(cameraIndex) {
	try {
		// result 摄像头的硬件ID
		var result = this.getObj().GetDevicesID(cameraIndex);
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.3 获取摄像头的硬件名称
 * 
 * @param cameraIndex
 *            摄像头序号
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:摄像头的名称; obj.msg:提示信息;
 */
OCX_XUSBVideo.getDevicesName = function(cameraIndex) {
	try {
		// result 摄像头的名称
		var result = this.getObj().GetDevicesName(cameraIndex);
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.4 获取摄像头的分辨率像素数量
 * 
 * @param cameraIndex
 *            摄像头序号
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:支持的像素数量; obj.msg:提示信息;
 */
OCX_XUSBVideo.getVideoInfoCount = function(cameraIndex) {
	try {
		// result 支持的像素数量
		var result = this.getObj().GetVideoInfoCount(cameraIndex);
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.5 GetVideoInfo
 * 
 * @param cameraIndex
 *            摄像头索引
 * @param resolutionIndex
 *            分辨率索引
 * @param nWidth
 *            [out] 分辨率宽度
 * @param nHeight
 *            [out] 分辨率高度
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_XUSBVideo.getVideoInfo = function(cameraIndex, resolutionIndex, nWidth,
		nHeight) {
	try {
		// result 0 表示成功，<0 失败，
		var result = this.getObj().GetVideoInfo(cameraIndex, resolutionIndex,
				nWidth, nHeight);
		if (result == 0) {
			return OCXResult(this, "1001", result);
		} else {
			return OCXResult(this, "9200", result);
		}
	} catch (e) {
		return OCXExceptionResult(this, e);
	};
};

/**
 * 3.6 获取指定摄像头的指定分辨率索引的摄像头宽度
 * 
 * @param cameraIndex
 *            摄像头索引
 * @param resolutionIndex
 *            分辨率索引
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:分辨率宽度信息; obj.msg:提示信息;
 */
OCX_XUSBVideo.getVideoInfoWidth = function(cameraIndex, resolutionIndex) {
	try {
		// result 获取分辨率宽度信息
		var result = this.getObj().GetVideoInfoWidth(cameraIndex,
				resolutionIndex);
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	};
};

/**
 * 3.7 获取指定摄像头的指定分辨率索引的摄像头高度
 * 
 * @param cameraIndex
 *            摄像头索引
 * @param resolutionIndex
 *            分辨率索引
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:分辨率高度信息; obj.msg:提示信息;
 */
OCX_XUSBVideo.getVideoInfoHeight = function(cameraIndex, resolutionIndex) {
	try {
		// result 获取分辨率高度信息
		var result = this.getObj().GetVideoInfoHeight(cameraIndex,
				resolutionIndex);
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	};
};

/**
 * 3.8 获取指定摄像头的指定分辨率的图像格式
 * 
 * @param cameraIndex
 *            摄像头索引
 * @param resolutionIndex
 *            分辨率索引
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:摄像头分辨率的格式; obj.msg:提示信息;
 */
OCX_XUSBVideo.getVideoFormat = function(cameraIndex, resolutionIndex) {
	try {
		// result 获取摄像头分辨率的格式
		var result = this.getObj().GetVideoFormat(cameraIndex, resolutionIndex);
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.9 获取当前连接的500万像素摄像头的设备索引
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:摄像头索引; obj.msg:提示信息;
 */
OCX_XUSBVideo.getVideoDevice500W = function() {
	try {
		// result 摄像头索引
		var result = this.getObj().GetVideoDevice500W();
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.10 获取当前连接的包含指定分辨率的设备索引
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:摄像头索引; obj.msg:提示信息;
 */
OCX_XUSBVideo.getVideoRes500W = function() {
	try {
		// result 摄像头索引
		var result = this.getObj().GetVideoRes500W();
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.11 获取当前连接设备的包含指定分辨率的设备的分辨率索引
 * 
 * @param lWidth
 *            分辨率宽度
 * @param lHeight
 *            分辨率高度
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:摄像头索引; obj.msg:提示信息;
 */
OCX_XUSBVideo.getVideoDeviceWH = function(lWidth, lHeight) {
	try {
		// result 摄像头索引
		var result = this.getObj().GetVideoDeviceWH(lWidth, lHeight);
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.12 获取当前连接的500万像素摄像头的500万分辨率的索引
 * 
 * @param nVideoDevice
 *            摄像头索引
 * @param lWidth
 *            分辨率宽度
 * @param lHeight
 *            分辨率高度
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:摄像头索引; obj.msg:提示信息;
 */
OCX_XUSBVideo.getVideoResWH = function(nVideoDevice, lWidth, lHeight) {
	try {
		// result 摄像头索引
		var result = this.getObj().GetVideoResWH(nVideoDevice, lWidth, lHeight);
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.13 设置配置文件路径
 * 
 * @param lpszFilePath
 *            配置文件路径
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常; obj.data:"";
 *          obj.msg:提示信息;
 */
OCX_XUSBVideo.loadConfigParam = function(lpszFilePath) {
	try {
		// result
		this.getObj().LoadConfigParam(lpszFilePath);
		return OCXResult(this, "1001", "");
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.14 控件绑定摄像头，以下接口均是对绑定设备的操作
 * 
 * @param cameraIndex
 *            摄像头索引
 * @param resolutionIndex
 *            分辨率索引
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_XUSBVideo.bindDevice = function(cameraIndex, resolutionIndex) {
	try {
		// result TRUE成功，FALSE失败
		var result = this.getObj().BindDevice(cameraIndex, resolutionIndex);
		if (result) {
			return OCXResult(this, "1001", result);
		} else {
			return OCXResult(this, "9200", result);
		}
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.15 打开摄像头
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_XUSBVideo.open = function() {
	try {
		// result TRUE成功，FALSE失败
		var result = this.getObj().Open();
		if (result) {
			return OCXResult(this, "1001", result);
		} else {
			return OCXResult(this, "9200", result);
		}
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.16 关闭摄像头
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常; obj.data:"";
 *          obj.msg:提示信息;
 */
OCX_XUSBVideo.close = function() {
	try {
		// result
		this.getObj().Close();
		return OCXResult(this, "1001", "");
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.17 显示摄像头属性配置界面
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_XUSBVideo.showVideoProperty = function() {
	try {
		// result TRUE成功，FALSE失败
		var result = this.getObj().ShowVideoProperty();
		if (result) {
			return OCXResult(this, "1001", result);
		} else {
			return OCXResult(this, "9200", result);
		}
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.18 配置裁剪区域参数
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_XUSBVideo.configDeskew = function() {
	try {
		// result TRUE成功，FALSE失败
		var result = this.getObj().ConfigDeskew();
		if (result) {
			return OCXResult(this, "1001", result);
		} else {
			return OCXResult(this, "9200", result);
		}
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.19 查询设备是否可以拍照
 * 
 * @returns obj(code,data,msg) obj.code:"1046",可以拍照;"1047",不能拍照;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_XUSBVideo.isCaptureEnbale = function() {
	try {
		// result True 可以拍照，False不能拍照
		var result = this.getObj().IsCaptureEnbale();
		if (result) {
			return OCXResult(this, "1046", result);
		} else {
			return OCXResult(this, "1047", result);
		}
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.20 获取裁剪裁剪后的图像坐标在原图上的位置
 * 
 * @param nX
 *            坐标x值
 * @param nY
 *            坐标y值
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:坐标字符串：X,Y; obj.msg:提示信息;
 */
OCX_XUSBVideo.getPositionInOriginal = function(nX, nY) {
	try {
		// result 坐标字符串：X,Y
		var result = this.getObj().GetPositionInOriginal(nX, nY);
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.21 抓取图像
 * 
 * @param lpszOriginal
 *            原图保存路径，原图也可能是纠偏裁剪后的图像
 * @param lpszSection
 *            图像切片保存路径
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_XUSBVideo.captureImage = function(lpszOriginal, lpszSection) {
	try {
		// result TRUE成功，FALSE失败
		var result = this.getObj().CaptureImage(lpszOriginal, lpszSection);
		if (result) {
			return OCXResult(this, "1001", result);
		} else {
			return OCXResult(this, "9200", result);
		}
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
};

/**
 * 3.22 预览开始
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_XUSBVideo.start = function() {
	try {
		// result TRUE成功，FALSE失败
		var result = this.getObj().Start();
		if (result) {
			return OCXResult(this, "1001", result);
		} else {
			return OCXResult(this, "9200", result);
		}
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.23 暂停预览
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_XUSBVideo.pause = function() {
	try {
		// result TRUE成功，FALSE失败
		var result = this.getObj().Pause();
		if (result) {
			return OCXResult(this, "1001", result);
		} else {
			return OCXResult(this, "9200", result);
		}
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.24 停止预览
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_XUSBVideo.stop = function() {
	try {
		// result TRUE成功，FALSE失败
		var result = this.getObj().Stop();
		if (result) {
			return OCXResult(this, "1001", result);
		} else {
			return OCXResult(this, "9200", result);
		}
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.25 连拍开始
 * 
 * @param nTakeCount
 *            连拍图像数，<=0：无限连拍，>0：拍摄得到nTakeCount张图像后停止连拍。
 * @param nInterval
 *            连拍时间间隔，单位毫秒，等于0，表示自动检测连拍，>0 按时间间隔连拍
 * @param lpszPath
 *            图像保存路径
 * @param nForamt
 *            图像格式
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_XUSBVideo.continuousCaptureBegin = function(nTakeCount, nInterval,
		lpszPath, nForamt) {
	try {
		// result TRUE成功，FALSE失败
		var result = this.getObj().ContinuousCaptureBegin(nTakeCount,
				nInterval, lpszPath, nForamt);
		if (result) {
			return OCXResult(this, "1001", result);
		} else {
			return OCXResult(this, "9200", result);
		}
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.26 结束连拍
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_XUSBVideo.continuousCaptureEnd = function() {
	try {
		// result TRUE成功，FALSE失败
		var result = this.getObj().ContinuousCaptureEnd();
		if (result) {
			return OCXResult(this, "1001", result);
		} else {
			return OCXResult(this, "9200", result);
		}
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.27 获取错误信息
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:控件出现的最后一次发生的错误信息字符串; obj.msg:提示信息;
 */
OCX_XUSBVideo.getLastError = function() {
	try {
		// result 控件出现的最后一次发生的错误信息字符串
		var result = this.getObj().GetLastError();
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.28 调试设备DPI
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:设备DPI值; obj.msg:提示信息;
 */
OCX_XUSBVideo.initCameraDPI = function() {
	try {
		// result 设备DPI值
		var result = this.getObj().InitCameraDPI();
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.29 获取控件当前绑定的设备索引，如果控件绑定摄像头后，与电脑连接的摄像头发生变化，该索引可能失效。
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:摄像头索引; obj.msg:提示信息;
 */
OCX_XUSBVideo.getCurDeviceIndex = function() {
	try {
		// result 摄像头索引
		var result = this.getObj().GetCurDeviceIndex();
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.30 获取控件当前绑定的设备的分辨率索引
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常; obj.data:
 *          摄像头分辨率索引; obj.msg:提示信息;
 */
OCX_XUSBVideo.getCurResolutionIndex = function() {
	try {
		// result 摄像头分辨率索引
		var result = this.getObj().GetCurResolutionIndex();
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.31 抓取图像，与CaptureImage不同的是，次函数返回图像DIB指针
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常; obj.data:
 *          图像DIB，需要调用FreeImageDIB释放; obj.msg:提示信息;
 */
OCX_XUSBVideo.captureImageDIB = function() {
	try {
		// result 图像DIB，需要调用FreeImageDIB释放
		var result = this.getObj().CaptureImageDIB();
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.32 结束连拍
 * 
 * @param nImageDIB
 *            图像DIB
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常; obj.data: "";
 *          obj.msg:提示信息;
 */
OCX_XUSBVideo.freeImageDIB = function(nImageDIB) {
	try {
		// result
		this.getObj().FreeImageDIB(nImageDIB);
		return OCXResult(this, "1001", "");
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.33
 * 获取片段剪裁区域信息。该剪裁区域不是纠偏剪裁区域，该区域是用于扣取图像上某部分图像片段，CaptureImage第二个参数保存的图像就是该区域内的片段。
 * 
 * @param pLeft
 *            接收剪裁框坐标left。
 * @param pTop
 *            接收剪裁框坐标Top
 * @param pRight
 *            接收剪裁框坐标Right
 * @param pBottom
 *            接收剪裁框坐标Bottom
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_XUSBVideo.getCropRect = function(pLeft, pTop, pRight, pBottom) {
	try {
		// result TRUE成功，FALSE失败
		var result = this.getObj().GetCropRect(pLeft, pTop, pRight, pBottom);
		if (result) {
			return OCXResult(this, "1001", result);
		} else {
			return OCXResult(this, "9200", result);
		}
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.34 设置片段剪裁框区域。该区域解释同GetCropRect
 * 
 * @param nLeft
 *            检查框坐标left
 * @param nTop
 *            检查框坐标Top
 * @param nRight
 *            检查框坐标Right
 * @param nBottom
 *            检查框坐标Bottom
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_XUSBVideo.setCropRect = function(nLeft, pTop, nRight, nBottom) {
	try {
		// result TRUE成功，FALSE失败
		var result = this.getObj().SetCropRect(nLeft, nTop, nRight, nBottom);
		if (result) {
			return OCXResult(this, "1001", result);
		} else {
			return OCXResult(this, "9200", result);
		}
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.35 抓取视频快照，图像不经过任何处理
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常; obj.data:
 *          图像DIB，需要调用FreeImageDIB释放; obj.msg:提示信息;
 */
OCX_XUSBVideo.takeSnapshot = function() {
	try {
		// result 图像DIB，需要调用FreeImageDIB释放
		var result = this.getObj().TakeSnapshot();
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.36 获取裁剪裁剪后的物体在原始图像上的角度
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常; obj.data:
 *          角度值，往顺时针倾斜返回正的角度值，逆时针倾斜返回负的角度值; obj.msg:提示信息;
 */
OCX_XUSBVideo.getAngelInOriginal = function() {
	try {
		// result 角度值，往顺时针倾斜返回正的角度值，逆时针倾斜返回负的角度值。
		var result = this.getObj().GetAngelInOriginal();
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.37 获取VIDEO对象指针
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常; obj.data:
 *          摄像头对象指针; obj.msg:提示信息;
 */
OCX_XUSBVideo.getVideoCore = function() {
	try {
		// result 摄像头对象指针
		var result = this.getObj().GetVideoCore();
		return OCXResult(this, "1001", result);
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};

/**
 * 3.38 设置视频每帧图像是否启动事件
 * 
 * @param bValue
 *            开关
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常; obj.data: "";
 *          obj.msg:提示信息;
 */
OCX_XUSBVideo.setNodifyFrame = function(bValue) {
	try {
		// result
		this.getObj().SetNodifyFrame(bValue);
		return OCXResult(this, "1001", "");
	} catch (e) {
		return OCXExceptionResult(this, e);
	}
	;
};
