/**
 * 创建于:2014-9-23<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 拍照控件测试脚本
 * 
 * @author 黄有坚
 * @version 1.0
 */
//INI配置文件
//var iniPath = "c:/yzjgss/config/3x/gss.ini";
var iniPath = "c:/yinzhijie/gss.ini";
//连拍数量
var nTakeCount = 20;
//连拍间隔时间
var nInterval = 1;
//连拍存放地址
var lpszPath = "c:\\photo\\";
//连拍图片存放格式
var nForamt = 3;
//文件id
var storeId;
//计数器
var countImage;
//开始识别
var isFacerecog = false;

var dealFile = new ActiveXObject("Scripting.FileSystemObject");

/**
 * 打开摄像头
 */
function openCamera() {
    showResult("打开摄像头", _openCamera().msg);
}

/**
 * 连拍开始
 * nTakeCount [in] 连拍图像数，<=0：无限连拍，>0：拍摄得到nTakeCount张图像后停止连拍。
 * nInterval [in] 连拍时间间隔，单位毫秒，等于0，表示自动检测连拍，>0 按时间间隔连拍
 * lpszPath [in] 图像保存路径
 * nForamt [in] 图像格式：
 * enum IMAGEFORMAT
 */
function continuousCaptureBegin(){
	
	deleteAllImage();

	countImage = 0;
	OCX_XUSBVideo.setNodifyFrame(1);
//	var isOk = OCX_XUSBVideo.continuousCaptureBegin(nTakeCount,nInterval,lpszPath,nForamt);
//	showResult("开始识别","请勿乱动 "+isOk.msg);
	
	 //录入图片数量计数器
//	 captureImagecoun();
	
}


/**
 * 结束连拍
 * Return Value
 * True成功，False失败
 
function continuousCaptureEnd(){
	var isOk = OCX_XUSBVideo.continuousCaptureEnd();
	showResult("结束连拍", isOk.msg);
	captureImage();
	alert("人脸录入成功.");
}

/**
 * 关闭摄像头
 */
function closeCamera() {
	OCX_XUSBVideo.close();
    showResult("关闭摄像头", "成功");
}

/**
 * 图像删除
 */
function deleteAllImage(){
	if(lpszPath == "") return;
	
	// 创建FileSystemObject对象实例  
	fso = new ActiveXObject("Scripting.FileSystemObject");
	var fileder = fso.GetFolder(lpszPath);
	var file = new Enumerator(fileder.files);
	for(; !file.atEnd(); file.moveNext()){
		var filePath = String(file.item());
		imageFile = fso.GetFile(filePath);
		imageFile.Delete();
	}
	
}

/**
 * 拍照数量
 */
function captureImagecoun(){
	num= 0;
	num = faceImageNum(num);
	
	showResult("录入中等待中。", num);
	
	setTimeout(function () {
		 if(num < 10)
			 captureImagecoun();
	 },500);
}


function faceImageNum(countImage){
	// 创建FileSystemObject对象实例  
		fso = new ActiveXObject("Scripting.FileSystemObject");
		var fileder = fso.GetFolder(lpszPath);
		var file = new Enumerator(fileder.files);
		for(; !file.atEnd(); file.moveNext()){
			countImage ++;			
		}
		return countImage;
}

/**
 * 拍照
 */
function capture() {
    var path = window.document.getElementById("path").value;
    var name = (new Date()).Format("yyyyMMddhhmmssS");
    var filename = path + "\\" + name + ".jpg";
    var src_filename = path + "\\" + name + "_src.jpg";
    if (_captureImage(filename, src_filename, 1).code == "1001") {
	try{
	    window.open("file:///" + filename, "_blank", "", "");
	}catch(e){}
	showResult("拍照成功", filename + ".jpg");
    } else
	showResult("拍照失败", "");
}

/**
 * 设置裁剪区域
 */
function showCutArear() {
	OCX_XUSBVideo.configDeskew();
    showResult("设置裁剪区域", "");
}

/**
 * 获取剪裁坐标
 */
function getCutArear() {
    showResult("获取剪裁坐标", _getCropRect.data);
}

/**
 * 设置拍照参数
 */
function showCameraConfig() {
	OCX_XUSBVideo.showVideoProperty();
    showResult("设置拍照参数", "");
}

/**
 * 获取裁剪角度
 */
function getAngle() {
    showResult("裁剪角度:", OCX_XUSBVideo.getAngelInOriginal().data);
}

/**
 * 获取裁剪位置
 */
function getPosition() {
    showResult("裁剪位置", OCX_XUSBVideo.getPositionInOriginal().data);
}

/**
 * 事件ImageToFile
 * 
 * @param path
 */
function imageToFile(path) {
	countImage++;
	showResult("人脸识别", "路径"+ path +"...");
	var fileder = dealFile.GetFile(path);
//	fileder.Close();
	var topath = lpszPath + Date.parse(new Date())+".bmp";
	fileder.Move(topath);
	 //上传人脸图像
	 if(countImage >= nTakeCount){
		OCX_XUSBVideo.setNodifyFrame(0);
		 //人脸识别
		 if(isFacerecog){
			 uploadFace();
			 faceRecognition(storeId);
		 }else{//人脸录入
			 uploadImageAll();
		 }
	 }
	 
    showResult("人脸识别", "正在识别人脸信息 "+ countImage +"...");
//    showResult("拍照事件", countImage + " [ImageToFile]触发，参数[" + path + "]");
}

/**
 * 事件[ImageToDIB]
 * 
 * @param path
 */
function imageToDIB(path) {
    showResult("拍照事件", "[ImageToDIB]触发，参数[" + path + "]");
}

/**
 * 事件[DeviceReady]
 * 
 * @param path
 */
function deviceReady() {
    showResult("拍照事件", "[DeviceReady]触发");
}

/**
 * 事件[ImageToFile]
 * 
 * @param status
 */
function deviceConnect(status) {
    showResult("拍照事件", "[ImageToFile]触发，参数[" + status + "]");
}




/** ************************************基本场景应用****************************************** */

//TODO
/**
* 打开摄像头
* 
* @returns obj(code,data,msg) obj.code:"1001",成功; "9204":"未读到摄像头配置信息或配置为空",
*          "9205":"摄像头序号配置错误", "9206":"绑定摄像头失败", "9207":"打开摄像头失败",
*          "9208":"打开摄像头异常", "9209":"摄像头分辨率配置错误", "9210":"摄像头连接异常",
*          obj.data:控件原始返回值; obj.msg:提示信息;
*/
function _openCamera() {
	try {
		var cameraNum = OCX_XUSBVideo.getDevicesCount().data;
		var cameraIndex = OCX_Tools.readIni(iniPath, "gss", "cameraIndex", "").data;
		var infoNum = OCX_XUSBVideo.getVideoInfoCount(cameraIndex).data;
		var infoIndex = OCX_Tools.readIni(iniPath, "gss", "cameraInfoIndex", "").data;
		OCX_Logger.info("{MachineOrderTest._openCamera}--摄像头个数：" + cameraNum);
		OCX_Logger.info("{MachineOrderTest._openCamera}--摄像头分辨率最大ID：" + infoNum);
		OCX_Logger.info("{MachineOrderTest._openCamera}--gss.ini中摄像头配置的序号：" + cameraIndex);
		OCX_Logger.info("{MachineOrderTest._openCamera}--gss.ini中摄像头配置的分辨率序号：" + infoIndex);
		if (cameraNum == null || cameraNum == undefined || cameraNum == ""
				|| infoNum == null || infoNum == undefined || infoNum == "") {// 未读到摄像头参数
			return OCXResult(OCX_XUSBVideo, "9210", "");
		};
		if (cameraIndex == null || cameraIndex == undefined
				|| cameraIndex == "" || infoIndex == null
				|| infoIndex == undefined || infoIndex == "") {// 未读到配置信息或配置为空
			return OCXResult(OCX_XUSBVideo, "9204", "");
		};
		if (cameraNum - 1 < parseInt(cameraIndex)) { // 配置的摄像头ID大于最大ID
			return OCXResult(OCX_XUSBVideo, "9205", "");
		};

		if (infoNum - 1 < parseInt(infoIndex)) { // 配置的像素ID大于最大ID
			return OCXResult(OCX_XUSBVideo, "9209", "");
		};

		OCX_XUSBVideo.close(); // 先关闭
//		OCX_XUSBVideo.setRectShowMode(1); // 设置剪裁框
		var rBind = OCX_XUSBVideo.bindDevice(cameraIndex, infoIndex).data;

		// cameraIndex和infoIndex参数无误并且已连接设备返回false的话，很可能是摄像头未在电脑上注册
		if (!rBind) { // 绑定设备id和分辨率id
			return OCXResult(OCX_XUSBVideo, "9206", "");
		};

//		OCX_XUSBVideo.setRectShowMode(5);

		if (!OCX_XUSBVideo.open().data) {
			return OCXResult(OCX_XUSBVideo, "9207", "");
		};
		return OCXResult(OCX_XUSBVideo, "1001", "");

	} catch (e) {
		return OCXResult(OCX_XUSBVideo, "9208", "");
	};
};

//TODO
/**
* 拍照
* 
* @param filePath
*            照片保存路径
* @param srcImagePath
*            原图保存路径
* @param isCut
*            是否剪裁 0 否， 1 是
* @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
*          obj.data:控件原始返回值; obj.msg:提示信息;
*/
function _captureImage(filePath, srcImagePath, isCut) {
	OCX_XUSBVideo.setDeskew(isCut);
	return OCX_XUSBVideo.captureImage(filePath, srcImagePath);
};


/**
* 获取剪裁区域
*/
function _getCropRect() {
	 var pLeft, pTop, pRight, pBottom;
	 pLeft = 0;
	 pTop = 0;
	 pRight = 0;
	 pBottom = 0;
	 if (OCX_XUSBVideo.GetCropRect(pLeft, pTop, pRight, pBottom)) {
		return OCXResult(OCX_XUSBVideo, "1001", pLeft + "," + pTop + "," + pRight + "," + pBottom);
	 } else {
	 	return OCXResult(OCX_XUSBVideo, "9200","");
	 }
};
