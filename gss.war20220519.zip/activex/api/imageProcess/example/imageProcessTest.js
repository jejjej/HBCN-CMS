/**
 * 创建于:2016-04-14<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 视频检测控件测试脚本
 *
 * @author 黄坤平
 * @version 1.0
 */

Date.prototype.Format = function(fmt) {
	var o = {
		"M+": this.getMonth() + 1, // 月份
		"d+": this.getDate(), // 日
		"h+": this.getHours(), // 小时
		"m+": this.getMinutes(), // 分
		"s+": this.getSeconds(), // 秒
		"q+": Math.floor((this.getMonth() + 3) / 3), // 季度
		"S": this.getMilliseconds()
			// 毫秒
	};
	if (/(y+)/.test(fmt))
		fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "")
			.substr(4 - RegExp.$1.length));
	for (var k in o)
		if (new RegExp("(" + k + ")").test(fmt))
			fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
	return fmt;
};

/**
 * 页面初始化方法
 */
function init() {
	if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, "../../", "run", 1, 1))
		alert("通用工具类控件初始化失败");
	if (!ocxObject.initOcx(ocxObject.OCX_IProcOperation, document.body, "../../", "run", 1, 1))
		alert("图像控件初始化失败");
	if (!ocxObject.initOcx(ocxObject.OCX_ImageProcess, document.body, "../../", "run", 1, 1))
		alert("白纸检测控件初始化失败");
}

function checkBlankPaper() {
	var imagePath = document.getElementById("imageFile").value;
	var discut = 200;
	if(imagePath) {
		var width = OCX_IProcOperation.getImageFileWidth(imagePath).data;
		var height = OCX_IProcOperation.getImageFileHeight(imagePath).data;
		var area ="[{"+discut+","+discut+","+(width - discut )+","+(height - discut )+"}]"; //识别裁剪整张纸
		var disresult = OCX_ImageProcess.checkBlankArea(imagePath, area).data;
		if(disresult < 0){
			showResult("识别异常，识别结果["+disresult+"]");
			return "识别异常，识别结果["+disresult+"]";
		}else if(disresult >= 0 && disresult <=150){ // >=0, 为所有区域中差异值最小的值（有字的地方占用的像素点数）
			showResult("识别出空白纸张");
			return "识别出空白纸张";
		}else{
			showResult("识别出非空白纸张");
			return null;
		}
	} else {
		showResult("请选择图像文件");
	}
}

/**
 * 清除日志记录方法
 */
function clearLog() {
	window.document.getElementById("result").value = "";
}

/**
 * 显示操作结果
 *
 * @param messgage
 *            操作结果
 */
function showResult(message) {
	var content = (new Date())
		.Format("hh:mm:ss") + "  " + message + "\r\n" + window.document.getElementById("result").value;
	if (content.length > 10000)
		content = content.substring(0, 10000);
	window.document.getElementById("result").value = content;
}
