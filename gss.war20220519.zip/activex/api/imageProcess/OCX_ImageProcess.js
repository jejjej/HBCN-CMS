/**
 * 创建于:2016-04-14<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 *
 * 图像文件操作
 *
 * @author 黄坤平
 * @version 1.0
 */

/**
 * 定义白纸检测控件封装对象<p>
 * 结合OCX_IProcOperation控件使用
 */
var OCX_ImageProcess = {
		/**
		 * 获取白纸检测控件
		 * @returns 白纸检测控件对象
		 */
		getObj:function() {
			return OCXElement[ocxObject.OCX_ImageProcess["content"]["id"]];
		},
		/**
		 * 白纸检测控件别名
		 */
		getAlias:function() {
			 return "PO";
		},
		/**
		 *  空白纸张 检测
		 *  拍图 -  固定剪裁 - 自动剪裁 - 调用函数
		 *   
		 * @param imagePath 图像路径 - 
		 * @param imageArea  识别区域 位置区域信息 格式 [{x,x,x,x}]
		 * @returns <0,异常；>=0, 为所有区域中差异值最小的值（有字的地方占用的像素点数）
		 */
		checkBlankArea:function(imagePath, imageArea) {
			try{
				var result = this.getObj().CheckBlankArea(imagePath, imageArea);
				return OCXResult(OCX_ImageProcess,"1001", result);
			}catch(e){
				return OCXExceptionResult(OCX_ImageProcess, e);
			};
		}
};
