/**
 * 创建于:2015-10-28<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 版面识别控件
 * @author 叶慧雄 
 * @version 1.0
 */

//定义版面识别控件封装对象
var OCX_DocRecog = new Object();

/**
 * 获取版面识别控件对象
 */
OCX_DocRecog.getObj = function(){
	return OCXElement[ocxObject.OCX_DocRecog["content"]["id"]];
};

OCX_DocRecog.getAlias = function() {
	 return "DR";
};

/**
 * 设置模版路径
 * @param templatePath 模板路径
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_DocRecog.setTemplate = function(templatePath){
	try{
		//result 0：成功； 其他：失败
		var result = this.getObj().SetTemplate (templatePath);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 版面识别
 * @param imagePath 图像路径
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:识别确信度;
 *			obj.msg:提示信息;
 */
OCX_DocRecog.recognize = function(imagePath){
	try{
		//result 大于等于0成功，为识别确信度，小于0失败。确信度越高说明识别效果越好。
		var result = this.getObj().DocRecognize(imagePath);
		if(result >= 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取文档编号
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:文档编号;
 *			obj.msg:提示信息;
 * 说明：在调用recognize成功后方可调用
 */
OCX_DocRecog.getDocNO = function(){
	try{
		//resulet 非空为文档编号，空值失败。
		var result  = this.getObj().GetDocNO();
		if(/^\s*$/g.test(result)){
			return OCXResult(this,"9200","");
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取文档名称
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:文档名称;
 *			obj.msg:提示信息;
 * 说明：在调用recognize成功后方可调用
 */
OCX_DocRecog.getDocName = function(){
	try{
		//result 非空为文档名称，空值失败。
		var result  = this.getObj().GetDocName();
		if(/^\s*$/g.test(result)){
			return OCXResult(this,"9200","");
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};


