/**
 * 创建于:2016-04-14<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 *
 * 图像文件操作
 *
 * @author 黄坤平
 * @version 1.0
 */

/**
 * 图像文件对象定义
 */
var OCX_IProcOperation = {
		/**
		 * 获取图像文件控件
		 * @returns 图像文件控件对象
		 */
		getObj:function() {
			return OCXElement[ocxObject.OCX_IProcOperation["content"]["id"]];
		},
		/**
		 * 图像文件控件别名
		 */
		getAlias:function() {
			 return "PO";
		},
		/**
		 *  获取图像的宽
		 *   
		 * @param imagePath 图像路径
		 * @returns 图像的宽
		 */
		getImageFileWidth:function(imagePath) {
			try{
				var result = this.getObj().GetImageFileWidth(imagePath);
				return OCXResult(OCX_IProcOperation,"1001", result);
			}catch(e){
				return OCXExceptionResult(OCX_IProcOperation, e);
			};
		},
		/**
		 *  获取图像的高
		 *   
		 * @param imagePath 图像路径
		 * @returns 图像的高
		 */
		getImageFileHeight:function(imagePath) {
			try{
				var result = this.getObj().GetImageFileHeight(imagePath);
				return OCXResult(OCX_IProcOperation,"1001", result);
			}catch(e){
				return OCXExceptionResult(OCX_IProcOperation, e);
			};
		}
};
