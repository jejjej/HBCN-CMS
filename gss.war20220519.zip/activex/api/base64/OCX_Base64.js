/**
 * 创建于:2016-01-12<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * Base64控件 JS 封装
 * 
 * @author 叶慧雄
 * @version 1.0
 */
var OCX_Base64  = {
	/**
	 * 获取控件对象
	 */
	getObj : function(){
		return OCXElement[ocxObject.OCX_Base64["content"]["id"]];
	},
	
	/**
	 * OCXResult对象msg信息中代表某某控件
	 */
	getAlias : function() {
		return "Base64";
	},
	
	decodeBase64 : function(imgStr,filePath) {
		try {
			this.getObj().DecodeBase64(imgStr,filePath);
			return OCXResult(this, "1001", "");
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	encodeBase64 : function(data){
		try {
			var result = this.getObj().EncodeBase64(data);
			if(/^\s*$/g.test(result)){
				return OCXResult(this, "9200", "");
			}else{
				return OCXResult(this, "1001", result);
			}
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
		
	}
	
};