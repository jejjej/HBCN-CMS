/**
 * 创建于:2016-04-14<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 视频检测控件测试脚本
 *
 * @author 黄坤平
 * @version 1.0
 */

Date.prototype.Format = function(fmt) {
	var o = {
		"M+": this.getMonth() + 1, // 月份
		"d+": this.getDate(), // 日
		"h+": this.getHours(), // 小时
		"m+": this.getMinutes(), // 分
		"s+": this.getSeconds(), // 秒
		"q+": Math.floor((this.getMonth() + 3) / 3), // 季度
		"S": this.getMilliseconds()
			// 毫秒
	};
	if (/(y+)/.test(fmt))
		fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "")
			.substr(4 - RegExp.$1.length));
	for (var k in o)
		if (new RegExp("(" + k + ")").test(fmt))
			fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
	return fmt;
};

/**
 * 页面初始化方法
 */
function init() {
	if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, "../../", "run", 1, 1))
		alert("通用工具类控件初始化失败");
	if (!ocxObject.initOcx(ocxObject.OCX_Base64, document.body, "../../", "run", 1, 1))
		alert("Base64控件初始化失败");
	document.getElementById("file").addEventListener('change', readFile, false);
}

function encodeBase64() {
	var file = window.document.getElementById("file").value;
	if (file) {
		var ret = OCX_Base64.encodeBase64(file);
		if (ret.code === "1001") {
			window.document.getElementById("base64Content").value = ret.data;
	    	showResult("base64编码成功");
	     }
		var reader = new FileReader();
	    reader.readAsDataURL(file);
	    reader.onload = function (e) { 
	    	window.document.getElementById("base64Content").value = this.result; 
			//document.getElementById("data").innerText=this.result.substring(this.result.indexOf(',')+1); 
	    }
	}
}

function readFile() {
    var file = this.files[0];
    var reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function (e) { 
    	window.document.getElementById("base64Content").src = this.result; 
		window.document.getElementById("base64Content").value=this.result.substring(this.result.indexOf(',')+1); 
	}
}

function dencodeBase64() {
	var base64Content = window.document.getElementById("base64Content").value;
	var filename = window.document.getElementById("filename").value;
	if (!filename) {
		showResult("文件名不允许为空");
	} else {
		if (base64Content) {
			var ret = OCX_Base64.decodeBase64(base64Content, "C:/" + filename);
		     if (ret.code === "1001") {
		    	 showResult("base64解码成功");
		     }
		}
	} 
}

/**
 * 清除日志记录方法
 */
function clearLog() {
	window.document.getElementById("result").value = "";
}

/**
 * 显示操作结果
 *
 * @param messgage
 *            操作结果
 */
function showResult(message) {
	var content = (new Date())
		.Format("hh:mm:ss") + "  " + message + "\r\n" + window.document.getElementById("result").value;
	if (content.length > 10000)
		content = content.substring(0, 10000);
	window.document.getElementById("result").value = content;
}
