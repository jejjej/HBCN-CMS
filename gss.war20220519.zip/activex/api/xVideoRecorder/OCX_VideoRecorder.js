var OCX_VideoRecorder = new Object();
OCX_VideoRecorder.getObj = function() {
	return OCXElement[ocxObject.OCX_VideoRecorder["content"]["id"]];
};

OCX_VideoRecorder.getAlias = function() {
	 return "VR";
};

/***************************************************************************/
/**
 * 设置录像属性
 */
OCX_VideoRecorder.setVideoParam = function(width, height, rate) {
	this.getObj().VideoWidth = width;
	this.getObj().VideoHeight = height;
	if (rate) {
		this.getObj().AsfBitrate = rate;
	}
}

/******************************控件属性设置************************************/

/**
 * 录像时是否录音开关 
 * @param audioRecord boolean
 */
OCX_VideoRecorder.setAudioRecord = function(audioRecord){
	this.getObj().AudioRecord = audioRecord;
};

/**
 * 录像时输出的视频文件的分辨率宽
 * @param 
 */
OCX_VideoRecorder.setVideoWidth = function(videoWidth){
	this.getObj().VideoWidth = videoWidth;
};

/**
 * 录像时输出的视频文件的分辨率宽高
 * @param 
 */
OCX_VideoRecorder.setVideoHeight = function(videoHeight){
	this.getObj().VideoHeight = videoHeight;
};

/**
 * 录制Asf文件比特率
 * @param 
 */
OCX_VideoRecorder.setAsfBitRate = function(asfBitRate){
	this.getObj().AsfBitRate = asfBitRate;
};

/**
 * 设置fps祯率
 */
OCX_VideoRecorder.setFPS = function(fps){
	this.getObj().FPS = fps;
};

/******************************控件方法************************************/

/**
 * 向录像控件添加输入源
 * @param pVideoCore 	[in] 视频输入源核心，通过XUSBVIDEO的接口GetVideoCore获得
 * @param nX		 	[in] 该输入源在视频中的水平位置
 * @param nY			[in] 该输入源在视频中的纵向位置
 * @param nWidth		[in] 该输入源在视频中的宽度
 * @param nHeight		[in] 该输入源在视频中的高度
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:成功返回输入源的索引，否则返回-1;
 *			obj.msg:提示信息;
 */
OCX_VideoRecorder.addVideoSource = function(pVideoCore,nX, nY, nWidth, nHeight){
	try{
		//result 成功返回输入源的索引，否则返回-1
		var result = this.getObj().AddVideoSource(pVideoCore,nX, nY, nWidth, nHeight);
		if(result == -1){
			return OCXResult(this,"9200",result);
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取当前包含的摄像头输入源数目
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:>=0 摄像头数目;
 *			obj.msg:提示信息;
 */
OCX_VideoRecorder.getVideoSourceCount = function(){
	try{
		//result >=0 摄像头数目
		var result = this.getObj().GetVideoSourceCount();
		if(result >= 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取索引指定输入源核心
 * @param nIndex	[in] 索引
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:摄像头对象指针;
 *			obj.msg:提示信息;
 */
OCX_VideoRecorder.getVideoSourceCore = function(nIndex){
	try{
		//result 摄像头对象指针
		var result = this.getObj().GetVideoSourceCore(nIndex);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取索引指定摄像头在水平文件中的水平坐标
 * @param nIndex	[in] 设备索引
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:返回X坐标;
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.getVideoSourcePosX = function(nIndex){
	try{
		//result 成功返回X坐标
		var result = this.getObj().GetVideoSourcePosX(nIndex);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取索引指定摄像头在水平文件中的垂直坐标
 * @param nIndex	[in] 设备索引
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:返回Y坐标;
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.getVideoSourcePosY = function(nIndex){
	try{
		//result 成功返回Y坐标
		var result = this.getObj().GetVideoSourcePosY(nIndex);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取索引指定的摄像头在拍摄数据在视频文件中的宽度
 * @param nIndex	[in] 设备索引
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:视频宽度;
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.getVideoSourceWidth = function(nIndex){
	try{
		//result 成功返回视频宽度
		var result = this.getObj().GetVideoSourceWidth(nIndex);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取索引指定的摄像头在拍摄数据在视频文件中的高度
 * @param nIndex	[in] 设备索引
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:视频高度;
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.getVideoSourceHeight = function(nIndex){
	try{
		//result 成功返回视频宽度
		var result = this.getObj().GetVideoSourceHeight(nIndex);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 从录像控件中移除指定的摄像头输入源
 * @param nIndex	[in] 设备索引
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.removeSourceAt = function(nIndex){
	try{
		//result TRUE FALSE
		var result = this.getObj().RemoveSourceAt(nIndex);
		if(result){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 清除所有设备输入源
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.removeAllSources = function(){
	try{
		//result TRUE FALSE
		var result = this.getObj().RemoveAllSources();
		if(result){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 开始录制文件
 * @param lpszVideoFile	[in]保存视频文件全路径
 * @param nFormat			[in]视频格式：
 * 										0 根据扩展名确定视频格式
 * 										1 AVI
 * 										2 ASF
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.startRecord = function(lpszVideoFile,nFormat){
	try{
		//result TRUE FALSE
		var result = this.getObj().StartRecord(lpszVideoFile,nFormat);
		if(result){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 结束录制
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.stopRecord  = function(){
	try{
		this.getObj().StopRecord();
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 录像开始
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.run = function(){
	try{
		//result TRUE FALSE
		var result = this.getObj().Run();
		if(result){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 暂停录像，重新开始时，接着之前的录像继续录制
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.pause = function(){
	try{
		//result TRUE FALSE
		var result = this.getObj().Pause();
		if(result){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 停止录像，重新开始时，放弃之前录制的内容
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.stop = function(){
	try{
		//result TRUE FALSE
		var result = this.getObj().Stop();
		if(result){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置视频压缩编码器
 * @param lpszCompressName [in] 视频压缩Filter名称，必须为24位视频格式
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.setVideoCompressorName = function(lpszCompressName){
	try{
		this.getObj().SetVideoCompressorName(lpszCompressName);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置音频编码器
 * @param lpszCompressName [in] 音频压缩Filter名称
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.setAudioCompressorName = function(lpszCompressName){
	try{
		this.getObj().SetAudioCompressorName(lpszCompressName);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取错误信息
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件出现的最后一次发生的错误信息字符;
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.getLastError = function(){
	try{
		var result = this.getObj().GetLastError();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 查询录像器状态
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:状态码;
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.getStatus = function(){
	try{
		var result = this.getObj().GetStatus();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置指定摄像头录制数据在视频中的位置
 * @param nIndex	[in] 设备索引
 * @param nX 		[in] 视频位置水平坐标
 * @param nY 		[in]  视频位置坐标Top
 * @param nWidth 	[in] 视频宽度
 * @param nHeight [in] 视频高度
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息; 
 */
OCX_VideoRecorder.setVideoSourcePos = function(nIndex, nX, nY, nWidth, nHeight){
	try{
		//result TRUE FALSE
		var result = this.getObj().SetVideoSourcePos(nIndex, nX, nY, nWidth, nHeight);
		if(result){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

