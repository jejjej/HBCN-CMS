/**
 * 创建于:2016-01-12<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 硬件固件控件 JS 封装
 * 
 * @author 叶慧雄
 * @version 1.0
 */
var OCX_USBProDownloadCTL = {
	/**
	 * 获取控件对象
	 */
	getObj : function(){
		return OCXElement[ocxObject.OCX_USBProDownloadCTL["content"]["id"]];
	},
	
	/**
	 * OCXResult对象msg信息中代表某某控件
	 */
	getAlias : function() {
		return "UDT";
	},
	
	downLoadFile : function(strFilePath) {
		try {
			this.getObj().DownLoadFile(strFilePath);
			return OCXResult(this, "1001", "");
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	enterApp : function() {
		try {
			this.getObj().EnterApp();
			return OCXResult(this, "1001", "");
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	stop : function() {
		try {
			this.getObj().Stop();
			return OCXResult(this, "1001", "");
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	/**
	 * 获取下载状态
	 * 
	 * @returns obj(code,data,msg) obj.code: "9300",调用控件方法异常;
     *		  								 "1071",下载开始;
     *		  								 "1072",下载初始化;            
     *		  								 "1073",下载中;
     *		  								 "1074",机器重启;
     *		  								 "1075",下载完成;
     *		  								 "9231",下载失败;
     *		  								 "9004",设备未打开通讯;
     *		  								 "9005",缓存溢出;
     *		  								 "9000",通讯异常;
     *		  								 "9006",指令不支持;
     *		  								 "9007",指令异常;
     *		  								 "9509",读文件失败;
     *		  								 "9510",文件发送失败;
     *		  								 "9511",用户终止;
     *		  								 "9101",未找到机器;
     *		  								 "9102",接入机器过多; 
     *		  								 "9211",设备连接失败，请重新连接设备;
     *		  								 "9232",下载后重连设备失败;
	 *          					obj.data:控件原始返回值; 
	 *          					obj.msg:提示信息;
	 */
	getDownloadStatus : function() {
		try {
			var result = this.getObj().GetDownloadStatus();
			if(result == 3){
				return OCXResult(this, "1073", result);
			}else if(result == 1){
				return OCXResult(this, "1071", result);
			}else if(result == 2){
				return OCXResult(this, "1072", result);
			}else if(result == 4){
				return OCXResult(this, "1074", result);
			}else if(result == 5){
				return OCXResult(this, "1075", result);
			}else if(result == 6){
				return OCXResult(this, "9231", result);
			}else if(result == -1){
				return OCXResult(this, "9004", result);
			}else if(result == -2){
				return OCXResult(this, "9005", result);
			}else if(result == -3){
				return OCXResult(this, "9000", result);
			}else if(result == -4){
				return OCXResult(this, "9006", result);
			}else if(result == -5){
				return OCXResult(this, "9007", result);
			}else if(result == -10){
				return OCXResult(this, "9509", result);
			}else if(result == -11){
				return OCXResult(this, "9510", result);
			}else if(result == -12){
				return OCXResult(this, "9511", result);
			}else if(result == -13){
				return OCXResult(this, "9101", result);
			}else if(result == -14){
				return OCXResult(this, "9102", result);
			}else if(result == -15){
				return OCXResult(this, "9211", result);
			}else if(result == -16){
				return OCXResult(this, "9232", result);
			}
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	getDownloadNums : function() {
		try {
			var result = this.getObj().GetDownloadNums();
			return OCXResult(this, "1001", result);
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	getCurrentDownloadPos : function() {
		try {
			var result = this.getObj().GetCurrentDownloadPos()
			return OCXResult(this, "1001", result);
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	}
	
};