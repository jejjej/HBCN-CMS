/**
 * 创建于:2014-9-18<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 控件定义集
 * 
 * @author 黄有坚
 * @author yhx 修改于2015/11/9
 * @version 1.0
 */

// OCX对象
var ocxObject = new Object();

/**
 * 异常 9000开头  90通讯类  91硬件故障类  96SMS(印章生命周期)
 * 正常 1000开头 
 */
var OCXMsg = {"1001":"成功",
			  "1002":"纸板打开",
			  "1003":"纸板未打开",
			  "1004":"用印完成",
			  "1005":"正在用印",
			  "1006":"用印不成功",
			  "1007":"用印不成功，已盖章",
			  "1008":"用印结束",
			  "1009":"已打开",
			  "1010":"未打开",
			  "1011":"初始化完成",
			  "1012":"设备正在初始化",
			  "1013":"未设置值",
			  "1014":"机器发生断电重启",
			  "1015":"取消用印",
			  "1016":"需要拍照确认",
			  "1017":"用印正常",
			  "1018":"没按键发生",
			  "1019":"按键编号[1]被按下",
			  "1020":"按键编号[2]被按下",
			  "1021":"按键编号[3]被按下",
			  "1022":"按键编号[4]被按下",
			  "1023":"按键编号[5]被按下",
			  "1024":"按键编号[6]被按下",
			  "1025":"无日志",
			  "1026":"有印章需要放回",
			  "1027":"章已放回章库",
			  "1028":"G1100",
			  "1029":"G1200",
			  "1030":"G1300",
			  "1031":"G1400",
			  "1032":"G1500",
			  "1033":"G1600",
			  "1034":"G2100",
			  "1035":"有纸遮挡",
			  "1036":"无纸遮挡",
			  "1037":"启用",
			  "1038":"禁用",
			  "1039":"空闲",
			  "1040":"正在查找",
			  "1041":"查找完毕，没有相关数据",
			  "1042":"超出查找范围",
			  "1043":"系统正忙",
			  "1044":"数据查完已发送",
			  "1045":"错误",
			  "1046":"可以拍照",
			  "1047":"不能拍照",
			  "1048":"用户取消操作",
			  "1049":"已经有录制过程",
			  "1050":"支持",
			  "1051":"不支持",
			  "1052":"通过",
			  "1053":"未通过",
			  "1054":"未找到印章",
			  "1055":"自动通过",
			  "1056":"无细节错误,但是整体误差超标",
			  "1057":"印章很不相同",
			  "1058":"笔画出现偏差",
			  "1059":"笔画出现多余",
			  "1060":"笔画出现缺失",
			  "1061":"可能出现错字",
			  "1062":"此印鉴为无效",
			  "1063":"此印鉴为有效",
			  "1064":"存在",
			  "1065":"纸板门已打开",
			  "1066":"纸板门已关闭",
			  "1067":"侧门已打开",
			  "1068":"侧门未打开",
			  "1069":"章槽内无此印章",
			  "1070":"章槽内有此印章",
			  "1071":"下载开始",
			  "1072":"下载初始化",             
			  "1073":"下载中",
			  "1074":"机器重启",
			  "1075":"下载完成",
			  "9000":"通讯异常",   
			  "9001":"盖章机通讯异常",
			  "9002":"打印机通讯异常",
			  "9003":"查询侧门状态时通讯异常",
			  "9004":"设备未打开通讯",
			  "9005":"缓存溢出",
			  "9006":"指令不支持",
			  "9007":"指令异常",
			  "9100":"机器故障",
			  "9101":"未找到机器",
			  "9102":"接入机器过多",
			  "9200":"失败",
			  "9201":"设备未连接任何摄像头",
			  "9202":"摄像头序号超出范围",
			  "9203":"分辨率序号超出范围",
			  "9204":"未读到摄像头配置信息或配置为空",
			  "9205":"摄像头序号配置错误",
			  "9206":"绑定摄像头失败",
			  "9207":"打开摄像头失败",
			  "9208":"打开摄像头异常",
			  "9209":"摄像头分辨率配置错误",
			  "9210":"摄像头连接异常",
			  "9211":"设备连接失败，请重新连接设备",
			  "9212":"取校准参数失败，请联系维护人员进行校准参数",
			  "9213":"设备未连接，请连接设备",
			  "9214":"打开纸板失败",
			  "9215":"设置使用盖骑缝章失败",
			  "9216":"设置旋转角度失败",
			  "9217":"设置印章失败",
			  "9218":"设置印章X坐标失败",
			  "9219":"设置印章Y坐标失败",
			  "9220":"开始用印失败",
			  "9221":"获取印控机编号失败，设备连接异常或设备未录入编号",
			  "9222":"打开照明灯失败",
			  "9223":"纸板打开失败，请检查纸板门状态",
			  "9224":"印章机控件计算盖章坐标失败",
			  "9225":"打开电子锁失败",
			  "9226":"查询章槽安装详情失败",
			  "9227":"修改盖骑缝章摆动振幅的个数失败",
			  "9228":"修改盖章轻重失败",
			  "9229":"修改灯亮度失败",
			  "9230":"设置银行设备编号失败",
			  "9231":"下载失败",
			  "9232":"下载后重连设备失败",
			  "9300":"控件方法异常",
			  "9400":"异常",
			  "9401":"未设置印章主体范围或者范围设置过大",
			  "9402":"打印机少纸",
			  "9403":"打印机模式异常",
			  "9404":"打印机或纸张设置错误",
			  "9405":"硒鼓油墨不足",
			  "9406":"无硒鼓",
			  "9407":"打印机空闲",
			  "9408":"打印机工作中",
			  "9409":"打印机预热",
			  "9410":"盖章机进纸位置卡纸",
			  "9411":"盖章机拍章位置卡纸",
			  "9412":"盖章机电机故障",
			  "9413":"前门打开",
			  "9414":"后门打开",
			  "9415":"前后门打开",
			  "9416":"盖章机异常",
			  "9417":"打印机或盖章机卡纸",
			  "9418":"打印机缺纸",
			  "9419":"打印机状态异常",
			  "9420":"检测纸板门状态异常",
			  "9421":"用印异常",
			  "9422":"机控用印异常",
			  "9500":"文件不存在",
			  "9501":"指定文件的路径错误",
			  "9502":"没有指定文件名或者没有后缀名",
			  "9503":"写入数据失败",
			  "9504":"上传发生异常",
			  "9505":"读取配置文件失败",
			  "9506":"检测库加载异常",
			  "9507":"检测文件打开失败",
			  "9508":"检测库初始化失败",
			  "9509":"读文件失败",
			  "9510":"文件发送失败",
			  "9511":"用户终止",
			  "9512":"读取数据失败",
			  "9513":"源文件不存在",
			  "9514":"目标目录不存在创建失败",
			  "9515":"格式不支持，支持.bmp和.jpg后缀文件",
			  "9601":"摄像头索引或者分辨率索引无效",
			  "9602":"读取摄像头总数失败",
			  "9603":"配置的摄像头ID无效",
			  "9604":"读取分辨率总数失败",
			  "9605":"配置的分辨率ID无效",
			  "9606":"绑定摄像头失败",
			  "9607":"打开摄像头失败",
			  "9608":"打开摄像头发生异常",
			  "9609":"读取配置信息失败",
			  "9610":"写入配置信息失败",
			  "9611":"控件初始化失败",
			  "9612":"加载待处理图像失败",
			  "9613":"图像二值化失败",
			  "9614":"没有找到印章",
			  "9615":"剪切图像失败！",
			  "9616":"保存图片失败!",
			  "9617":"印章旋转至水平失败!",
			  "9618":"获取水平图像列表失败!",
			  "9619":"印章二值化失败",
			  "9620":"设置参数严格性失败",
			  "9621":"加载待处理图像失败!",
			  "9622":"初始化印鉴图像链表失败!",
			  "9623":"加载待转换图片失败",
			  "9624":"转换图片颜色失败",
			  "9625":"保存转换后的图片失败",
			  "9626":"读取配置文件失败",
			  "9627":"加载印鉴图像失败",
			  "9628":"打开指纹仪失败",
			  "9629":"取消操作",
			  "9630":"等待手指超时",
			  "9631":"采集图像失败",
			  "9632":"上传图像失败",
			  "9633":"提取指纹特征失败",
			  "9634":"合并指纹模板失败",
			  "9635":"参数非法",
			  "9636":"已经在采集图像"};

//控件对象
var OCXElement = {};

//日志控件(集成文件操作)对象定义
ocxObject.OCX_CommonTool = {
	"content" : {
		"id" : "ocx_commontool",
		"classid" : "clsid:75947BAF-8DE0-4781-B890-5D544F4EC5CA"
	},
	"runjs" : "commonTool/OCX_CommonTool.js",
	"debugjs" : "commonTool/OCX_CommonTool.js"
};

// 版面识别控件
ocxObject.OCX_DocRecog = {
	"content" : {
		"id" : "ocx_docrecog",
		"classid" : "clsid:C8704D0D-26F2-4A6D-865A-BAD0C85DC9E8"
	},
	"runjs" : "docRecog/OCX_DocRecog.js",
	"debugjs" : "docRecog/OCX_DocRecog.js"
};

// 独立印章打印控件对象定义
ocxObject.OCX_ElecSealPrint = {
	"content" : {
		"id" : "ocx_elecsealprint",
		"classid" : "clsid:BA13FF2D-345A-46B5-8043-1F0842C53C64"
	},
	"runjs" : "elecSealPrint/OCX_ElecSealPrint.js",
	"debugjs" : "elecSealPrint/OCX_ElecSealPrint.js",
	"events" : {
		"OnPrintError(errorcode)" : "onPrintError(errorcode);",
		"OnPrintFinish()" : "onPrintFinish();"
	}
};

//图片操作控件对象定义
ocxObject.OCX_ImgHelper = {
	"content" : {
		"id" : "ocx_imghelper",
		"classid" : "clsid:6290BD59-4374-420E-B519-D0DB6C109A4E"
	},
	"runjs" : "imghelper/OCX_ImgHelper.js",
	"debugjs" : "imghelper/OCX_ImgHelper.js"
};

//杰表打印控件对象定义
ocxObject.OCX_JatoolsPrinter = {
	"content" : {
		"id" : "ocx_jatoolsprinter",
		"classid" : "clsid:B43D3361-D075-4BE2-87FE-057188254255"
	},
	"runjs" : "jatoolsPrinter/OCX_JatoolsPrinter.js",
	"debugjs" : "jatoolsPrinter/OCX_JatoolsPrinter.js"
};

// 一体化打印控件
ocxObject.OCX_Print = {
	"content" : {
		"id" : "ocx_print",
		"classid" : "clsid:1D788EBD-7C8D-4EF4-9EB2-C2B860268A12"
	},
	"runjs" : "printOcx/OCX_Print.js",
	"debugjs" : "printOcx/OCX_Print.js"
};

//验印控件对象定义
ocxObject.OCX_SealRecog = {
	"content": {
		"id": "ocx_sealrecog",
		"classid": "clsid:FEC47742-912A-484E-B997-56995C208D58"
	},
	"runjs" : "sealRecog/OCX_SealRecog.js",
	"debugjs" : "sealRecog/OCX_SealRecog.js"
};

//视频检测控件对象定义
ocxObject.OCX_VideoPaperSafeDetect = {
	"content": {
		"id": "ocx_videopapersafedetect",
		"classid": "clsid:6322714D-5565-423C-847B-84DF99D6635D"
	},
	//	"events" : {
	//		"DetectInitFail(result)" : "detectInitFail(result);",
	//		"DetectResult(result)" : "detectResult(result);"
	//	}
	"runjs" : "videoPaperSafeDetect/OCX_VideoPaperSafeDetect.js",
	"debugjs" : "videoPaperSafeDetect/OCX_VideoPaperSafeDetect.js"
};

// 视频流控件对象定义
ocxObject.OCX_VideoRecorder = {
	"content" : {
		"id" : "ocx_videorecorder",
		"classid" : "clsid:FC3FDAE7-353E-4DBC-B0DE-94A8A5BE1825"
	},
	"runjs" : "xVideoRecorder/OCX_VideoRecorder.js",
	"debugjs" : "xVideoRecorder/OCX_VideoRecorder.js"
};

// 拍照控件
ocxObject.OCX_XUSBVideo = {
	"content" : {
		"id" : "ocx_xusbvideo",
		"classid" : "clsid:0091E1F4-19FD-49D3-9EC2-5CB135E5ED84"
	},
	"runjs" : "XUSBVIDEO/OCX_XUSBVideo.js",
	"debugjs" : "XUSBVIDEO/OCX_XUSBVideo.js",
	"events" : {
		"ImageToFile(filePath)" : "imageToFile(filePath);",
		"ImageToDIB(lImageDib)" : "imageToDIB(lImageDib);",
		"DeviceReady()" : "deviceReady();",
		"DeviceConnect(nConnectStatus)" : "deviceConnect(nConnectStatus);"
	}
};

// 印控机控件
ocxObject.OCX_MachineOrder = {
	"content" : {
		"id" : "ocx_machineorder",
		"classid" : "clsid:327AF2B7-1971-4F9C-BBA1-392484FC3FCA"
	},
	"runjs" : "machineOrder/OCX_MachineOrder.js",
	"debugjs" : "machineOrder/OCX_MachineOrder.js"
};

//Base64控件
ocxObject.OCX_Base64 = {
	"content" : {
		"id" : "ocx_base64",
		"classid" : "clsid:98264C37-BD40-4F56-BFC5-133EFA9A7056"
	},
	"runjs" : "base64/OCX_Base64.js",
	"debugjs" : "base64/OCX_Base64.js"
};

//硬件固件控件
ocxObject.OCX_USBProDownloadCTL = {
	"content" : {
		"id" : "ocx_usbprodownloadctl",
		"classid" : "clsid:B8C9B557-D4DC-4E83-8789-DB54802806A2"
	},
	"runjs" : "USBProDownloadCTL/OCX_USBProDownloadCTL.js",
	"debugjs" : "USBProDownloadCTL/OCX_USBProDownloadCTL.js"
};

//指纹仪控件
ocxObject.OCX_Finger = {
	"content" : {
		"id" : "ocx_finger",
		"classid" : "clsid:0B6CD28F-5650-4FC9-877D-F8398F5A656F"
	},
	"runjs" : "finger/OCX_Finger.js",
	"debugjs" : "finger/OCX_Finger.js"
};

//白纸检测
ocxObject.OCX_ImageProcess = {
	"content": {
		"id": "ocx_imageprocess",
		"classid": "CLSID:94D444FF-3A92-476F-84E6-52ABBC71F3CE"
	}
};

//图像文件操作控件
ocxObject.OCX_IProcOperation = {
	"content": {
		"id": "ocx_iprocoperation",
		"classid": "CLSID:676B7535-C218-4786-B7B7-BBAB37B57B5A"
	}
};

//电子印章印模控件moulage
ocxObject.OCX_ElecMoulage = {
		"content" : {
			"id" : "ocx_elecmoulage",
			"classid" : "CLSID:6E48C719-29D9-467E-A1B7-70EC09E224BD"
		},
		"runjs" : "sealGenerate/OCX_SealGenerate.js",
		"debugjs" : "sealGenerate/OCX_SealGenerate.js",
		"events" : {
			"OnPicOutEx(strImagePath, strSealInfo, strTextInfo)" : "OnPicOutEx(strImagePath, strSealInfo, strTextInfo);"
		}
};

//打印盖章一体机控件moulage
ocxObject.OCX_YKJPrintDevice = {
		"content" : {
			"id" : "ocx_printdevice",
			"classid" : "CLSID:6D4C3A2F-3922-46FA-899D-DA12FC96D062"
		},
		"runjs" : "YKJ_PrintDevice/OCX_YKJPrintDevice.js",
		"debugjs" : "YKJ_PrintDevice/OCX_YKJPrintDevice.js"
};

/**
 * 方法 控件初始化
 * 说明 控件初始化函数，动态生成控件和调用js
 * @param ocxDefine 控件对象定义，在本JS中取，例如 ocxObject.log
 * @param parentElement 生成控件对象的父节点
 * @param height 控件的 高
 * @param width 控件的 宽
 * @param rootpath 调用文件与本js的相对路径
 * @param debugmode 调试模式 run：正式、 debug：调试
 * @returns true：成功； false：失败
 */
ocxObject.initOcx = function(ocxDefine, parentElement, rootpath,
		debugmode, height, width) {
	if (height=="" || typeof(height) == "undefined") { 
		var height = 1;
	} 
	if (width=="" || typeof(width) == "undefined") { 
		var width = 1;
	} 
	var head = document.getElementsByTagName('head')[0];
	if (ocxDefine == "" || ocxDefine == undefined){
		return false;
	}
	try {
		// 动态生成控件
		var object = document.createElement("object");
		object.setAttribute("width", width); // 设置控件宽度
		object.setAttribute("height", height); // 设置控件高度
		if (width == 0 || height == 0)
			object.setAttribute("display", "none");
		// //设置类型为ActiveX控件
		for (i in ocxDefine["content"])
			object.setAttribute(i, ocxDefine["content"][i]);
		parentElement.appendChild(object);
		// 动态加载js
//		if (ocxDefine["runjs"]) {
//			var jsfile = "";
//			if (debugmode == "debug"){
//				jsfile = ocxDefine["debugjs"];
//			}else{
//				jsfile = ocxDefine["runjs"];
//			}
//			var script = document.createElement("script");
//			script.type = "text/javascript";
//			script.src = rootpath + jsfile;
//			head.appendChild(script);
//		}
		// 动态封装控件的事件
//		if (ocxDefine["events"]) {
//			for (i in ocxDefine["events"]) {
//				var eventscript = document.createElement("script");
//				// for不是element的专有属性，需要特殊添加
//				var atr = document.createAttribute("for");
//				atr.nodeValue = ocxDefine["content"]["id"];
//				eventscript.setAttributeNode(atr);
//
//				eventscript.setAttribute("event", i);
//				eventscript.text = ocxDefine["events"][i];
//				head.appendChild(eventscript);
//			}
//		}
		// 验证控件加载是否成功
		var ocx_element = document.getElementById(ocxDefine["content"]["id"]);
		if (ocx_element.object){
			OCXElement[ocxDefine["content"]["id"]] = ocx_element;
			return true;
		}else{
			return false;
		}
	} catch (e) {
		return false;
	}
};

function getYzjgssRootPath(){
	return OCX_Libcurl.getYzjgssRootPath().data;
}
/**
 * js封装控件返回对象工厂
 * @param code 自定义代码 
 * @param data 控件返回值
 * @param msg  错误信息
 * @returns 返回结果对象
 */
function OCXResult(ocx, code, data){
	var obj = new Object();
	obj.code = code;
	obj.data = data;
	obj.msg = "[" + ocx.getAlias() + "]-" + getOCXMsg(code);
	return obj;
};

/**
 * 获取信息   
 * @param code 信息代码
 * @returns 代码解析信息
 */
function getOCXMsg(code){
	//判断是否为空
	var msg = OCXMsg[code];
	if(/^\s*$/g.test(msg)){
		return "未知返回代码[" + code + "]";
	}else{
		return msg;
	}
};

function OCXExceptionResult(ocx, e) {
	//TODO 这里记录e日志
	return OCXResult(ocx, "9300", "");
};