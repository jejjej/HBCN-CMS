/**
 * 创建于:2015-01-13<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 杰表打印控件js封装
 * @author 刘鋆 
 * @author 叶慧雄 修改:2015-11-06
 * @version 1.0
 */


/**
 * 杰表打印控件对象
 */
var OCX_JatoolsPrinter = new Object();

/**
 * 获取杰表打印控件对象
 */
OCX_JatoolsPrinter.getObj = function(){
	return OCXElement[ocxObject.OCX_JatoolsPrinter["content"]["id"]];
};

/**
 * 定义控件别名
 */
OCX_JatoolsPrinter.getAlias = function() {
	 return "JP";
};


//使用手册参考地址： http://print.jatools.com/guide.htm
/**
 * 基本说明：
 * 
 * doc 打印对象：打印文档参数。
 * 该对象有如下属性：
    copyrights:String (必选)
    	版权信息，取值必须为'杰创软件拥有版权  www.jatools.com'。
    documents：Document/String/Object/Array (必选)
    	用来设定要打印的内容来自哪个页面，控件默认要打印的页面里面，必须包含page1,page2,...等这些div。如果指定的页面不包含这些标识的div，则报"不存在可打印的页"错误。
	    类型为Document：
		    表示你需要打印的页面(<div id=page1….><div id=page2….>)在哪个document对象上。这个document对象可以是声明控件的那个文档，也可以是其他任何合法document对象，比如iframe里的document，举例如下：
		    var mydoc = {
		    ...
		    documents:document,// div们在控件所在页面上
		    // document:myiframe.contentWindow.document, div们在iframe上
		    ...
		    }
		    OCX_JatoolsPrinter.print(mydoc);
	    类型为String：
		    表示要打印的div们所在文档的URL。URL可以是绝对地址，也可以相对地址。可以指向静态页面，也可以是一个动态页面，比如jsp，php等：
		    documents:'/abc.htm'
		    documents:'/abc.jsp?id=1'
		    documents:'http://www.xxx.com/abc.jsp?id=1'
	    类型为Object：
		    当你有一个html的字符串，想把它打印成一页时，可以采用带html属性的js对象来指定，如下所示：
		    documents:{html:'<h2>hi,你好!</h2>'}
	    类型为数组(Array)
		    如果你想一次打印多个页面中的div，则可采取数组方式指定各页面，元素类型可以是以上二种中的任意一种。如：
		    documents:['x.htm',
		    document,
		    {html:'<p>hi</p>'},
		    myiframe.contentWidnow.document]
	settingsID：String (可选)
	    打印文档的设置参数ID。 如果你想让控件记住某个文档最后一次打印使用的设置，以便下一次打印同一文档时自动采用，则需要设置该属性。
	    当你设置了该属性，且loadPrintSettings为true， 则控件在打印前，自动从系统的注册表中查找对应的历史打印设置信息，如果找到，则采用找到的参数来设置打印机，此时忽略setttings属性中指定的纸张设置。如果没找到，则使用setttings属性中的设置。
	    当你指定了该参数，且savePrintSettings为true,则控件在打印后，即将打印参数保存到系统中，以便下一次打印同一settingsID的文档时取用。如果你不指定该参数，则系统不从注册表中装载，也不会将打印设置保存到注册表。
	    可以保存的打印设置参数属性即是以下settings属性对象中的内容，比如输出打印机，页高、页宽等。
	settings:Object (可选)
	    你可以使用这个参数来设置你的打印机输出，包括输出到哪个打印机、纸张大小、打印方向。当你指定了 settingsID属性，而且在系统中找到该settingsID的历史打印设置时，本属性所设无效，打印参数将依照历史参数设置之，而忽略本属性中的参数。参照settingsID属性。
    	settings对象有如下属性：
        	printer:String (可选/默认值=系统默认打印机) 
        		输出打印机，当你的系统安装了多台打印机时，比如，有针式打印机，激光打印机，你可以使用这个属性来设置你要求输出的打印机，如果不设置，系统将用默认打印机进行输出。
        	paperName：String（可选/默认=打印机的默认纸张大小）
        		打印纸张类型。对于标准纸张类型，如A3，A4，可以采用本属性来指定纸张大小，对于非标准纸张，建议采用paperWidth,paperHeight来指定纸张大小。本属性值大小写任意：
		        var mydoc =...
		        mydoc.settings.paperName ='a3'; // 'A3'亦可
		        OCX_JatoolsPrinter.print(mydoc);
        	paperWidth / paperHeight：Number（可选/默认=打印机的默认纸张大小）
		        打印纸张的宽度与高度，以1/10毫米为单位。paperWidth必须与paperHeight一起指定，如果仅指定一个参数，则系统忽略。
		        如果你指定的纸张是非标准的纸张大小，控件会自动创建一个自定义纸张，如果你的打印机支持自定义纸张，则选用之，如果不支持，则不设置纸张。
		        多数激光打印机，不支持自定义纸张。针式的票据打印机，一般都会支持。
		        控件自动创建的自定义纸张名称类似这种形式 jatools 1000_9000，即按“Custom 宽_高”规则取名。
		        你的打印机是否支持自定义纸张，可以通过控件的  iscustompapersupport.htm 来测试，该测试页面使用使用控件方法 isCustomPaperSupported 来测试。
        	topMargin / leftMargin / bottomMargin / rightMargin：Number(可选/默认值=打印机默认边距)
        		你可以使用上述属性设置页边距。topMargin, leftMargin, bottomMargin, rightMargin分别表示上，左，下，右边距，单位是 1/10毫米 。多数打印机有最小边距问题，如果你的设置太小，将不会起作用。
        	orientation：Number(可选/默认值=打印机默认纸张方向)
        		打印方向，以纵向还是横向打印，纵向取值为1，横向为2。
        	copies：Number(可选/默认值=打印机默认份数)
        		可以在这里指定要打印的份数
        	copyway:String(可选/默认值='123123')
        		打印顺序，取值112233打印顺序为112233， 取值123123 打印顺序为123123
        	duplex: Number(可选/默认值=1)
        		对于支持双面打印的打印机，你可以使用本属性，来设置双面打印方式 ，可取值1/2/3= 不双面打印/左侧装订/上方装订。
        	header:Object (可选/默认值=不显示页眉) 页眉对象。该对象有两个属性，分别是:
            	html: String/HTML Element(必选)
            	html对象，可以是包含html标签的字符串，也可以是一个HTML Element，比如<div>对象。本属性中，可以包含以下宏变量，以取得相应的页号或时间。
	            宏变量	含义
	               #p	当前页号
	               #P	总页数
	               #d	当前日期，以控制面板/区域与语言选项中设置的短日期格式
	               #D	当前日期，长日期格式
	               #t	当前时间，短时间格式
	               #T	当前时间，长时间格式
            height:Number(必选)
            	页眉对象的高度，以象素为单位
        	footer:Object (可选/默认值=不显示页脚)
        		页脚对象。属性与页眉对象一致。
    done:function(err:String) (可选)
    	打印结束时调用。如果打印成功，则err为空，如果打印出错，err表示出错原因信息。注意，这里的打印成功，表示打印内容已经成功发送到打印队列，并不表示已经成功输出到打印机，也就是说，一些打印机错误，比如卡纸等情况，不在此函数监控之列。
    onPagePrinted:function(pagePrint:Number, pageSize:Number) (可选)
    	回调函数，当打印完一页之后就会调用此函数
    pagePrefix:String (可选/默认值='') 打印页面ID的前缀， 控件查找打印页面序列的规则是:
	    pagePrefix +'page'+页序号(以1开始递增)
	    如本属性为 'doc1' ，则控件以 doc1page1，doc1page2，…这样的顺序查找打印页。
    autoBreakPage:Boolean(可选/默认值=false)
	    是否自动分页打印。true为自动分页，false为不自动分页。当自动分页时，page1，page2…指定的内容如果一页打印不下时，打印不下的内容会自动另起一页打印。false时，控件隐藏打印不下内容（不会另起一页打印）
	    如果有一个表格，行数可能超过一页，你不想用程序分页，你就可以将这个大表格放在page1中，然后，设定autoBreakPage为true，从而让控件来帮你分页。
    loadPrintSettings:Boolean (可选/默认值=true)
    	是否从注册表中，装载历史设置，如果是则装载，反之不装载。应与settingsID属性配合使用，参照settingsID属性。
    savePrintSettings:Boolean (可选/默认值=true)
    	是否将最后一次打印参数，保存到注册表中，如果是则保存，反之不保存。应与settingsID属性配合使用，参照settingsID属性。
    classesReplacedWhenPrint:Array(可选)
    	在打印时替换 css类选择器的定义。你可以在打印或打印预览时，动态地修改这个类的定义。

 */

/**
 * 打印预览
 * @param {Object} doc  打印对象 (对象属性说明见本文件开头)
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_JatoolsPrinter.preview = function(doc) {
	try{
		var result = this.getObj().printPreview(doc, false);
		if(result){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 打印
 * @param {Object} doc  打印对象 (对象属性说明见本文件开头)
 * @param {Boolean} prompt 是否在打印前显示打印机选择对话框，默认false
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_JatoolsPrinter.print = function(doc, prompt) {
	if (typeof(prompt) == "undefined") {
		prompt = false;
	};
	try{
		var result = this.getObj().print(doc, prompt);
		if(result){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 打印到图片
 * @param {Object} doc 打印对象 (对象属性说明见本文件开头)
 * @param {String} path 图片保存路径，如：c:\\1.jpg
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_JatoolsPrinter.printToImage = function(doc,path){
	try{
		var result = this.getObj().printToImage(doc, path);
		if(result){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 取得系统已安装的打印机列表
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:{Array}  打印机名称字符串数组。如果没有安装任何打印机，则返回为null;
 *			obj.msg:提示信息;
 */
OCX_JatoolsPrinter.getPrinters = function() {
	try{
		var result = this.getObj().getPrinters();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 取得指定打印机的可用纸张列表
 * @param {String} printerName 打印机名称
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:{Array}  纸张尺寸对象列表(对象属性有name,width,height)， width,height 以1/10毫米为单位;
 *			obj.msg:提示信息;
 */
OCX_JatoolsPrinter.getPapers = function(printerName) {
	try{
		var result = this.getObj().getPapers(printerName);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 判断指定打印机是否支持自定义纸张大小
 * @param {String} printerName 打印机名称
 * @returns obj(code,data,msg)
 * 			obj.code:"1050",支持;"1051",不支持;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_JatoolsPrinter.isCustomPaperSupported = function(printerName) {
	try{
		var result = this.getObj().isCustomPaperSupported(printerName);
		if(result){
			return OCXResult(this,"1050",result);
		}else{
			return OCXResult(this,"1051",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取系统的默认打印机
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:打印机名称;
 *			obj.msg:提示信息;
 */
OCX_JatoolsPrinter.getDefaultPrinter = function() {
	try{
		var result = this.getObj().getDefaultPrinter();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置系统的默认打印机
 * @param {String} printerName 打印机名称
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_JatoolsPrinter.setDefaultPrinter = function(printerName) {
	try{
		var result = this.getObj().setDefaultPrinter(printerName);
		if(result){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 显示纸张设置对话框，并取得纸张设置参数
 * @return {Object} 打印设置参数对象settings (对象属性说明见本文件开头)
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:{Object} 打印设置参数对象settings (对象属性说明见本文件开头);
 *			obj.msg:提示信息;
 */
OCX_JatoolsPrinter.showPageSetupDialog = function() {
	try{
		var result = this.getObj().showPageSetupDialog();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 取得指定打印设置settingsID的设置对象
 * @param {String} settingsID 打印设置ID
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:{Object} 打印设置参数对象settings (对象属性说明见本文件开头);
 *			obj.msg:提示信息;
 */
OCX_JatoolsPrinter.getLastSettings = function(settingsID) {
	try{
		var result = this.getObj().getLastSettings(settingsID);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置打印参数
 * @param {String} settingsID 需要设置的打印设置ID
 * @param {Object} settings   设置参数对象 (对象属性说明见本文件开头)
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_JatoolsPrinter.setLastSettings = function(settingsID, settings) {
	try{
		this.getObj().setLastSettings(settingsID, settings);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};
