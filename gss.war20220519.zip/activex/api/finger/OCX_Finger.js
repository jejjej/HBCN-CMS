/**
 * 创建于:2016-03-23<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 指纹仪控件 JS 封装
 * @author 叶慧雄
 * @version 1.0
 */
var OCX_Finger = {
	
	/**
	 * 获取控件对象
	 */
	getObj : function(){
		return OCXElement[ocxObject.OCX_Finger["content"]["id"]];
	},
	
	/**
	 * OCXResult对象msg信息中代表某某控件
	 */
	getAlias : function() {
		return "Finger";
	},
	
	/**
	 * 1.获取设备个数
	 * @returns 设备个数
	 */
	getDeviceNum : function() {
		try {
			var result = this.getObj().GetDeviceNum();
			return OCXResult(this, "1001", result);
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	/**
	 * 2.获取指纹特征
	 * @param iDevIndex 设备序号(从0开始)
	 * @param nTimeOut 超时时间(单位：毫秒)。
	 * @returns obj(code,data,msg) obj.code: "9300",调用控件方法异常;
     *		  								 "1001",成功;
     *		  								 "9628",打开指纹仪失败;            
     *		  								 "9629",取消操作;
     *		  								 "9630",等待手指超时;
     *		  								 "9631",采集图像失败;
     *		  								 "9232",上传图像失败;
     *		  								 "9633",提取指纹特征失败;
     *		  								 "9634",合并指纹模板失败;
     *		  								 "9635",参数非法;
     *		  								 "9636",已经在采集图像;
	 *          					obj.data:控件原始返回值;(指纹特征数据，经过Base64编码后的字符串)
	 *          					obj.msg:提示信息;
	 *
	 */
	getFeature : function(iDevIndex,nTimeOut) {
		try {
			var result = this.getObj().GetFeature(iDevIndex,nTimeOut);
			return this.getReturnData(result);
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	/**
	 * 3.获取指纹特征时的图像。（调用该函数时，需要先调用GetFeature函数）
	 * @returns 成功：指纹图像信息（指纹图像数据进行Base64编码后的字符串）；
	 * 			失败：-1
	 */
	getFeatureImage : function() {
		try {
			var result = this.getObj().GetFeatureImage();
			if(result == -1){
				return OCXResult(this,"9200",result);
			}else{
				return OCXResult(this,"1001",result);
			}
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	/**
	 * 4.获取指纹模板
	 * @param iDevIndex 设备序号(从0开始)
	 * @param nTimeOut 超时时间(单位：毫秒)。
	 * @returns obj(code,data,msg) obj.code: "9300",调用控件方法异常;
     *		  								 "1001",成功;
     *		  								 "9628",打开指纹仪失败;            
     *		  								 "9629",取消操作;
     *		  								 "9630",等待手指超时;
     *		  								 "9631",采集图像失败;
     *		  								 "9232",上传图像失败;
     *		  								 "9633",提取指纹特征失败;
     *		  								 "9634",合并指纹模板失败;
     *		  								 "9635",参数非法;
     *		  								 "9636",已经在采集图像;
	 *          					obj.data:控件原始返回值;(指纹模板数据，经过Base64编码后的字符串)
	 *          					obj.msg:提示信息;
	 *
	 */
	getTemplate : function(iDevIndex,nTimeOut) {
		try {
			var result = this.getObj().GetTemplate(iDevIndex,nTimeOut);
			return this.getReturnData(result);
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	/**
	 * 5.获取指纹模板时的图像。（调用该函数时，需要先调用GetTemplate函数）
	 * @param iImageIndex 图像序号，1-3
	 * @returns 成功：指纹图像信息（指纹图像数据进行Base64编码后的字符串）；
	 *			失败： -1 
	 */
	getTemplateImage : function(iImageIndex) {
		try {
			var result = this.getObj().GetTemplateImage(iImageIndex);
			if(result == -1){
				return OCXResult(this,"9200",result);
			}else{
				return OCXResult(this,"1001",result);
			}
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	/**
	 * 6.指纹模板与指纹特征比对。
	 * @param mb - 指纹模板数据，经过Base64编码后的字符串
	 * @param tz - 指纹特征数据，经过Base64编码后的字符串
	 * @param level - 安全等级，1-5级，级别越高，越安全，一般取3。
	 * @returns 0   - 比对通过；
	 *			非 0  - 比对失败。
	 */
	fingerMatch : function(mb, tz,level) {
		try {
			var result = this.getObj().FingerMatch(mb, tz,level);
			if(result == 0){
				return OCXResult(this,"1001",result);
			}else{
				return OCXResult(this,"9200",result);
			}
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	/**
	 * 7.获取指纹图像
	 * @param iDevIndex 设备序号(从0开始)
	 * @param nTimeOut 超时时间(单位：毫秒)。
	 * @returns obj(code,data,msg) obj.code: "9300",调用控件方法异常;
     *		  								 "1001",成功;
     *		  								 "9628",打开指纹仪失败;            
     *		  								 "9629",取消操作;
     *		  								 "9630",等待手指超时;
     *		  								 "9631",采集图像失败;
     *		  								 "9232",上传图像失败;
     *		  								 "9633",提取指纹特征失败;
     *		  								 "9634",合并指纹模板失败;
     *		  								 "9635",参数非法;
     *		  								 "9636",已经在采集图像;
	 *          					obj.data:控件原始返回值;(指纹图像信息 指纹图像数据，并且经过Base64编码后的字符串)
	 *          					obj.msg:提示信息;
	 */
	getImage : function(iDevIndex, nTimeOut) {
		try {
			var result = this.getObj().GetImage(iDevIndex, nTimeOut);
			return this.getReturnData(result);
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	/**
	 * 8.将Base64编码的指纹图像数据，保存为BMP文件
	 * @param szFileName BMP文件名
	 * @param pImage 指纹图像数据，并且经过Base64编码后的字符串
	 * @returns 0   - 成功；
	 * 			非 0  - 失败。
	 */
	imageToBmpFile : function(szFileName, pImage) {
		try {
			var result = this.getObj().ImageToBmpFile(szFileName, pImage);
			if(result == 0){
				return OCXResult(this,"1001",result);
			}else{
				return OCXResult(this,"9200",result);
			}
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	/**
	 * 9.获取设备版本
	 * @param iDevIndex 设备序号(从0开始)
	 * @returns 设备版本信息
	 */
	getDevVersion : function(iDevIndex) {
		try {
			var result = this.getObj().GetDevVersion(iDevIndex);
			return OCXResult(this, "1001", result);
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	/**
	 * 10.设置采集图像、采集特征、采集模板过程中，是否显示对话框
	 * @param iShowMode 0：不显示，1：显示中文对话框，2：显示英文对话框
	 * @returns 0 – 设置成功
	 */
	setShowMode : function(iShowMode) {
		try {
			var result = this.getObj().SetShowMode(iShowMode);
			if(result == 0){
				return OCXResult(this,"1001",result);
			}else{
				return OCXResult(this,"9200",result);
			}
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	/**
	 * 11.获取库版本
	 * @returns 库版本信息
	 */
	getOcxVersion : function() {
		try {
			var result = this.getObj().GetOcxVersion();
			return OCXResult(this, "1001", result);
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	/**
	 * 12.获取算法版本
	 * @returns 算法版本信息
	 */
	getAlgVersion : function() {
		try {
			var result = this.getObj().GetAlgVersion();
			return OCXResult(this, "1001", result);
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	/**
	 * 13.合并模板
	 * @param tz1
	 * @param tz2
	 * @param tz3
	 * @returns 成功：指纹模板数据，经过Base64编码后的字符串
	 *			失败： -7
	 */
	mergeTemplate : function(tz1, tz2, tz3) {
		try {
			var result = this.getObj().MergeTemplate(tz1, tz2, tz3);
			if(result == -7){
				return OCXResult(this,"9200",result);
			}else{
				return OCXResult(this,"1001",result);
			}
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
/********************************串口********************************************************/
	
	/**
	 * 1.获取指纹特征
	 * @param iPort 串口号（1：串口1，2：串口2，3：串口3）
	 * @param nTimeOut 超时时间(单位：毫秒)
	 * @returns obj(code,data,msg) obj.code: "9300",调用控件方法异常;
     *		  								 "1001",成功;
     *		  								 "9628",打开指纹仪失败;            
     *		  								 "9629",取消操作;
     *		  								 "9630",等待手指超时;
     *		  								 "9631",采集图像失败;
     *		  								 "9232",上传图像失败;
     *		  								 "9633",提取指纹特征失败;
     *		  								 "9634",合并指纹模板失败;
     *		  								 "9635",参数非法;
     *		  								 "9636",已经在采集图像;
	 *          					obj.data:控件原始返回值;(指纹特征数据，经过Base64编码后的字符串)
	 *          					obj.msg:提示信息;
	 */
	getComFeature : function(iPort, nTimeOut) {
		try {
			var result = this.getObj().GetComFeature(iPort, nTimeOut);
			return this.getReturnData(result);
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	/**
	 * 2.获取指纹模板
	 * @param iPort 串口号（1：串口1，2：串口2，3：串口3）
	 * @param nTimeOut 超时时间(单位：毫秒)
	 * @returns obj(code,data,msg) obj.code: "9300",调用控件方法异常;
     *		  								 "1001",成功;
     *		  								 "9628",打开指纹仪失败;            
     *		  								 "9629",取消操作;
     *		  								 "9630",等待手指超时;
     *		  								 "9631",采集图像失败;
     *		  								 "9232",上传图像失败;
     *		  								 "9633",提取指纹特征失败;
     *		  								 "9634",合并指纹模板失败;
     *		  								 "9635",参数非法;
     *		  								 "9636",已经在采集图像;
	 *          					obj.data:控件原始返回值;(指纹模板数据，经过Base64编码后的字符串)
	 *          					obj.msg:提示信息;
	 */
	getComTemplate : function(iPort, nTimeOut) {
		try {
			var result = this.getObj().GetComTemplate(iPort, nTimeOut);
			return this.getReturnData(result);
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},
	
	/**
	 * 3.获取设备版本
	 * @param iPort 串口号（1：串口1，2：串口2，3：串口3）
	 * @returns 设备版本信息
	 */
	getComDevVersion : function(iPort) {
		try {
			var result = this.getObj().GetComDevVersion(iPort);
			return OCXResult(this, "1001", result);
		} catch (e) {
			return OCXExceptionResult(this, e);
		}
	},

/********************************内部工具方法********************************************************/
	
	/**
	 * 控件返回值封装 适用方法 getFeature(iDevIndex, nTimeOut)
	 * 						getTemplate(iDevIndex, nTimeOut)
	 * 						getImage(iDevIndex, nTimeOut)
	 * @param result 控件返回值
	 * @returns obj(code,data,msg) obj.code: "1001",成功;
     *		  								 "9628",打开指纹仪失败;            
     *		  								 "9629",取消操作;
     *		  								 "9630",等待手指超时;
     *		  								 "9631",采集图像失败;
     *		  								 "9232",上传图像失败;
     *		  								 "9633",提取指纹特征失败;
     *		  								 "9634",合并指纹模板失败;
     *		  								 "9635",参数非法;
     *		  								 "9636",已经在采集图像;
	 *          					obj.data:控件原始返回值;
	 *          					obj.msg:提示信息;
	 */
	getReturnData : function(result) {
		if(result == -1){
			return OCXResult(this,"9628",result);
		}else if(result == -2){
			return OCXResult(this,"9629",result);
		}else if(result == -3){
			return OCXResult(this,"9630",result);
		}else if(result == -4){
			return OCXResult(this,"9631",result);
		}else if(result == -5){
			return OCXResult(this,"9632",result);
		}else if(result == -6){
			return OCXResult(this,"9633",result);
		}else if(result == -7){
			return OCXResult(this,"9634",result);
		}else if(result == -10){
			return OCXResult(this,"9635",result);
		}else if(result == -11){
			return OCXResult(this,"9636",result);
		}else{
			return OCXResult(this,"1001",result);
		}
	}
};