/**
 * 创建于:2015-10-28<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 图片工具控件JS封装
 * @author 叶慧雄
 * @version 1.0 
 */

//定义图片工具控件对象
var OCX_ImgHelper = new Object();

/**
 * 获取图片工具控件对象
 */
OCX_ImgHelper.getObj = function(){
	return OCXElement[ocxObject.OCX_ImgHelper["content"]["id"]];
};

/**
 * 定义控件别名
 */
OCX_ImgHelper.getAlias = function() {
	 return "IH";
};

/** 
 * 加载图像
 * @param  ImgPath 图像文件全路径
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_ImgHelper.loadImage = function(ImgPath) {
    try{
		//resulet 0：成功； 其他：失败
		var result = this.getObj().LoadImage(ImgPath);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * @param  lpszImgPath 图片绝对路径
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_ImgHelper.startSetSealNoCheckPoints = function(lpszImgPath) {
    try{
		//resulet
    	this.getObj().StartSetSealNoCheckPoints(lpszImgPath);
    	return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取多边形区域信息，字符串类型
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"1048",用户取消操作;"9300",调用控件方法异常;
 * 			obj.data:多边形区域信息，字符串类型。包含多边形每个定点的坐标值，格式为 “x0,y0,x1,y1 …”;
 *			obj.msg:提示信息;
 */
OCX_ImgHelper.getNotCheckPoints = function() {
    try{
		//resulet 多边形区域信息 当返回值为空时，表示用户取消操作。
		var result = this.getObj().GetNotCheckPoints();
		if(/^\s*$/g.test(result)){
			return OCXResult(this,"1048","");
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取指定图片的尺寸
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:width*height，如640*480
 *			obj.msg:提示信息;
 */
OCX_ImgHelper.getImageSize = function(imgPath) {
    try{
		//resulet width*height
		var result = this.getObj().GetImageSize(imgPath);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 旋转图片
 * 
 * @param imgSrcPath
 *                图片源路径
 * @param imgDestPath
 *                旋转后图片路径
 * @param angle
 *                旋转角度
 * 
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_ImgHelper.rotateImage = function(imgSrcPath, imgDestPath, angle) {
    try{
		//resulet 0：成功； 其他：失败
		var result = this.getObj().RotateImage(imgSrcPath, imgDestPath, angle);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};