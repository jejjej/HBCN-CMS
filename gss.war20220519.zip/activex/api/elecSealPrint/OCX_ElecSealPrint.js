/**
 * 创建于:2015-10-28<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 独立盖章控件JS封装
 * @author 叶慧雄
 * @version 1.0 
 */

// 定义独立盖章控件对象
var OCX_ElecSealPrint = new Object();

/**
 * 获取独立盖章控件对象
 */
OCX_ElecSealPrint.getObj = function(){
	return OCXElement[ocxObject.OCX_ElecSealPrint["content"]["id"]];
};

/**
 * 定义控件别名
 */
OCX_ElecSealPrint.getAlias = function() {
	 return "ESP";
};

//INI配置文件
OCX_ElecSealPrint.iniPath = top.yzjgssRootPath + "/yzjgss/config/3x/gss.ini";
/********************基本场景应用******************************/
/**
 * 开始打印图片
 * 
 * @param strPath
 *            图片文件的全路径，如C:\\a.jpg
 * @param lPosX
 *            位置x(毫米)
 * @param lPosY
 *            位置y(毫米)
 * @param lWidth
 *            宽,单位（毫米）
 * @param lHeight
 *            高,单位（毫米）
 * @returns Boolean true：成功； false：失败
 * 
 */
OCX_ElecSealPrint.startPrintPic = function(strPath, lPosX, lPosY, lWidth, lHeight) {
	//转换长宽单位
	lPosX = lPosX*10;
	lPosY = lPosY*10;
	lWidth = lWidth*10;
	lHeight = lHeight*10;
	if (this.setPicPath(strPath, lPosX, lPosY, lWidth, lHeight).code != "1001") {
		return this.setPicPath(strPath, lPosX, lPosY, lWidth, lHeight);
	};
	var printerName = OCX_Tools.readIni(this.iniPath, "gss", "printername", "").data;
	if (this.setPrinterInfo(printerName).code != "1001") {
		return this.setPrinterInfo(printerName);
	};
	return this.startPrint();
};

/**
 * 开始打印防伪码
 * 
 * @param strData
 *            防伪码 数字格式，非数字会打印成A
 * @param lPosX
 *            位置x(毫米)
 * @param lPosY
 *            位置y(毫米)
 * @param lWidth
 *            宽,单位（毫米）
 * @param lHeight
 *            高,单位（毫米）
 * @returns Boolean true：成功； false：失败
 * 
 */
OCX_ElecSealPrint.startPrintStr = function(strData, lPosX, lPosY, lWidth, lHeight) {
	var printerName = OCX_Tools.readIni(this.iniPath, "gss", "printername", "").data;
	if (this.setPrinterInfo(printerName).code != "1001") {
		return this.setPrinterInfo(printerName);
	};
	//转换长宽单位
	lPosX = lPosX*10;
	lPosY = lPosY*10;
	lWidth = lWidth*10;
	lHeight = lHeight*10;
	return this.printRegString(strData, lPosX, lPosY, lWidth, lHeight)
};
/*************控件封装***********************************/
/**
 * 设置其他信息。格式“"X:190,Y:220,SIZE:40,VALUE:上海XXXX支行;X:230,Y:260,SIZE:40,VALUE:业务专用章”。
 * 每条打印记录间以；分隔。X，Y为打印位置，size为字符大小，VALUE为打印内容。计量单位0.1mm
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_ElecSealPrint.setPrintParam = function(strParam){
	try{
		//resulet 0：成功； 其他：失败
		var result = this.getObj().SetPrintParam(strParam);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置印章信息
 * @param strPath为印章图片路径，其他依次为位置和宽高。单位0.1mm
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_ElecSealPrint.setPicPath = function(strPath,lPosX,lPosY,lWidth,lHeight){
	try{
		//resulet 0：成功； 其他：失败
		var result = this.getObj().SetPicPath(strPath,lPosX,lPosY,lWidth,lHeight);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置打印机信息
 * @param strPrinterName为打印机名字
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_ElecSealPrint.setPrinterInfo = function(strPrinterName){
	try{
		//resulet 0：成功； 其他：失败
		var result = this.getObj().SetPrinterInfo(strPrinterName);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 开始打印
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_ElecSealPrint.startPrint = function(){
	try{
		//resulet 0：成功； 其他：失败
		var result = this.getObj().StartPrint();
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 打印标识字符串，与SetPrinterInfo配合使用。
 * @param strData标识内容，
 * @param lPosX，lPosY位置坐标，单位0.1mm      lWidth,lHeight无意义。 
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_ElecSealPrint.printRegString = function(strData,lPosX,lPosY,lWidth,lHeight){
	try{
		//resulet 0：成功； 其他：失败
		var result = this.getObj().PrintRegString(strData,lPosX,lPosY,lWidth,lHeight);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 防伪码识别
 * @param strFileName
 *            识别图片路径
 * @param top
 *            识别区域的top(像素)
 * @param left
 *            识别区域的left(像素)
 * @param bottom
 *            识别区域的bottom(像素)
 * @param right
 *            识别区域的right(像素)
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:识别出来的防伪码值;
 *			obj.msg:提示信息;
 */
OCX_ElecSealPrint.regString = function(strFileName,top,left,bottom,right){
	try{
		//resulet 识别出来的防伪码值 如果识别失败，返回空字符
		var result = this.getObj().RegString(strFileName,top,left,bottom,right);
		if(/^\s*$/g.test(result)){
			return OCXResult(this,"9200","");
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
	
};

/**
 * 旋转图像
 * @param strSrc：待旋转图像的全路径    
 * @param strDest：旋转后的图像的全路径   
 * @param angle:旋转角度
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_ElecSealPrint.rotateImage = function(strSrc,strDest,angel){
	try{
		//resulet 0-----成功     -1----失败
		var result = this.getObj().RotateImage(strSrc,strDest,angel);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};
/**
 * 获取错误代码的信息
 * 
 * @param code
 *            错误代码
 * @returns {String} 错误代码代表的含义
 */
OCX_ElecSealPrint.getErrorMessage = function(code) {
	var reStr = "";
	switch (code) {
	case -1:
		reStr = "打印机连接不上";
		break;
	default:
		reStr = "未知返回码[" + code + "]";
	};
	return OCXResult(this,"1001",reStr);
};
