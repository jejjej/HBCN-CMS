/**
 * 电子印章js封装
 * 包含电子印章生成、图像处理接口、验证码与重空凭证号识别功能
 * 电子印章控件：CLSID:6E48C719-29D9-467E-A1B7-70EC09E224BD
 */

//定义印模控件
var OCX_Moulage = new Object();

/**
 * 获取电子印章控件对象
 */
OCX_Moulage.getObject = function() {
	return document.getElementById(ocxObject.OCX_ElecMoulage["content"]["id"]);
};

OCX_Moulage.getAlias = function() {
	 return "OM";
};

/************************************电子印章相关接口*****************************/
/**
 * 生成当前印章图片（全路径）。支持jpg，png，bmp，tif， gif
 */
OCX_Moulage.GeneratePic = function (strImage) {
	try{
		this.getObject().GeneratePic(strImage);
		return OCXResult(this, "1001", "");
	}catch(e){
		return OCXExceptionResult(this, e);
	}
};

/**
 * 清除配置信息
 */
OCX_Moulage.Reset = function () {
	try{
		this.getObject().Reset();
		return OCXResult(this, "1001", "");
	}catch(e){
		return OCXExceptionResult(this, e);
	}
};

/**
 * 设置运行模式。0，可编辑各种印章。1，按传入的印章配置显示可配置信息。2，预览模式。显示的为最近传入的印章配置。默认为模式1
 */
OCX_Moulage.SetRunMode = function (iType) {
	try{
		this.getObject().SetRunMode(iType);
		return OCXResult(this, "1001", "");
	}catch(e){
		return OCXExceptionResult(this, e);
	}
};

/**
 * 设置印章颜色。RGB32模式
 */
OCX_Moulage.SetPenColor = function (r,g,b) {
	try{
		this.getObject().SetPenColor(r,g,b);
		return OCXResult(this, "1001", "");
	}catch(e){
		return OCXExceptionResult(this, e);
	}
};

/**
 * 设置图片输出路径
 */
OCX_Moulage.SetPicDir = function (strDir) {
	try{
		this.getObject().SetPicDir(strDir);
		return OCXResult(this, "1001", "");
	}catch(e){
		return OCXExceptionResult(this, e);
	}
};

/**
 * 设置印章保存图片类型。0：png；1，1位bmp；2，32位bmp；3，jpg；4，gif；5，tif。其他为png格式。默认为png
 */
OCX_Moulage.SetImageType = function (imageType) {
	try{
		this.getObject().SetImageType(imageType);
		return OCXResult(this, "1001", "");
	}catch(e){
		return OCXExceptionResult(this, e);
	}
};

/**
 * 设置印章数据模板
 */
OCX_Moulage.SetSealData = function(strSealInfo,strTextInfo) {
	try{
		this.getObject().SetSealData(strSealInfo,strTextInfo);
		return OCXResult(this, "1001", "");
	}catch(e){
		return OCXExceptionResult(this, e);
	}
};

/**
 * 设置保存图像的dpi值
 */
OCX_Moulage.SetDpi = function(dpi){
	try{
		this.getObject().SetDpi(dpi);
		return OCXResult(this, "1001", "");
	}catch(e){
		return OCXExceptionResult(this, e);
	}
};

/**
 * 根据文件后缀，设置印章图片类型
 * @param picType png,1位bmp,32位bmp,jpg,gif,tif。其他为png格式。默认为png。
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_Moulage.SetPicType = function (picType) {
	try{
		if (picType == ".bmp") {
			this.getObject().SetImageType(1);
		} else if (picType == ".32bmp") {
			this.getObject().SetImageType(2);
		} else if (picType == ".jpg") {
			this.getObject().SetImageType(3);
		} else if (picType == ".gif") {
			this.getObject().SetImageType(4);
		} else if (picType == ".tif") {
			this.getObject().SetImageType(5);
		} else {//默认为png
			this.getObject().SetImageType(0);
		}
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	}
};

/**
 * 根据颜色类型，设置印章颜色
 * @param type 颜色类型，0红色(默认),2蓝色,1黑色
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_Moulage.SetColor = function (type) {
	try{
		if (type == "2") {//蓝色
			this.getObject().SetPenColor(0, 0, 255);
		} else if(type == "1") {//黑色
			this.getObject().SetPenColor(0, 0, 0);
		} else {//0红色
			this.getObject().SetPenColor(255, 0, 0);
		}
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	}
};

/************************************图像处理接口*****************************/
/**
 * 16位验证码识别
 * path:图片绝对路径
 * left，top，right，bottom 为图像的识别区域左上右下像素点坐标
 * dpi：图像dpi，传入0为读取图片写入的DPI
 */
OCX_Moulage.VerifyCodeReg = function(path,left,top,right,bottom,dpi){
	try{
		var code = this.getObject().VerifyCodeReg(path,left,top,right,bottom,dpi);
		return OCXResult(this, "1001", code);
	}catch(e){
		return OCXExceptionResult(this, e);
	}
};

/**
 * 重空票据号识别
 * path:图片绝对路径
 * left，top，right，bottom 为图像的识别区域左上右下像素点坐标
 * dpi：图像dpi，传入0为读取图片写入的DPI
 */
OCX_Moulage.CertSNCodeReg = function(path,left,top,right,bottom,dpi){
	try{
		var code = this.getObject().CertSNCodeReg(path,left,top,right,bottom,dpi);
		return OCXResult(this, "1001", code);
	}catch(e){
		return OCXExceptionResult(this, e);
	}
};

/**
 * 图像dpi转换
 * srcPath:原图路径
 * destPath:转换后的图像路径
 * srcDpi:原图dpi
 * destDpi:转换后的图像dpi
 * srcDpi，源图dpi，传入0为读取图片写入的DPI。 destDpi，目标图dpi，传入0为复制原图
 */
OCX_Moulage.TransDpi = function(srcPath,destPath,srcDpi,destDpi){
	try{
		this.getObject().TransDpi(srcPath,destPath,srcDpi,destDpi);
		return OCXResult(this, "1001", "");
	}catch(e){
		return OCXExceptionResult(this, e);
	}
};

/**
 * 旋转图像
 * srcPath:原图路径
 * destPath:旋转后的图像路径
 * angle:旋转角度 +-角度
 * 
 */
OCX_Moulage.RotateImage = function(srcPath,destPath,angle){
	try{
		this.getObject().RotateImage(srcPath,destPath,angle);
		return OCXResult(this, "1001", "");
	}catch(e){
		return OCXExceptionResult(this, e);
	}
};
