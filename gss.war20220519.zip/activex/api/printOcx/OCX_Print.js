/**
 * 创建于:2015-10-28<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 一体化打印控件JS封装 
 * @author 叶慧雄
 * @version 1.0
 */

//定义打印控件封装JS对象
var OCX_Print = new Object();

/**
 * 获取打印控件对象
 */
OCX_Print.getObj = function() {
	return OCXElement[ocxObject.OCX_Print["content"]["id"]];
};

OCX_Print.getAlias = function() {
	 return "OP";
};
//INI配置文件
OCX_Print.iniPath = top.yzjgssRootPath + "/yzjgss/config/3x/gss.ini";
/********************基本场景应用**********************************/
var interval_print;	//打印定时器对象
var errmsg = "";

/**
 * 开始打印
 * @param xmldata  打印模板数据
 * @param datalist	打印数据
 * @param	callBackError		打印异常回调函数，带参数，参数意义详见PrintOcx.getErrorMessage
 * @param callBackSuccess	打印成功回调函数，无参数
 * @returns true 成功，false 失败
 */
OCX_Print._startPrint = function(xmldata,datalist,callBackError,callBackSuccess){
	printxmlpath = OCX_Tools.readIni(this.iniPath, "gss","terminalPath",top.yzjgssRootPath + "\\yzjgss\\template\\3x\\print").data;
	printxmlfile = OCX_Tools.readIni(this.iniPath, "gss","terminalFile",top.yzjgssRootPath + "\\yzjgss\\template\\3x\\print\\printxml.xml").data;
	OCX_Tools.writeXML(xmldata,printxmlfile);//写xml文件内容到printxmlpath
	var loadmode = this.loadXMLFile(printxmlpath,errmsg);//加载XML模板
	if(loadmode.code != "1001") {
		loadmode.data = "加载模板失败.";
		return loadmode;
	};
	var ra = this.addPrintData(datalist);//添加打印数据
	if(ra.code != "1001"){
		loadmode.data = "添加打印数据失败.";
		return ra;
	}
	var rs = this.startPrint(errmsg);
	if(rs.code != "1001") { //开始打印
		loadmode.data = "打印失败.";
		return rs;
	};
	var self = this;
	//启动定时检测打印状态
	interval_print = setInterval(function(){
		var resultObj = self.getPrinterStatus();// 获取打印状态
		var result = resultObj.data; 
		if (result=="0" ||result=="-1" ||result=="-2" ||result=="-3" ||result=="-4" ||result=="-5" || result=="515") {
			//ignore
		} else {
			clearInterval(interval_print);
			self.stopPrint();
			if (result == "4") {//打印完成
				callBackSuccess();
			} else {
				callBackError(resultObj);
			}
		}
	},1000);
	return OCXResult(this,"1001", "成功");
};

/********************控件封装**************************************/
/**
 * 加数据
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_Print.addPrintData = function(strData){
	try{
		var result = this.getObj().AddPrintData(strData);
		if(result >= 1){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 加载配置文件夹  或者 相应的单文件的xml数据流，参数2无效传空 .
 * 当加载的为 xml数据流 时，如果配置中的 "receiptType":XX 相同，则会覆盖前面的配置。
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_Print.loadXMLFile = function(strFileName,errorMsg){
	try{
		var result = this.getObj().LoadXMLFile(strFileName,errorMsg);
		if(result){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取需打印数据份数
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_Print.getDataSize = function(){
	try{
		var result = this.getObj().GetDataSize();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_Print.getPrintInfo = function(lPrintedPage,errorMsg){
	try{
		var result = this.getObj().GetPrintInfo(lPrintedPage,errorMsg);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 开始打印，参数无效传空.需确认返回正确if(!rs)
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_Print.startPrint = function(errorMsg){
	try{
		var result = this.getObj().StartPrint(errorMsg);
		if(!result){
			return OCXResult(this,"9200",result);
		}else{
			return OCXResult(this,"1001",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 开启监控(盖章机和打印机)，参数无效
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_Print.setPrinterInfo = function(printerDllPath){
	try{
		var result = this.getObj().SetPrinterInfo(printerDllPath);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 开启监控（盖章机是否允许盖章），参数为滚章/盖章库路径
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_Print.setStampInfo = function(stampDllPath){
	try{
		var result = this.getObj().SetStampInfo(stampDllPath);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 停止正在打印的线程
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_Print.stopPrint = function(){
	try{
		this.getObj().StopPrint();
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * /获取打印状态
 * 
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9402",打印机少纸;"9403",打印机模式异常;"9404",打印机或纸张设置错误;
 * 					 "9001",盖章机通讯异常;"9002",打印机通讯异常;"9405",硒鼓油墨不足;"9406",无硒鼓;
 * 					 "9407",打印机空闲;"9408",打印机工作中;"9409",打印机预热;"9410",盖章机进纸位置卡纸;
 * 					 "9411",盖章机拍章位置卡纸;"9412",盖章机电机故障;"9413",前门打开;"9414",后门打开;
 * 					 "9415",前后门打开;"9416",盖章机异常;"9417",打印机或盖章机卡纸;"9418",打印机缺纸;
 * 					 "9419",打印机状态异常;"9100",机器故障;"9300",调用控件方法异常;
 * 			obj.data:4，正常结束；
 * 					 3，打印机连接故障
 * 					 0，打印中或未开始，
 * 					 i//卡纸  0x200 + 1;
 * 					 //缺纸 0x200 + 2;
 * 					 纸盒未关闭 0x200 + 4;
 * 					 取打印机状态失败 3;
 * 					 //少纸 -1;
 * 					 忽略（未知）   -2
 * 					 盖章设备库初始化失败 ，打开串口失败 2;
 *			obj.msg:提示信息;
 */
OCX_Print.getPrinterStatus = function(){
	try{
		var result = this.getObj().GetPrinterStatus();
		if(result=="4"){
			return OCXResult(this,"1001",result);
		}else if(result=="-1"){
			return OCXResult(this,"9402",result);
		}else if(result=="-2"){
			return OCXResult(this,"9403",result);
		}else if(result=="1"){
			return OCXResult(this,"9404",result);
		}else if(result=="2"){
			return OCXResult(this,"9001",result);
		}else if(result=="3"){
			return OCXResult(this,"9002",result);
		}else if(result=="516"){
			return OCXResult(this,"9405",result);
		}else if(result=="517"){
			return OCXResult(this,"9406",result);
		}else if(result=="-3"){
			return OCXResult(this,"9407",result);
		}else if(result=="-4"){
			return OCXResult(this,"9408",result);
		}else if(result=="-5"){
			return OCXResult(this,"9409",result);
		}else if(result=="257"){
			return OCXResult(this,"9410",result);
		}else if(result=="258"){
			return OCXResult(this,"9411",result);
		}else if(result =="259"){
			return OCXResult(this,"9412",result);
		}else if(result == "260" || result == "261" || result == "262" || result == "263"){
			return OCXResult(this,"9413",result);
		}else if(result == "264" || result == "265" || result == "266" || result == "267"){
			return OCXResult(this,"9414",result);
		}else if(result == "268" || result == "269" || result == "270" || result == "271"){
			return OCXResult(this,"9415",result);
		}else if(result=="304"){
			return OCXResult(this,"9416",result);
		}else if(result=="513"){
			return OCXResult(this,"9417",result);
		}else if(result=="514"){
			return OCXResult(this,"9418",result);
		}else if(result=="515"){
			return OCXResult(this,"9419",result);
		}else{
			return OCXResult(this,"9100",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取章数
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:章数;
 *			obj.msg:提示信息;
 */
OCX_Print.getPrintedNum = function(){
	try{
		var result = this.getObj().GetPrintedNum();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取错误信息
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:错误信息;
 *			obj.msg:提示信息;
 */
OCX_Print.getErrorMsg = function(){
	try{
		var result = this.getObj().GetErrorMsg();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 预热
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_Print.preparePrinter = function(){
	try{
		this.getObj().PreparePrinter();
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取盖章机序列号等
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:盖章机序列号等;
 *			obj.msg:提示信息;
 */
OCX_Print.getStampSerial = function(stampDllPath){
	try{
		var result = this.getObj().GetStampSerial(stampDllPath);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取打印机序列号
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:打印机序列号;
 *			obj.msg:提示信息;
 */
OCX_Print.getPrinterSerial = function(){
	try{
		var result = this.getObj().GetPrinterSerial();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 打开/关闭盖章机报警
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_Print.setAlarm = function(stampDllPath,iStatus){
	try{
		var result = this.getObj().SetAlarm(stampDllPath,iStatus);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 枚举系统打印机。以‘，’分隔
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:枚举系统打印机。以‘，’分隔;
 *			obj.msg:提示信息;
 */
OCX_Print.enumPrintersName = function(){
	try{
		var result = this.getObj().EnumPrintersName();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 选择打印机，如果不调用此函数，则使用默认打印机。使用此函数后需要重新加载配置文件
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_Print.selPrinter = function(strPrinterName){
	try{
		var result = this.getObj().SelPrinter(strPrinterName);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 加载文件的xml数据流  与 LoadXMLFile 部分的加载文件流功能相同 返回
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_Print.loadXMLString = function(strXml){
	try{
		var result = this.getObj().LoadXMLString(strXml);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};
