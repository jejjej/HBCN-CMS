// 
//  flexVTM.js
//  视频流服务前端播放或录制js
//  
//  Created by JUST20 on 2015-01-23.
//  Copyright 2015 深圳市银之杰科技股份有限公司. All rights reserved.
// 

/**
 * 控件定义对象
 */
var flexVTM = new Object();

/**
 * js文件版本
 */
flexVTM.version = "1.0.20150302";

/**
 * 控件配置文件
 */
flexVTM.PROFILE_PATH = "FlexVTM.ini";

/**
 * 控件计时器
 */
flexVTM.start_timer = 0;

/**
 * 初始化控件
 * @param {Object} parentElement 父元素
 * @param {Object} height 元素高度
 * @param {Object} width 元素宽度
 * @param {Object} rootpath	父路径
 *
 * 该方法未实现（embed元素未能成功插入），请先自行在页面上定义object对象，后续再完善该方法。
 */
flexVTM.initObject = function(parentElement, height, width, rootpath) {
	var object = document.createElement("object");
	object.setAttribute("width", width); // 设置控件宽度
	object.setAttribute("height", height); // 设置控件高度
	if (width == 0 || height == 0) {
		object.setAttribute("display", "none");
	};
	object.setAttribute("id", "FlexVTM");
	object.setAttribute("classid", "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000");
	object.setAttribute("codebase", rootpath + "cab/swflash.cab");


	//	var embed = '<embed src="'+ rootpath+'cab/FlexVTM.swf" quality="high" bgcolor="#ffffff" width="'
	//			  + width + '" height="'+height+'" name="FlexVTM" align="middle" play="true" loop="false" quality="high" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.adobe.com/go/getflashplayer">';
	//	object.innerHTML = embed;
	//

	var param = document.createElement("param");
	param.setAttribute("movie", rootpath + "cab/FlexVTM.swf");
	param.setAttribute("quality", "high");
	param.setAttribute("bgcolor", "#ffffff");
	param.setAttribute("allowScriptAccess", "sameDomain");
	object.appendChild(param);

	var embed = document.createElement("embed");
	embed.setAttribute("src", rootpath + "cab/FlexVTM.swf");
	embed.setAttribute("quality", "high");
	embed.setAttribute("bgcolor", "#ffffff");
	embed.setAttribute("width", width);
	embed.setAttribute("height", height);
	embed.setAttribute("name", "FlexVTM");
	embed.setAttribute("align", "middle");
	embed.setAttribute("play", "true");
	embed.setAttribute("loop", "false");
	embed.setAttribute("quality", "high");
	embed.setAttribute("allowScriptAccess", "always");
	embed.setAttribute("type", "application/x-shockwave-flash");
	embed.setAttribute("pluginspage", "http://www.adobe.com/go/getflashplayer");
	object.appendChild(embed);

	//	object.applyElement(embed,"inside");

	parentElement.appendChild(object);

	//	document.documentElement.appendChild(embed);

};

/**
 * 初始化摄像头和Mic
 * @returns {Boolean}
 */
flexVTM.initDev = function() {
	try {
		//判断通用控件是否存在
		if (typeof commonTool == "undefined") {
			return false; //读取配置文件失败
		};
		var cameraId = 0;
		var bandWidth = 100;
		var quality = 80;
		var fps = 30;
		var useMic = 1;
		var locshow = 1;
		var pubType = 2;
		cameraId = WFOcxTools.readIni(this.PROFILE_PATH, "CONFIG", "cameraId", "2"); //摄像头编号，默认为2
		bandWidth = WFOcxTools.readIni(this.PROFILE_PATH, "CONFIG", "bandWidth", "100"); //分配带宽，默认为100
		quality = WFOcxTools.readIni(this.PROFILE_PATH, "CONFIG", "quality", "80"); //视频质量，默认为80
		fps = WFOcxTools.readIni(this.PROFILE_PATH, "CONFIG", "fps", "30"); //帧率，默认为30
		useMic = WFOcxTools.readIni(this.PROFILE_PATH, "CONFIG", "useMic", "1"); //使用语音，默认为1 不使用  （0 使用）
		locshow = WFOcxTools.readIni(this.PROFILE_PATH, "CONFIG", "locshow", "1"); //是否本地显示，默认为1 显示（0 不显示）
		pubType = WFOcxTools.readIni(this.PROFILE_PATH, "CONFIG", "pubType", "2"); //发布模式 整型，0 代表每次都重新录制 1 追加模式，支持断点续传 2 直播模式，不录制，默认为2

		thisMovie("FlexVTM").initCameraAndMic(cameraId, bandWidth, quality, fps, useMic,
			document.getElementById("FlexVTM").width,
			document.getElementById("FlexVTM").height, locshow, pubType);
		return true;
	} catch (e) {
		flexVTM._error("initDev失败[" + e.message + "]");
		return false;
	};
};

/**
 * 连接视频流服务
 * @param {Object} serverAdd 视频流服务器地址
 * @returns {Boolean}
 */
flexVTM.connectSer = function(serverAdd) {
	try {
		//var serverAdd = "rtmp://192.168.1.102/oflaDemo";
		thisMovie("FlexVTM").connectServer(serverAdd);
		return true;
	} catch (e) {
		flexVTM._error("connectSer失败[" + e.message + "]");
		return false;
	};
};

/**
 * 开始视频上传
 * @param {Object} localId 视频ID
 * @returns {Boolean}
 */
flexVTM.startRec = function(localId) {
	try {
		//var localId = document.getElementById("fileName").value;
		if (localId == "") {
			//alert("文件名不能为空!");
			return false;
		};
		thisMovie("FlexVTM").startRecVideo(localId);
		return true;
	} catch (e) {
		flexVTM._error("startRec失败[" + e.message + "]");
		return false;
	};
};

/**
 * 播放视频
 * @param {Object} localId 播放视频ID
 * @returns {Boolean}
 */
flexVTM.playFile = function(localId) {
	try {
		//var localId = document.getElementById("fileName").value;
		if (localId == "") {
			//alert("文件名不能为空!");
			return false;
		};
		thisMovie("FlexVTM").showRecConnectStream(localId);
		return true;
	} catch (e) {
		flexVTM._error("playFile失败[" + e.message + "]");
		return false;
	};
};

/**
 * 停止录制或停止播放
 * @returns {Boolean}
 */
flexVTM.stopRec = function() {
	try {
		thisMovie("FlexVTM").stopRecVideo();
		return true;
	} catch (e) {
		flexVTM._error("stopRec失败[" + e.message + "]");
		return false;
	};
};

function thisMovie(movieName) {
	if (navigator.appName.indexOf("Microsoft") != -1) {
		//return window[movieName];
		return document[movieName];
	} else {
		return document[movieName];
	};
};

/**
 * 开始视频录制（含设备初始化和连接视频流服务、开始视频上传等）
 * @param {Object} serverAdd 视频流服务地址
 * @param {Object} localId	上传视频ID
 * @param {Function} callBackSuccess 开始录制成功
 * @param {Function} callBackError 开始录制失败
 * @returns {Boolean}
 */
flexVTM.startRecord = function(serverAdd, localId, callBackSuccess, callBackError) {
	var delay = 3000;
	delay = WFOcxTools.readIni(this.PROFILE_PATH, "CONFIG", "delay", "3000");
	if (flexVTM.connectSer(serverAdd)) {
		if (flexVTM.initDev()) {
			this.start_timer = window.setTimeout(flexVTMRecord, delay); //延时录制
			return true;
		};
	};

	function flexVTMRecord() {
		if (flexVTM.startRec(localId)) {
			if(typeof(callBackSuccess) == "function"){
				callBackSuccess();
			}else{alert("参数callBackSuccess不是函数");}
		} else {
			if(typeof(callBackError) == "function"){
				callBackError();
			}else{alert("参数callBackError不是函数");}
		};
	};
	return false;
};

/**
 * 播放视频
 * @param {Object} serverAdd 服务地址
 * @param {Object} videoId	视频ID
 * @param {Function} callBackError 错误回调
 * @returns {Boolean}
 */
flexVTM.playVideo = function(serverAdd, videoId, callBackError) {
	var delay = 3000;
	delay = WFOcxTools.readIni(this.PROFILE_PATH, "CONFIG", "delay", "3000");

	function flexVTMPlay() {
		if (!flexVTM.playFile(videoId) && typeof(callBackError) == "function") {
			callBackError();
		};
	};
	if (flexVTM.connectSer(serverAdd)) {
		this.start_timer = window.setTimeout(flexVTMPlay, delay); //延时播放
		return true;
	};
	return false;
};

/**
 * 停止播放
 * @returns {Boolean}
 */
flexVTM.disConnect = function() {
	window.clearTimeout(this.start_timer);
	return flexVTM.stopRec();
};


flexVTM._debug = function(msg){
	if (OcxLogger && OcxLogger.debug) {
		OcxLogger.debug(LOGGER._ROOT,"{flexVTM._debug}"+msg);
	};
};

flexVTM._error = function(msg){
	if (OcxLogger && OcxLogger.error) {
		OcxLogger.error(LOGGER._ROOT,"{flexVTM._error}"+msg);
	};
};