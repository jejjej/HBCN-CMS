/**
 * 创建于:2015-10-28<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 视频检测控件封装 
 * @author 叶慧雄
 * @version 1.0
 */

//定义视频检测控件封装对象
var OCX_VideoPaperSafeDetect = new Object();

OCX_VideoPaperSafeDetect.iniPath = (top.yzjgssRootPath || "C:") + "/yzjgss/config/1x/1x.ini";

/**
 * 获取视频检测控件对象
 */
OCX_VideoPaperSafeDetect.getObj = function() {
	return OCXElement[ocxObject.OCX_VideoPaperSafeDetect["content"]["id"]];
};

OCX_VideoPaperSafeDetect.getAlias = function() {
	 return "VPSD";
};

/**
 * 设置设定ASF比特率，
 * @param lRate 默认值1000，范围185-50000，此值越大越清晰，但是生成的文件就会越大。
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.setAsfRate = function(lRate){
	try{
		//resulet 返回无意义
		var result = this.getObj().SetAsfRate(lRate);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 开始录制视频。
 * @param videoPath，视频文件存储路径,为空（""）时，不开始视频录制功能（降低占用系统资源）。
 * @param detectMethod视频检测模式：0为detect方法取mask;1为detect方法;2为watch方法,设置1和2可在视频处理过程中切换处理的方法，常用watch方法
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"1049",已经有录制过程;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:0，正常；2，已经有录制过程。其他失败;
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.startAsfRecord = function(videoPath, detectMethod, detectInitFailCallback, watchResultCallback) {
	try{
		detectInitFailCallback 	= detectInitFailCallback || function(){};
		watchResultCallback 	= watchResultCallback || function(){};
		
		function ocx_videopapersafedetect::DetectInitFail(lResult) {
			detectInitFailCallback(lResult);
		};

		function ocx_videopapersafedetect::WatchResult(lResult) {
			watchResultCallback(lResult);
		};
		var camIndex 	    = OCX_Tools.readIni(this.iniPath, "CONFIG", "CAM_INDEX_VIDEO", 1).data; //摄像头序号
		var resIndex 	    = OCX_Tools.readIni(this.iniPath, "CONFIG", "RES_INDEX_VIDEO", 6).data; //摄像头分辨率序号
		var rate 		    = OCX_Tools.readIni(this.iniPath, "VIDEODETECT", "RATE", 1000).data; //ASF比特率
		var camExposure     = OCX_Tools.readIni(this.iniPath, "VIDEODETECT", "VIDEO_CAMERA_EXPOSURE", -5).data; //摄像头曝光值
		var detectMode	    = OCX_Tools.readIni(this.iniPath, "VIDEODETECT", "DETECTMODE", 0).data; //检测模式
		var unnormalImage   = OCX_Tools.readIni(this.iniPath, "VIDEODETECT", "UNNORMAL_IMAGE", (top.yzjgssRootPath || "C:") + "//yzjgss/resources/temp").data; //保存用印图像的路径
		var unnormalImageMode	= OCX_Tools.readIni(this.iniPath, "VIDEODETECT", "UNNORMAL_IMAGE_MODE", 0).data; //保存用印图像的路径
		OCX_Logger.info("{OCX_VideoPaperSafeDetect.startAsfRecord}-- camIndex:(" + camIndex + "), resIndex:(" + resIndex + "), camExposure:(" + camExposure + "), rate:(" 
				+ rate + "), detectMode:(" + detectMode + ", unnormalImage:(" + unnormalImage + "), unnormalImageMode:(" + unnormalImageMode + ")");
		this.getObj().SetAsfRate(rate);				//设置比特率
		this.getObj().SetDetectMethod(detectMethod);//设置检测模式
		this.getObj().SetExposure(camExposure);		//设置摄像头曝光值
		this.getObj().SetImageInfo(unnormalImageMode, unnormalImage);//是否保存异常图像,调试使用 0:保留至处理完成;1:即时删除;2:异常时保留所有图片
		//resulet 0，正常；2，已经有录制过程。其他失败
		var result = this.getObj().StartAsfRecord(camIndex, resIndex, videoPath, detectMode);
		if(result == 0) {
			return OCXResult(this,"1001",result);
		}else if(result == 2) {
			return OCXResult(this,"1049",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		alert(e.message);
		return OCXExceptionResult(this, e);
	};
};

/**
 * 开始录制视频。(3x里机外用印的)
 * @param videoPath，视频文件存储路径,为空（""）时，不开始视频录制功能（降低占用系统资源）。
 * @param detectMethod视频检测模式：0为detect方法取mask;1为detect方法;2为watch方法,设置1和2可在视频处理过程中切换处理的方法，常用watch方法
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"1049",已经有录制过程;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:0，正常；2，已经有录制过程。其他失败;
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.startAsfRecord3X = function(videoPath,detectInitFailCallBack, detectStaticCallBack) {
	try{
		detectInitFailCallBack 	= detectInitFailCallBack || function(){};
		detectStaticCallBack 	= detectStaticCallBack || function(){};
		
		function ocx_videopapersafedetect::DetectInitFail(lResult){
			detectInitFailCallBack(lResult);
		}
		function ocx_videopapersafedetect::DetectStatic(lResult){
			detectStaticCallBack(lResult);
		}
		

		var camIndex 	    = OCX_Tools.readIni(this.iniPath, "CONFIG", "CAM_INDEX_VIDEO", 1).data; // 摄像头序号
		var resIndex 	    = OCX_Tools.readIni(this.iniPath, "CONFIG", "RES_INDEX_VIDEO", 6).data; // 摄像头分辨率序号
		var rate 		    = OCX_Tools.readIni(this.iniPath, "VIDEODETECT", "RATE", 1000).data; // ASF比特率
		var camExposure     = OCX_Tools.readIni(this.iniPath, "VIDEODETECT", "VIDEO_CAMERA_EXPOSURE",-3).data; // 摄像头曝光值
		var detectMode	    = OCX_Tools.readIni(this.iniPath, "VIDEODETECT", "DETECTMODE", 0).data; // 检测模式
		var staticDetectMode= OCX_Tools.readIni(this.iniPath, "VIDEODETECT", "STATICDETECTMODE", 1).data; // 设置是否使用静止检测功能，设置后视频检测失效。1有效
		var itFrames	    = OCX_Tools.readIni(this.iniPath, "VIDEODETECT", "ITFRAMES", 6).data; // 设置静止判断的帧数
		var iDiff	    	= OCX_Tools.readIni(this.iniPath, "VIDEODETECT", "IDIFF", 2).data; // 设置静止判断的差异值范围。
		this.getObj().SetAsfRate(rate);				// 设置比特率
		this.getObj().SetExposure(camExposure);		// 设置摄像头曝光值
		this.getObj().SetStaticDetectMode(staticDetectMode);// 设置是否使用静止检测功能，设置后视频检测失效。1有效
		this.getObj().SetStaticParam(itFrames,iDiff);// 设置静止判断的帧数和差异值范围。
		// resulet 0，正常；2，已经有录制过程。其他失败
		var result = this.getObj().StartAsfRecord(camIndex, resIndex, videoPath, detectMode);
		if(result == 0) {
			return OCXResult(this,"1001",result);
		}else if(result == 2) {
			return OCXResult(this,"1049",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		alert(e.message);
		return OCXExceptionResult(this, e);
	};
};
/**
 * 处理过程中的临时图像路径，
 * 此路径在程序开始和结束时均会被清空，如果设置，请使用独立的路径。
 * 默认为系统临时文件夹下新建目录yzjvd
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.setCapturePicPath = function(strDirPath){
	try{
		this.getObj().SetCapturePicPath(strDirPath);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 停止视频录制
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 * 此接口默认调用StopVideo(2);
 */
OCX_VideoPaperSafeDetect.endAsf = function(){
	try{
		//resulet 0，正常；
		var result = this.getObj().EndAsf();
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置检测mask值
 * @param strMask  mask值
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.setMask = function(strMask){
	try{
		this.getObj().SetMask(strMask);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取检测mask值。同时写入配置文件的节点 MASK 中
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.getMaskValue = function(){
	try{
		var result = this.getObj().GetMaskValue();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置检测过程中忽略的界限值（detect方法会使用到这个值）.
 * 大于此值才会在事件中回送结果。
 * 如果不设置此值，将返回全部的检测值。
 * 此值使用具体值需要多次测试后定义。
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.setRetDiffValue = function(lValue){
	try{
		this.getObj().SetRetDiffValue(lValue);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 忽略视频开始的几个帧，默认为2
 * @param lFrames 忽略视频开始的几个帧，默认为2
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.setIgnoreFrame = function(lFrames){
	try{
		this.getObj().SetIgnoreFrame(lFrames);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/***************************文件比对的调用不要在视频过程中使用。**************************************************************/

/**
 * 计算两图片之间忽略的区域。
 * （一张空白纸的图像，在此空白纸山改完章（两个位置的章）的图像，计算的结果是忽略盖章区域）。
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9506",检测库加载异常;"9507",检测文件打开失败;"9508",检测库初始化失败;"9300",调用控件方法异常;
 * 			obj.data:0正常；-1，检测库加载异常；-2，检测文件打开失败。-3，检测库初始化失败;
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.calFileCompareMask = function(strImagePath1, strImagePath2){
	try{
		//resulet 0正常；-1，检测库加载异常；-2，检测文件打开失败。-3，检测库初始化失败
		var result = this.getObj().CalFileCompareMask(strImagePath1, strImagePath2);
		if(result == 0){
			return OCXResult(this,"1001",result);
		}else if(result == -1){
			return OCXResult(this,"9506",result);
		}else if(result == -2){
			return OCXResult(this,"9507",result);
		}else{
			return OCXResult(this,"9508",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取CalFileCompareMask(strImagePath1, strImagePath2)中计算的值，同时写入配置文件的节点 FILEMASK 中
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.getFileMaskValue = function(){
	try{
		var result = this.getObj().GetFileMaskValue();
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 比较两张图片的差异值
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9506",检测库加载异常;"9507",检测文件打开失败;"9508",检测库初始化失败;"9300",调用控件方法异常;
 * 			obj.data:>=0正常。-1，检测库加载异常；-2，检测文件打开失败。-3，检测库初始化失败;
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.compareFile = function(strImagePath1, strImagePath2){
	try{
		//resulet >=0正常。-1，检测库加载异常；-2，检测文件打开失败。-3，检测库初始化失败
		var result = this.getObj().CompareFile(strImagePath1, strImagePath2);
		if(result >= 0){
			return OCXResult(this,"1001",result);
		}else if(result == -1){
			return OCXResult(this,"9506",result);
		}else if(result == -2){
			return OCXResult(this,"9507",result);
		}else{
			return OCXResult(this,"9508",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置文件比较的mask值
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.setFileCompareMask = function(strMask){
	try{
		this.getObj().SetFileCompareMask(strMask);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置文件比较方法，
 * @param iType 1，mask检测（detect）方法；2，监视（watch）方法
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.setFileCompareMethod = function(iType){
	try{
		this.getObj().SetFileCompareMethod(iType);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置检测方法：
 * @param iMethod 0为detect方法取mask，1为detect方法，2为watch方法。
 * 设置1和2可在视频处理过程中切换处理的方法
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.setDetectMethod = function(iMethod){
	try{
		this.getObj().SetDetectMethod(iMethod);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置处理过程中的图像保留方式。
 * @param iDeleteIfError1，即时删除，0，保留至处理完成,2,异常时保留所有图片（只针对watch方法有效）
 * @param strSaveDir，iDeleteIfError1=2时异常时存储的图片源目录。
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.setImageInfo = function(iDeleteIfError, strSaveDir){
	try{
		this.getObj().SetImageInfo(iDeleteIfError, strSaveDir);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 程序是否接收图像进行处理：
 * @param lPro 1接收；0，不接收，
 * 此接口主要用法：
 * 在视频过程中调用其他摄像头拍照时，先设置不接收再拍照，
 * 完成后设置接收或根据需要做其他处理。开启视频后默认接收
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.setImageProStatus = function(lPro){
	try{
		this.getObj().SetImageProStatus(lPro);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * @param lMethod 为1时图片处理过程中允许跳帧，0时不跳帧，默认0。
 * 如果选择跳帧处理，可以加快处理速度，但会降低发现抽换的可能性。
 * 不跳帧可能会有很大的处理延时。根据需要使用。（detect方式的处理速度比watch方式的处理速度快很多）
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.setImageProMethod = function(lMethod){
	try{
		this.getObj().SetImageProMethod(lMethod);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 停止视频功能
 * @param lType istatus =0 时将即时结束；其他，是处理全部图片结束
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.endVideo = function(lType){
	try{
		var result = this.getObj().EndVideo(lType);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置识别出来的印章大小限制（图像尺寸），lWidth和lHeight都<=0 时会清除已有的设置。默认无限制
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.addSealSize = function(lWidth, lHeight){
	try{
		this.getObj().AddSealSize(lWidth, lHeight);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 获取图片指定区域上识别出来的印章数量。负数异常
 * @param strImage，图像全路径。
 * @param linfo,识别参数（>0）,有些图片在参数不同时识别的印章数量不一致，如果发现前后图像的结果不符合要求时，可换参数尝试（实际使用时可先用4，如果不符合再用1或其他）。
 * @param lLeft,lTop,lRight,lBottom  图像识别区域
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9400",异常;"9300",调用控件方法异常;
 * 			obj.data:图片指定区域上识别出来的印章数量。负数异常;
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.getSealNum = function(strImage, linfo, lLeft, lTop, lRight, lBottom){
	try{
		var result = this.getObj().GetSealNum(strImage, linfo, lLeft, lTop, lRight, lBottom);
		if(result>=0){
			return OCXResult(this,"1001",result);
		}else{
			return OCXResult(this,"9400",result);
		}
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置视频检测时忽略的上部分区域（像素），主要是解决白色机器如果摄像头拍照位置偏向印油位置时会盖原点引起的抽换误报
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:控件原始返回值;
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.setTopClip = function(iTop){
	try{
		var result = this.getObj().SetTopClip(iTop);
		return OCXResult(this,"1001",result);
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 设置打开视频时使用的曝光值，在StartAsfRecord 调用前使用
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.setExposure = function(exposure){
	try{
		this.getObj().SetExposure(exposure);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};

/**
 * 视频帧率
 * 两种检测方式简要说明：
 * detect方式为全图根据mask值比对，不允许纸张移动，速度较快，灵敏度高，但不适合在盖章过程中使用。
 * watch方式在检测过程中会允许纸张小范围的变动（为排除机器盖章动作的影响），处理速度稍慢，灵敏度没有detect方式高
 * @returns obj(code,data,msg)
 * 			obj.code:"1001",成功;"9300",调用控件方法异常;
 * 			obj.data:"";
 *			obj.msg:提示信息;
 */
OCX_VideoPaperSafeDetect.setFps = function(iFps){
	try{
		this.getObj().SetFps(iFps);
		return OCXResult(this,"1001","");
	}catch(e){
		return OCXExceptionResult(this, e);
	};
};