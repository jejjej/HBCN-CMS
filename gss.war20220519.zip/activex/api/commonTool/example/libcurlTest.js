/**
 * 创建于:2015-01-13<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 文件上传控件测试脚本
 *
 * @author 刘鋆
 * @version 1.0
 */


var _fso = new ActiveXObject("Scripting.FileSystemObject");

/**
 * 遍历目录下的文件
 * 
 * @param folderPath
 *            目录的路径
 * @return 文件路径数组
 * 
 */
listFolder = function(folderPath) {
	var folder = _fso.GetFolder(folderPath);
	var fileArray = new Array();
	var subFiles = new Enumerator(folder.Files);// 目录下的子文件
	for (; !subFiles.atEnd(); subFiles.moveNext()) {
		var file = subFiles.item();
		fileArray.push(file);
	}
	var subFolders = new Enumerator(folder.SubFolders); // 目录下的子目录
	for (; !subFolders.atEnd(); subFolders.moveNext()) {
		var subFolder = subFolders.item();
		var array = listFolder(subFolder);
		for ( var int = 0; int < array.length; int++) {
			fileArray.push(array[int]);
		}
	}
	return fileArray;
}

function upload() {
	//var url = "http://192.168.3.3:8080/SMSStandard/uploadFile!uploadFile.action";
	var async = window.document.getElementById("async").checked;
	var url = window.document.getElementById("urlPath").value;
	var files = window.document.getElementsByName("files");
	for ( var i = 0; i < files.length; i++) {
		var filepath = files[i].value;
		if (typeof(filepath) == "undefined" || filepath == "") {
			showResult("未选择上传文件");
			continue;
		}
		if (async) {
			var result = OCX_Libcurl.HttpUpload(url, filepath, {"storeId":"", "async" : async}, function (data, seq, url, file, param) {
				if (data.responseMessage.success) { //成功
					showResult("文件上传成功: " + filepath);
				} else {
					showResult("文件上传失败: " + filepath);
				}
			});
			if(result.code != "1001"){
				showResult("执行上传失败");
			}
		} else {
			var result = OCX_Libcurl.HttpUpload(url, filepath, {"storeId":"", "async" : async}, function () {});
			if (result.responseMessage.success) { //成功
				showResult("文件上传成功: " + filepath);
			} else {
				showResult("文件上传失败: " + filepath);
			}
		}
	}
}

function deepCopy(source) { 
	var result={};
	for (var key in source) {
	      result[key] = typeof source[key]==='object'? deepCopy(source[key]): source[key];
	   } 
	   return result; 
	}

function uploadFromDir() {
	var async = window.document.getElementById("async").checked;
	var url = window.document.getElementById("urlPath").value;
	var dirPath = window.document.getElementById("dirPath").value;
	if ( _fso.FolderExists(dirPath)) {
		var filePaths = listFolder(dirPath);
		for ( var i = 0; i < filePaths.length; i++) {
			// 参数说明：url-服务器地址，filepath-本地文件全路径，filename-保存到服务器上的新文件名，回调函数
			if (async) {
				var result = OCX_Libcurl.HttpUpload(url, filePaths[i], {"storeId":"", "async" : async}, function (data, seq, url, file, param) {
					if (data.responseMessage.success) { //成功
						showResult("文件上传成功: " + filePaths[i]);
					} else {
						showResult("文件上传失败: " + filePaths[i]);
					}
				});
				if(result.code != "1001"){
					showResult("执行上传失败");
				}
			} else {
				var result = OCX_Libcurl.HttpUpload(url, filePaths[i], {"storeId":"", "async" : async}, function () {});
				if (result.responseMessage.success) { //成功
					showResult("文件上传成功: " + filePaths[i]);
				} else {
					showResult("文件上传失败: " + filePaths[i]);
				}
			}
		}
	} else {
		showResult(dirPath + "文件夹不存在");
	}
}

function afterUpload(data, seq, url, file, param) {
	if (data.responseMessage.success) { //成功
		showResult("服务器返回成功 ");
	} else {
		showResult("服务器返回失败：" + data.responseMessage.message);
	}
}

function newFileUpload() {
	var fileUploadTD = document.getElementById("fileUploadTD");
	var newDiv = document.createElement("<div></div>");
	var newInput = document.createElement('<input id="filePath" type="file" name="files" style="width:450px" value="" />');
	newDiv.appendChild(newInput);
	fileUploadTD.appendChild(newDiv);
}

function IsURL(str_url) {
	var strRegex = '^((https|http|ftp|rtsp|mms)?://)?' + '(([0-9a-z_!~*\'()\.&=+$%-]+: )?[0-9a-z_!~*\'()\.&=+$%-]+@)?' //ftp的user@
		+ '(([0-9]{1,3}\.){3}[0-9]{1,3}' // IP形式的URL- 199.194.52.184
		+ '|' // 允许IP和DOMAIN（域名）
		+ '([0-9a-z_!~*\'()-]+\.)*' // 域名- www.
		+ '([0-9a-z][0-9a-z-]{0,61})?[0-9a-z]\.' // 二级域名
		+ '[a-z]{2,6})' // first level domain- .com or .museum
		+ '(:[0-9]{1,4})?' // 端口- :80
		+ '((/?)|' // a slash isn't required if there is no file name
		+ '(/[0-9a-z_!~*\'()\.;?:@&=+$,%#-]+)+/?)$';
	var re = new RegExp(strRegex);
	if (re.test(str_url)) {
		return (true);
	} else {
		return (false);
	}
}


function zipFile() {
	var filePath = window.document.getElementById("filePath").value;
	var destPath = window.document.getElementById("destPath").value;
	if (filePath) {
		var fileName = filePath.substring(filePath.lastIndexOf("\\") + 1, filePath.lastIndexOf("."));
		if (!destPath) {
			destPath = "C:/temp";
		}
		destPath = destPath + "/" + fileName+".zip";
		var result = OCX_Libcurl.zipPackFile(filePath, destPath);
		if (result.code==="1001") { //成功
			showResult("文件压缩成功: " + filePath +", " + destPath);
		} else {
			showResult("文件压缩失败: " + filePath +", " + destPath);
		}
	} else {
		showResult("请选择要压缩的文件.");
	}
}

function zipFold() {
	var dirPath = window.document.getElementById("dirPath").value;
	var destPath = window.document.getElementById("destPath").value;
	if (filePath) {
		var fileName = dirPath.substring(dirPath.lastIndexOf("\\") + 1);
		if (!destPath) {
			destPath = "C:/temp";
		}
		destPath = destPath + "/" + fileName+".zip";
		var result = OCX_Libcurl.zipPackFold(dirPath, destPath);
		if (result.code==="1001") { //成功
			showResult("文件夹压缩成功: " + dirPath +", " + destPath);
		} else {
			showResult("文件夹压缩失败: " + dirPath +", " + destPath);
		}
	} else {
		showResult("请选择要压缩的文件夹.");
	}
}

function zipUnPackFiles() {
	var zipPath = window.document.getElementById("zipPath").value;
	var destPath = window.document.getElementById("destPath").value;
	if (zipPath) {
		var foldName = zipPath.substring(zipPath.lastIndexOf("\\") + 1, zipPath.lastIndexOf("."));
		if (!destPath) {
			destPath = "C:/temp";
		}
		destPath = destPath + "/" + foldName;
		var result = OCX_Libcurl.zipUnPackFiles(zipPath, destPath);
		if (result.code==="1001") { //成功
			showResult("文件夹压缩成功: " + zipPath +", " + destPath);
		} else {
			showResult("文件夹压缩失败: " + zipPath +", " + destPath);
		}
	} else {
		showResult("请选择要压缩的文件夹.");
	}
}

/**
 * 清除日志记录方法
 */
function clearLog() {
	window.document.getElementById("result").value = "";
}

/**
 * 显示操作结果
 *
 * @param messgage
 *            操作结果
 */
function showResult(message) {
	var content = (new Date())
		.Format("hh:mm:ss") + "  " + message + "\r\n" + window.document.getElementById("result").value;
	if (content.length > 10000)
		content = content.substring(0, 10000);
	window.document.getElementById("result").value = content;
}