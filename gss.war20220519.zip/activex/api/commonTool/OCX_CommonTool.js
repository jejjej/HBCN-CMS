/**
 * 创建于:2015-10-28<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 常用控件工具集，对应控件logactivex.ocx
 * 
 * @author 叶慧雄
 * @version 1.0
 */

// 定义日志控件(包括通用函数)对象
var OCX_CommonTool = new Object();

/**
 * 获取日志控件(包括通用函数)对象
 */
OCX_CommonTool.getObj = function(){
	return OCXElement[ocxObject.OCX_CommonTool["content"]["id"]];
};

OCX_CommonTool.getAlias = function() {
	 return "CT";
};

/**
 * 判断是否为空字符串
 * 
 * @param {String}
 *            str
 * @returns {Boolean}
 */
function __IsEmptyStr(str) {
	return /^\s*$/g.test(str);
};
// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 日志打印控件调用对象
// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// 定义日志记录控件调用对象
var OCX_Logger = new Object();

/**
 * 默认的logger名称
 */
OCX_Logger.DEFAULT_LOGGER = "root";

/**
 * 记录Debug日志
 * 
 * @param logger
 *            logger名称
 * @param msg
 *            必填，日志内容
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_Logger.debug = function(/* logger, msg */) {
	var msg = Array.prototype.pop.apply(arguments);
	var logger = Array.prototype.shift.apply(arguments) || this.DEFAULT_LOGGER;
	try{
		if (logger != this.DEFAULT_LOGGER) {
			OCX_CommonTool.getObj().LogDebug(this.DEFAULT_LOGGER, msg);
		}
		OCX_CommonTool.getObj().LogDebug(logger, msg);
		return OCXResult(OCX_CommonTool,"1001","");
	}catch(e){
		return OCXExceptionResult(OCX_CommonTool, e);
	};
};


/**
 * 记录Error日志
 * 
 * @param logger
 *            logger名称
 * @param msg
 *            必填，日志内容
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_Logger.error = function(/* logger, msg */) {
	var msg = Array.prototype.pop.apply(arguments);
	var logger = Array.prototype.shift.apply(arguments) || this.DEFAULT_LOGGER;
	try{
		if (logger != this.DEFAULT_LOGGER) {
			OCX_CommonTool.getObj().LogError(this.DEFAULT_LOGGER, msg);
		}
		OCX_CommonTool.getObj().LogError(logger, msg);
		return OCXResult(OCX_CommonTool,"1001","");
	}catch(e){
		return OCXExceptionResult(OCX_CommonTool, e);
	};
};

/**
 * 记录Info日志
 * 
 * @param logger
 *            logger名称
 * @param msg
 *            必填，日志内容
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_Logger.info = function(/* logger, msg */) {
	var msg = Array.prototype.pop.apply(arguments);
	var logger = Array.prototype.shift.apply(arguments) || this.DEFAULT_LOGGER;
	try{
		if (logger != this.DEFAULT_LOGGER) {
			OCX_CommonTool.getObj().LogInfo(this.DEFAULT_LOGGER, msg);
		}
		OCX_CommonTool.getObj().LogInfo(logger, msg);
		return OCXResult(OCX_CommonTool,"1001","");
	}catch(e){
		return OCXExceptionResult(OCX_CommonTool, e);
	};
};

/**
 * 记录Trace日志
 * 
 * @param logger
 *            logger名称
 * @param msg
 *            必填，日志内容
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_Logger.trace = function(/* logger, msg */) {
	var msg = Array.prototype.pop.apply(arguments);
	var logger = Array.prototype.shift.apply(arguments) || this.DEFAULT_LOGGER;
	try{
		if (logger != this.DEFAULT_LOGGER) {
			OCX_CommonTool.getObj().LogTrace(this.DEFAULT_LOGGER, msg);
		}
		OCX_CommonTool.getObj().LogTrace(logger, msg);
		return OCXResult(OCX_CommonTool,"1001","");
	}catch(e){
		return OCXExceptionResult(OCX_CommonTool, e);
	};
};

/**
 * 记录Warn日志
 * 
 * @param logger
 *            logger名称
 * @param msg
 *            必填，日志内容
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_Logger.warn = function(/* logger, msg */) {
	var msg = Array.prototype.pop.apply(arguments);
	var logger = Array.prototype.shift.apply(arguments) || this.DEFAULT_LOGGER;
	try{
		if (logger != this.DEFAULT_LOGGER) {
			OCX_CommonTool.getObj().LogWarn(this.DEFAULT_LOGGER, msg);
		}
		OCX_CommonTool.getObj().LogWarn(logger, msg);
		return OCXResult(OCX_CommonTool,"1001","");
	}catch(e){
		return OCXExceptionResult(OCX_CommonTool, e);
	};
};

/**
 * 记录Fatal日志
 * 
 * @param logger
 *            logger名称
 * @param msg
 *            必填，日志内容
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_Logger.fatal = function(/* logger, msg */) {
	var msg = Array.prototype.pop.apply(arguments);
	var logger = Array.prototype.shift.apply(arguments) || this.DEFAULT_LOGGER;
	try{
		if (logger != this.DEFAULT_LOGGER) {
			OCX_CommonTool.getObj().LogFatal(this.DEFAULT_LOGGER, msg);
		}
		OCX_CommonTool.getObj().LogFatal(logger, msg);
		return OCXResult(OCX_CommonTool,"1001","");
	}catch(e){
		return OCXExceptionResult(OCX_CommonTool, e);
	};
};


// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 通用函数封装（日志控件集成）
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// 定义通用函数对象
var OCX_Tools = new Object();

/**
 * 写INI文件
 * 
 * @param iniPath
 *            ini文件的相对路径，相对于日志控件的位置
 * @param section
 *            ini文件中的段名称
 * @param key
 *            ini中的key名
 * @param value
 *            ini中key对应的value
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_Tools.writeIni = function(iniPath, section, key, value) {
	try{
		// resulet 0：成功； 其他：失败
		var result = OCX_CommonTool.getObj().WriteIniFile(iniPath,
				section, key, value);
		if(result == 0){
			return OCXResult(OCX_CommonTool,"1001",result);
		}else{
			return OCXResult(OCX_CommonTool,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(OCX_CommonTool, e);
	};
	
};

/**
 * 读INI文件
 * 
 * @param iniPath
 *            ini文件的相对路径，相对于日志控件的位置
 * @param section
 *            ini文件中的段名称
 * @param key
 *            ini中的key名
 * @param defaultValue
 *            ini中无值的时候赋予的默认值
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_Tools.readIni = function(iniPath, section, key, defaultValue) {
	try{
		// result 0：成功； 其他：失败
		var result = OCX_CommonTool.getObj().ReadIniFile(iniPath,
				section, key, defaultValue);
		if(result == 0){
			return OCXResult(OCX_CommonTool,"1001",result);
		}else{
			return OCXResult(OCX_CommonTool,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(OCX_CommonTool, e);
	};
};

/**
 * 写XML，将传入的内容写到D:\printxml.xml内
 * 
 * @param xmlContent
 *            XML内容
 * @param type
 *            写XML文件的路径配置。
 *            具体的路径对应C:\Windows\System32\DevicePort.ini文件中Receipt节点中相应的type的值
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_Tools.writeXML = function(xmlContent, type) {
	try{
		// result 0：成功； 其他：失败
		var result = OCX_CommonTool.getObj().WriteXML(xmlContent,
				type);
		if(result == 0){
			return OCXResult(OCX_CommonTool,"1001",result);
		}else{
			return OCXResult(OCX_CommonTool,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(OCX_CommonTool, e);
	};
};

/**
 * 设置本地时间（仅XP有效）
 * 
 * @param currentTime
 *            要设置的时间，格式"YYYY-MM-DD HH:MI:SS"
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_Tools.setClientTime = function(currentTime) {
	try{
		// result 0:成功；其他：失败
		var result = OCX_CommonTool.getObj().SetClientTime(
				currentTime);
		if(result == 0){
			return OCXResult(OCX_CommonTool,"1001",result);
		}else{
			return OCXResult(OCX_CommonTool,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(OCX_CommonTool, e);
	};
};

/**
 * 设置屏幕分辨率
 * 
 * @param px
 *            横分辨率
 * @param py
 *            纵分辨率
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_Tools.setScreenSize = function(px, py) {
	try{
		// result 0：成功； 其他：失败
		var result = OCX_CommonTool.getObj().SetScreenSize(px, py);
		if(result == 0){
			return OCXResult(OCX_CommonTool,"1001",result);
		}else{
			return OCXResult(OCX_CommonTool,"9200",result);
		}
	}catch(e){
		return OCXExceptionResult(OCX_CommonTool, e);
	};
};

/**
 * 取MAC地址和IP
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:"[mac1],[IP1]|[mac2],[IP2]|...|[macn],[IPn]" 或 "";
 *          obj.msg:提示信息;
 */
OCX_Tools.getIPAndMac = function() {
	try{
		// result {String} "[mac1],[IP1]|[mac2],[IP2]|...|[macn],[IPn]" 或 ""
		var result = OCX_CommonTool.getObj().GetIPAndMac();
		return OCXResult(OCX_CommonTool,"1001",result);
	}catch(e){
		return OCXExceptionResult(OCX_CommonTool, e);
	};
};

/**
 * 取默认打印机名称
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:打印机名称，无打印机的时候返回空字符串; obj.msg:提示信息;
 */
OCX_Tools.getDefaultPrinter = function(){
	try{
		// result 打印机名称，无打印机的时候返回空字符串
		var result = OCX_CommonTool.getObj().GetDefaultPrinter();
		return OCXResult(OCX_CommonTool,"1001",result);
	}catch(e){
		return OCXExceptionResult(OCX_CommonTool, e);
	};
};

/**
 * 取所有打印机名称
 * 
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9300",调用控件方法异常;
 *          obj.data:"打印机1,打印机2,打印机3,...,打印机n" 或者 ""; obj.msg:提示信息;
 */
OCX_Tools.getAllPrinter = function(){
	try{
		// result "打印机1,打印机2,打印机3,...,打印机n" 或者 ""
		var result = OCX_CommonTool.getObj().GetAllPrinter();
		return OCXResult(OCX_CommonTool,"1001",result);
	}catch(e){
		return OCXExceptionResult(OCX_CommonTool, e);
	};
};

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 通用函数封装（文件上传控件集成）
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


/**
 * 文件上传控件对象
 */
var OCX_Libcurl = new Object();

/**
 * 定义别名
 */
OCX_Libcurl.getAlias = function() {
	 return "OL";
};

/**
 * 文件上传回调方法数组
 */
OCX_Libcurl._callbacks = {};

/**
 * 文件上传
 * 
 * @param {String}
 *            url 服务器地址
 * @param {String}
 *            file 本地文件路径
 * @param {String}
 *            param 传到服务器上时保存的文件名
 * @param {Function}
 *            callback 回调函数
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9504",上传发生异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_Libcurl.HttpUpload = function(url, file, param, callback) {
	if (top.sessionId) {
		url = url + ";jsessionid=" + top.sessionId;
	} else {
		url = url + ";jsessionid=" + top.getSessionId();
	};
	
	// 上传文件
	var urlParam = "";
	if(param instanceof String) {
		urlParam = param;
	} else {
		for ( var key in param) {
			urlParam += (key + "=" + param[key] + "&");
		}
	};
	if(param["async"] === false) {
		// 同步
		var response = "";
		try {
			response = OCX_CommonTool.getObj().HttpUpload(url, file, urlParam);
			var data = eval("(" + response + ")");
			return data;
		} catch(e) {
			return {responseMessage: {success: false, message: e.message}};
		}
	} else {
		// 异步
		try {
			var seq = OCX_CommonTool.getObj().HttpUpload(encodeURI(url), file, urlParam);
			OCX_Libcurl._callbacks[seq] = callback;
			return OCXResult(OCX_Libcurl,"1001",seq);
		} catch(e) {
			OCX_Libcurl._error("{OCX_Libcurl.HttpUpload} 上传发生异常！ Exception:("+e.message+")");
			return OCXResult(OCX_Libcurl,"9504","");
		}
	};
};

/**
 * 
 * @param seq
 * @param url
 * @param file
 * @param param
 * @param response
 * @returns
 */
function libCurlCallback(seq, url, file, param, response){
	if (OCX_Libcurl._callbacks[seq] && typeof(OCX_Libcurl._callbacks[seq]) == "function") {
		try {
			response = decodeURI(response);
			var data = eval("(" + response + ")");
			OCX_Libcurl._callbacks[seq](data, seq, decodeURI(url), decodeURI(file), param);
		} catch (e) {
			OCX_Libcurl._callbacks[seq]({
				responseMessage: {
					success: false,
					message: response
				}
			}, seq, decodeURI(url), decodeURI(file), param);
		};
		delete OCX_Libcurl._callbacks[seq];
	};
}

/**
 * 文件追加上传
 * 
 * @param {String}
 *            url 服务器地址
 * @param {String}
 *            file 本地文件路径
 * @param {String}
 *            param 传到服务器上时保存的文件名
 * @param {Function}
 *            callback 回调函数
 * @returns obj(code,data,msg) obj.code:"1001",成功;"9504",上传发生异常;
 *          obj.data:控件原始返回值; obj.msg:提示信息;
 */
OCX_Libcurl.appendHttpUpload = function(url, file, param, objectId, callback) {
	if(param instanceof String) {
		param += "&storeId=" + objectId;
	} else {
		param["storeId"] = objectId;
	}
	return OCX_Libcurl.HttpUpload(url, file, param, callback);
	
};

OCX_Libcurl.getYzjgssRootPath = function(){
	var result = OCX_CommonTool.getObj().GetModulePath();
	var yzjgssRootPath = result.substr(0, 2);
	if(/^\s*$/g.test(result)){
		return OCXResult(this, "9200", "");
	}else{
		return OCXResult(this, "1001", yzjgssRootPath);
	}
};

OCX_Libcurl._error = function(msg){
	if (OCX_Logger && OCX_Logger.error) {
		OCX_Logger.error(LOGGER._ROOT, "{OCX_Libcurl._error}--"+msg);
	};
};

/**
 * 指定文件夹打zip压缩文件
 * 
 * @param foldPath
 *            待压缩的文件夹
 * @param zipPath
 *            压缩后的zip文件
 */
OCX_Libcurl.zipPackFold = function(foldPath, zipPath){
	var result = OCX_CommonTool.getObj().ZipPackFold(foldPath, zipPath);
	if(result){
		return OCXResult(this, "1001", "");
	}else{
		return OCXResult(this, "9200", "");
	}
};

/**
 * 指定文件打zip压缩文件
 * 
 * @param filePath
 *            待压缩的文件
 * @param zipPath
 *            压缩后的zip文件
 */
OCX_Libcurl.zipPackFile = function(filePath, zipPath){
	var result = OCX_CommonTool.getObj().ZipPackFile(filePath, zipPath);
	if(result){
		return OCXResult(this, "1001", "");
	}else{
		return OCXResult(this, "9200", "");
	}
};

/**
 * 指定zip文件进行解压缩
 * 
 * @param zipPath
 *            待解压缩zip文件
 * @param unPackPath
 *            解压缩的文件
 */
OCX_Libcurl.zipUnPackFiles = function(zipPath, unPackPath){
	var result = OCX_CommonTool.getObj().ZipUnPackFiles(zipPath, unPackPath);
	if(result){
		return OCXResult(this, "1001", "");
	}else{
		return OCXResult(this, "9200", "");
	}
};

/**
 * 图像尺寸转换
 * 
 * @param sourcePath
 *            源图像地址
 * @param destPath
 *            目标图像地址
 * @param width
 *            转换的图像宽
 * @param height
 *            转换的图像高
 * @returns 0 正常；1源文件不存在；2目标目录不存在创建失败；3格式不支持，支持.bmp和.jpg后缀文件
 */
OCX_Libcurl.transImg = function(sourcePath,destPath,width,height){
	var result  = OCX_CommonTool.getObj().TransPicDimension(sourcePath,destPath,width,height);
	if(result ===0 ){
		return OCXResult(this, "1001", result);
	}else if(result ===1 ){
		return OCXResult(this, "9512", result);
	}else if(result ===2 ){
		return OCXResult(this, "9513", result);
	}else if(result ===3 ){
		return OCXResult(this, "9514", result);
	}else{
		return OCXResult(this, "9200", result);
	}
}
