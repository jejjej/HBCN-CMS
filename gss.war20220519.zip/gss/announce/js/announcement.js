
//公告状态0,表示正常，2表示删除
var ANNOUNCEMENT_STATUS_NORMAL = 0;
var ANNOUNCEMENT_STATUS_DELETE = 2;
//公告栏管理机构
var ANNOUNCEMENT_OPERATE_ORGTYPE = 4;

var announceDeletePower = false;
var announceMangerPower = false;

var allChildOrgSids = [];

Array.prototype.S=String.fromCharCode(2);
Array.prototype.in_array=function(e){
    var r=new RegExp(this.S+e+this.S);
    return (r.test(this.S+this.join(this.S)+this.S));
};

/**
 * 公告栏页面初始化
 * @author HuangKunping
 */
function announcementInit(){
	
	$.ajax({
		type : "POST",
		url : ctx + "/uss/power/ussPowerAction!checkAddAnnouncementPower.action",
		dataType : "json",
		data:{peopleSid :top.loginPeopleInfo.peopleSid},
		async : false,
		success : function(data) {
			if (data.responseMessage&&data.responseMessage.success) {
				announceDeletePower = true;
			}
		}
	});
	
	$.ajax({
		type : "POST",
		url : ctx + "/uss/power/ussPowerAction!checkQueryAnnocucementPower.action",
		dataType : "json",
		data:{peopleSid :top.loginPeopleInfo.peopleSid},
		async : false,
		success : function(data) {
			if (data.responseMessage&&data.responseMessage.success) {
				announceMangerPower = true;
			}
		}
	});
	if (announceMangerPower) {
		$.ajax({
			type : "POST",
			url : ctx + "/uss/announce/announcementAction!findAllChildAndSelfOrgSids.action",
			dataType : "json",
			data:{},
			async : false,
			success : function(data) {
				if (data.responseMessage&&data.responseMessage.success) {
					var orgSids = data.allChildAndSelfOrgSids;
					if (orgSids.length > 0) {
						allChildOrgSids = orgSids;
					}
				}
			}
		});
	}
	
	$("#announcementDLG").dialog({
		autoOpen: false,
		caption:"公告详情", 
		resizable: false,
		height: 450,
		width:600,
		modal: true,
		buttons: {
			"关闭": function() { 
				$("#announcementDLG").dialog("close"); 
			}
		},
		close: function() { 
				$("#announcement_item")[0].reset();
		}, 
		open : function() {
			$(".ui-widget-overlay").height($(".ui-widget-overlay").height() - 9);
		}
	});
	
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight
			+ 6 - 50 * 2 + 20;
	
	//公告列表
	$("#announcementList").jqGrid({
		width : pageContentWidth,
		height : tableHeight,
		url: ctx+"/uss/announce/announcementAction!announcementList.action",
		multiselect: false,
		rowNum: 20, 
		rowList: [20,50,100], 
		colNames:["公告标题","发布机构","发布生效时间","失效时间","发布人",/*"状态",*/"详情"],
		colModel:[
	   		{name:"title",index:"title", align:"center",sortable:false},
	   		{name:"orgName",index:"orgName", align:"center",sortable:false},
	   		{name:"repleaseTime",index:"repleaseTime",align:"center",sortable:false,formatter:formatterDatetime},
	   		{name:"invalidTime",index:"invalidTime",  align:"center",sortable:false,formatter:formatterDatetime},
	   		{name:"peopleName",index:"peopleName",  align:"center",sortable:false},
	   		/*{name:"state",index:"state",  align:"center",sortable:false,formatter:function(value,options,rData){
	   			var html = "";
	   			if(ANNOUNCEMENT_STATUS_NORMAL == rData.state){
	   				html += "正常";
	   			}else if(ANNOUNCEMENT_STATUS_DELETE == rData.state) {
	   				html += "已删除";
	   			}
	   			return html;
	   		}},*/
	   		{name:"autoId",index:"autoId", align:"center",width:"50px",sortable:false,formatter:function(value,options,rData){
	   			var html = "<div><div class='icon_search' onclick='announcementContent(\"" + value + "\")' title='查看内容' style='float:left'></div>";
//	   			if (announceDeletePower && ANNOUNCEMENT_STATUS_DELETE != rData.state && LoginPeople.getOrgSid() == rData.orgSid) {
//	   				html += "<div class='icon_delete' onclick='deleteAnnouncement(\"" + value + "\")' title='删除' style='float:left'></div></div>";
//	   			}else{
//	   				html += "</div>";
//				}
	   			
	   			
	   			if (announceMangerPower && ANNOUNCEMENT_STATUS_DELETE != rData.state && allChildOrgSids.in_array(rData.orgSid)) {
	   				html += "<div class='icon_delete' onclick='deleteAnnouncement(\"" + value + "\")' title='删除' style='float:left'></div></div>";
	   			}else{
	   				html += "</div>";
				}
	   			
//	   			if(LoginPeople.getOrgType() == ANNOUNCEMENT_OPERATE_ORGTYPE && ANNOUNCEMENT_STATUS_DELETE != rData.state){
//	   				html += "<div class='icon_delete' onclick='deleteAnnouncement(\"" + value + "\")' title='删除' style='float:left'></div></div>";
//	   			}else{
//	   				html += "</div>";
//	   			}
	   			return html;
	   		}}
	   	],
	   	pager: "#announcementListPager",
	   	onSelectRow:function(id){
	   		
	   	}
	});
}

function queryAnnouncementForTerm(){
	$("#announcementList").jqGrid("search", "#announcementList_Item");
}

function clearAnnouncementForTerm(){
	$("#announcementList_Item")[0].reset();
}

/**
 * 格式化时间日期，去除秒后面的.毫秒，如：2015-08-28 14:12:22.0 → 2015-08-28 14:12:22
 * @param value
 * @returns
 */
function formatterDatetime(value) {
	if (value != null && value != "") {
		var pos = value.indexOf(".");
		if( pos != -1) {
			value = value.substring(0, pos);
		}
		return value;
	} else {
		return "";
	}
}
/**
 * 查看内容
 * 
 */
function announcementContent(autoId){
	$.ajax({
		type : "POST",
		url : $.getContextPath()+ "/uss/announce/announcementAction!findAnnouncementByAutoId.action",
		data : {autoId : autoId},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.announcement) {
				var announcement = data.announcement;
				$("#onnouncement_content").val(announcement.content);
			}
		}
	});
	$("#announcementDLG").dialog("open");
}

/**
 * 删除内容
 * 
 */
function deleteAnnouncement(autoId){
	if(confirm("确定删除?")) {
		$.ajax({
			type : "POST",
			url : $.getContextPath()+ "/uss/announce/announcementAction!deleteAnnouncement.action",
			data : {autoId:autoId},
			dataType : "json",
			async : false,
			success : function(data) {
				if(data.responseMessage.success) {
					//成功
					$.success("删除成功");
					$("#announcementList").trigger("reloadGrid");
				} else {
					//失败
					$.error("删除失败: " + data.responseMessage.message);
				}
			}
		});
	}
}


/**
 * 添加公告栏
 */
function addAnnouncement(){
	if(!$("#add_Item").validationEngine("validate")) {
		return;
	}
	if($.trim($("#title").val()) == ""){
		alert("公告标题不能为空");
		return;
	}
	if($.trim($("#repleaseTime").val()) == ""){
		alert("公告生效时间不能为空");
		return;
	}
	if($.trim($("#invalidTime").val()) == ""){
		alert("公告失效时间不能为空");
		return;
	}
	if($.trim($("#content").val()) == ""){
		alert("公告内容不能为空");
		return;
	}
	if($.trim($("#content").val()).length > 1000){
		alert("公告内容不能超过1000字");
		return;
	}
	var params = $("#add_Item").serializeForm();
	$("#saveBtn").attr("disabled",true);//禁用按钮
	$.post(ctx+"/uss/announce/announcementAction!saveOrUpdateAnnouncement.action",params,function(data){
		$("#saveBtn").attr("disabled",false);//启用按钮
		if(null != data.responseMessage){
			if(data.responseMessage.success){
				alert("公告发布成功");
				$("#add_Item")[0].reset();
			}else{
				alert("服务异常");
			}
		}else{
			alert("服务异常");
		}
	});
}
