/**
 * 创建于:2015-11-17<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 拍照控件JS封装
 *
 * @author HuangKunping
 * @version 1.0
 */


/**
 * 定义拍照控件封装对象
 */
var xUSBVideo = new Object();
xUSBVideo.iniPath = (top.yzjgssRootPath || "C:") + "/yzjgss/config/1x/1x.ini";

/**
 * @param {Number} type 摄像头类型: 0-主摄像头，1-副摄像头，2-环境摄像头，3-视频检测
 * @param return 0表示成功，其他表示失败信息
 */
xUSBVideo.openCamera = function(type) {
	
	try {
		//检测摄像头类型
		if (!(type === "PHOTO" || type ==="VIDEO" || type ==="ENV")) {
			throw new Error("摄像头类型无效:(" + type + ")");
		}
		var camIndex    = OCX_Tools.readIni(this.iniPath, "CONFIG", "CAM_INDEX_" + type, "").data;		//摄像头索引
		var resIndex    = OCX_Tools.readIni(this.iniPath, "CONFIG", "RES_INDEX_" + type, "").data;		//分辨率索引
		var camExposure = OCX_Tools.readIni(this.iniPath, "CONFIG", "PHOTO_CAMERA_EXPOSURE", "").data;	//曝光值,默认为-5
		OCX_Logger.debug(LOGGER._1X,"{xUSBVideo.openCamera} 使用Type:(" + type + "), camIndex:(" + camIndex + "), resIndex:(" + resIndex + "), camExposure:(" + camExposure + ")" );
		
		if (!camIndex || !resIndex) {
			throw new Error("摄像头索引或者分辨率索引无效");
		}
		
		var camCountRet = OCX_XUSBVideo.getDevicesCount();//获取摄像头个数
		if ("1001" != camCountRet.code) {
			throw new Error("获取摄像头个数失败");
		}
		if (!(camCountRet.data && camCountRet.data > parseInt(camIndex))) {
			throw new Error("配置的摄像头ID无效");
		}
		OCX_Logger.debug(LOGGER._1X,"{xUSBVideo.openCamera} 摄像头个数:(" + camCountRet.data + ")");
		
		//获取分辨率个数
		var videoInfoCountRet = OCX_XUSBVideo.getVideoInfoCount(camIndex);
		if ("1001" != videoInfoCountRet.code) {
			throw new Error("获取摄像头分辨率参数失败");
		}
		if (!(videoInfoCountRet.data && videoInfoCountRet.data > parseInt(camIndex))) {
			throw new Error("配置的分辨率ID无效");
		}
		OCX_Logger.debug(LOGGER._1X,"{xUSBVideo.openCamera} 摄像头分辨率个数:(" + videoInfoCountRet.data + ")");
		
		//绑定摄像头
		var bindDeviceRet = OCX_XUSBVideo.bindDevice(camIndex, resIndex);
		if ("1001" != bindDeviceRet.code) {
			throw new Error("绑定摄像头失败");
		}
		
		//此处若是设置了曝光值，则IE8下，每次选择扫描源的时候曝光就越亮，估计是控件的一个bug
		if (camExposure) {
			OCX_XUSBVideo.setExposure(camExposure);//增加拍照曝光值的设置
		}
		//OCX_XUSBVideo.setRectShowMode(5);// 设置剪裁框
		
		//打开摄像头
		var openCameraRet = OCX_XUSBVideo.open();
		if ("1001" != openCameraRet.code) {
			throw new Error("打开摄像头失败");
		}
		return 0;
	} catch (e) {
		OCX_Logger.error(LOGGER._1X,"{xUSBVideo.openCamera} -- Exception:[" + e.message + "]");
		return e.message;
	}
};

/**
 * 拍照
 * @param {String} sectionImagePath  照片保存路径
 * @param {String} originalImagePath 原图保存路径
 * @param {Number} isCut     		 是否剪裁  0 否， 1 是
 * @returns 成功，返回0，失败返回异常信息; 
 */
xUSBVideo.captureImage = function(sectionImagePath, originalImagePath, isCut) {
	isCut = isCut || 0;
	try {
		OCX_XUSBVideo.setDeskew(isCut);
		var captureImageRet = OCX_XUSBVideo.captureImage(sectionImagePath, originalImagePath)
		OCX_Logger.debug(LOGGER._1X,"{xUSBVideo.captureImage} section-ImgPath:(" + sectionImagePath + "), original-imgPath:(" + originalImagePath + "), isCut:(" + isCut + ")");
		if ("1001" != captureImageRet.code) {
			throw new Error("拍照失败");
		}
		return 0;
	} catch(e) {
		OCX_Logger.error(LOGGER._1X,"{xUSBVideo.captureImage} -- Exception:[" + e.message + "]");
		return e.message;
	}
};

/**
 * 关闭摄像头
 * @returns 成功，返回0，失败返回异常信息; 
 */
xUSBVideo.closeCamera = function() {
	try {
		var closeCameraRet = OCX_XUSBVideo.close();
		if ("1001" != closeCameraRet.code) {
			throw new Error("关闭摄像头失败");
		}
		return 0;
	} catch(e) {
		OCX_Logger.error(LOGGER._1X,"{xUSBVideo.closeCamera} -- Exception:[" + e.message + "]");
		return e.message;
	}
};

/**
 * 摄像头就绪拍照事件
 * 若使用到此方法，请覆盖使用
 */
function deviceReady() {
	//do-nothing
}

/**
 * 摄像头连接事件
 * 若使用到此方法，请覆盖使用
 */
function deviceConnect(nConnectStatus) {
	//do-nothing
}