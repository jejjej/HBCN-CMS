/**
 * 创建于:2015-11-20<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 印章用印步骤
 * @description 1、数据库里必须配置有默认凭证"000";<br>
 * 				2、除了默认的"000"，若其他均未开启版面识别、背书拍照、OCR切片，则采用默认凭证配置;<br>
 * 				3、若版面识别未通过，在重复识别过程中，若默认凭证未开启背书拍照，则不显示背书拍照选框，<br>
 * 				若勾选了背书拍照，但又版面识别成功，则会按照识别成功的凭证类型参数进行用印;<br>
 * 				4、版面识别成功后，则是否进行授权，由afterRecogNoApproval参数配置，则可查看"//IS REMOTE CODE"
 * @author HuangKunping
 * @version 1.0.0
 */

var SealStep = function(msgHanlder) {
	var isDetectException;//视频检测是否有异常，默认为false 
	var photoFailTryTimes = 3;// 拍照失败尝试的次数，默认3次 
	
	// 视频检测模式 0为detect方法取mask， 1为detect方法， 2为watch方法。
	//设置1和2可在视频处理过程中切换处理的方法，常用watch方法
	var detectMethod = 2;
	var isCut = 1;//-是否要裁剪， 0表示不裁剪；1表示裁剪
	
	var timer = {};//定时器
	var remote_approval_result;//远程审批结果，默认为 waiting_approval
	var remote_approval_msg;//远程审批信息
	var exception;//用印异常状态，默认为false
	var recognizeSuccess = false;
	var recognizeMsg;//版面识别信息
	var useSealMsg;//用印信息
	var useSealTimeout;// 用印是否超时
	var useSealFinish;//用印是否完成
	
	
	var approvalMode;//审批模式
	var photoDirection;//拍出的图像方向, 朝上、右、下、左 
	var isUploadedBeforePhoto;//是否已上传用印前图像，默认为false 
	
	var that = this;		//拷贝保存this对象
	var sealLog;
	var hasError;
	var hasDetectException;
	var detectExceptionMsg;//视频检测异常信息
	
	var isOpenPhotoCamera = false;		//是否打开拍照摄像头
	var isOpenVideoCamera = false;
	var openCameraDelayMs;	//拍照延时(毫秒)
	
	var beforePhotoPath;	//用印前图像路径
	var afterPhotoPath;
	var endorsePhotoPath;
	var videoPath;
	
	var beforeImgOcr = {};//用印前ocr切片
	var afterImgOcr  = {};//用印后ocr切片
	
	var defalutDocNo = "000";//默认凭证类型代码
	var defalutDocName = "其他";//默认凭证类型名称
	
	var watchTimer = null;
	var isOpenRecogDialog = false;//是否打开版面识别对话框

	var localApprovalPeopleCode;//本地审批人
	var remoteApprovalStartTime;//远程审批开始时间
	
	var checkedPaper = false; //是否已检测纸张，若第一次检查了纸张，由于没有发生版面识别和背书拍照就不进行第二次纸张检查
	
	this.init = function(param) {
		watchTimer 			   = Utils.watchTimer();
		isDetectException      = false;//视频检测是否有异常，默认为false 
		remote_approval_result = "waiting_approval";//远程审批结果，默认为 waiting_approval
		remote_approval_msg    = "";//远程审批信息
		timer 				   = {};//定时器
		exception 			   = false;//用印异常状态，默认为false
		recognizeSuccess	   = false;//版面识别是否成功
		recognizeMsg 		   = null;//版面识别信息
		useSealMsg 			   = null;//用印信息
		useSealTimeout 		   = false;// 用印是否超时
		useSealFinish 		   = false;//用印是否完成
		approvalMode 		   = null;
		photoDirection 		   = 1;//拍出的图像方向, 朝上、右、下、左 
		isUploadedBeforePhoto  = false;//是否已上传用印前图像，默认为false
		hasError 			   = false;
		hasDetectException     = false;
		detectExceptionMsg     = null;//视频检测异常信息
		beforePhotoPath 	   = null;
		afterPhotoPath  	   = null;
		endorsePhotoPath 	   = null;
		videoPath 			   = null;
		detectMethod           = param.detectMethod || 2;
		isCut				   = param.isCut || 1;
		openCameraDelayMs      = param.openCameraDelay;
		isOpenRecogDialog	   = false;
		localApprovalPeopleCode= "";
		checkedPaper 		   = false; 
		beforeImgOcr           = { ocrBN:"", ocrMN:"", ocrAN:"", ocrAP:"" };
		afterImgOcr            = { ocrBN:"", ocrMN:"", ocrAN:"", ocrAP:"" };
		sealLog                = sealLogUtils.createSealLog().SealNum(param.sealNum).DeviceNum(param.machineSN)
								.SealModuleSn(param.sealModuleSn).SealBizTypeId(param.sealBizTypeId).SealBizTypeName(param.sealBizTypeName)
								.HasDetectException(hasDetectException).ApplyFormId(param.applyFormId || "");
		initFilePath(param);
		return true;
	};
	
	function initFilePath(param) {
		var filePrefix = "YZJ_YKMS_" + param.orgNo + param.peopleCode + Utils.format(new Date(), "yyyyMMddhhmmssS");
		param.beforePhoto  = param.imagePath + filePrefix + "_before.jpg";
		param.afterPhoto   = param.imagePath + filePrefix + "_after.jpg";
		param.endorsePhoto = param.imagePath + filePrefix + "_endorse.jpg";//背书图像路径
		param.video 	   = param.videoPath + filePrefix + "_video.asf";//用印视频路径
		if (param.noApproval) {
			param.approvalMode = ussConstants.NOT_NEED_APPROVAL;
			param.endorsePhoto = null;//若有无需审批权限，则不需要背书拍照
		}
		param.distcut = param.distcut || 200;//白纸检测忽略的像素值，默认200
		sealLog.TempStoreId(filePrefix);
	}
	
	
	/**
	 * 开始用印流程
	 * @param {object} param
	 * {String} param.videoDetect 视频检测参数 null-不视频检测 / 1-视频检测,不上传视频 / 2-视频检测,上传视频 / 3-视频检测,上传异常视频
	 * {String} param.beforePhoto 用印前拍照参数 null-不拍照 / 非空字符串-拍照到非空字符串指定的路径并上传
	 * {String} param.recognize 版面识别参数 null-不版面识别 / 空字符串-版面识别 / 非空字符串-版面识别并将识别结果与非空字符串比对
	 * {String} param.approvalMode 授权参数 none-不授权 / local-本地授权 / remote-远程授权
	 * {String} param.afterPhoto 用印后拍照参数 null-不拍照 / 非空字符串-拍照到非空字符串指定的路径并上传
	 * {Object} param.photoCamera: 拍照摄像头参数 {cameraIndex-摄像头序号, resIndex-分辨率序号, camExposure-曝光值, isCut-是否要裁剪, readyCallback, disconnectCallback}
	 * {Object} param.videoCamera: 视频摄像头参数 {cameraIndex-摄像头序号, resIndex-分辨率序号, camExposure-曝光值}
	 * {Function} param.showSealLogCallback 用印完成后回调方法, 传入参数: responseMessage{success, message, sealLog}对象
	 * {Function} param.callback 用印完成后回调方法, 传入参数: responseMessage对象{success, message}
	 */
	this.start = function(param) {

		this.log("准备用印...");
		OCX_Logger.info(LOGGER._1X,"{useSealStep.start}--=====================================================================");
		OCX_Logger.info(LOGGER._1X,"{useSealStep.start}--                    {useSealStep.start}--准备用印                     ");
		OCX_Logger.info(LOGGER._1X,"{useSealStep.start}--=====================================================================");
		this.init(param);
		
		var beforeChain = [this.check, this.checkPaper, this.recognize, this.beforePhotoOCR, this.endorsePhoto, this.checkPaper, this.beforePhoto, this.checkBlankPaper, this.startVideoDetect, this.authorize/*, this.closeCamera*/, this.addSealLog];
		var afterChain  = [this.uploadBeforePhoto, this.useSeal, this.afterPhoto, this.endVideoDetect, this.afterPhotoOCR, this.closeCamera, this.updateSealLog, this.uploadVideo, this.uploadAfterPhoto, this.end];
		var beforeExceptionChain = [this.updateSealLogException, this.closeCamera, this.endVideoDetect, this.uploadVideoException, this.endException];
		
		//通过回调方法逐个方法执行
		var i = 0;
		var beforeCallback = function(responseMessage) {
			if(responseMessage.success) {
				if(that.hasDetectException) {
					//视频检测异常，停止
					exception = true;
					if(beforeExceptionChain[0]) {
						beforeExceptionChain[0].call(that, param, exceptionCallback);
					} 
					param.callback({success: false, message: detectExceptionMsg});
					return;
				}
				i++;
				if(beforeChain[i]) {
					beforeChain[i].call(that, param, beforeCallback);
				} else {
					//用印前完成
					afterChain[0].call(that, param, afterCallback);
				}
			} else {
				//中途出错
				exception = true;
				if(beforeExceptionChain[0]) {
					beforeExceptionChain[0].call(that, param, exceptionCallback);
				} 
				param.callback(responseMessage);
			}
		};
		
		var j = 0;
		var response = null;
		var afterCallback = function(responseMessage) {
			if(!responseMessage.success ) {
				response = responseMessage;
			}
			//用印后即使出异常也继续往下走
			j++;
			if(afterChain[j]) {
				afterChain[j].call(that, param, afterCallback);
			} else if (response) {
				//用印完成
				param.callback(response);
			} else {
				//用印完成
				param.callback({success: true, message: hasDetectException ? detectExceptionMsg : "", sealLog: sealLog});
				
			}
			
		};
		//清理资源
		var k = 0;
		var exceptionCallback = function(responseMessage) {
			if(responseMessage.success) {
				k++;
				if(beforeExceptionChain[k]) {
					beforeExceptionChain[k].call(that, param, exceptionCallback);
				}
			}
		};
		//从第一个链开始
		beforeChain[0].call(this, param, beforeCallback);
	};
	
	/**
	 * 用印前检查
	 * 1、检查锁章模块编号
	 * 2、检查设备编号
	 * 3、检查锁章模块权限
	 * 4、检查设备是否可用
	 * 5、检查工作时间
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.check = function(param, callback) {
		try {
			OCX_Logger.debug(LOGGER._1X,"{useSealStep.check}--用印前检查开始");
			// 1.检查锁章模块编号
			Utils.checkConditions(Utils.isNumberAndAlphabet(param.sealModuleSn), "该锁章模块编号未设置.");
			// 2.检查设备编号
			Utils.checkConditions(Utils.isNumberAndAlphabet(param.machineSN), "该设备编号未设置.");
			// 3.锁章模块权限校验
			Utils.checkConditions(smsInterface.checkSealInfo(param.peopleCode, param.sealModuleSn, param.sealNum).success, "您无使用此锁章模块的权限.");
			// 4.检查设备工作时间
			Utils.checkEquals("0", smsInterface.checkMachineWorkTime(param.orgNo), "设备在该工作时间内不可用.");
			OCX_Logger.debug(LOGGER._1X,"{useSealStep.check}--用印前检查结束");
			callback({success: true});
		} catch (e) {
			OCX_Logger.error(LOGGER._1X,"{useSealStep.check}--用印前检查异常：" + e.message);
			callback({success: false, message:e.message});
		}
	};
	
	this.checkPaper = function(param, callback) {
		try {
			//若无版面识别或背书拍照，则不需要第二次检查纸张
			if (!checkedPaper || param.isRecognize || param.endorsePhoto != null) {
				OCX_Logger.debug(LOGGER._1X,"{useSealStep.checkPaper}--开始检测纸张");
				var checkPaperRet = machineOrder.checkPaper();
				Utils.checkEquals("0", checkPaperRet, checkPaperRet);
				OCX_Logger.debug(LOGGER._1X,"{useSealStep.checkPaper}--检测纸张结束");
				checkedPaper = true;
			}
			callback({success: true});
		} catch (e) {
			OCX_Logger.error(LOGGER._1X,"{useSealStep.checkPaper}--检测纸张异常：" + e.message);
			callback({success: false, message:e.message});
		}
	};
	
	/**
	 * 白纸检测
	 */
	this.checkBlankPaper = function(param, callback) {
		if(param.checkBlankPaper && !recognizeSuccess) {
			if(beforePhotoPath) {
				try {
					//获取图片的宽
					var widthRet = OCX_IProcOperation.getImageFileWidth(beforePhotoPath);
					Utils.checkEquals("1001", widthRet.code, "获取图片数据失败");
					//获取图片的高
					var heightRet = OCX_IProcOperation.getImageFileHeight(beforePhotoPath);
					Utils.checkEquals("1001", heightRet.code, "获取图片数据失败");
					
					var area ="[{"+param.checkBlankPaperDistcut + "," + param.checkBlankPaperDistcut + "," 
						+ (widthRet.data - param.checkBlankPaperDistcut ) +","+ (heightRet.data - param.checkBlankPaperDistcut )+"}]"; //识别裁剪整张纸
					var disresult = OCX_ImageProcess.checkBlankArea(beforePhotoPath, area).data;
					if(disresult < 0) {
						OCX_Logger.error(LOGGER._1X,"{useSealStep.checkBlankPaper}--白纸检测识别异常，识别结果["+disresult+"]");
						callback({success: false, message:"白纸检测识别异常."});
					} else if(disresult >= 0 && disresult <=150){ // >=0, 为所有区域中差异值最小的值（有字的地方占用的像素点数）
						OCX_Logger.info(LOGGER._1X,"{useSealStep.checkBlankPaper} 识别出空白纸张.");
						callback({success: false, message:"识别出空白纸张，取消用印."});
					} else{
						OCX_Logger.info(LOGGER._1X,"{useSealStep.checkBlankPaper}--识别出非空白纸张.");
						callback({success: true});
					}
				} catch (e) {
					OCX_Logger.error(LOGGER._1X,"{useSealStep.checkBlankPaper}--白纸检测失败：" + e.message);
					callback({success: false, message:"白纸检测失败：" + e.message});
				}
			} else {
				OCX_Logger.error(LOGGER._1X,"{useSealStep.checkBlankPaper}--白纸检测失败：用印前未拍照或拍照失败.");
				callback({success: false, message:"白纸检测失败：用印前未拍照或拍照失败."});
			}
			
		} else {
			callback({success: true});
		}
	};
	
	this.beforePhoto = function(param, callback) {
		OCX_Logger.debug(LOGGER._1X,"{useSealStep.beforePhoto}--用印前拍照开始...");
		if(param.beforePhoto == null || beforePhotoPath != null) {
			callback({success: true});
		} else if(param.beforePhoto != null) {
			this.log("正在采集用印前图像...");
			OCX_Logger.info(LOGGER._1X,"{useSealStep.beforePhoto}--正在采集用印前图像..." + param.beforePhoto);
			this.openCamera(param, function(responseMessage) {
				if(responseMessage.success) {
					var retryTimes = photoFailTryTimes;
					that.photo(param.beforePhoto, isCut, retryTimes, function(msg) {
						beforePhotoPath = msg.success ? param.beforePhoto : null;
						OCX_Logger.info(LOGGER._1X,"{useSealStep.beforePhoto}--采集用印前图像["+param.beforePhoto+"]成功");
						callback(msg);
					});
				} else {
					OCX_Logger.error(LOGGER._1X,"{useSealStep.beforePhoto}--采集用印前图像失败" +responseMessage.message + "," + param.beforePhoto);
					callback(responseMessage);
				}
			});
		}
	};
	
	/**
	 * 用印后拍照
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.afterPhoto = function(param, callback) {
		if(param.afterPhoto == null || afterPhotoPath != null) {
			callback({success: true});
		} else {
			this.log("正在采集用印后图像...");
			OCX_Logger.info(LOGGER._1X,"{useSealStep.afterPhoto}--正在采集用印后图像..." + param.afterPhoto);
			this.openCamera(param, function(responseMessage) {
				if(responseMessage.success) {
					var retryTimes = photoFailTryTimes;
					that.photo(param.afterPhoto, isCut, retryTimes, function(msg) {
						OCX_MachineOrder.photoFinishReply();
						afterPhotoPath = msg.success ? param.afterPhoto : null;
						machineOrder.rotateImage(photoDirection, afterPhotoPath);
						OCX_Logger.info(LOGGER._1X,"{useSealStep.afterPhoto}--采集用印后["+afterPhotoPath+"]图像成功");
						callback(msg);
					});
				} else {
					OCX_Logger.error(LOGGER._1X,"{useSealStep.afterPhoto}--采集用印后图像失败" + responseMessage.message + "," + param.afterPhoto);
					callback(responseMessage);
				}
			});
		}
	};
	
	/**
	 * 开始视频检测
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.startVideoDetect = function(param, callback) {
		if(param.video != null) {
			this.log("正在开启视频检测...");
			if (isOpenVideoCamera) {//如果已经打开了视频检测，则关闭
				this.endVideoDetect(param, callback);
			}
			OCX_Logger.info(LOGGER._1X,"{useSealStep.startVideoDetect}--正在开启视频检测，计时开始...");
			var timer = Utils.watchTimer();
			var result = document.getElementById("videoPaperSafeDetectIFrame").contentWindow
					.OCX_VideoPaperSafeDetect.startAsfRecord(param.video, detectMethod, 
						function() {
							detectExceptionMsg = "视频检测开启失败，取消用印";
							if(!hasDetectException){
								OCX_Logger.error(LOGGER._1X,"{useSealStep.startVideoDetect}--" + detectExceptionMsg);
								hasDetectException = true;
								machineOrder.cancelSeal();
							}
						}, function() {
							detectExceptionMsg = "视频检测发现凭证有异常";
							if(!hasDetectException){
								OCX_Logger.error(LOGGER._1X,"{useSealStep.startVideoDetect}--" + detectExceptionMsg);
								hasDetectException = true;
								machineOrder.cancelSeal();
							}
					});
			if(result.code != "1001"){
				OCX_Logger.error(LOGGER._1X,"{useSealStep.startVideoDetect}--视频摄像头开启失败，取消用印");
				callback({success: false, message:"视频摄像头开启失败，取消用印"});
			} else {
				OCX_Logger.info(LOGGER._1X,"{useSealStep.startVideoDetect}--视频摄像头开启成功，耗时(ms): " + timer.diffTime());
				videoPath = param.video;
				isOpenVideoCamera = true;
				callback({success: true});
			}
		} else {
			callback({success: true});
		}
	};
	
	/**
	 * 停止视频检测
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.endVideoDetect = function(param, callback) {
		if(isOpenVideoCamera) {
			OCX_Logger.info(LOGGER._1X,"{useSealStep.endVideoDetect}--准备关闭视频检测...");
			document.getElementById("videoPaperSafeDetectIFrame").contentWindow.OCX_VideoPaperSafeDetect.endVideo(0);
			OCX_Logger.info(LOGGER._1X,"{useSealStep.endVideoDetect}--视频检测关闭结束...");
			isOpenVideoCamera = false;
		}
		callback({success: true});
	};
	
	/**
	 * 用印盖章
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.useSeal = function(param, callback) {
		that.log("正在用印...");
		OCX_Logger.debug(LOGGER._1X,"{useSealStep.useSeal}--开始用印，计时开始...");
		var timer = Utils.watchTimer();
		machineOrder.startUseSeal(sealLog.autoId, param.sealNum, function(responseMessage) {
			OCX_Logger.debug(LOGGER._1X,"{useSealStep.useSeal}--用印完成，耗时(ms): " + timer.diffTime());
			callback(responseMessage);
		});
	};
	
	
	/**
	 * 保存用印日志
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.addSealLog = function(param, callback) {
		if(Utils.isEmpty(param.approvalMode) || param.approvalMode == ussConstants.NOT_NEED_APPROVAL) {
			OCX_Logger.debug(LOGGER._1X,"{useSealStep.addSealLog}--准备添加用印日志...");
			sealLog = saveSealLog("addLog", "waiting_use", hasDetectException, "准备开始用印");
			if (Utils.isEmpty(sealLog) || Utils.isEmpty(sealLog.autoId)) {
				OCX_Logger.info(LOGGER._1X,"{useSealStep.addSealLog}--添加用印日志失败...");
				callback({success: false, message:"添加用印日志失败"});
			} else {
				//日志的显示
				OCX_Logger.debug(LOGGER._1X,"{useSealStep.addSealLog}--添加用印日志成功...");
				callback({success: true});
			}	
		} else {
			callback({success: true});
		}
	};
	
	/**
	 * 更新用印记录
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.updateSealLog = function(param, callback) {
		this.log("准备更新用印日志...");
		OCX_Logger.debug(LOGGER._1X,"{useSealStep.updateSealLog}--准备更新用印日志...");
		var memo = Utils.options1(hasDetectException, "发现凭证有异常", "用印完成");
		sealLog = saveSealLog("updateLog", "finish", hasDetectException, memo);
		if (Utils.isEmpty(sealLog)) {
			OCX_Logger.info(LOGGER._1X,"{useSealStep.updateSealLog}--更新用印日志失败...");
			callback({success: false, message:"更新用印日志失败"});
		} else {
			//日志的显示
			OCX_Logger.debug(LOGGER._1X,"{useSealStep.updateSealLog}--更新用印日志成功");
			param.showSealLogCallback({success:true, sealLog:sealLog});
			callback({success: true});
		}	
	};
	
	this.updateSealLogException = function(param, callback) {
		if(sealLog.autoId != null && remote_approval_result == "approval_pass") {
			sealLog = saveSealLog("updateLog", "exe_before_video", hasDetectException, "发现凭证异常，取消用印");
		}
		callback({success: true});
	};
	
	/**
	 * 视频上传异常处理
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.uploadVideoException = function(param, callback) {
		if(sealLog.autoId != null && videoPath != null && WTFileUtil.fileExists(videoPath)) {
			fileStore.asyncUpload(videoPath, sealLog.storeId, function(responseMessage){
				if (responseMessage.success) {
					sealLog.storeId = responseMessage.storeId;
					WTFileUtil.deleteFile(videoPath);// 上传成功删除本地文件
				} else {
					that.log("用印视频上传失败...");
				}
			});
		}
		//因为要求是异步上传，所以要立即回调
		callback({success: true});
	}; 
	
	/**
	 * 用印异常结束
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.endException = function(param, callback) {
		OCX_Logger.info(LOGGER._1X,"{useSealStep.endException}--用印异常结束");
		OCX_MachineOrder.setPressboard(2);
		this.clearTimer();
		callback({success: false});
	};
	
	
	/**
	 * 打开拍照摄像头
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.openCamera = function(param, callback) {
		if (isOpenPhotoCamera) {
			callback({success: true});
		} else {
			OCX_Logger.debug(LOGGER._1X,"{useSealStep.openCamera}--准备打开拍照摄像头，计时开始...");
			var timer = Utils.watchTimer();
			var openCameraRet = xUSBVideo.openCamera("PHOTO");
			if(openCameraRet == 0) {//摄像头打开成功
				isOpenPhotoCamera = true;
				OCX_Logger.debug(LOGGER._1X,"{useSealStep.openCamera}--拍照摄像头打开成功，耗时(ms): " + timer.diffTime());
				setTimeout(function(){callback({success: true});}, openCameraDelayMs);
			} else {
				OCX_Logger.info(LOGGER._1X,"{useSealStep.openCamera}--拍照摄像头打开失败：" + openCameraRet);
				callback({success: false, message: openCameraRet});
			}
		}
	};
	
	/**
	 * 关闭拍照摄像头
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.closeCamera = function(param, callback) {
		if(isOpenPhotoCamera) {
			OCX_Logger.info(LOGGER._1X,"{useSealStep.closeCamera}--准备关闭拍照摄像头，计时开始...");
			var timer = Utils.watchTimer();
			var closeCameraRet = xUSBVideo.closeCamera();
			if (closeCameraRet != 0) {
				OCX_Logger.info(LOGGER._1X,"{useSealStep.closeCamera}--摄像头关闭失败：" + closeCameraRet);
				callback({success: false, message:"摄像头关闭失败"});
				return;
			}
			OCX_Logger.info(LOGGER._1X,"{useSealStep.closeCamera}--拍照摄像头关闭成功，耗时(ms): " + timer.diffTime());
			isOpenPhotoCamera = false;
		}
		callback({success: true});
		if (hasError) {
			OCX_Logger.info(LOGGER._1X,"{useSealStep.closeCamera}--删除影像文件");
			WTFileUtil.deleteFile(beforePhotoPath);
			WTFileUtil.deleteFile(afterPhotoPath);
			WTFileUtil.deleteFile(endorsePhotoPath);
		}
	};
	
	/**
	 * 拍照函数
	 * @param photoPath 图像路径
	 * @param isCut 是否裁剪
	 * @param retryTimes 失败重试次数
	 * @param callback 回调函数
	 */
	this.photo = function(photoPath, isCut, retryTimes, callback) {
		OCX_Logger.info(LOGGER._1X,"{useSealStep.photo}--开始拍照");
		var result = xUSBVideo.captureImage(photoPath, "", isCut);
		if (result == 0) {
			OCX_Logger.info(LOGGER._1X,"{useSealStep.photo}--拍照成功");
			callback({success: true});
		} else {
			if(--retryTimes < 0) {
				OCX_Logger.error(LOGGER._1X,"{useSealStep.photo}--拍照失败：" + photoPath);
				callback({success: false, message:result});
			} else {
				setTimeout(function() {that.photo(photoPath, isCut, retryTimes, callback);}, 100);
			}
		}
	};
	
	
	
	/**
	 * 上传用印前图像
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.uploadBeforePhoto = function(param, callback) {
		//因为要求是异步上传，所以要立即回调
		OCX_Logger.debug(LOGGER._1X,"{useSealStep.uploadBeforePhoto}--开始上传用印前图像");
		if(!isUploadedBeforePhoto && beforePhotoPath != null) {
			//上传
			fileStore.asyncUpload(beforePhotoPath, sealLog.storeId, function(responseMessage){
				if (responseMessage.success) {
					sealLog.storeId = responseMessage.storeId; 
					WTFileUtil.deleteFile(beforePhotoPath);// 上传成功删除本地文件
					OCX_Logger.info(LOGGER._1X,"{useSealStep.uploadBeforePhoto}--上传用印前图像成功");
				} else {
					that.log("用印前图像上传失败...");
					OCX_Logger.error(LOGGER._1X,"{useSealStep.uploadBeforePhoto}--用印前图像上传失败：" + beforePhotoPath);
				}
			});
		}
		callback({success: true});
	};
	
	/**
	 * 上传用印后图像
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.uploadAfterPhoto = function(param, callback) {
		OCX_Logger.info(LOGGER._1X,"{useSealStep.uploadAfterPhoto}--开始上传用印后图像");
		if(afterPhotoPath != null) {
			//上传
			var tempSealLog = Utils.deepCopyObject(sealLog);
			var tempPhotoPath = afterPhotoPath;
			fileStore.asyncUpload(tempPhotoPath, sealLog.storeId, function(responseMessage){
				if (responseMessage.success) {
					sealLog.storeId = responseMessage.storeId;
					tempSealLog.storeId = responseMessage.storeId;
					WTFileUtil.deleteFile(tempPhotoPath);// 上传成功删除本地文件
					param.showSealLogCallback({success:true, sealLog:tempSealLog});
					OCX_Logger.info(LOGGER._1X,"{useSealStep.uploadAfterPhoto}--用印后图像上传成功");
				} else {
					that.log("用印后图像上传失败...");
					OCX_Logger.error(LOGGER._1X,"{useSealStep.uploadAfterPhoto}--用印后图像上传失败" + tempPhotoPath);
				}
			});
		}
		callback({success: true});
	};
	
	/**
	 * 上传视频
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.uploadVideo = function(param, callback) {
		OCX_Logger.info(LOGGER._1X,"{useSealStep.uploadVideo}--开始上传视频");
		if(videoPath != null) {
			var tempSealLog = Utils.deepCopyObject(sealLog);
			var tempVideoPath = videoPath;
			fileStore.asyncUpload(tempVideoPath, sealLog.storeId, function(responseMessage){
				if (responseMessage.success) {
					sealLog.storeId = responseMessage.storeId; 
					tempSealLog.storeId = responseMessage.storeId;
					WTFileUtil.deleteFile(tempVideoPath);// 上传成功删除本地文件
					param.showSealLogCallback({success:true, sealLog:tempSealLog});
					OCX_Logger.info(LOGGER._1X,"{useSealStep.uploadVideo}--上传视频成功");
				} else {
					that.log("用印视频上传失败...");
					OCX_Logger.error(LOGGER._1X,"{useSealStep.uploadVideo}--用印视频上传失败:" + tempVideoPath);
				}
			});
		}
		callback({success: true});
	};
	
	/**
	 * 版面识别
	 * 
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.recognize = function(param, callback) {
		// 如果需要版面识别
		if(param.isRecognize && param.beforePhoto) {
			that.log("正在版面识别中...");
			OCX_Logger.debug(LOGGER._1X,"{useSealStep.recognize}--正在版面识别中");
			// 拍照
			that.beforePhoto(param, function(responseMessage) {
				if(responseMessage.success) {
					// 版面识别
					var credibility = OCX_DocRecog.recognize(param.beforePhoto).data;
					if(credibility < 0) {
						sealLog.docNo = defalutDocNo;
						sealLog.docName = defalutDocName;
						that.log("图像文件版面识别失败");
						if (param.noApproval) {//无需审批
							setBillTypeParam(param, param.billTypeParams.get(sealLog.docNo));//直接设置凭证类型参数
							param.approvalMode = ussConstants.NOT_NEED_APPROVAL;//设置为无需审批模式
							OCX_Logger.info(LOGGER._1X,"{useSealStep.recognize}--图像文件版面识别失败，不审批");
							callback({success: true, message: "图像文件版面识别失败，无需审批"});
						} else {
							OCX_Logger.info(LOGGER._1X,"{useSealStep.recognize}--图像文件版面识别失败，继续识别");
							beforePhotoPath = null;
							var t_billTypeParam = param.billTypeParams.get(defalutDocNo);
							if (t_billTypeParam) {
								param.defaultApprovalMode = t_billTypeParam.approvalMode;
							}
							if (!isOpenRecogDialog) {
								isOpenRecogDialog = true;
								param.recognizeCallback(param, function(msg){
									sealLog.docNo = (sealLog.docNo == defalutDocNo ? defalutDocNo : sealLog.docNo);
									sealLog.docName = (sealLog.docName == defalutDocName ? defalutDocName : sealLog.docName);
									if(msg.success) {
										var t_endorsePhotoPath = param.endorsePhoto;
										setBillTypeParam(param, param.billTypeParams.get(sealLog.docNo));
										if (param.approvalMode == ussConstants.LOCAL_APPROVAL_ONLY) {
											recognizeMsg = "版面识别失败，进入现场审批";
											OCX_Logger.info(LOGGER._1X,"{useSealStep.recognize}--" + recognizeMsg);
										} else if (param.approvalMode == ussConstants.REMOTE_APPROVAL_ONLY) {
											recognizeMsg = "版面识别失败，进入远程审批";
											OCX_Logger.info(LOGGER._1X,"{useSealStep.recognize}--" + recognizeMsg);
										} else {
											recognizeMsg = "版面识别失败，无需审批";
											OCX_Logger.info(LOGGER._1X,"{useSealStep.recognize}--" + recognizeMsg);
										}
										//勾选背书拍照或开启了远程审批才会进行背书拍照
										if ((msg.hasOwnProperty("endorse") && msg.endorse) || param.approvalMode == ussConstants.REMOTE_APPROVAL_ONLY) {
											param.endorsePhoto = t_endorsePhotoPath;
										} else {
											param.endorsePhoto = null;
										}
									}
									callback(msg);
								}, function(_callback) {
									that.recognize(param, _callback);
								});
							}
						}
					} else {
						// 凭证类型名称
						var docName = OCX_DocRecog.getDocName().data.split("_")[0];
						param.firstDocName = docName;
						sealLog.docName = docName;
						// 凭证类型编码
						var docRecogResults = OCX_DocRecog.getDocNO().data.split("_");
						sealLog.docNo = docRecogResults[0];
						// 根据版面识别的结果算出图片的方向，旋转方向
						photoDirection = docRecogResults[docRecogResults.length-1];
						machineOrder.rotateImage(photoDirection, beforePhotoPath);
						
						recognizeSuccess = true;
						doAfterRecognize(param, sealLog.docNo, sealLog.docName, callback);
						OCX_Logger.debug(LOGGER._1X,"{useSealStep.recognize}--"+param.firstDocName+"版面识别成功");
					}
				} else {
					callback(responseMessage);
				}
			});
		} else {// 不需要版面识别，则获取默认的凭证类型000
			sealLog.docNo = defalutDocNo;
			sealLog.docName = defalutDocName;
			var defalutBillTypeParam = param.billTypeParams.get(defalutDocNo);
			if (defalutBillTypeParam) {
				sealLog.docName = defalutBillTypeParam.billName;
				setBillTypeParam(param, defalutBillTypeParam);
				callback({success: true});
			} else {// 默认凭证类型不存在
				OCX_Logger.debug(LOGGER._1X,"{useSealStep.recognize}--凭证类型代码 "+ defalutDocNo +" 参数配置出错，请检查数据库表信息!");
				callback({success: false, message:"凭证类型代码 "+ defalutDocNo +" 参数配置出错，请检查数据库表信息!"});
			}
		}
	};
	
	/**
	 * 版面识别后的后期处理函数
	 * @param param
	 * @param docNo
	 * @param docName
	 * @param callback
	 */
	function doAfterRecognize(param, docNo, docName, callback) {
		OCX_Logger.debug(LOGGER._1X,"{useSealStep.doAfterRecognize}--版面识别后的后期处理");
		var billTypeParam = param.billTypeParams.get(docNo);// 获取凭证类型参数
		if (billTypeParam) {// 凭证类型存在
			var sealType = billTypeParam.sealType;
			if (sealType != -1) {// 印章类型不为"全部"
				var sealInfo = param.sealInfos.get(sealType);
				if (sealInfo) {
					if (sealInfo.sealNum == param.sealNum) {// 按键相同
						setBillTypeParam(param, billTypeParam);
						if(recognizeSuccess && !param.recogSuccApproval) {
							param.approvalMode = ussConstants.NOT_NEED_APPROVAL;//IS REMOTE CODE 加上这句话，则版面识别成功之后不用进入审批模式
						}
						OCX_Logger.debug(LOGGER._1X,"{useSealStep.doAfterRecognize}--图像文件版面识别成功：凭证名称为 " + docName + "["+docNo+"]");
						callback({success: true, message: "图像文件版面识别成功：凭证名称为 " + docName + "["+docNo+"]"});
					} else {
						OCX_Logger.info(LOGGER._1X,"{useSealStep.doAfterRecognize}--图像文件版面识别失败：按键不正确，请按 " + sealInfo.sealNum +" 号印章");
						callback({success: false, message: "按键不正确，请按 " + sealInfo.sealNum +" 号印章"});
					}
				} else {// 印章信息不存在
					OCX_Logger.info(LOGGER._1X,"{useSealStep.doAfterRecognize}--图像文件版面识别失败：印章类型为 " + sealType +" 不存在");
					callback({success: false, message: "印章类型为 " + sealType +" 不存在"});
				}
			} else {// 印章类型为全部
				setBillTypeParam(param, billTypeParam);
				if(recognizeSuccess && !param.recogSuccApproval) {
					param.approvalMode = ussConstants.NOT_NEED_APPROVAL;//IS REMOTE CODE 加上这句话，则版面识别成功之后不用进入审批模式
				}
				OCX_Logger.debug(LOGGER._1X,"{useSealStep.doAfterRecognize}--图像文件版面识别成功：凭证名称为 " + docName + "["+docNo+"]");
				callback({success: true, message: "图像文件版面识别成功"});
			}
		} else {// 不存在
			OCX_Logger.info(LOGGER._1X,"{useSealStep.doAfterRecognize}--图像文件版面识别失败：凭证名称为 " + docName + "["+docNo+"] 数据库中不存在");
			callback({success: false, message: "凭证名称为 " + docName + "["+docNo+"] 数据库中不存在"});
		}
	}
	
	/**
	 * 设置凭证类型参数
	 * @param param
	 * @param billTypeParam
	 * @returns
	 */
	function setBillTypeParam(param, billTypeParam) {
		OCX_Logger.debug(LOGGER._1X,"{useSealStep.setBillTypeParam}--开始设置凭证类型参数");
		if (billTypeParam) {
			param.approvalMode = param.noApproval ? ussConstants.NOT_NEED_APPROVAL : billTypeParam.approvalMode;
			var captureImageMode = billTypeParam.captureImageMode;// 拍照模式
			var beforePhotoPath = param.beforePhoto;
			var afterPhotoPath = param.afterPhoto;
			// 用印前拍照
			if (captureImageMode != "before") {
				param.beforePhoto = null;
			}
			// 用印后拍照
			if(captureImageMode != "after"){
				param.afterPhoto = null;
			}
			// 用印前后拍照
			if(captureImageMode == "before+after"){
				param.beforePhoto = beforePhotoPath;
				param.afterPhoto = afterPhotoPath;
			}
			/**
			 * // 审批模式不为none或开启版面识别则需要用印前拍照
			 * if(billTypeParam.approvalMode != useSealConstants.NOT_NEED_APPROVAL) {
			 *		param.beforePhoto = beforePhotoPath;
			 *	}
			 */
			// 背书图像路径
			if (billTypeParam.endorsePhotoStatus == 0) {
				param.endorsePhoto = null;
			}
			// 用印视频路径
			if (billTypeParam.videoDefectStatus == 0) {
				param.video = null;
			}
			//ocr状态
			param.ocrStatus = billTypeParam.ocrStatus;
			if (billTypeParam.billCode == defalutDocNo) {
				param.ocrStatus = 0;	//默认凭证类型不开启ocr
			}
			//ocr切片
			param.ocrArea = null;
			if (billTypeParam.ocrArea) {
				param.ocrArea = eval('(' + billTypeParam.ocrArea + ')');//ocr区域坐标
			}
			if (param.noApproval || param.approvalMode == ussConstants.LOCAL_APPROVAL_ONLY) {// 若有无需审批权限或本地审批，则不需要背书拍照
				param.endorsePhoto = null;
			}
			OCX_Logger.debug(LOGGER._1X,"{useSealStep.setBillTypeParam}--设置凭证类型参数结束");
		} else {
			that.log("凭证类型参数配置出错，请检查数据库表信息!");
			OCX_Logger.error(LOGGER._1X,"{useSealStep.setBillTypeParam}--凭证类型参数配置出错，请检查数据库表信息");
		}
		return param;
	}
	
	/**
	 * 授权
	 * 
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.authorize = function(param, callback) {
		that.log("准备授权...");
		OCX_Logger.debug(LOGGER._1X,"{useSealStep.authorize}--准备授权");
		OCX_MachineOrder.setPressboard(1); // 压纸
		// 如果需要授权
		approvalMode = param.approvalMode;
		if(approvalMode && approvalMode!=ussConstants.NOT_NEED_APPROVAL) {
			var paths = [];
			if (endorsePhotoPath != null) {
				paths.push(endorsePhotoPath);
			}
			if (beforePhotoPath != null) {
				paths.push(beforePhotoPath);
			}
			for (var i = 0; i < paths.length; i++) {
				var responseMessage = fileStore.syncUpload(paths[i], sealLog.storeId);
				if (responseMessage.success) {
					sealLog.storeId = responseMessage.storeId; 
					isUploadedBeforePhoto = true;
					WTFileUtil.deleteFile(paths[i]);// 上传成功删除本地文件
				}
			}//end for
			var saveType = Utils.options2(approvalMode, ussConstants.REMOTE_APPROVAL_ONLY, "addLogAndTask", "addLog");
			sealLog = saveSealLog(saveType, "waiting_approval", hasDetectException, "等待用印审批");
			if(sealLog == null || Utils.isEmpty(sealLog.autoId)){
				OCX_Logger.info(LOGGER._1X,"{useSealStep.authorize}--用印申请提交失败,用印日志为不存在或用印日志号不存在");
				callback({success: false, message:"用印申请提交失败"});
			} else {
				if(approvalMode == ussConstants.LOCAL_APPROVAL_ONLY){
					OCX_Logger.debug(LOGGER._1X,"{useSealStep.authorize}--用印申请提交成功,本地审批");
					localApprovalOnly(param, callback);
				} else if(approvalMode == ussConstants.REMOTE_APPROVAL_ONLY){
					OCX_Logger.debug(LOGGER._1X,"{useSealStep.authorize}--用印申请提交成功,远程审批");
					waitAndDealRemoteApproval(param, callback);
				} else {
					callback({success: true});
				}
			}
			return;
		}
		// 不需要授权直接返回
		OCX_Logger.debug(LOGGER._1X,"{useSealStep.authorize}--授权结束");
		callback({success: true});
	};
	
	/**
	 * 背书拍照
	 * 
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	this.endorsePhoto = function(param, callback) {
		OCX_Logger.debug(LOGGER._1X,"{useSealStep.endorsePhoto}--开始背书拍照");
		// 如果未配置用印前拍照，则把用印前照片删除
		if (param.beforePhoto == null && beforePhotoPath != null) {
			WTFileUtil.deleteFile(beforePhotoPath);// 删除本地文件
			beforePhotoPath = null;
		}
		// 如果不是远程审批，则不需要背书
		if (param.approvalMode != ussConstants.REMOTE_APPROVAL_ONLY) {
			param.endorsePhoto = null;
		}
		if(endorsePhotoPath != null) {
			callback({success: true, message: this.endorsePhotoPath});
			return;
		}
		if (param.endorsePhoto != null) {
			// 背书拍照
			param.endorsePhotoCallback(param, callback, function(_callback) {
				that.log("正在采集背书图像...");
				OCX_Logger.info(LOGGER._1X,"{useSealStep.endorsePhoto}--正在采集背书图像");
				// 打开摄像头
				var retryTimes = photoFailTryTimes;
				that.openCamera(param, function(responseMessage) {
					if(responseMessage.success) {
						// 拍照
						that.photo(param.endorsePhoto, isCut, retryTimes, function(msg) {
							if(msg.success) {
								endorsePhotoPath = param.endorsePhoto;
							}
							_callback(msg);
						});
						OCX_Logger.info(LOGGER._1X,"{useSealStep.endorsePhoto}--采集背书图像成功");
					} else {
						// 打开摄像头失败
						OCX_Logger.error(LOGGER._1X,"{useSealStep.endorsePhoto}--采集背书图 "+param.endorsePhoto+" 失败: " + responseMessage.message );
						_callback(responseMessage);
					}
				});
			}, function(_callback) {
					that.log("正在采集用印前图像...");
					OCX_Logger.info(LOGGER._1X,"{useSealStep.endorsePhoto}--正在采集用印前图像");
					// 打开摄像头
					var retryTimes = photoFailTryTimes;
					that.openCamera(param, function(responseMessage) {
						if(responseMessage.success) {
							// 拍照
							that.photo(param.beforePhoto, isCut, retryTimes, function(msg) {
								if(msg.success) {
									beforePhotoPath = param.beforePhoto;
								}
								_callback(msg);
							});
							OCX_Logger.info(LOGGER._1X,"{useSealStep.endorsePhoto}--采集用印前图像成功");
						} else {
							// 打开摄像头失败
							OCX_Logger.error(LOGGER._1X,"{useSealStep.endorsePhoto}--采集用印前图 "+param.beforePhoto+" 失败: " + responseMessage.message );
							_callback(responseMessage);
						}
					});
			});
			OCX_Logger.debug(LOGGER._1X,"{useSealStep.endorsePhoto}--背书拍照结束");
		} else {
			// 不需要背书拍照，直接返回
			OCX_Logger.debug(LOGGER._1X,"{useSealStep.endorsePhoto}--无需背书拍照，流程结束");
			callback({success: true});
		}
	};
	
	// --------------------本地审批 start--------------------------
	/**
	 * 本地审批
	 * 
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	function localApprovalOnly(param, callback){
		that.log("正在等待审核结果，请稍候....");
		OCX_Logger.debug(LOGGER._1X,"{useSealStep.localApprovalOnly}--正在等待审核结果，请稍候...");
		try{
			var operAuth = new top.OperAuth();
			operAuth.operType = "applyUseMechSeal"; // 权限
			operAuth.authSuccess = function(peopleCode) {
				if(Utils.isNotEmpty(peopleCode)) {
					localApprovalPeopleCode = peopleCode;
					var sealStatus = Utils.options1(hasDetectException, "exe_before_video", "waiting_use");
					var memo 	   = Utils.options1(hasDetectException, "发现凭证异常,取消用印", "准备开始用印");
					saveSealLog("updateLog", sealStatus, hasDetectException, memo);
					OCX_Logger.debug(LOGGER._1X,"{useSealStep.localApprovalOnly}--审核通过");
					callback({success:true});
				} else {
					OCX_Logger.error(LOGGER._1X,"{useSealStep.localApprovalOnly}--审核失败，取消用印：前台授权方式配置错误，请联系技术人员!");
					refuseUseSeal("updateLog","cancel","前台授权方式配置错误，请联系技术人员!", param, callback);
				}
			};
			operAuth.authCancel = function() {
				OCX_Logger.info(LOGGER._1X,"{useSealStep.localApprovalOnly}--用印申请未通过现场审核，取消用印");
				refuseUseSeal("updateLog","approval_refuse","用印申请未通过现场审核", param, callback);
			};
			operAuth.auth();
		}catch(e){
			OCX_Logger.error(LOGGER._1X,"{useSealStep.localApprovalOnly}--审核异常："+ e.message +"，取消用印");
			refuseUseSeal("addLog","cancel", e.message +"，取消用印", param, callback);
		}
	}
	// --------------------本地审批 end--------------------------
	
	
	// --------------------远程审批 start--------------------------
	/**
	 * 远程审批
	 * 
	 * @Description 等待并处理远程用印申请审批结果
	 * @param param 用印参数
	 * @param callback 回调函数
	 */
	function waitAndDealRemoteApproval(param, callback){
		// 等待审核结果
		remoteApprovalStartTime = new Date().getTime();
		waitRemoteApprovalResult(param, function(responseMessage) {
			// 处理审核结果
			dealRemoteApprovalResult(param, callback,
				responseMessage.hasOwnProperty("approvalTimeout")
				&& responseMessage.approvalTimeout);
		});
	}

	/**
	 * 获取审批结果 循环获取审核结果，直到审核完毕
	 * 
	 * @param param
	 *            用印参数
	 * @param callback
	 *            回调函数
	 */

	function waitRemoteApprovalResult(param, callback){
		that.log("正在等待审核结果，请稍候....");
		OCX_Logger.debug(LOGGER._1X,"{useSealStep.waitRemoteApprovalResult}--正在等待审核结果，请稍候");
		if (param.openMaskLayer) {
			param.openMaskLayer(sealLog.autoId, "正在等待审核结果，请稍候....", approvalCancel);
		}
		// 重置审核结果
		remote_approval_result = "waiting_approval";
		var approving = false;
		var result = getApprovalResult();
		if(result.status == "waiting_approval"){
			approving = true;
		}
		if(approving) {
			if((new Date().getTime() - remoteApprovalStartTime > 180000)
				&& approvalCancel(sealLog.autoId, "用印远程审批超时，取消用印")) {
				if (param.closeMaskLayer) {
					param.closeMaskLayer();
				}
				remote_approval_result = "approval_cancel";
				callback({success:false, message:"用印远程审批超时，取消用印", approvalTimeout:true});
				return;
			}
			// 向服务器获取审核结果的请求频率，在此加timeout可缓解服务器的压力，可适当调整timeout时间
			timer["waitRemoteApprovalResultTimer"] = setTimeout(function(){
				 waitRemoteApprovalResult(param, callback);
			},2000);
		} else {
			if (param.closeMaskLayer) {
				param.closeMaskLayer();
			}
			remote_approval_result = result.status;
			if(remote_approval_result == "approval_pass"){
				that.log("审核通过，正在用印....");
				OCX_Logger.debug(LOGGER._1X,"{useSealStep.waitRemoteApprovalResult}--审核通过，正在用印...");
				callback({success:true});
			} else if(remote_approval_result == "approval_refuse") {
				remote_approval_msg = result.memo ? ("，" + result.memo) : "";
				OCX_Logger.info(LOGGER._1X,"{useSealStep.waitRemoteApprovalResult}--用印远程审批未通过" + remote_approval_msg);
				callback({success:false, message:"用印远程审批未通过" + remote_approval_msg});
			} else if(remote_approval_result == "approval_cancel") {
				OCX_Logger.info(LOGGER._1X,"{useSealStep.waitRemoteApprovalResult}--用印远程审批被取消");
				callback({success:false, message:"用印远程审批被取消"});
			} else {
				OCX_Logger.info(LOGGER._1X,"{useSealStep.waitRemoteApprovalResult}--用印远程审批未通过");
				callback({success:false, message:"用印远程审批未通过"});
			}
		}
		OCX_Logger.debug(LOGGER._1X,"{useSealStep.waitRemoteApprovalResult}--获取审核结果结束");
	}

	/**
	 * 处理审核结果
	 * 
	 * @param param
	 *            用印参数
	 * @param callback
	 *            回调函数
	 */
	function dealRemoteApprovalResult(param, callback, approvalTimeout) {
		if(remote_approval_result == "waiting_approval"){
			// 向本地全局变量获取审核结果的请求频率，可适当调整timeou的时间来调节处理审核结果的时间
			timer["dealRemoteApprovalResultTimer"] = setTimeout(function(){
					dealRemoteApprovalResult(param, callback);
				},2000);
		}else{
			if(remote_approval_result == "approval_pass"){
				callback({success:true});
			} else if(remote_approval_result == "approval_refuse") {
				refuseUseSeal("updateLog","approval_refuse","用印远程审批被拒绝" + remote_approval_msg+"，取消用印", param, callback);
			} else if(remote_approval_result == "approval_cancel") {
				// 更正远程审批被取消状态approval_cancel为用印取消cancel
				if (approvalTimeout) {
					refuseUseSeal("updateLog","cancel","用印远程审批超时，取消用印", param, callback);
				} else {
					refuseUseSeal("updateLog","cancel","用印远程审批被取消，取消用印", param, callback);
				}
			} else{
				refuseUseSeal("updateLog","cancel","审核失败:"+remote_approval_result+"，取消用印", param, callback);
			}
		} 
	}
	
	/**
	 * 获取审核的状态
	 * 
	 * @returns 审核状态pass/refuse/approving
	 */
	function getApprovalResult() {
		if(Utils.isEmpty(sealLog.autoId)){
			return "用印申请未生成";
		}
		try{
			var getApprovalRet = Utils.ajax(ctx + "/uss/mech/applyUseSeal!findApprovalResult.action", {"autoId" : sealLog.autoId}).doPost();
			return {status:getApprovalRet.data.webResponseJson.data, memo:getApprovalRet.data.webResponseJson.message};
		}catch(e){
			OCX_Logger.error(LOGGER._1X,"{useSealStep.getApprovalResult}--获取远程审核状态异常(" + sealLog.autoId +")：" + e.message);
			return {status:e.message};
		}
	}
	// --------------------远程审批 end----------------------------
	
	// ------------------------取消远程审批 start----------------------------
	/**
	 * 主动取消远程审批
	 * 
	 * @param autoId
	 *            用印审批autoId
	 * @param memo
	 *            取消远程审批备注
	 */
	function approvalCancel(autoId, memo) {
		memo = memo || "(用印远程审批被取消)";
		var approvalCancelRet = Utils.ajax(ctx + "/uss/mech/approvalUseSeal!approvalCancel.action", 
				{ "autoId" : autoId, "sealMemo":memo}).doPost();
		if (approvalCancelRet.data.state == "exception") {
			OCX_Logger.error(LOGGER._1X,"{useSealStep.approvalCancel}--主动取消远程审批失败(" + autoId + ")：" + approvalCancelRet.data.data);
			//alert(approvalCancelRet.data);
			return approvalCancelRet.data.data;
		} else {
			OCX_Logger.debug(LOGGER._1X,"{useSealStep.approvalCancel}--主动取消远程审批成功(" + autoId + ")");
		}
		return;
	}
	// ------------------------取消远程审批 end----------------------------
	
	
	
	/**
	 * 拒绝用印
	 *
	 * @param saveType addLog:新增；updateLog:更新
	 * @param sealStatus 用印状态
	 * @param msg 拒绝用印信息
	 * @param param
     * @param callback
     */
	function refuseUseSeal(saveType, sealStatus, msg, param, callback){
		try{
			callback = callback || function(){};
			saveSealLog(saveType, sealStatus, hasDetectException, msg);// 保存用印日志
			callback({success:false, message: msg ? msg :("用印审批未通过" + remote_approval_msg + "，取消用印")});
		}catch(e){
			OCX_Logger.error(LOGGER._1X,"{useSealStep.refuseUseSeal}--保存拒绝用印日志异常：" + e.message);
			that.log(e.message);
		}
	}
	
	/**
	 * 保存用印日志
	 * @param saveType					保存类型
	 * @param sealStatus				用印状态
	 * @param hasDetectException		是否有异常
	 * @param memo						备注信息
	 * @param localApprovalPeopleCode	本地审批人peopleCode
	 * @returns
	 */
	function saveSealLog(saveType, sealStatus, hasDetectException, memo) {
		that.log("正在保存用印日志...");
		OCX_Logger.debug(LOGGER._1X,"{useSealStep.saveSealLog}--开始保存用印日志");
		var newSealLog = sealLog.SealStatus(sealStatus).HasDetectException(hasDetectException).Memo(memo)
				.FirstApprovalPeopleCode(localApprovalPeopleCode).ApprovalMode(approvalMode);
		sealLog = sealLogUtils.saveOrUpdateUseSealLog(saveType, newSealLog, false);
		OCX_Logger.info(LOGGER._1X,"{useSealStep.saveSealLog}--保存用印日志结束");
		return sealLog;
	}
	
	this.end = function(param, callback) {
		this.log("用印完成");

		OCX_Logger.info(LOGGER._1X,"{useSealStep.end}--=====================================================================");
		OCX_Logger.info(LOGGER._1X,"{useSealStep.end}--            {useSealStep.start}--用印完成，总耗时(ms): " + watchTimer.diffTime());
		OCX_Logger.info(LOGGER._1X,"{useSealStep.end}--=====================================================================");

		this.clearTimer();
		OCX_MachineOrder.setPressboard(2);
		callback({success: true});
	};
	
	this.log = function(msg) {
		msgHanlder(msg);
	};
	
	this.clearTimer = function() {
		if (timer) {
			$.each(timer, function(i, d) {
				if(d != null) {
					clearTimeout(d);
					timer[i] = null;
				}
			});
		}
		timer = {};
	};
	
	this.beforePhotoOCR = function(param, callback) {
		ocr(param, "before", callback);
	};
	
	this.afterPhotoOCR = function(param, callback) {
		ocr(param, "after", callback);
	};
	
	/**
	 * @param imgState before表示用印前图片;after表示用印后
	 */
	function ocr(param, imgState, callback) {
		if (recognizeSuccess && param.ocrStatus) {
			if (param.ocrArea) {
				var ocrArea = param.ocrArea;
				var billNo = ocrArea.billNo;//凭证号码
				var amount = ocrArea.amount;//金额
				var accountNo = ocrArea.accountNo;//账号
				var applyPersonnel = ocrArea.applyPersonnel;//申请人
				var strImagePath = null;
				var ocrInfoPath = null;
				if (imgState == "before" && beforePhotoPath) {
					strImagePath = beforePhotoPath;
					beforeImgOcr = {
							ocrBN: billNo         ? param.fileRootPath + sealLog.tempStoreId +"_" + imgState + "OcrBN.jpg" : null,//凭证号
							ocrMN: amount         ? param.fileRootPath + sealLog.tempStoreId +"_" + imgState + "OcrMN.jpg" : null,//金额
							ocrAN: accountNo      ? param.fileRootPath + sealLog.tempStoreId +"_" + imgState + "OcrAN.jpg" : null,//账号
							ocrAP: applyPersonnel ? param.fileRootPath + sealLog.tempStoreId +"_" + imgState + "OcrAP.jpg" : null //申请人
					};
					ocrInfoPath = beforeImgOcr;
				} else if (imgState == "after" && afterPhotoPath) {
					strImagePath = afterPhotoPath;
					afterImgOcr = {
							ocrBN: billNo         ? param.fileRootPath + sealLog.tempStoreId +"_" + imgState + "OcrBN.jpg" : null,//凭证号 
							ocrMN: amount         ? param.fileRootPath + sealLog.tempStoreId +"_" + imgState + "OcrMN.jpg" : null,//金额  
							ocrAN: accountNo      ? param.fileRootPath + sealLog.tempStoreId +"_" + imgState + "OcrAN.jpg" : null,//账号  
							ocrAP: applyPersonnel ? param.fileRootPath + sealLog.tempStoreId +"_" + imgState + "OcrAP.jpg" : null //申请人
					};
					ocrInfoPath = afterImgOcr;
				}
				if (strImagePath&&ocrInfoPath) {
					if (billNo) {
						OCX_MachineOrder.getRectImage(strImagePath, ocrInfoPath.ocrBN, billNo.x1, billNo.y1, billNo.x2, billNo.y2);// 凭证号
					}
					if (amount) {
						OCX_MachineOrder.getRectImage(strImagePath, ocrInfoPath.ocrMN, amount.x1, amount.y1, amount.x2, amount.y2);// 金额
					}
					if (accountNo) {
						OCX_MachineOrder.getRectImage(strImagePath, ocrInfoPath.ocrAN, accountNo.x1, accountNo.y1, accountNo.x2, accountNo.y2);// 账号
					}
					if (applyPersonnel) {
						OCX_MachineOrder.getRectImage(strImagePath, ocrInfoPath.ocrAP, applyPersonnel.x1, applyPersonnel.y1, applyPersonnel.x2, applyPersonnel.y2);//申请人
					}
					var uploadError = false;
					for (var ocrPath in ocrInfoPath) {
						if (!ocrPath) {
							continue;
						}
						var tempOcrPath = ocrInfoPath[ocrPath];
						if (tempOcrPath) {
							var responseMessage = fileStore.syncUpload(tempOcrPath, sealLog.storeId);
							if (responseMessage.success) {
								sealLog.storeId = responseMessage.storeId; 
								WTFileUtil.deleteFile(tempOcrPath);// 上传成功删除本地文件
							} else {
								uploadError = true;
								OCX_Logger.error(LOGGER._1X,"{useSealStep.ocr}--" + responseMessage.message +"---" + tempOcrPath);
							}
						}
					}//end for
					if (uploadError) {
						callback({success: false, message:"切片图像文件上传失败"});
					} else {
						callback({success: true});
					}
				}//
			} else {
				OCX_Logger.error(LOGGER._1X,"{useSealStep.ocr}--请配置凭证切片区域");
				callback({success: false, message:"请配置凭证切片区域"});
			}
		}  else {//无需切片
			callback({success: true});
		}
	} 
};
	