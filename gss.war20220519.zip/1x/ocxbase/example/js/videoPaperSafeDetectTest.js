/**
 * 创建于:2015-11-19<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 视频检测控件测试脚本
 *
 * @author huangkunping
 * @version 1.0
 */

/**
 * 页面初始化方法
 */
function init() {
	if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, "../../", "run", 1, 1))
		alert("通用工具类控件初始化失败");
	if (!ocxObject.initOcx(ocxObject.OCX_VideoPaperSafeDetect, document.getElementById("videoDetect"), "../../", "run", 100, 100))
		alert("视频检测控件初始化失败");
}

/**
 * 开始视频检测
 *
 */
function checkVideo() {
	var mode = document.getElementById("mode").value;
	var savePath = document.getElementById("savePath").value;
	var ret = OCX_VideoPaperSafeDetect.startAsfRecord(savePath, 2, detectInitFail, detectResult);
	if (ret.code == "1001") {
		showResult("开启视频检测成功");
	} else {
		showResult("开启视频检测失败");
	}
}

/**
 *	停止检测
 */
function stopCheck() {
	var ret = OCX_VideoPaperSafeDetect.endAsf();
	if (ret.code == "1001") {
		showResult("停止视频检测成功");
	} else {
		showResult("停止视频检测失败");
	}
}


/**
 * 回调函数
 * @param {Object} result
 */
function detectInitFail(result) {
	showResult("视频检测初始化失败[" + result + "]");
}

/**
 * 回调函数
 * @param {Object} result
 */
function detectResult(result) {
	showResult("视频检测发现异常[" + result + "]");
}

/**
 * 图片检测
 */
function checkImage() {
	var img1 = window.document.getElementById("checkImage1").value;
	var img2 = window.document.getElementById("checkImage2").value;
	if (img1 == "" || img2 == "") {
		alert("请先选择要比较的图片");
		return;
	}
	var ret = OCX_VideoPaperSafeDetect.compareFile(img1, img2);
	if (ret.code == "1001") {
		showResult("比较图片成功");
	} else {
		showResult("比较图片失败");
	}
}

/**
 * 获取视频MASK值
 */
function getMask() {
	var maskRet = OCX_VideoPaperSafeDetect.getMaskValue();
	if (maskRet.code == "1001") {
		window.document.getElementById("maskVal").value = maskRet.data;
		showResult("获取Mask值成功。[" + maskRet.data + "]");
	} else {
		showResult("获取Mask值失败");
	}
}

/**
 * 设置视频MASK值
 */
function setMask() {
	var mask = window.document.getElementById("maskVal").value;
	var maskRet = OCX_VideoPaperSafeDetect.setMask(mask);
	if (maskRet.code == "1001") {
		window.document.getElementById("maskVal").value = mask;
		showResult("设置Mask值成功。[" + mask + "]");
	} else {
		showResult("设置Mask值失败");
	}
}

/**
 * 比较文件
 */
function compareFile() {
	var img1 = window.document.getElementById("compareImage1").value;
	var img2 = window.document.getElementById("compareImage2").value;
	if (img1 == "" || img2 == "") {
		alert("请先选择要比较的图片");
		return;
	}
	var compareMaskRet = OCX_VideoPaperSafeDetect.calFileCompareMask(img1, img2);
	if (compareMaskRet.code == "1001") {
		showResult("图片比较成功");
	} else {
		showResult("图片比较成功失败");
	}
}

/**
 * 获取文件MASK值
 */
function getFileMask() {
	var maskRet = OCX_VideoPaperSafeDetect.getFileMaskValue();
	if (maskRet.code == "1001") {
		window.document.getElementById("fileMaskVal").value = maskRet.data;
		showResult("获取文件比较Mask值成功。[" + maskRet.data + "]");
	} else {
		showResult("获取文件比较Mask值失败");
	}
}

/**
 * 设置文件MASK值
 */
function setFileMask() {
	var mask = window.document.getElementById("fileMaskVal").value;
	var maskRet = OCX_VideoPaperSafeDetect.setFileCompareMask(mask);
	if (maskRet.code == "1001") {
		window.document.getElementById("fileMaskVal").value = mask;
		showResult("设置文件比较Mask值成功。[" + mask + "]");
	} else {
		showResult("设置文件比较Mask值失败");
	}
}