
/**
 * G1610控件封装测试
 * 拍照
 * @author huangkunping
 * @version 1.0 
 * @Date 2015-11-19
 */
/**
 * 摄像头开启次数
 * @type {number}
 */
var openCount = 0;
/**
 * 拍照次数
 */
var captureCount = 0;
/**
 * 初始化控件
 */
function init() {
	if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, "../../", "run", 1, 1))
		alert("通用工具类控件初始化失败");
	if (!ocxObject.initOcx(ocxObject.OCX_XUSBVideo, document.getElementById("xUSBVideoView"), "../../", "run", 320, 480))
		alert("拍照控件初始化失败");
	if (!ocxObject.initOcx(ocxObject.OCX_VideoRecorder, document.getElementById("xUSBVideoView"), "../../", "run", 1, 1))
		alert("视频录制控件初始化失败");
	
	var list = getCameras();
	var cameraSelect = window.document.getElementById("cameraIndex");
	for ( var i = 0; i < list.length; ++i) {
		var option = window.document.createElement("option");
		option.setAttribute("value", list[i].index);
		option.innerText = list[i].index + " - " + list[i].name;
		cameraSelect.appendChild(option);
	}
	
	cameraSelect.onchange = function() {
		var resSelect = window.document.getElementById("resolutionInfo");
		var cameraIndex = cameraSelect.value;
		var resList = getResolutions(cameraIndex);
		resSelect.innerHTML = '';
		for ( var i = 0; i < resList.length; ++i) {
			var resOption = window.document.createElement("option")
			resOption.setAttribute("value", resList[i].index);
			resOption.innerText = resList[i].index + "-["
					+ resList[i].format + "]" + resList[i].width + "x"
					+ resList[i].height;
			resSelect.appendChild(resOption);
		}
		if (resList.length > 0) {
			resSelect.options[0].setAttribute("selected", "selected");
		}
	}
	if (list.length > 0) {
		cameraSelect.options[0].setAttribute("selected", "selected");
		cameraSelect.fireEvent("onchange");
	}
}


function startRecord() {
	var resSelect = document.getElementById("resolutionInfo");
	var optionText = resSelect.options[resSelect.value].text;
	if (optionText) {
		resSelect.disabled = true;
		var s1 = optionText.substring(optionText.indexOf("]") + 1);
		var s2 = s1.split("x");
		var width = parseInt(s2[0]);
		var height = parseInt(s2[1]);
		var path = window.document.getElementById("recordPath").value;
	    var name = (new Date()).Format("yyyyMMddhhmmssS");
	    var filename = path + "\\" + name + ".asf";
	    var getVideoCoreRet = OCX_XUSBVideo.getVideoCore();
	    if (getVideoCoreRet.code == "1001") {
	    	var asfRate = document.getElementById("asfRate").value;
	    	try {
	    		if (asfRate) {
	    			asfRate = parseInt(asfRate);
				} else {
					asfRate = 185;
				}
			} catch (e) {
				asfRate = 185;
			}
	    	OCX_VideoRecorder.setVideoParam(width, height, asfRate);
	    	var addVideoSourceRet = OCX_VideoRecorder.addVideoSource(getVideoCoreRet.data, 0, 0, width, height);
	    	if (addVideoSourceRet.code == "1001") {
	    		var startRecordRet = OCX_VideoRecorder.startRecord(filename, 2);
	    		if (startRecordRet.code == "1001") {
	    			showResult("打开录像", "成功");
	    		} else {
	    			showResult("打开录像", "失败3");
	    		}
			} else {
				showResult("打开录像", "失败2");
			}
		} else {
			showResult("打开录像", "失败1");
		}
	} else {
		showResult("分辨率错误", "失败0");
	}
}

function stopRecord() {
	document.getElementById("resolutionInfo").disabled = false;
	var stopRecordRet = OCX_VideoRecorder.stopRecord();
	if (stopRecordRet.code == "1001") {
    	showResult("关闭录像", "成功");
	} else {
		showResult("关闭录像", "失败");
	}
}


function stopAll() {
	document.getElementById("cameraIndex").disabled = false;
	document.getElementById("resolutionInfo").disabled = false;
	var stopRecordRet = OCX_VideoRecorder.stopRecord();
	if (stopRecordRet.code == "1001") {
    	showResult("关闭录像", "成功");
    	var ret = xUSBVideo.closeCamera();
    	if (ret == 0) {
    		showResult("关闭摄像头", "成功");
    	} else {
    		showResult("关闭摄像头", "失败");
    	}
	} else {
		showResult("关闭录像", "失败");
	}
}

/**
 * 关闭摄像头
 */
function closeCamera1() {
	document.getElementById("cameraIndex").disabled = false;
	document.getElementById("resolutionInfo").disabled = false;
	var ret = xUSBVideo.closeCamera();
	if (ret == 0) {
		OCX_Logger.info(LOGGER._1X,"{xVideoRecorderTest.closeCamera1}--第 "+openCount + " 次关闭摄像头成功ret,：" + ret);
		showResult("关闭摄像头", "成功");
	} else {
		OCX_Logger.info(LOGGER._1X,"{xVideoRecorderTest.closeCamera1}--第 "+openCount + " 次关闭摄像头失败,ret：" + ret);
		showResult("关闭摄像头", "失败");
	}
}

/**
 * 打开摄像头
 */
function openCamera1() {
	try {
		captureCount = 0;
		OCX_Logger.info(LOGGER._1X,"{xVideoRecorderTest.openCamera1}--打开摄像头次数: " + (++openCount));
		//type: 0拍照摄像头;1视频检测摄像头;2环境摄像头
		var cameraIndex = document.getElementById("cameraIndex");
		var type = cameraIndex.value;
		var _type = "PHOTO";
		if(type == 0) {
			_type = "PHOTO";
		} else if(type == 1) {
			_type = "VIDEO";
		} else if(type == 2) {
			_type = "ENV";
		}
		var ret = xUSBVideo.openCamera(_type);
		if (ret == 0) {
			cameraIndex.disabled = true;
			OCX_Logger.info(LOGGER._1X,"{xVideoRecorderTest.openCamera1}--第 "+openCount + " 次打开摄像头成功,ret：" + ret);
			showResult("打开摄像头", "成功");
		} else {
			OCX_Logger.info(LOGGER._1X,"{xVideoRecorderTest.openCamera1}--第 "+openCount + " 次打开摄像头失败,ret：" + ret);
			showResult("打开摄像头", ret);
		}
	} catch (e) {
		throw e;
	}
}

/**
 * 拍照
 */
function capture(flag) {
	captureCount++;
	var isChecked = window.document.getElementById("isCut").checked;
	var path = window.document.getElementById("path").value;
    var name = (new Date()).Format("yyyyMMddhhmmssS");
    var filename = path + "\\" + name + ".jpg";
    var src_filename = path + "\\" + name + "_src.jpg";
    var ret = xUSBVideo.captureImage(filename, src_filename, isChecked ? 1 : 0);
    if (ret == 0) {
		try{
			if (flag) {
				window.open("file:///" + filename, "_blank", "", "");
			}
		}catch(e){}
			OCX_Logger.info(LOGGER._1X,"{xVideoRecorderTest.capture}--第 "+openCount + " 次打开摄像头,第 "+captureCount+" 次拍照成功,ret：" + ret +", " + filename);
			showResult("拍照成功", filename);
	} else {
		showResult("拍照失败", "");
		OCX_Logger.info(LOGGER._1X,"{xVideoRecorderTest.capture}--第 "+openCount + " 次打开摄像头,第 "+captureCount+" 次拍照成功,ret：" + ret +", " + filename);
	}
}

/**
 * 获取摄像头信息
 * @returns 摄像头信息数组 
 */
function getCameras() {
	var arr = new Array();
	try {
		var camCountRet = OCX_XUSBVideo.getDevicesCount();//获取摄像头个数
		Utils.checkEquals("1001", camCountRet.code, "获取摄像头个数失败");
		OCX_Logger.debug(LOGGER._1X,"{xUSBVideo.getCameras}-- 摄像头个数:(" + camCountRet.data + ")");
		for (var i = 0; i < camCountRet.data; i++) {
			var device = new Object();
			device.index = i;
			device.name = OCX_XUSBVideo.getDevicesName(i).data; 
			device.videoInfoCount = OCX_XUSBVideo.getVideoInfoCount(i).data;
			arr.push(device);
		}
	} catch(e) {
		showResult("获取摄像头信息失败", e.message);
	}
	return arr;
};

function getResolutions(cameraIndex) {
	var resArray = new Array();
	try {
		var resCount = OCX_XUSBVideo.getVideoInfoCount(cameraIndex).data;
		for (var i = 0; i < resCount; ++i) {
			var res = new Object();
			res.index = i;
			res.width = OCX_XUSBVideo.getVideoInfoWidth(cameraIndex, i).data;
			res.height = OCX_XUSBVideo.getVideoInfoHeight(cameraIndex, i).data;
			res.format = "";
			resArray.push(res);
		};
	} catch (e) {
		showResult("获取摄像头分辨率信息失败", e.message);
	};
	return resArray;
};