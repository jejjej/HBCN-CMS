/**
 * G1610控件封装测试
 * 
 * @author huangkunping
 * @version 1.0 
 * @Date 2015-11-19
 */

function init() {
	if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, "../../", "run", 1, 1))
		alert("通用工具类控件初始化失败");
	if (!ocxObject.initOcx(ocxObject.OCX_MachineOrder, document.body, "../../", "run", 1, 1))
		alert("用印控件初始化失败");
}


/**
 * 初始化设备
 */
function initMachine() {
	var ret = machineOrder.intMachine(function (result) {
		if(result == 0){
			showResult("USB重新连接成功.");
		}else if(result == 1){
			showResult("USB已断开连接，请重新连接.");
		}
	});
	if (ret == 0) {
		showResult("初始化设备成功");
	} else {
		showResult("初始化设备失败", ret);
	}
}


/**
 * 关闭设备
 */
function closeMachine() {
	var ret = machineOrder.closeMachine();
	if (ret == 0) {
		showResult("关闭设备成功");
	} else {
		showResult("关闭设备失败", ret);
	}
}



function updateTime() {
}

/**
 * 开始用印
 */
function startSeal() {
	loopUseSeal(1);
}

/**
 * 停止用印
 */
function stopSeal() {
	var ret = machineOrder.stopSeal();
	if (ret == 0) {
		showResult("停止用印成功");
	} else {
		showResult("停止用印失败", ret);
	}
}

/**
 * 取消用印
 */
function cancleSeal() {
	var ret = machineOrder.cancelSeal();
	if (ret == 0) {
		showResult("取消用印成功");
	} else {
		showResult("取消用印失败", ret);
	}
}

var intervalTime = 100;
function machineTest() {
	var times = parseInt(window.document.getElementById("times").value);
	intervalTime = parseInt(document.getElementById("interval").value);
	if (times > 0 && intervalTime > 0) {
		loopUseSeal(times);
	}
}

function loopUseSeal(times) {
	machineOrder.startUseSeal("990011", 1, function(responseMessage) {
		if (responseMessage.success) {
			OCX_MachineOrder.photoFinishReply();//拍照回应
			OCX_MachineOrder.recordSuccess();//清除日志回应
			showResult("用印成功");
			times = times - 1;
			if (times > 0) {
				setTimeout(function(){loopUseSeal(times);}, intervalTime) ;
			}
		} else {
			showResult("用印失败", responseMessage.message);
		}
	});
}



/**
 * 清除日志
 */
function clearLog() {
	window.document.getElementById("result").value = "";
}



