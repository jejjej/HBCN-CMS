/**
 * 创建于: 2015-11-18 <br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司 <br>
 * 小印控机用印控件封装
 * 
 * @author HuangKunping
 * @version 1.0
 */

/**
 * 定义印控机控件封装对象
 */
var machineOrder = new Object();

var iniPath = function() {
	machineOrder.iniPath = (top.yzjgssRootPath || "C:") + "/yzjgss/config/1x/1x.ini";
};
/**
 * 机器设备初始化
 * 
 * @param {Function}
 *            callBack 回调函数，用于检测设备连接是否断开，USB通讯时有效。 回调参数callBack(state)。 参数说明
 *            state: 0 设备连接，1 设备断开连接
 * 
 * @returns 返回0表示成功，其他表示错误信息
 */
machineOrder.intMachine = function(callBack) {
	var openCommNSuccess = false;// 打开通讯连接标志
	callBack = callBack || function(){};
	try {
		
		function ocx_machineorder::OnDeviceFind() {
			callBack(0);
		}
		function ocx_machineorder::OnDeviceLost() {
			callBack(1);
		}

		// 获取配置文件中的通讯方式
		iniPath();
		var commType = OCX_Tools.readIni(this.iniPath, "MACHINEORDER", "COMMTYPE", "1").data; // 通讯方式,0:串口、1:USB,没有配置时默认为USB
		var com = OCX_Tools.readIni(this.iniPath, "MACHINEORDER", "COM", "1").data; // 读取串口号，没有配置时默认为串口1，当通讯方式为USB时，该配置无效
		OCX_Logger.debug(LOGGER._1X,"{machineOrder.intMachine}-- 读取配置参数：commType:("+commType+"),com:("+com+")");
		if ("1001" != OCX_MachineOrder.setCommType(commType).code) {
			throw new Error("设置通讯方式失败");
		}
		if ("1001" != OCX_MachineOrder.setMachineType(0).code) {
			throw new Error("设置设备类型失败");
		}
		if ("1001" != OCX_MachineOrder.openCom().code) {
			throw new Error("打开通讯连接失败");
		}
		openCommNSuccess = true;// 设置打开通讯连接标志为true
		if ("1001" != OCX_MachineOrder.machineLoginIn().code) {
			throw new Error("设备登录失败");
		}

		return 0;
	} catch (e) {
		if (openCommNSuccess) {
			OCX_MachineOrder.closeCom();// 关闭通讯
		}
		OCX_Logger.error(LOGGER._1X,"{machineOrder.intMachine} -- Exception:[" + e.message + "]");
		return e.message;
	}
};

/**
 * 更新印控机时间
 * 
 * @param {Object}
 *            serverTime { serverYear, 年份(yyyy) serverMonth, 月份(MM) serverDay,
 *            日期(dd) serverHour, 小时(HH) serverMinitus, 分钟 serverSecond 秒}
 * 
 * @returns 返回0表示成功，其他表示错误信息
 */
machineOrder.updateDevTime = function(serverTime) {
	try{
		OCX_Logger.debug(LOGGER._1X,"{machineOrder.updateDevTime}-- 更新印控机时间:[" + serverTime.serverYear+"/"+serverTime.serverMonth+"/"+ serverTime.serverDay+" "+ serverTime.serverHour+":"+serverTime.serverMinitus+":"+serverTime.serverSecond + "]");
		
		if ("1001" != OCX_MachineOrder.setYear(serverTime.serverYear).code) {
			throw new Error("更新设备年份失败");
		}
		if ("1001" != OCX_MachineOrder.setMD(serverTime.serverMonth, serverTime.serverDay).code) {
			throw new Error("更新设备日期失败");
		}
		if ("1001" != OCX_MachineOrder.setTime(serverTime.serverHour, serverTime.serverMinitus, serverTime.serverSecond).code) {
			throw new Error("更新设备时间失败");
		}
		
		return 0;
	} catch (e) {
		OCX_Logger.error(LOGGER._1X,"{machineOrder.updateDevTime} -- Exception:[" + e.message + "]");
		return e.message;
	};
};

/**
 * 关闭设备，关闭通讯
 * 
 * @returns 返回0表示成功，其他表示错误信息
 */
machineOrder.closeMachine = function() {
	if (OCX_MachineOrder.closeCom().code != "1001") {
		OCX_Logger.error(LOGGER._1X,"{machineOrder.closeMachine} -- Exception:[设备关闭失败]");
		return "设备关闭失败";
	}
	return 0;
};

/**
 * 检测纸张，若纸张存在，则返回0，其他的返回异常信息
 */
machineOrder.checkPaper = function() {
	try {
		var hasPaper = OCX_MachineOrder.getPaperSensorStatus().code;// 检测纸张
		if (hasPaper == "9000") { // 检测通讯异常
			throw new Error("设备通讯异常,检测纸张失败");
		} else if (hasPaper == "1036") { // 检测到未放纸
			throw new Error("未检测到纸张");
		}
		return 0;
	} catch (e) {
		OCX_Logger.error(LOGGER._1X,"{machineOrder.checkPaper} -- Exception:[" + e.message + "]");
		return e.message;
	}
}


machineOrder.rotateImage = function(direction, imagePath) {
	switch (direction) {
	case "1":
		// do-nothing
		break;
	case "2":
		OCX_MachineOrder.rotateImage(imagePath, 180);
		break;
	case "3":
		OCX_MachineOrder.rotateImage(imagePath,  90);
		break;
	case "4":
		OCX_MachineOrder.rotateImage(imagePath, -90);
		break;
	default:
		break;
	}
}

/**
 * 设备用印
 */
var queryMachinePosTimer = null;// 查询机械臂位置定时器
var canCancelSeal = false;		// 是否可以取消用印
machineOrder.startUseSeal = function(loginPeople, sealNum, callback) {
	canCancelSeal = false;
	callback = callback || function(){};
	try {
		var checkPaperRet = this.checkPaper();
		if ("0" != checkPaperRet) {
			throw new Error(checkPaperRet);
		}
		if ("1001" != OCX_MachineOrder.setLoginPeople(loginPeople).code) {
			throw new Error("设置用印流水号失败");
		}
		OCX_MachineOrder.sendSealNum(sealNum);// 设置印章编号
		OCX_Logger.debug(LOGGER._1X,"{machineOrder.startUseSeal}-- 开始用印^_^");
		var sealStartRet = OCX_MachineOrder.sealStartForLGAddInfo("0"); // 开始用印
		if (sealStartRet.code == "1017" || sealStartRet.code == "1016") {// 正常1,未拍照201
			canCancelSeal = true;
			if (queryMachinePosTimer) {
				clearTimeout(queryMachinePosTimer);// 清空定时器
			}
			queryMachinePosTimer = window.setTimeout(function() {checkFinish(callback);}, 50); // 开始检测用印是否完成
		} else if (sealStartRet.code == "1014") {// 机器发生过断电重启,101
			throw new Error("设备断电重启");
		} else if (sealStartRet.code == "1015") {
			throw new Error("设备取消用印");
		} else if (sealStartRet.code == "9100") {// 机器故障,102
			throw new Error("设备故障");
		} else {// 通讯异常,0，-1
			throw new Error("设备通讯异常");
		}
	} catch (e) {
		machineOrder.stopSeal();
		OCX_Logger.error(LOGGER._1X,"{machineOrder.startUseSeal} -- Exception:[" + e.message + "]");
		callback({success:false, message:e.message});
	}
}


/**
 * 查询设备盖章是否回到了原点 回到原点后去拍照裁减识别OCR.
 * 
 * @returns
 */
function checkFinish(callback){
	if (queryMachinePosTimer) {
		clearTimeout(queryMachinePosTimer);// 清空定时器
	}
	try {
		var queryMachinePosRet = OCX_MachineOrder.queryMachinePos();
		if ("1001" != queryMachinePosRet.code) {
			throw new Error("设备通讯异常");
		}
		var pos = queryMachinePosRet.data;// 机械臂位置
		if (pos == "306") {
			canCancelSeal = false;
		}
		if(pos == "502" || pos == "504" || pos == "507") {// 机器回到原点正常回应 - 获取图像
			// OCX_MachineOrder.photoFinishReply();//拍照回应
			OCX_Logger.debug(LOGGER._1X,"{machineOrder.checkFinish}-- 机器回到原点。pos:("+pos+")");
			callback({success:true});
		} else if(pos == "300"|| pos == "305" || pos == "500" || pos == "505") {// 断电重启 - 禁止用印
			throw new Error("设备断电重启");
		} else if(pos == "301" || pos == "302" || pos == "304" || pos == "306" || pos == "307" || pos == "501"
			|| pos == "506" || pos == "406" ){// 继续查询是否回到原点
			queryMachinePosTimer = setTimeout(function() {checkFinish(callback);},50);
		} else {// 禁止用印 - 提示异常
			throw new Error("设备通讯异常");
		}
	} catch (e) {
// 		startStopDisabled(true,true);
		OCX_Logger.error(LOGGER._1X,"{machineOrder.checkFinish} -- Exception:[" + e.message + "]");
		callback({success:false, message:e.message});
	}
}

/**
 * 取消用印
 * 
 * @returns 返回0表示成功，其他表示错误信息
 */
machineOrder.cancelSeal = function() {
	var pos = OCX_MachineOrder.queryMachinePos().data;
	if(canCancelSeal || pos == "306") {
		if (OCX_MachineOrder.initialization().code != "1001") {
			OCX_Logger.error(LOGGER._1X,"{machineOrder.cancelSeal} -- Exception:[取消用印失败]");
			return "取消用印失败";
		}
		return 0;
	}
	OCX_Logger.error(LOGGER._1X,"{machineOrder.cancelSeal} --开始下压用印或机器臂往回收时不能取消用印！");
	return "正在用印期间,不可取消用印";
};

/**
 * 停止用印
 * 
 * @returns 返回0表示成功，其他表示错误信息
 */
machineOrder.stopSeal = function() {
	if (OCX_MachineOrder.initialization().code != "1001") {
		OCX_Logger.error(LOGGER._1X,"{machineOrder.stopSeal} -- Exception:[停止用印失败]");
		return "停止用印失败";
	}
	return 0;
};
