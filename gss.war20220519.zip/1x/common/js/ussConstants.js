/**
 * 创建于:2015-11-17<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 印章用印常量
 * 
 * @author HuangKunping
 * @version 1.0.0
 */

//GSS
//是否可以选择非营业机构

var ussConstants = new Object();

/**
 * 机控印章
 */
ussConstants.MECH_SEAL = "mech";

/**
 * 电子印章
 */
ussConstants.ELEC_SEAL = "elec";

/**
 * 用印状态
 */
ussConstants.USE_SEAL_STATUS = {
	"waiting_approval" : "等待用印审批",
	"waiting_use" : "等待用印",//
	"approval_pass" : "审批通过",
	"approval_refuse" : "审批拒绝",
	"approval_cancel" : "审批取消",
	"finish" : "用印完成",//
	"pending" : "挂起未用印",
	"cancel" : "取消用印",//
	"fail" : "用印失败故障",
	"exception" : "用印异常",//
	"undefinded" : "未知状态",
	"exe_before_video" : "用印前异常",//
	"exe_after_video" : "用印后异常"//
};

/**
 * 凭证类型类别
 */
ussConstants.BILL_CATEGORY = {
	"0" : "非重空",
	"1" : "重空"
};

/**
 * 版面识别
 */
ussConstants.OCX_STATUS = {
	"0" : "关闭",
	"1" : "开启"
};

/**
 * 视频检测
 */
ussConstants.VIDEO_DEFECT_STATUS = {
	"0" : "关闭",
	"1" : "开启"
};

/**
 * 背书拍照
 */
ussConstants.ENDORSE_PHOTO_STATUS = {
	"0" : "关闭",
	"1" : "开启"
};

/**
 * 用印拍照模式
 */
ussConstants.CAPTURE_IMAGE_MODULE = {
	"before" : "用印前拍照",
	"after" : "用印后拍照",
	"before+after" : "用印前且用印后拍照"
};

/**
 * 印章编号与印章种类名称对应关系
 * <li>当系统未与印章管理系统对接时起效</li>
 */
ussConstants.SEAL_BIZ_TYPE = {
	"0" : "个人业务专用章",
	"1" : "会记业务专用章",
	"2" : "本票专用章",
	"3" : "汇票专用章",
	"4" : "业务办讫章",
	"5" : "受理凭证章",
	"6" : "结算专用章",
	"7" : "假币鉴定专用章",
	"8" : "票据交换用章",
	"9" : "行政用章",
	"10" : "其他"
};

/**
 * 印章位置与印章编号对应关系
 * <li>当系统未与印章管理系统对接时起效</li>
 */
ussConstants.SEAL_NUM = {
	"1" : "0",
	"2" : "1",
	"3" : "2",
	"4" : "3"
};

// ---------------审批模式------------------------
/**
 * 审批模式参数与名称的对应关系
 */
ussConstants.APPROVAL_BIZ = {
//	"*" : "通用业务",
//	"use_seal" : "印章用印",
	"unload_seal" : "印章卸载"
};

/**
 * 审批模式
 */
ussConstants.NOT_NEED_APPROVAL = "none";
ussConstants.LOCAL_APPROVAL_ONLY = "local";
ussConstants.REMOTE_APPROVAL_ONLY = "remote";

/**
 * 审批模式与名称的对应关系
 */
ussConstants.APPROVAL_MODE = {
	"none" : "无需审批",
	"local" : "仅现场审批",
	"remote" : "仅远程审批"
};

// ---------------------------------------------
//----------------ini文件名定义-----------------

// ---------------副摄像头-----------------------
ussConstants.DEFAULT_ROOT_PATH = top.yzjgssRootPath + "\\yzjgss\\";//本地文件存储的根目录
ussConstants.GSS_1X_INI = ussConstants.DEFAULT_ROOT_PATH + "\\config\\1x\\1x.ini";
ussConstants.DEFAULT_LOG_PATH = ussConstants.DEFAULT_ROOT_PATH  + "log\\1x\\";//本地文件存储的根目录
ussConstants.DEFAULT_USE_SEAL_IMAGE_PATH = ussConstants.DEFAULT_ROOT_PATH + "resources\\1x\\img\\";//本地图像文件存储的目录
ussConstants.DEFAULT_USE_SEAL_VIDEO_PATH = ussConstants.DEFAULT_ROOT_PATH + "resources\\1x\\video\\";//本地视频文件存储的目录
ussConstants.DEFAULT_SINGLE_CAPTRUE_IMAGE_PATH = ussConstants.DEFAULT_ROOT_PATH  + "resources\\1x\\picture\\";//本地单张拍照文件存储的目录
ussConstants.DEFAULT_SINGLE_CAPTRUE_DELAY = 1000;//单张拍照延时
ussConstants.DEFAULT_SINGLE_CAPTRUE_CUT_MODE = 0;//单张拍照裁剪模式


//版面模版路径
ussConstants.DEFAULT_DOC_RECOG_TEMPLATE_PATH = top.yzjgssRootPath + "\\yzjgss\\template\\1x\\版面模板\\版面模板.xml";//默认版面模版位置

/**
 * 视频检测模块与名称的对应关系
 */
ussConstants.DETECT_RESULT_MODULE = {
	"*" : "通用模块",
	"fast_use_seal" : "快速用印",
	"approval_use_seal" : "审批用印"
};

/**
 * 锁章模块装卸操作说明
 */
ussConstants.UNLOAD_SEAL_MODULE_OPERATE_MEMO = {
	"noSealModuleInstallNew" : "印控机无锁章模块，新锁章模块安装",
	"noSealModuleNoInstall" : "印控机无锁章模块，未装新锁章模块",
	"haveSealModuleUpdate" : "印控机有锁章模块，更换新锁章模块",
	"haveSealModuleNoInstallNew" : "印控机有锁章模块，未更换新锁章模块",
	"haveSealModuleUnload" : "印控机有锁章模块，锁章模块卸载"
};

// ---------------------------------------------

// ---------------后台xml参数-------------------
ussConstants.VIDEO_STREAM_SERVER_ADD = "videoStreamServerAddress"; // 视频流服务器地址
ussConstants.INTEGRATION_SWITCH = "integrationSwitch"; // 系统集成开关
ussConstants.ENV_VIDEO_SWITCH = "envVideoSwitch"; // 环境摄像头开关
ussConstants.CHECK_MACHINE_WORKTIME_SWITCH = "checkMachineWorkTimeSwitch"; // 系统是否校验设备工作时间开关
ussConstants.CHECK_USE_SEAL_EXCEPTION_SWITCH = "checkUseSealExceptionSwitch"; // 系统是否检测用印异常弹窗提示开关
// true/false
ussConstants.CHECK_RECENT_USE_SEAL_LOG_SWITCH = "checkRecentUseSealLogSwitch"; // 系统是否检测用印异常弹窗提示开关
// true/false
ussConstants.CHECK_USE_SEAL_SWITCH = "checkUseSealSwitch"; // 系统是否检测印控机用印权限开关
// true/false
ussConstants.CHECK_SEAL_DEVICE_SWITCH = "checkSealDeviceSwitch"; // 系统校验关联的设备是否可用开关
// true/false
// ---------------------------------------------

//检测印控机用印过程中是否检测印控机是否属于当前机构开关 true/false
ussConstants.CHECK_DEVICE_ORG_SWITCH="checkDeviceOrgSwitch";


//打开摄像头之后的延时，默认为1100ms
ussConstants.DEFAULT_OPEN_CAMERA_DELAY = 1100;
//检测空白纸张忽略的像素值，默认为200
ussConstants.DEFAULT_CHECK_BLANK_PAPER_DISCUT = 200;
