/**
 * 申请用印js
 * 
 * @Description 用于福建中行用印
 * @author HuangKunping
 * @Date 2015-09-09
 */

/************************** 全局变量定义 start ************************/
//印章编号对应印章类型 Map<印章位置编号,印章类型对象>
var seal2sealTypes = new Map();
//印章类型对应印章类型 Map<印章类型,印章类型对象>
var sealInfos = new Map();
//凭证列表Map<凭证类型编码, 凭证对象>
var billTypeParams  = new Map();
//登陆用户信息
var loginPeople = top.loginPeopleInfo;
//检测用印定时器（用于检测用户是否按下键）
var checkUseSealTimer = null;
//无需审批权限
var noApproval = false;
var isEndorse  = false;
//服务器时间同步标识
var syncServerTime = false;
//停止用印按钮检测标识
var stopCheckPressedUseSeal = false;
var singleCaptureDelay = ussConstants.DEFAULT_SINGLE_CAPTRUE_DELAY;
var singleCaptureCutMode = ussConstants.DEFAULT_SINGLE_CAPTRUE_CUT_MODE;
var docRecogTemplatePath = ussConstants.DEFAULT_DOC_RECOG_TEMPLATE_PATH;//默认版面模版路径
var isRecognize = false;//判断是否需要版面识别，若是申请单用印则需要版面识别，快速用印不需要版面识别
var applyID = "";// 用印申请单ID
var checkBlankPaperDistcut = 200;//白纸检测忽略的像素值，默认为200
var openCameraDelay = 1100;//打开摄像头后的延时
var useSeal = new SealStep(showMsg);//用印全局变量（单例）
/************************** 全局变量定义 end ************************/

/**
 * 页面初始化，要注意控件初始化顺序，避免控件冲突
 */
function initUseSeal() {
	try {
		initOcx();
		initConfig();
		initMachine();//初始化印控机
		top.beforeLock(window, function() { disconnectMachine();});// 锁屏之前停用设备 
		top.afterUnlock(window, function() { connectMachine();});// 解锁后开始用印
	} catch (e) {
		showMsg(e.message)
	}
}

/*************************************** 开始用印入口 **********************************************/
/**
 * 检查是否按下键<br>
 * 此方法首先被印控机连接connectMachine()方法调用<br>
 * 页面初始化通过"开始用印"按钮触发<br>
 */
function checkPressedUseSeal(){
	Utils.clearTimeouts(checkUseSealTimer);
	if (!stopCheckPressedUseSeal) {
		var result = OCX_MachineOrder.getSealNumber();//获取按键位置信息
		if (result.code == "9000") { // 通讯异常
			machineOrder.stopSeal();
			callback({success:false, message:"通讯异常"});
		} else if (result.code == "1015") {// 取消用印
			machineOrder.stopSeal();
			callback({success:false, message:"取消用印"});
		} else if (result.code == "1014") {// 机器发生过断电重启
			machineOrder.stopSeal();
			callback({success:false, message:"机器发生过断电重启"});
		} else if (result.code == "9100") {// 机器故障
			machineOrder.stopSeal();
			callback({success:false, message:"机器故障"});
		} else if (result.code == "1016") {// 需要拍照确认
			machineOrder.stopSeal();
		} else if (result.code == "1001") { // 检测到机器上用印按钮触发
			//获取设备编号
			var queryMachineSNRet = OCX_MachineOrder.queryMachineSN();
			if (queryMachineSNRet.code != "1001") {
				callback({success:false, message:"获取设备序列号失败"});
				return;
			};
			//获取印章模块编号
			var querySealSNRet = OCX_MachineOrder.querySealSN();
			if (querySealSNRet.code != "1001") {
				callback({success:false, message:"获取印章模块编号失败"});
				return;
			};
			//开始用印入口函数
			startSeal(queryMachineSNRet.data, querySealSNRet.data, result.data, getPagingSealAngle());
			return;
		}
		checkUseSealTimer = setTimeout(checkPressedUseSeal, 50);
	}

}

/**
 * 获取盖骑缝章倾斜角度
 * @returns 缝章倾斜角度
 */
function getPagingSealAngle() {
	return $("#qifgStamp").val();
}

/**
 * 开始用印
 * @param _machineSN	设备编号
 * @param _sealNum	按键位置
 */
function startSeal(machineSN, sealModuleSn, sealNum, pagingSealAngle) {
	var seal = seal2sealTypes.get(sealNum);
	if (!seal) {
		showMsg(sealNum + " 号印章信息不存在");
		OCX_MachineOrder.initialization();
		checkUseSealTimer = setTimeout(function(){checkPressedUseSeal();}, 100);
		return;
	}
	//设置骑缝章角度
	if (Utils.isNotEmpty(pagingSealAngle)) {
		OCX_MachineOrder.setPagingSealAngle(pagingSealAngle);
	}
	//开始用印，调用useSealStep.js
	useSeal.start({
		applyFormId:applyID,//申请单id
		imagePath:ussConstants.DEFAULT_USE_SEAL_IMAGE_PATH,//本地图像存储目录
		videoPath:ussConstants.DEFAULT_USE_SEAL_VIDEO_PATH,//本地视频存储目录
		isRecognize:isRecognize,//是否开启版面识别,若设置为false，则版面识别未开启，并获取默认的凭证类型参数配置（默认凭证类型代码为000）
		peopleCode:loginPeople.peopleCode,//用户编号
		orgNo:loginPeople.orgNo,//机构号
		machineSN:machineSN,//设备编号
		sealNum:sealNum,//印章位置	
		sealModuleSn:sealModuleSn,//锁章模块编号
		sealBizTypeId:seal.sealType, //印章类型
		sealBizTypeName:seal.sealText + seal.sealNumber,//印章名称
		sealSn:seal.sealSn,//印章编号
		noApproval:noApproval,//用印无需审批权限
		isEndorse:isEndorse,//是否存在背书拍照
		recogSuccApproval: Utils.isTrue(GPCache.get(GPCache.USS,"RECOG_SUCC_APPROVAL")),	//	版面识别成功之后是否需要授权,true表示需要无需授权，false表示按照识别的凭证参数用印
		checkBlankPaper:Utils.isTrue(GPCache.get(GPCache.USS,"CHECK_BLANK_PAPER_SWITCH")),//空白纸张检测
		checkBlankPaperDistcut:checkBlankPaperDistcut,//白纸张检测忽略的像素值，默认为200
		openCameraDelay:openCameraDelay,//打开摄像头后的延时ms
		sealInfos:sealInfos,//<印章类型,印章信息>
		billTypeParams:billTypeParams,//<凭证类型代码, 凭证类型信息>
		openMaskLayer:openMaskLayer,//开启等待用印审批遮罩层函数
		closeMaskLayer:closeMaskLayer,//关闭等待用印审批遮罩层函数
		showSealLogCallback:doShowSealLogCallback,//显示日志回调函数
		endorsePhotoCallback:doEndorsePhotoCallback,//背书拍照函数
		recognizeCallback:doRecognizeCallback,//版面识别函数
		callback: callback//用印回调函数
	});
}

/*************************************** 印控机初始化方法 **********************************************/
function initMachine() {
	try {
		// 设备工作时间校验
		Utils.checkEquals("0", smsInterface.checkMachineWorkTime(loginPeople.orgNo), "设备在该工作时间内不可用.");
		showMsg("正在初始化设备...");
		//初始化印控机
		var initRet = machineOrder.intMachine(initMachineCallBack);
		Utils.checkEquals("0", initRet, initRet);
		// 松夹子,释放纸张
		OCX_MachineOrder.setPressboard(2);
		// 同步服务器时间至印控机
		if (!syncServerTime) {
			Utils.checkEquals("0", machineOrder.updateDevTime(ussInterface.getServerTime()), "设备同步服务器时间出错.");
			syncServerTime = true;
		}
		initUseSealInfoParams();//初始化用印参数信息
		if (isRecognize) {
			//设置版面识别参数
			Utils.checkEquals("1001", OCX_DocRecog.setTemplate(docRecogTemplatePath).code, "设置版面识别参数失败.");
		}
		// 检测印控机在当前机构是否可用
		if (GPCache.get(GPCache.USS, "checkDeviceOrgSwitch")) {
			var machineNumRet = OCX_MachineOrder.queryMachineSN();
			Utils.checkEquals("1001", machineNumRet.code, "获取设备编号：出现错误.");
			Utils.checkEquals("0", smsInterface.checkSealMachine(loginPeople.orgNo, machineNumRet.data), "此设备在当前机构下不可用.");
		}
		// 用印日志重传
		Utils.checkConditions(reuploadHistoryLog(showSealLog, function(){
			startStopDisabled(false, true);
			showMsg("设备连接成功");
			// 初始化设备
			OCX_MachineOrder.initialization();
			setTimeout(function() {
				if (top.autoClickUseSeal) {
					$("#startgather").click();
				}
				showMsg("设备等待用印...");
			}, 3000);
		}), "日志重传失败.");
	} catch (e) {
		showMsg(e.message);
	}
}

/**
 * 初始化设备回调函数(usb重新连接/断开时触发事件)
 * @param result 0：重新连接成功，1：断开连接
 */
function initMachineCallBack(result){
	if(useSeal) {
		useSeal.clearTimer();
	}
	if(result == 0){
		showMsg("USB重新连接成功.");
		initMachine();//重新打开串口不成功
	}else if(result == 1){
		Utils.clearTimeouts(checkUseSealTimer);
		closeMaskLayer();//关闭等待用印审批遮罩层
		$("#ChkEndorseImgDLG").dialog("close");//关闭背书对话框
		$("#ChkRecognizeDLG").dialog("close");//关闭版面识别对话框
		startStopDisabled(true,true);
		showMsg("USB已断开连接，请重新连接.");
	}
}


/*************************************** 用印回调函数方法 ********************************************/
/**
 * 用印完成后回调函数
 * @param responseMessage
 */
function callback(responseMessage){
	if(responseMessage.success) {
		showSealLog(responseMessage.sealLog);
		showMsg(responseMessage.message || "用印成功。设备等待用印...");
		checkPressedUseSeal();
	} else {
		showMsg(responseMessage.message);
		Utils.clearTimeouts(checkUseSealTimer);
		var delayTimeMs = 50;
		var sealNum = OCX_MachineOrder.getSealNumber().data;
		if(sealNum > 0 && sealNum < 9) {
			OCX_MachineOrder.initialization();//清除按键
			delayTimeMs = 100;
		}
		checkUseSealTimer = setTimeout(function(){checkPressedUseSeal();}, delayTimeMs);
	}
}

/**
 * 日志显示回调函数
 * @param responseMessage
 */
function doShowSealLogCallback(responseMessage) {
	if(responseMessage.success) {
		showSealLog(responseMessage.sealLog);
	}
}


/*************************************** 日志重传函数方法 ********************************************/
/**
 * 日志重传
 * @param showFunc 回调函数，用于更新页面的显示值
 * @param callback 回调函数，用于日志重传完毕之后回调处理
 * @returns {Boolean} true/false 成功/失败
 */
function reuploadHistoryLog(showFunc, callback) {
	try{
		OCX_MachineOrder.photoFinishReply();
		var url = ctx + "/uss/log/useSealLog!saveUseSealHistoryLog.action";
		sealLogUtils.uploadUseSealHistoryLog(url, false, showFunc, callback);
		return true;
	} catch(e) {
		Utils.handleExceptions("用印日志重传出现错误，错误信息为：" + sealLogUtils.getCodeMessage(e.message));
	}
	return false;
}

/************************************* 印控机连接、断开方法 *******************************************/
/**
 * 连接印控机
 */
function connectMachine(){
	stopCheckPressedUseSeal = false;
	// 检测是否有按键
	checkPressedUseSeal();
	// 历史用印日志重新传
	reuploadHistoryLog(showSealLog);
	// 设置开始用印按钮不可用
	startStopDisabled(true,false);
}

/**
 * 与印控机断开连接
 */
function disconnectMachine() {
	Utils.clearTimeouts(checkUseSealTimer);
	if(machineOrder.stopSeal() != "0"){//停止用印
		showMsg("停止用印异常");
	}
	stopCheckPressedUseSeal = true;
	// 此timeout用于延时释放按钮，等待设备归位
	setTimeout(function(){
		showMsg("设备停止用印.");
		startStopDisabled(false,true);
	},5000);
}


/**
 * 初始化控件
 */
function initOcx() {
	// 1.初始化通用控件(日志/写本地xml/设置分辨率/获取MAC与IP)
	Utils.checkConditions(ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, ctx+'/activex/api/', 'run', 1, 1), "初始化通用控件失败");
	// 2.初始印控机控件
	Utils.checkConditions(ocxObject.initOcx(ocxObject.OCX_MachineOrder, document.body, ctx+'/activex/api/', 'run', 1, 1), "初始化印控机控件失败");
	// 3.初始化拍照控件
	Utils.checkConditions(ocxObject.initOcx(ocxObject.OCX_XUSBVideo, document.body, ctx+'/activex/api/', 'run', 1, 1), "初始化拍照控件失败");
	// 4.初始化文件上传控件,已经合并到OCX_CommonTool
	// Utils.checkConditions(ocxObject.initOcx(ocxObject.OCX_Libcurl, document.body, ctx+'/activex/api/', 'run', 1, 1), "初始化文件上传控件失败");
	// 5.初始化版面识别控件
	Utils.checkConditions(ocxObject.initOcx(ocxObject.OCX_DocRecog, document.body, ctx+'/activex/api/', 'run', 1, 1), "初始化版面识别控件失败");
	// 6.初始化图像操作控件
	Utils.checkConditions(ocxObject.initOcx(ocxObject.OCX_IProcOperation, document.body, ctx+'/activex/api/', 'run', 1, 1), "初始化图像操作控件失败");
	// 7.初始化白纸检测控件
	Utils.checkConditions(ocxObject.initOcx(ocxObject.OCX_ImageProcess, document.body, ctx+'/activex/api/', 'run', 1, 1), "初始化白纸检测控件失败");
}


/**
 * 初始化配置信息
 */
function initConfig() {
	
	//打开摄像头后延时
	openCameraDelay = OCX_Tools.readIni(ussConstants.GSS_1X_INI, "CONFIG", "OPEN_CAMERA_DELAY", ussConstants.DEFAULT_OPEN_CAMERA_DELAY).data;
	//白纸检测忽略的像素值
	checkBlankPaperDistcut = OCX_Tools.readIni(ussConstants.GSS_1X_INI, "CONFIG", "CHECK_BLANK_PAPER_DISCUT", ussConstants.DEFAULT_CHECK_BLANK_PAPER_DISCUT).data;
	//版面识别模版路径
	docRecogTemplatePath = OCX_Tools.readIni(ussConstants.GSS_1X_INI, "CONFIG", "DOC_RECOG_TEMPLATE_PATH", ussConstants.DEFAULT_DOC_RECOG_TEMPLATE_PATH).data;
	//单张拍照延时
	singleCaptureDelay = OCX_Tools.readIni(ussConstants.GSS_1X_INI, "CONFIG", "SINGLE_CAPTRUE_DELAY", ussConstants.DEFAULT_SINGLE_CAPTRUE_DELAY).data;
	//单张拍照裁剪模式
	singleCaptureCutMode = OCX_Tools.readIni(ussConstants.GSS_1X_INI, "CONFIG", "SINGLE_CAPTRUE_CUT_MODE", ussConstants.DEFAULT_SINGLE_CAPTRUE_CUT_MODE).data;
	//初始化文件夹
	WTFileUtil.createMultiLevelFolder(ussConstants.DEFAULT_LOG_PATH);//本地用印日志路径
	WTFileUtil.createMultiLevelFolder(ussConstants.DEFAULT_USE_SEAL_IMAGE_PATH);//本地用印图像路径
	WTFileUtil.createMultiLevelFolder(ussConstants.DEFAULT_USE_SEAL_VIDEO_PATH);//本地用印视频路径
	WTFileUtil.createMultiLevelFolder(ussConstants.DEFAULT_SINGLE_CAPTRUE_IMAGE_PATH);//单张拍照路径
}

/**
 * 初始化用印信息
 * 
 */
function initUseSealInfoParams() {
	var querySealSNRet = OCX_MachineOrder.querySealSN();
	Utils.checkEquals("1001", querySealSNRet.code, "获取锁章模块编号失败.");
	//根据锁章模块编号获取印章信息
	var sealInfoMsg = "";
	var sealInfosRet = Utils.ajax(ctx + "/sms/base/smsAction_findSealInfoBySealModuleSn.action", {"sealModuleSn":querySealSNRet.data}).doPost();
	if (sealInfosRet.data.responseMessage.success) {
		for (var i = 0, len = sealInfosRet.data.sealInfos.length; i < len; i++) {
			if (sealInfosRet.data.sealInfos[i].processStatus == '38') {//印章状态启用才显示
				var sealInfo = {};
				sealInfo.sealNum = sealInfosRet.data.sealInfos[i].sealNum;
				sealInfo.sealSn = sealInfosRet.data.sealInfos[i].sealSn;
				sealInfo.sealType = sealInfosRet.data.sealInfos[i].sealType;
				sealInfo.sealModuleSn = sealInfosRet.data.sealInfos[i].sealModuleSn;
				sealInfo.sealText = sealInfosRet.data.sealInfos[i].sealText;
				sealInfo.sealNumber = (sealInfosRet.data.sealInfos[i].sealNumber ||"");
				seal2sealTypes.put(sealInfo.sealNum, sealInfo);
				sealInfos.put(sealInfo.sealType, sealInfo);
				sealInfoMsg += (i+1) + "号印章["+ sealInfo.sealText + sealInfo.sealNumber +"]、";
				if (i == len-1) {
					sealInfoMsg =  sealInfoMsg.substring(0, sealInfoMsg.length - 1);
				}
			}
		}
	}
	$("#gatherSealInfo_MSG").text(sealInfoMsg);
	
	//初始化凭证类型列表
	billTypeParams = ussInterface.listBillTypeParams();
	for (var i = 0; i < billTypeParams.keys.length; i++) {
		var val = billTypeParams.data[billTypeParams.keys[i]];
		if (val) {
			if (!isRecognize && val.billCode != "000" &&  val.ocxStatus == 1) {
				isRecognize = true;
			}
			if (!isEndorse && val.endorsePhotoStatus == 1) {
				isEndorse = true;
			}
		}
	}
	
	//查询有无需审批权限
	noApproval = ussInterface.checkNoApprovalUseaSealPower(loginPeople.peopleSid);
}

/*************************************** 关闭浏览器操作 ******************************************/
/**
 * 关闭浏览器前需要的操作
 * 1.重置UseSeal对象useSeal属性
 * 2.关闭印控机
 */
$.onunload(function(){
	top.autoClickUseSeal = false;
	closeMaskLayer(true);//关闭远程审批遮罩层
	if (useSeal) {
		useSeal.clearTimer();
	}
	top._billTypeParam = {
		"before" : false,
		"after" : false,
		"videoDefectStatus" : false,
		"endorsePhotoStatus" : false,
		"ocxStatus" : false,
		"ocrStatus" : false
	};
	machineOrder.closeMachine();// 关闭印控机 
	top.removeLockCalBack(window);	// 注销锁屏方法
	top.removeUnlockCallBack(window);// 注销解锁屏方法
});

/*************************************** 用印信息的打印与记录日志 ******************************************/
/**
 * 信息处理
 * @param type error:异常信息；info:普通信息；debug模式不显示，只记录到日志文件中
 * @param msg 信息
 */
function showMsg(msg){
	$("#gatherSeal_MSG").text(msg);
}


/*************************************** 背书拍照、版面识别对话框 ******************************************/
/**
 * 背书拍照，弹出背书拍照对话框
 * @param param		用印参数
 * @param callback	用印回调函数
 * @param photo		拍照函数
 */
function doEndorsePhotoCallback(param, callback, photo, beforePhoto) {
	$("#ChkEndorseImgDLG").data("param", param).data("photo", photo).data("beforePhoto", beforePhoto).data("callback", callback);
	$("#ChkEndorseImgDLG").dialog("open");
}

/**
 * 版面识别，弹出版面识别对话框
 * @param param		用印参数
 * @param callback	用印回调函数
 * @param photo		版面识别函数
 */
function doRecognizeCallback(param, callback, recognize) {
	$("#ChkRecognizeDLG").data("param", param).data("recognize", recognize).data("callback", callback);
	$("#ChkRecognizeDLG").dialog("open");
}

/*************************************** 用印审批等待遮罩层 ******************************************/
/**
 * 打开遮罩层
 * @param msg 遮罩层对话框显示信息
 */
function openMaskLayer(data, msg, callback) {
	if (!window.parent.document.getElementById("msgMaskDiv")) {
		commonMask.open({data:data, msg:msg}, window.parent.document, callback);
	}
}

/**
 * 关闭遮罩层
 */
function closeMaskLayer(doClick) {
	commonMask.close(window.parent.document, doClick);
}


/*************************************** 追加用印日志 ******************************************/
/**
 * 设置表格内容
 * @param sealLog 用印日志
 */
var record_index = 1;
function showSealLog(sealLog) {
	var tableContent = "<tr id='useSealLog_"+sealLog.autoId+"'>";
	var trContent =
		"<td style='border-left:none;'>" + (sealLog.recordId || "") + "</td>"
		+ "<td>" + sealLog.deviceNum + "</td>"
		+ "<td>" + sealLog.sealModuleSn + "</td>"
		+ "<td>" + sealLog.sealNum + "</td>" 
		+ "<td>" + sealLog.sealBizTypeName + "</td>"
		+ "<td style='display:"+(top._billTypeParam.ocxStatus ? '' : 'none')+";'>" + sealLog.docNo + "</td>"
		+ "<td>" + sealLog.startTime + "</td>"
		+ "<td>" + (ussConstants.USE_SEAL_STATUS[sealLog.sealStatus]||"") + "</td>";
	if (null == sealLog.storeId || sealLog.storeId == "") {
		trContent += "<td style='display:"+(top._billTypeParam.before ? '' : 'none')+";'>无图像</td>";//用印前图像
		trContent += "<td style='display:"+(top._billTypeParam.after ? '' : 'none')+";'>无图像</td>";//用印后图像
		trContent += "<td style='display:"+(top._billTypeParam.videoDefectStatus ? '' : 'none')+";'>无视频</td>";//用印视频
		
		if (top._billTypeParam.ocrStatus) {
			trContent += "<td >无图像</td>";//用印后图像
			trContent += "<td >无图像</td>";//用印后图像
			trContent += "<td >无图像</td>";//用印后图像
			trContent += "<td >无图像</td>";//用印后图像
			trContent += "<td >无图像</td>";//用印后图像
			trContent += "<td >无图像</td>";//用印后图像
			trContent += "<td >无图像</td>";//用印后图像
			trContent += "<td >无图像</td>";//用印后图像
		}
		
	} else {
			var mediatype2Images = new Map();
			var docObjects = null;
			try {
				docObjects = fileStore.syncDownload(sealLog.storeId);
				if (docObjects != null && docObjects.length != 0) {
					for ( var i = 0; i < docObjects.length; i++) {
						mediatype2Images.put(docObjects[i].propertyList.mediatype, docObjects[i].fileUrl);
					}
				}
			} catch (e) {}
			if (mediatype2Images.get("before")) {
				trContent = trContent + "<td style='display:"+(top._billTypeParam.before ? '' : 'none')+";'><img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;'"
				+ " alt='用印图像'   title='用印图像'  onclick=\"window.parent.viewImage('" + mediatype2Images.get("before") + "');\"/></td>";
			} else {
				trContent += "<td style='display:"+(top._billTypeParam.before ? '' : 'none')+";'>无图像</td>";//用印前图像
			}
			if (mediatype2Images.get("after")) {
				trContent = trContent + "<td style='display:"+(top._billTypeParam.after ? '' : 'none')+";'><img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;'"
				+ " alt='用印图像'   title='用印图像'  onclick=\"window.parent.viewImage('" + mediatype2Images.get("after") + "');\"/></td>";
			} else {
				trContent += "<td style='display:"+(top._billTypeParam.after ? '' : 'none')+";'>无图像</td>";//用印后图像
			}
			if (mediatype2Images.get("video")) {
				trContent = trContent + "<td style='display:"+(top._billTypeParam.videoDefectStatus ? '' : 'none')+";'><img src='" + ctx + "/gss/common/images/gss/play.png' style='cursor:pointer;margin-left:3px;' " 
				+ "alt='用印视频'  title='用印视频'   onclick=\"window.parent.viewVideo('"+ mediatype2Images.get("video") + "');\"/></td>";
			} else {
				trContent += "<td style='display:"+(top._billTypeParam.videoDefectStatus ? '' : 'none')+";'>无视频</td>";//用印视频
			}
			if (top._billTypeParam.ocrStatus) {
				if (mediatype2Images.get("beforeOcrBN")) {
					trContent = trContent + "<td ><img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;'"
					+ " alt='凭证号1'   title='凭证号1'  onclick=\"window.parent.viewImage2('" + mediatype2Images.get("beforeOcrBN") + "');\"/></td>";
				} else {
					trContent += "<td >无图像</td>";//用印后图像
				}
				
				if (mediatype2Images.get("beforeOcrAN")) {
					trContent = trContent + "<td ><img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;'"
					+ " alt='账号1'   title='账号1'  onclick=\"window.parent.viewImage2('" + mediatype2Images.get("beforeOcrAN") + "');\"/></td>";
				} else {
					trContent += "<td >无图像</td>";//用印后图像
				}
				
				if (mediatype2Images.get("beforeOcrMN")) {
					trContent = trContent + "<td ><img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;'"
					+ " alt='金额1'   title='金额1'  onclick=\"window.parent.viewImage2('" + mediatype2Images.get("beforeOcrMN") + "');\"/></td>";
				} else {
					trContent += "<td >无图像</td>";//用印后图像
				}
				
				if (mediatype2Images.get("beforeOcrAP")) {
					trContent = trContent + "<td ><img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;'"
					+ " alt='申请人1'   title='申请人1'  onclick=\"window.parent.viewImage2('" + mediatype2Images.get("beforeOcrAP") + "');\"/></td>";
				} else {
					trContent += "<td >无图像</td>";//用印后图像
				}
				
				if (mediatype2Images.get("afterOcrBN")) {
					trContent = trContent + "<td ><img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;'"
					+ " alt='凭证号2'   title='凭证号2'  onclick=\"window.parent.viewImage2('" + mediatype2Images.get("afterOcrBN") + "');\"/></td>";
				} else {
					trContent += "<td >无图像</td>";//用印后图像
				}
				if (mediatype2Images.get("afterOcrAN")) {
					trContent = trContent + "<td ><img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;'"
					+ " alt='账号2'   title='账号2'  onclick=\"window.parent.viewImage2('" + mediatype2Images.get("afterOcrAN") + "');\"/></td>";
				} else {
					trContent += "<td >无图像</td>";//用印后图像
				}
				if (mediatype2Images.get("afterOcrMN")) {
					trContent = trContent + "<td ><img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;'"
					+ " alt='金额2'   title='金额2'  onclick=\"window.parent.viewImage2('" + mediatype2Images.get("afterOcrMN") + "');\"/></td>";
				} else {
					trContent += "<td >无图像</td>";//用印后图像
				}
				if (mediatype2Images.get("afterOcrAP")) {
					trContent = trContent + "<td ><img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;'"
					+ " alt='申请人2'   title='申请人2'  onclick=\"window.parent.viewImage2('" + mediatype2Images.get("afterOcrAP") + "');\"/></td>";
				} else {
					trContent += "<td >无图像</td>";//用印后图像
				}
			}
	}
	tableContent =  tableContent + trContent + "</tr>";
	if($("#useSealLog_"+sealLog.autoId).length == 0){
		$("#sealRecordContent_body").prepend(tableContent);
	} else {
		$("#useSealLog_"+sealLog.autoId).html(trContent);
	}
	$("#showSealLogDiv").scrollTop(0);
	record_index++;
}

/********************************************************************************************/


function initPage() {
	initDisplayParam();
	createTableTR();
	$("#ChkEndorseImgDLG").dialog({
			autoOpen : false,
			resizable : false,
			closeOnEscape:false,
			height : $(window).height() - 50, 
			width : $(window).width() - 50,
			modal : true,
			buttons : {
			    "提交": function(){
			    	if($("#paperImgIterm img").length == 0) {
			    		alert("请先拍照");
			    		return;
			    	}
			    	
			    	if(!confirm("请确认您已将凭证背书朝上放置")) {
			    		return;
			    	}
			    	//解决移动纸张导致取消用印，在此操作之前必须要把按键位置保存下，并在此操作之后重新设置用印
			    	OCX_MachineOrder.initialization();
			    	//由于背书翻转，需要重新拍照
			    	$("#ChkEndorseImgDLG").data("beforePhoto")(function(responseMessage) {
						if(responseMessage.success) {
					    	$("#ChkEndorseImgDLG").data("callback")({success:true});
						} else {
							$("#ChkEndorseImgDLG").data("callback")({success:false, message:"用印前拍照失败"});
						}
					    $("#ChkEndorseImgDLG").dialog("close");
					});
				},
				"重拍": function(){
					$("#ChkEndorseImgDLG").data("photo")(function(responseMessage) {
						if(responseMessage.success) {
							$("#paperImgIterm").html("<img style='width:100%;visibility:hidden;' src='" + $("#ChkEndorseImgDLG").data("param").endorsePhoto + "?" + new Date().getTime() + "' onload='adjustImage(this)'></img>");
						} else {
							alert("拍照失败");
						}
					});
				},
			    "取消": function(){
			    	$("#ChkEndorseImgDLG").data("callback")({success:false, message:"人工取消用印"});
			    	$("#ChkEndorseImgDLG").dialog("close");
				}
			},
			close : function() {
				$("#ChkEndorseImgDLG").data("param", "").data("photo", "").data("callback", "");
				document.getElementById("paperImgIterm").innerHTML = "<div></div>";
			},
			open : function(){
				$("#paperImgIterm").height($(window).height() - 130);
				$("#ChkEndorseImgDLG").data("photo")(function(responseMessage) {
					if(responseMessage.success) {
						$("#paperImgIterm").html("<img style='width:100%;visibility:hidden;' src='" + $("#ChkEndorseImgDLG").data("param").endorsePhoto + "?" + new Date().getTime() + "' onload='adjustImage(this)'></img>");
					} else {
						alert("拍照失败");
					}
				});
			}
		});
	$("#ChkRecognizeDLG").dialog({
			autoOpen : false,
			resizable : false,
			closeOnEscape:false,
			height : 200, 
			width : 350,
			modal : true,
			buttons : {
			 	"提交授权": {
			 		id:"subApproval",
			 		text:"提交授权",
			 		click:function(){
				    	$("#ChkRecognizeDLG").data("callback")({success:true, endorse:$("#isEndorse")[0].checked});
				    	$("#ChkRecognizeDLG").dialog("close");
					}
			 	},
				"继续识别": {
					id:"recogAgain",
					text:"继续识别",
					click: function() {
					 		$("#recogAgain .ui-button-text").text("正在识别").attr("disabled", true);
							var retryTimes = $("#ChkRecognizeDLG").data("retryTimes") -1;
							var defaultApprovalMode = $("#ChkRecognizeDLG").data("param").defaultApprovalMode;
							if (retryTimes < 1 && defaultApprovalMode 
								&& defaultApprovalMode == ussConstants.REMOTE_APPROVAL_ONLY) {
								$("#subApproval").show();
								if($("#ChkRecognizeDLG").data("param").isEndorse) {
									$("#endorseSpan").show();
								} else {
									$("#isEndorse").attr("checked", false);
									$("#endorseSpan").hide();
								}
							} else {
								$("#ChkRecognizeDLG").data("recognize")(function(responseMessage) {
									if(responseMessage.success) {
										$("#recMsgDiv").html("<span id='recoMsg' style='color: green;font-size: 16px;font-weight:bold;'>版面识别成功...</span>");
										//解决移动纸张导致取消用印，在此操作之前必须要把按键位置保存下，并在此操作之后重新设置用印
										OCX_MachineOrder.initialization();
										$("#ChkRecognizeDLG").data("callback")({success:true});
										$("#ChkRecognizeDLG").dialog("close");
									} else {
										if(responseMessage.message) {
											$("#recoMsg").text(responseMessage.message);
										}
									}
								});
								
							}
					 		setTimeout(function(){
					 			$("#recogAgain .ui-button-text").text("继续识别").attr("disabled", false);
								$("#ChkRecognizeDLG").data("retryTimes", retryTimes);
					 		}, 50);
					}
				},
			    "取消": {
			    	id:"recogCancel",
			    	text:"取消",
			    	click:function(){
				    	$("#ChkRecognizeDLG").data("callback")({success:false, message:"人工取消用印"});
				    	$("#ChkRecognizeDLG").dialog("close");
			    	}
				}
			},
			close : function() {
				$("#ChkRecognizeDLG").data("param", "").data("recognize", "").data("callback", "").data("retryTimes", "");
			},
			open : function(){
			    $("#subApproval").hide();
				$("#ChkRecognizeDLG").data("retryTimes", 3);
				var content = "<div id='recMsgDiv' style='margin-top:30px;margin-left:50px;'>";
				var recognizeMsg = $("#ChkRecognizeDLG").data("param").recognizeMsg;
				if (recognizeMsg) {
					content +="<span id='recoMsg' style='color: red;font-size: 16px;font-weight:bold;'>" + recognizeMsg + "</span>";
				} else {
					content +="<span id='recoMsg' style='color: red;font-size: 16px;font-weight:bold;'>版面识别失败,请重新放置凭证.</span>";
				}
				content +="</div>";
				$("#recognizeIterm").html(content);
			},
			create: function(){
				$("#subApproval").before("<span id='endorseSpan' style='display:none;'><input type='checkbox' id='isEndorse' style='width:auto;'/><span style='font-size: 14px;'>背书拍照</span></span>");
			}
		});
};



/**
 * 调整图片比例
 * @param img
 */
function adjustImage(img) {
	setTimeout(function() {
		if($(img).height() > $("#paperImgIterm").height() - 20) {
			$(img).width("auto").height($("#paperImgIterm").height() - 20);
		}
		$(img).css("visibility", "visible");
	}, 1);
}

/**
 * 初始化页面显示
 */
function initDisplayParam() {
	top._billTypeParam = {
		"before" : false,
		"after" : false,
		"videoDefectStatus" : false,
		"endorsePhotoStatus" : false,
		"ocxStatus" : false,
		"ocrStatus" : false
	};
	var captureImageMode = false;
	billTypeParams = ussInterface.listBillTypeParams();
	for (var i = 0; i < billTypeParams.keys.length; i++) {
		var val = billTypeParams.data[billTypeParams.keys[i]];
		if (val) {
			if (val.billCode != "000") {
				if (!top._billTypeParam.ocxStatus && val.ocxStatus == 1) {
					top._billTypeParam.ocxStatus = true;
				}
				if (!top._billTypeParam.ocrStatus && val.ocrStatus == 1) {
					top._billTypeParam.ocrStatus = true;
				}
			}
			
			if (!captureImageMode && val.captureImageMode == "before+after") {
				top._billTypeParam.before = true;
				top._billTypeParam.after = true;
				captureImageMode = true;
			}
			
			if (!captureImageMode && val.captureImageMode == "before") {
				top._billTypeParam.before = true;
				top._billTypeParam.after = false;
				captureImageMode = true;
			}
			
			if (!captureImageMode && val.captureImageMode == "after") {
				top._billTypeParam.before = false;
				top._billTypeParam.after = true;
				captureImageMode = true;
			}
			
			if (!top._billTypeParam.endorsePhotoStatus && val.endorsePhotoStatus == 1) {
				top._billTypeParam.endorsePhotoStatus = true;
			}
			
			if (!top._billTypeParam.videoDefectStatus && val.videoDefectStatus == 1) {
				top._billTypeParam.videoDefectStatus = true;
			}
		}
	}
}

/**
 * 显示table 的TR
 * @param trId
 */
function createTableTR(trId) {
	var trContent = "<td style='width:50px;background: #c5d6e8;border-top:none;border-left:none;'>序号</td>"					
	+ "<td style='width:80px;background: #c5d6e8;border-top:none;'>设备编号</td>"
	+ "<td style='width:80px;background: #c5d6e8;border-top:none;'>锁章模块编号</td>"
	+ "<td style='width:55px;background: #c5d6e8;border-top:none;'>印章位置</td>"
	+ "<td style='width:180px;background: #c5d6e8;border-top:none;'>印章名称</td>"
	+ "<td style='display:"+(top._billTypeParam.ocxStatus ? '' : 'none')+";width:70px;background: #c5d6e8;border-top:none;'>凭证代码</td>"
	+ "<td style='width:100px;background: #c5d6e8;border-top:none;'>用印时间</td>"
	+ "<td style='width:60px;background: #c5d6e8;border-top:none;'>用印状态</td>"
	+ "<td style='display:"+(top._billTypeParam.before ? '' : 'none')+";width:65px;background: #c5d6e8;border-top:none;border-right:none;'>用印前图像</td>"
	+ "<td style='display:"+(top._billTypeParam.after ? '' : 'none')+";width:65px;background: #c5d6e8;border-top:none;border-right:none;'>用印后图像</td>"
	+ "<td style='display:"+(top._billTypeParam.videoDefectStatus ? '' : 'none')+";width:55px;background: #c5d6e8;border-top:none;border-right:none;'>用印视频</td>" 
	+ "<td style='display:"+(top._billTypeParam.ocrStatus ? '' : 'none')+";width:30px;background: #c5d6e8;border-top:none;border-right:none;'>凭证号1</td>"
	+ "<td style='display:"+(top._billTypeParam.ocrStatus ? '' : 'none')+";width:30px;background: #c5d6e8;border-top:none;border-right:none;'>账号1</td>"
	+ "<td style='display:"+(top._billTypeParam.ocrStatus ? '' : 'none')+";width:30px;background: #c5d6e8;border-top:none;border-right:none;'>金额1</td>"
	+ "<td style='display:"+(top._billTypeParam.ocrStatus ? '' : 'none')+";width:30px;background: #c5d6e8;border-top:none;border-right:none;'>申请人1</td>"
	+ "<td style='display:"+(top._billTypeParam.ocrStatus ? '' : 'none')+";width:30px;background: #c5d6e8;border-top:none;border-right:none;'>凭证号2</td>"
	+ "<td style='display:"+(top._billTypeParam.ocrStatus ? '' : 'none')+";width:30px;background: #c5d6e8;border-top:none;border-right:none;'>账号2</td>"
	+ "<td style='display:"+(top._billTypeParam.ocrStatus ? '' : 'none')+";width:30px;background: #c5d6e8;border-top:none;border-right:none;'>金额2</td>"
	+ "<td style='display:"+(top._billTypeParam.ocrStatus ? '' : 'none')+";width:30px;background: #c5d6e8;border-top:none;border-right:none;'>申请人2</td>";
		
	$("#" + (trId || "sealRecordContentTR")).html(trContent);
}