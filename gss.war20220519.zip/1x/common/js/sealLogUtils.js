/**
 * 创建于:2015-11-20<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 用印日志工具类
 * @author HuangKunping
 * @version 1.0.0
 */
var sealLogUtils = new Object();

/**
 * 日志重传
 * 
 * @param url url
 * @param async 是否异步上传
 * @param showFunc 回调函数，用于更新页面的显示值
 * @param callback 回调函数，用于日志重传完毕之后回调处理
 * @returns sealLog 返回上传的日志
 */
sealLogUtils.uploadUseSealHistoryLog = function(url, async, showFunc, callback) {
	//本地用印图像路径
	var imagePath = OCX_Tools.readIni(ussConstants.GSS_1X_INI, "CONFIG",
			"USE_SEAL_IMAGE_PATH", ussConstants.DEFAULT_USE_SEAL_IMAGE_PATH).data;
	//本地用印视频路径
	var videoPath = OCX_Tools.readIni(ussConstants.GSS_1X_INI, "CONFIG",
			"USE_SEAL_VIDEO_PATH", ussConstants.DEFAULT_USE_SEAL_VIDEO_PATH).data;
	receiveSealHistoryLog();//收取历史日志
	function receiveSealHistoryLog() {
		var historyLog = sealLogUtils.getUseSealLogFromMachine();//获取印控机日志
		if (Utils.isNotEmpty(historyLog)) {//设备存在历史日志
			if (Utils.isEmpty(historyLog.autoId)) {
				OCX_MachineOrder.recordSuccess();
				OCX_Logger.info(LOGGER._1X,"{sealLogUtils.receiveSealHistoryLog}--清空印控机用印错误日志.");
			} else {
				if (historyLog.sealStatus == "finish") {
					historyLog.SealStatus("exe_after_video").Memo("用印后异常(日志重传)");
				}
				// 上传用印日志
				var saveLog = sealLogUtils.saveUseSealLog(url, historyLog, async);
				if (saveLog !=null) {
					// 日志保存成功后清除印控机内部的用印日志
					OCX_MachineOrder.recordSuccess();
					OCX_Logger.info(LOGGER._1X,"{sealLogUtils.receiveSealHistoryLog}--清空印控机用印日志.recordId=["+saveLog.recordId+"]");
					if (showFunc) {
						showFunc(saveLog);
					}
				}
			}
			setTimeout(receiveSealHistoryLog, 100);
		} else {//设备无日志
			upload(imagePath);//上传图像目录文件
			if (imagePath != videoPath) {//若图像目录与视频目录不相同时，则把视频目录的文件上传
				upload(videoPath);
			}
			if (callback) {//历史日志重传完毕之后回调处理
				callback();
			}
		}
	};
};

/**
 * 上传给定的目录的所有文件
 * @param fileDir 文件目录
 */
function upload(fileDir) {
	var filePaths = WTFileUtil.listFolder(fileDir);
	for (var i = 0; i < filePaths.length; i++) {
		OCX_Logger.debug(LOGGER._1X,"{sealLogUtils.upload}--上传文件的路径为：" + filePaths[i].Path);
		var responseMessage = fileStore.syncUpload(filePaths[i].Path);
		if (responseMessage.success) {
			WTFileUtil.deleteFile(filePaths[i].Path);
		}
	}
}

/**
 * 从印控机中获取用印日志
 * 
 * @returns 如果没有返回null，否则返回用印日志对象
 */
sealLogUtils.getUseSealLogFromMachine = function() {
	try {
		var sealRecordRet = OCX_MachineOrder.getSealRecord();
		OCX_Logger.info(LOGGER._1X,"{sealLogUtils.getUseSealLogFromMachine}--印控机用印日志报文：" + sealRecordRet.data );
		if (sealRecordRet.code == "1025") { // 1:正常（没有用印）
			return null;
		} else if (sealRecordRet.code == "1015") {
			//取消用印
		} else if (sealRecordRet.code == "1014") {
			throw new Error('E303');
		} else if (sealRecordRet.code == "9100") {
			throw new Error('E304');
		} else if (sealRecordRet.code == "1005") {
			throw new Error('E305');
		} else if (sealRecordRet.code == "1016") {
			OCX_MachineOrder.photoFinishReply();
			return sealLogUtils.getUseSealLogFromMachine();
		} else if (sealRecordRet.code == "9400") {
			//异常
		} else if (sealRecordRet.code == "1001") {
			if (sealRecordRet.data.length == 68) {//合法的历史日志
				return sealLogUtils.formatMachineLog(sealRecordRet.data);
			} else if(sealRecordRet.data.length > 18 && sealRecordRet.data.length < 68) {//非法历史日志
				OCX_MachineOrder.recordSuccess();
				OCX_Logger.info(LOGGER._1X,"{sealLogUtils.getUseSealLogFromMachine}--清空印控机错误日志：" + sealRecordRet.data );
				return null;
			}
		}
	} catch (e) {
		OCX_Logger.error(LOGGER._1X,"{sealLogUtils.getUseSealLogFromMachine}--获取印控机用印日志异常：" + sealLogUtils.getCodeMessage(e.message) );
	}
	return null;
};

/**
 * 格式化机器日志
 * @param machineLog 机器日志报文
 * @returns sealLog 返回日志对象
 */
sealLogUtils.formatMachineLog = function(machineLog) {
	var recordDate = machineLog.substr( 8, 4) + "-" + machineLog.substr(12, 2) + "-" + machineLog.substr(14, 2);
	var startTime =  machineLog.substr(16, 2) + ":" + machineLog.substr(18, 2) + ":" + machineLog.substr(20, 2);
	var finishTime = machineLog.substr(24, 2) + ":" + machineLog.substr(26, 2) + ":" + machineLog.substr(28, 2);
	var sealStatus = "finish";
	var status = machineLog.substr(31, 1);
	if (status == "1") {
		sealStatus = "finish";
	} else if (status == "2") {
		sealStatus = "pending";
	} else if (status == "3") {
		sealStatus = "cancel";
	} else if (status == "4") {
		sealStatus = "fail";
	} else if (status == "5") {
		sealStatus = "exe_before_video";
	} else {
		OCX_Logger.error(LOGGER._1X,"{sealLogUtils.formatMachineLog}--未定义的用印状态：[" + status + "]" );
		sealStatus = "undefinded";
	}
	return sealLogUtils.createSealLog().RecordId(machineLog.substr(0, 8))
			.StartTime(recordDate + " " +startTime).FinishTime(recordDate + " " +finishTime)
			.SealStatus(sealStatus).SealNum(machineLog.substr(23, 1))
			.SendStatus(machineLog.substr(32, 2)).RecordCount(machineLog.substr(34, 5))
			.AutoId($.trim(machineLog.substr(44, 9))).SealModuleSn(machineLog.substr(53, 12));
};

/**
 * 新增用印日志
 * 
 * @param type addLog:普通用印日志新增；addLogAndTask:工作流任务新增；updateLog:更新
 * @param newLog 用印日志
 * @param async 异步传输标识 true/false
 * 
 * @returns 后台UseSealLog.java格式的用印日志
 */
sealLogUtils.saveOrUpdateUseSealLog = function(type, newLog, async) {
	if (type == "addLog") {
		var url = ctx + "/uss/log/useSealLog!addUseSealLog.action";
		return sealLogUtils.saveUseSealLog(url, newLog, async);
	} else if (type == "addLogAndTask") {
		var url = ctx + "/uss/mech/applyUseSeal!applyUseSeal.action?approvalPeopleCode=" + newLog.firstApprovalPeopleCode;
		return sealLogUtils.saveUseSealLog(url, newLog, async);
	} else if (type == "updateLog") {
		var saveLog = newLog;
		var url = ctx + "/uss/log/useSealLog!updateUseSealLog.action";
		if (newLog.sealStatus == "approval_refuse" || newLog.sealStatus == "cancel"|| newLog.sealStatus == "exe_before_video") {
			newLog.RecordId("未用印").FinishTime("未用印");
			saveLog = sealLogUtils.saveUseSealLog(url, newLog, async);
		} else {
			var retryTimes = 5;//失败尝试次数
			// 获取印控机内部的日志
			var machineLog = sealLogUtils.getUseSealLogFromMachine();
			while (--retryTimes >= 0 && Utils.isEmpty(machineLog)) {
				OCX_Logger.info(LOGGER._1X,"{sealLogUtils.saveOrUpdateUseSealLog}--获取单片机日志失败，剩余尝试次数："+ retryTimes);
				machineLog = sealLogUtils.getUseSealLogFromMachine();
			}
			var mergeLog = sealLogUtils.mergeMachineUseLogAndNewUseLog(machineLog, newLog);
			saveLog = sealLogUtils.saveUseSealLog(url, mergeLog, async);
			var status = saveLog.sealStatus;
			// 日志保存成功后清除印控机内部的用印日志
			if (Utils.isNotEmpty(machineLog) && ("finish" == status || "pending" == status || "cancel" == status || "fail" == status
					|| "exception" == status || "exe_before_video" == status || "exe_after_video" == status)) {
				OCX_MachineOrder.recordSuccess();
				OCX_Logger.info(LOGGER._1X,"{sealLogUtils.saveOrUpdateUseSealLog}--清空印控机用印日志.recordId=["+saveLog.recordId+"]" );
			}
		}
		return saveLog;
	} else {
		OCX_Logger.error(LOGGER._1X,"{sealLogUtils.saveOrUpdateUseSealLog}--日志存储参数错误.." );
	}
};




/**
 * 合并“印控机用印日志”与“新增用印日志”
 * 
 * @param machineLog 印控机用印日志信息
 * @param newLog 外部用印日志
 * 
 * @returns 合并后的用印日志
 */
sealLogUtils.mergeMachineUseLogAndNewUseLog = function(machineLog, newLog) {
	if (Utils.isNotEmpty(machineLog)) {
		var sealStatus = machineLog.sealStatus;
		newLog.RecordId(machineLog.recordId).RecordCount(machineLog.recordCount).SealStatus(sealStatus)
			.SendStatus(machineLog.sendStatus).FinishTime(machineLog.finishTime);
		if(newLog.hasDetectException){//用印出现有异常，判断是用印前还是用印后
			if (sealStatus=="finish") {
				newLog.SealStatus("exe_after_video").Memo("用印后，发现凭证有异常");
			} else {
				newLog.SealStatus("exe_before_video").Memo("用印前，发现凭证有异常，取消用印");
			}
		}
	} else {
		newLog.SealStatus("exe_before_video").RecordId("未用印").FinishTime("未用印").Memo("用印前异常，取消用印");
	}
	return newLog;
};


/**
 * 保存用印日志
 * 
 * @param url 地址
 * @param useSealLog 用印日志对象
 * @param async 异步标识；true:异步；false:同步
 * 
 * @returns 服务器返回的用印日志信息
 */
sealLogUtils.saveUseSealLog = function(url, useSealLog, async) {
	try {
		var data = {
			"useSealLog.autoId" : useSealLog.autoId || "",
			"useSealLog.recordId" : useSealLog.recordId || "",
			"useSealLog.sealMeterialType" : useSealLog.sealMeterialType || "",
			"useSealLog.sealBizTypeId" : useSealLog.sealBizTypeId || "",
			"useSealLog.sealBizTypeName" : useSealLog.sealBizTypeName || "",
			"useSealLog.startTime" : useSealLog.startTime || "",
			"useSealLog.finishTime" : useSealLog.finishTime || "",
			"useSealLog.sealNum" : useSealLog.sealNum || "",
			"useSealLog.sealSn" : useSealLog.sealSn || "",
			"useSealLog.sealModuleSn" : useSealLog.sealModuleSn || "",
			"useSealLog.sealStatus" : useSealLog.sealStatus || "",
			"useSealLog.sendStatus" : useSealLog.sendStatus || "",
			"useSealLog.deviceNum" : useSealLog.deviceNum || "",
			"useSealLog.peopleSid" : useSealLog.peopleSid || "",
			"useSealLog.peopleCode" : useSealLog.peopleCode || "",
			"useSealLog.peopleName" :  useSealLog.peopleName || "",
			"useSealLog.peoplePhoneNo" : useSealLog.peoplePhoneNo || "",
			"useSealLog.orgSid" : useSealLog.orgSid || "",
			"useSealLog.orgNo" : useSealLog.orgNo || "",
			"useSealLog.orgName" : useSealLog.orgName || "",
			"useSealLog.firstApprovalPeopleCode" : useSealLog.firstApprovalPeopleCode || "",
			"useSealLog.firstApprovalPeopleName" : useSealLog.firstApprovalPeopleName || "",
			"useSealLog.secondApprovalPeopleCode" : useSealLog.secondApprovalPeopleCode || "",
			"useSealLog.secondApprovalPeopleName" : useSealLog.secondApprovalPeopleName || "",
			"useSealLog.recordCount" : useSealLog.recordCount || "",
			"useSealLog.storeId" : useSealLog.storeId || "",
			"useSealLog.tempStoreId" : useSealLog.tempStoreId || "",
			"useSealLog.memo" : useSealLog.memo || "",
			"useSealLog.docNo" : useSealLog.docNo || "",
			"useSealLog.docName" : useSealLog.docName || "",
			"useSealLog.approvalMode" : useSealLog.approvalMode || "",
			"useSealLog.applyFormId" : useSealLog.applyFormId || "",
			"useSealLog.operateType" : useSealLog.operateType
		};
		var saveUseSealLogRet = Utils.ajax(url, data).doPost();
		if (saveUseSealLogRet.data.webResponseJson.state == "normal") {// 保存成功
			return sealLogUtils.createSealLog().wrap(saveUseSealLogRet.data.webResponseJson.data);
		} else {//保存失败,抛出异常
			Utils.handleExceptions(saveUseSealLogRet.data.webResponseJson.data);
		}
	} catch (e) {
		throw e;
	}
};


/**
 * 获取返回码信息
 * 
 * @param code
 *            返回码
 * @returns 返回码信息
 */
sealLogUtils.getCodeMessage = function(code) {
	switch (code) {
		case 0:
			return "正常";
		case "E301":
			return "E301:上传历史用印日志异常.";
		case "E302":
			return "E302:获取历史用印日志异常:设备通讯异常,停止用印.";
		case "E303":
			return "E303:获取历史用印日志异常:设备通讯异常.";
		case "E304":
			return "E304:获取历史用印日志异常:设备通讯异常.停止用印.";
		case "E305":
			return "E305:获取历史用印日志异常:设备正在用印中.";
		case "E306":
			return "E306:网络异常,保存用印日志失败.";
		case "E307":
			return "E307:获取历史用印日志异常.";
		case "E500":
			return "E500:网络异常或服务器异常.";
		case "E501":
			return "E501:运行时异常";
		default:
			return code;
	}
};

sealLogUtils.createSealLog = function() {
	function SealLog() {
		this.autoId = "";
		this.recordId = "";
		this.sealMeterialType = "mech";
		this.sealBizTypeId = "";
		this.sealBizTypeName = "";
		this.startTime = "";
		this.finishTime = "";
		this.sealNum = "";
		this.sealSn = "";
		this.sealModuleSn = "";
		this.sealStatus = "";
		this.sendStatus = "";
		this.deviceNum = "";
		this.peopleSid = "";
		this.peopleCode = "";
		this.peopleName = "";
		this.peoplePhoneNo = "";
		this.orgSid = "";
		this.orgNo = "";
		this.orgName = "";
		this.firstApprovalPeopleCode = "";
		this.firstApprovalPeopleName = "";
		this.secondApprovalPeopleCode = "";
		this.secondApprovalPeopleName = "";
		this.recordCount = "";
		this.storeId = "";
		this.tempStoreId = "";
		this.docNo = "";
		this.docName = "";
		this.memo = "";
		this.applyFormId = "";
		this.operateType = "";
		this.hasDetectException = false;
		this.approvalMode = "";
		
		this.AutoId = function(autoId) {
			this.autoId = autoId;
			return this;
		};
		
		this.RecordId = function(recordId) {
			this.recordId = recordId;
			return this;
		};
		
		this.SealMeterialType = function(sealMeterialType) {
			this.sealMeterialType = sealMeterialType;
			return this;
		};
		
		this.SealBizTypeId = function(sealBizTypeId) {
			this.sealBizTypeId = sealBizTypeId;
			return this;
		};
		
		this.SealBizTypeName = function(sealBizTypeName) {
			this.sealBizTypeName = sealBizTypeName;
			return this;
		};
		
		this.StartTime = function(startTime) {
			this.startTime = startTime;
			return this;
		};
		
		this.FinishTime = function(finishTime) {
			this.finishTime = finishTime;
			return this;
		};
		
		
		this.SealNum = function(sealNum) {
			this.sealNum = sealNum;
			return this;
		};
		
		this.SealSn = function(sealSn) {
			this.sealSn = sealSn;
			return this;
		};
		
		this.SealModuleSn = function(sealModuleSn) {
			this.sealModuleSn = sealModuleSn;
			return this;
		};
		this.SealStatus = function(sealStatus) {
			this.sealStatus = sealStatus;
			return this;
		};
		
		this.SendStatus = function(sendStatus) {
			this.sendStatus = sendStatus;
			return this;
		};
		
		this.DeviceNum = function(deviceNum) {
			this.deviceNum = deviceNum;
			return this;
		};
		
		this.PeopleSid = function(peopleSid) {
			this.peopleSid = peopleSid;
			return this;
		};
		
		this.PeopleCode = function(peopleCode) {
			this.peopleCode = peopleCode;
			return this;
		};
		
		this.PeopleName = function(peopleName) {
			this.peopleName = peopleName;
			return this;
		};
		
		this.PeoplePhoneNo = function(peoplePhoneNo) {
			this.peoplePhoneNo = peoplePhoneNo;
			return this;
		};
		
		this.OrgSid = function(orgSid) {
			this.orgSid = orgSid;
			return this;
		};
		
		this.OrgNo = function(orgNo) {
			this.orgNo = orgNo;
			return this;
		};
		
		this.OrgName = function(orgName) {
			this.orgName = orgName;
			return this;
		};
		
		this.FirstApprovalPeopleCode = function(firstApprovalPeopleCode) {
			this.firstApprovalPeopleCode = firstApprovalPeopleCode;
			return this;
		};
		
		this.FirstApprovalPeopleName = function(firstApprovalPeopleName) {
			this.firstApprovalPeopleName = firstApprovalPeopleName;
			return this;
		};
		
		this.SecondApprovalPeopleCode = function(secondApprovalPeopleCode) {
			this.secondApprovalPeopleCode = secondApprovalPeopleCode;
			return this;
		};
		
		this.SecondApprovalPeopleName = function(secondApprovalPeopleName) {
			this.secondApprovalPeopleName = secondApprovalPeopleName;
			return this;
		};
		
		this.RecordCount = function(recordCount) {
			this.recordCount = recordCount;
			return this;
		};
		
		this.StoreId = function(storeId) {
			this.storeId = storeId;
			return this;
		};
		
		this.TempStoreId = function(tempStoreId) {
			this.tempStoreId = tempStoreId;
			return this;
		};
		
		this.DocNo = function(docNo) {
			this.docNo = docNo;
			return this;
		};

		this.DocName = function(docName) {
			this.docName = docName;
			return this;
		};
		
		this.Memo = function(memo) {
			this.memo = memo;
			return this;
		};
		
		this.ApplyFormId = function(applyFormId) {
			this.applyFormId = applyFormId;
			return this;
		};
		
		this.OperateType = function(operateType) {
			this.operateType = operateType;
			return this;
		};
		
		this.HasDetectException = function(hasDetectException) {
			this.hasDetectException = hasDetectException;
			return this;
		};

		this.ApprovalMode = function(approvalMode) {
			this.approvalMode = approvalMode;
			return this;
		};
		
		this.wrap = function (sealLog) {
			if (sealLog) {
				this.autoId = sealLog.autoId || "";
				this.recordId = sealLog.recordId || "";
				this.sealMeterialType = "mech";
				this.sealBizTypeId = sealLog.sealBizTypeId || "";
				this.sealBizTypeName = sealLog.sealBizTypeName || "";
				this.startTime = sealLog.startTime || "";
				this.finishTime = sealLog.finishTime || "";
				this.sealNum = sealLog.sealNum || "";
				this.sealSn = sealLog.sealSn || "";
				this.sealModuleSn = sealLog.sealModuleSn || "";
				this.sealStatus = sealLog.sealStatus || "";
				this.sendStatus = sealLog.sendStatus || "";
				this.deviceNum = sealLog.deviceNum || "";
				this.peopleSid = sealLog.peopleSid || "";
				this.peopleCode = sealLog. peopleCode || "";
				this.peopleName = sealLog.peopleName || "";
				this.peoplePhoneNo = sealLog.peoplePhoneNo || "";
				this.orgSid = sealLog.orgSid || "";
				this.orgNo = sealLog.orgNo || "";
				this.orgName = sealLog.orgName || "";
				this.firstApprovalPeopleCode = sealLog.firstApprovalPeopleCode || "";
				this.firstApprovalPeopleName = sealLog.firstApprovalPeopleName || "";
				this.secondApprovalPeopleCode = sealLog.secondApprovalPeopleCode || "";
				this.secondApprovalPeopleName = sealLog.secondApprovalPeopleName || "";
				this.recordCount = sealLog.recordCount || "";
				this.storeId = sealLog.storeId || "";
				this.tempStoreId = sealLog.tempStoreId || "";
				this.docNo = sealLog.docNo || "";
				this.docName = sealLog.docName || "";
				this.memo = sealLog.memo || "";
				this.applyFormId = sealLog.applyFormId || "";
				this.operateType = sealLog.operateType || "";
				this.hasDetectException = sealLog.hasDetectException || "";
				this.approvalMode = sealLog.approvalMode || "";
			}
			return this;
		}
	}
	return new SealLog();
};
