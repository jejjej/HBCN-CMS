/**
 * 文件上传
 * 
 * @Description fileStore.js采用的是libcurl控件进行文件上传
 * @author HuangKunping
 * @Date 2015-09-09
 */

var fileStore = new Object();
/**
 * 初始化文件上传地址
 */
$(function() {
	try{
		upload_file_url = basePath + "extStore/extStoreAction!saveOrUpdateObject.action";
	}catch(e){}
});


/**
 * 异步上传：单个文件上传，用印图片或视频
 * @param localFilePath 图片本地路径
 * @param storeId 文件存储ID
 * @param callback 文件上传回调函数
 */
fileStore.asyncUpload = function (localFilePath, storeId, callback){
	callback = callback || function() {};
	if (WTFileUtil.fileExists(localFilePath)) {//文件存在才上传
		var param = {"storeId":storeId || "", "async" : true};
		var result = OCX_Libcurl.HttpUpload(upload_file_url, localFilePath, param, function (data, seq, url, file, param) {
			if (data.responseMessage.success) { //成功
				callback({success: true, storeId:data.storeId});
			} else {
				callback({success: false, message:"文件上传失败"});
			}
		});
		if(result.code != "1001"){
			callback({success: false, message:"调用文件上传失败"});
		}
	} else {
		callback({success: false, message:"上传失败，文件不存在"});
	}
}

/**
 * 同步上传：单个文件上传，用印图片或视频
 * @param localFilePath 图片本地路径
 * @param storeId 文件存储ID
 * @returns 对象：{success:true/false, message:"xx", storeId:"xx"}
 */
fileStore.syncUpload = function (localFilePath, storeId) {
	if (WTFileUtil.fileExists(localFilePath)) {//文件存在才上传
		var param = {"storeId":storeId || "", "async" : false};
		var result = OCX_Libcurl.HttpUpload(upload_file_url, localFilePath, param, function () {});
		if (result.responseMessage && result.responseMessage.success) {
			return {success: true, storeId:result.storeId};
		} else {
			return {success: false, message:"文件上传失败"};
		}
	} else {
		return {success: false, message:"上传失败，文件不存在"};
	}
}

/**
 * 下载用印图像（图片/视频）
 * @param storeId 文件存储ID
 * @returns list
 */
fileStore.syncDownload = function (storeId){
	var success = false;
	var urlList = null;
	$.ajax({
		type : "post",
		url : ctx + "/extStore/extStoreAction!findObject.action",
		dataType : "json",
		data: { "storeId" : storeId },
		async : false,
		success : function(response) {
			success = (response.state == "normal");
			urlList = response.data;
		},
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0" || XMLHttpRequest.status != "200") {
				urlList = "网络异常或服务器异常.";
			}
		}
	});
	if(success){
		if(urlList != null){
			return urlList;
		}else{
			throw new Error("无相应文件信息.");
		}
	}else{
		throw new Error(urlList);
	}
};
