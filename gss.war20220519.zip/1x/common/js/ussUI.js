/**
 * 用印通用遮罩层
 * 调用方式：创建遮罩层commonMask.open <br/>
 * 			关闭遮罩层：commonMask.close <br/>
 * @author HuangKunping
 * @version 1.0.0
 */
var commonMask = new Object();
/**
 * 创建遮罩层，对话框
 * @param param	对话框提示内容
 * @param parentView	父页面
 * @param callback	关闭对话框后的回调函数
 */
commonMask.open = function(param, parentView, callback, hideCloseBtn) {
	var strContent = param.msg;
	callback = callback ||function(){};
	hideCloseBtn = hideCloseBtn || false;
	var message = strContent;
	if (!parentView) {
		parentView = document;
	}
	createMask(parentView); // 锁屏
	var strTitle = "提示框";
	var msgw, msgh, bordercolor;
	msgw = 400;// 提示窗口的宽度
	msgh = 100;// 提示窗口的高度
	titleheight = 25; // 提示窗口标题高度
	titlecolor = "#99CCFF";// 提示窗口的标题颜色
	var msgObj = parentView.createElement("div");
	msgObj.setAttribute("id", "msgMaskDiv");
	msgObj.setAttribute("align", "center");
	msgObj.style.background = "white";
	msgObj.style.position = "absolute";
	msgObj.style.left = "55%";
	msgObj.style.top = "50%";
	msgObj.style.font = "12px/1.6em Verdana, Geneva, Arial, Helvetica, sans-serif";
	msgObj.style.marginLeft = "-225px";
	msgObj.style.marginTop = -55 + parentView.documentElement.scrollTop + "px";
	msgObj.style.width = msgw + "px";
	msgObj.style.height = msgh + "px";
	msgObj.style.textAlign = "center";
	msgObj.style.lineHeight = "25px";
	msgObj.style.zIndex = "21";
	var title = parentView.createElement("h4");
	title.setAttribute("id", "msgTitle");
	title.setAttribute("align", "right");
	title.style.margin = "0";
	title.style.padding = "3px";
	title.style.filter = "progid:DXImageTransform.Microsoft.Alpha(startX=20, startY=20, finishX=100, finishY=100,style=1,opacity=75,finishOpacity=100);";
	title.style.opacity = "0.75";
	title.style.height = "18px";
	title.style.font = "12px Verdana, Geneva, Arial, Helvetica, sans-serif";
	title.style.cursor = "pointer";
	title.innerHTML = "<table border='0' width='400px' style='vertical-align:top'><tr style='vertical-align:top'><td align='left'><b>"
			+ strTitle + "</b></td><td align='right' id='closeButton'>"+ (hideCloseBtn ? "" : "关闭") +"&nbsp;</td></tr></table></div>";
	var txt = parentView.createElement("div");
	txt.setAttribute("id", "msgTxtDiv");
	var subContent = strContent;
	var data = param.data || "";
	var msgDataContent ="<input type='hidden' id='msgData' value='"+data+"'>";
	if (strContent.length > 40) { // 提示语过长时只显示前40位
		subContent = strContent.substring(0, 40) + "...";
		subContent += "<a href='javascript:void(0)' style='color:#FF0000' id='showDetail' >详情</a>";
	}
	txt.innerHTML = msgDataContent + "<table style='width:100%'><tr style='vertical-align:top'><td id='msgTxt'>" + subContent + "</td></tr></table>";
	parentView.body.appendChild(msgObj);
	msgObj.appendChild(title);
	msgObj.appendChild(txt);
	parentView.getElementById("closeButton").onblur = function() {
		closeBlur(parentView);

	};
	parentView.getElementById("closeButton").focus();
	parentView.getElementById("closeButton").onclick = function() {
		var _data = parentView.getElementById("msgData").value;
		parentView.getElementById("msgTxt").value="正在处理中,请等待...";
		if (callback && _data) {
			var response = callback(_data);
			if (response) {
				alert(response);
			}
		}
	};
}

function closeBlur(parentView) {
	if (parentView.getElementById("closeButton") != null) {
		parentView.getElementById("closeButton").focus();
	}
}

/**
 * 锁住页面
 * 
 * @param parentView 父页面，也就是需要锁住的页面
 */
function createMask(parentView) {
	if (!parentView) {
		parentView = document;
	}
	var sWidth;
	var sHeight;
	sWidth = parentView.body.scrollWidth;
	sHeight = parentView.body.scrollHeight;
	var bgObj = parentView.createElement("div");
	bgObj.setAttribute('id', 'wfbgDiv');
	bgObj.style.position = "absolute";
	bgObj.style.top = "0";
	bgObj.style.background = "#777";
	bgObj.style.filter = "progid:DXImageTransform.Microsoft.Alpha(style=3,opacity=25,finishOpacity=75";
	bgObj.style.opacity = "0.6";
	bgObj.style.left = "0";
	bgObj.style.width = sWidth + "px";
	bgObj.style.height = sHeight + "px";
	bgObj.style.zIndex = "20";
	parentView.body.appendChild(bgObj);
	if (navigator.userAgent.indexOf("MSIE 6.0") > 0) {
		parentView.body.appendChild(createBgFrame("maskBgFrame", parentView));
	}
}

/**
 * 针对ie6下下拉框不能被div遮住的问题
 * 
 * @param frameId frame的id
 * @returns
 */
function createBgFrame(frameId, parentView) {
	var frame = parentView.createElement("iframe");
	frame.setAttribute('id', frameId);
	frame.style.position = "absolute";
	frame.style.top = "0px";
	frame.style.left = "0px";
	frame.style.filter = "progid:DXImageTransform.Microsoft.Alpha(style=0,opacity=0)";
	frame.style.width = $(window).width() + "px";
	frame.style.height = $(window).height() + "px";
	return frame;
}

/**
 * 关闭弹出框，内部方法
 * @param parentView 父页面
 */
commonMask.close = function(parentView, doClick) {
	if (!parentView) {
		parentView = document;
	}
	var msgMaskDiv = parentView.getElementById("msgMaskDiv");
	if (msgMaskDiv) {
		if (doClick) {
			parentView.getElementById("closeButton").click();
		}
		msgMaskDiv.removeChild(parentView.getElementById("msgTitle"));
		parentView.body.removeChild(parentView.getElementById("msgMaskDiv"));
		releaseScreen(parentView); // 释放屏幕
	}
}

/**
 * 释放页面
 * @param parentView 父页面，也就是需要释放的页面
 */
function releaseScreen(parentView) {
	if (!parentView) {
		parentView = document;
	}
	var bgdiv = parentView.getElementById("wfbgDiv");
	parentView.body.removeChild(bgdiv);
	if (navigator.userAgent.indexOf("MSIE 6.0") > 0) {
		var maskBgFrame = parentView.getElementById("maskBgFrame");
		parentView.body.removeChild(maskBgFrame);
	}
}