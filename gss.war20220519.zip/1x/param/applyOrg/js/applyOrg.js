/**
 * 
 * 创建于:2015-5-19<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 申请机构参数JS
 * 
 * @author 李水野
 * @version 1.0.0
 */

var colNames = [ "申请机构名称", "设置机构", "操作人员", "操作时间", "处理" ];
var colModel = [
		{
			name : "applyOrgName",
			index : "applyOrgName",
			align : "center",
			sortable : false
		},
		{
			name : "targetOrgSid",
			index : "targetOrgSid",
			align : "center",
			sortable : false,
			formatter : "organization"
		},
		{
			name : "peopleCode",
			index : "peopleCode",
			align : "center",
			sortable : false,
			formatter : "getFormatPersonnelByCode"
		},
		{
			name : "operateTime",
			index : "operateTime",
			align : "center",
			sortable : false,
			formatter : function(value, options, rData) {
				return value.replace("T", " ");
			}
		},
		{
			name : "autoId",
			index : "autoId",
			width : 50,
			align : "center",
			formatter : function(value, options, rData) {
				var html = "<div><div class='icon_edit' onclick='showUpdate(\""
						+ value + "\",\"" + rData.applyOrgName
						+ "\")' title='更新' style='float:left'></div>";
				html += "<div class='icon_delete' onclick='del(\"" + value
						+ "\")' title='删除' style='float:left'></div></div>";
				return html;
			}
		} ];

/**
 * 页面初始化
 */
$(function() {
	showList();
	$("#applyOrgAdd").dialog({
		autoOpen : false,
		height : 120,
		width : 560,
		resizable : false,
		modal : true,
		buttons : {
			"确定" : function(event) {
				addApplyOrg();
			},
			"取消" : function() {
				$(this).dialog("close");
			}
		},
		close : function() {
			$("#applyOrgAdd").validationEngine("hideAll");
			$("#applyOrgAdd")[0].reset();
		}
	});

	// 表单验证器
	$("#applyOrgAdd").validationEngine({
		showOnMouseOver : true,
		validationEventTrigger : "keyup blur",
		promptPosition : "centerRight",
		autoPositionUpdate : true,
		onValidationComplete : function() {
		}
	});
	$(":button").button();
	$(":reset").button();

	// 默认数据
	queryApplyOrgForTerm();
});

/**
 * 显示申请机构信息列表
 */
function showList() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2 -8;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 34 - 50 * 2 -5;
	var listUrl = ctx + "/uss/param/applyOrgParamAction_list.action";
	// 审核机构列表
	$("#applyOrglist").jqGrid({
		width : pageContentWidth,
		height : tableHeight + "px",
		url : listUrl,
		multiselect : false,
		rowNum : 20,
		rowList : [ 20, 50, 100 ],
		colNames : colNames,
		colModel : colModel,
		pager : "#applyOrglistpager"
	});
}

function queryApplyOrgForTerm() {
	$("#applyOrglist").jqGrid("search", "#applyOrgIterm");
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo) {
	$("#operateOrg_Item").dialogOrgTree("radio",top.loginPeopleInfo.orgSid,false,null,null,
			function(event, treeId, treeNode) {
				if (treeNode) {
					$("#" + organizationNo + "_Item").val(
							treeNode.organizationName + "("
									+ treeNode.organizationNo + ")");
					$("#" + organizationNo).val(treeNode.sid);
				}
			});
}

/**
 * 显示增加申请机构界面
 */
function showAdd() {
	$("#autoId").val("");
	$("#applyOrgAdd").dialog("open");
}

/**
 * 添加申请机构
 */
function addApplyOrg() {
	if (!$("#applyOrgAdd").validationEngine("validate")) {
		return;
	}
	var url = ctx
			+ "/uss/param/applyOrgParamAction_saveOrUpdateApplyOrgName.action";
	$(event.target).post(url, $("#applyOrgAdd").serializeForm(),
			function(data) {
				if (data.responseMessage.success) {
					// 成功
					$.success("操作成功");
					$("#applyOrglist").trigger("reloadGrid");
					$("#applyOrgAdd").dialog("close");
				} else {
					// 失败
					$.error("操作失败: " + data.responseMessage.message);
				}
			});
}

/**
 * 显示修改申请机构界面
 * 
 * @param autoId
 *            申请机构ID
 * @param orgName
 *            申请机构名称
 */
function showUpdate(autoId, orgName) {
	$("#autoId").val(autoId);
	$("#add_applyOrgName").val(orgName);
	$("#applyOrgAdd").dialog("open");
}

/**
 * 删除申请机构
 * 
 * @param id
 *            申请机构ID
 */
function del(id) {
	var deleteUrl = ctx
			+ "/uss/param/applyOrgParamAction_deleteApplyOrgName.action";
	var deleteParam = {
		"paramApplyOrg.autoId" : id
	};
	if (confirm("确定删除？")) {
		$.post(deleteUrl, deleteParam, function(data) {
			if (data.responseMessage.success) {
				// 成功
				$.success("操作成功");
				$("#applyOrglist").trigger("reloadGrid");
			} else {
				// 失败
				$.error("操作失败: " + data.responseMessage.message);
			}
		});
	}
}
