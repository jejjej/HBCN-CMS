/**
 * 创建于:2015-7-30<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 审批模式参数
 * 
 * @author huangkunping
 * @version 1.0.0
 */
function billTypeParamInit() {
	$("#billTypeParamDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 250,
		width : 550,
		modal : true,
		buttons : {},
		close : function() {
			$("#modifyParamForm").validationEngine("hideAll");
			$("#modifyParamForm")[0].reset();
		}
	});
	
	$("#modifyParamForm").validationEngine({
		showOnMouseOver : true
	});
	
	var integrationSwitch = Boolean(GPCache.get(GPCache.USS,"integrationSwitch")=="true");
	var sealTypeContent = "";
	// 是否与印章管理系统做交互，如果是，则到印章管理系统查询所有印章类型，如果不是，则使用js常量定义中的印章类型
	if (integrationSwitch) {
		delete ussConstants.SEAL_BIZ_TYPE;
		ussConstants.SEAL_BIZ_TYPE = new Object();
		$.ajax({
			type : "POST",
			url : $.getContextPath()
					+ "/sms/config/sealTypeConfig_listAll.action",
			dataType : "json",
			async : false,
			success : function(data) {
				var pageBean = data.pageBean;
				var typeList = pageBean.data;
				for ( var i = 0; i < typeList.length; i++) {
					sealTypeContent += "<option value='"
							+ typeList[i].type + "'>"
							+ typeList[i].name + "</option>";
					ussConstants.SEAL_BIZ_TYPE[typeList[i].type]=typeList[i].name;
				}
				sealTypeContent += "<option value='-1'>全部</option>";
				ussConstants.SEAL_BIZ_TYPE['-1']="全部";

			}
		});
	} else {
		for ( var key in ussConstants.SEAL_BIZ_TYPE) {
			sealTypeContent += "<option value='" + key + "'>"
					+ ussConstants.SEAL_BIZ_TYPE[key] + "</option>";
		}
	}
	
	$("#sealType").html(sealTypeContent);

	var billCategoryContent = "";
	for ( var key in ussConstants.BILL_CATEGORY) {
		billCategoryContent += "<option value='" + key + "'>"
				+ ussConstants.BILL_CATEGORY[key] + "</option>";
	}
	$("#billCategory").html(billCategoryContent);
	
	var videoDefectStatusContent = "";
	for ( var key in ussConstants.VIDEO_DEFECT_STATUS) {
		videoDefectStatusContent += "<option value='" + key + "'>"
				+ ussConstants.VIDEO_DEFECT_STATUS[key] + "</option>";
	}
	$("#videoDefectStatus").html(videoDefectStatusContent);
	
	var ocxStatusContent = "";
	for ( var key in ussConstants.OCX_STATUS) {
		ocxStatusContent += "<option value='" + key + "'>"
				+ ussConstants.OCX_STATUS[key] + "</option>";
	}
	$("#ocxStatus").html(ocxStatusContent);

	var approvalModeContent = "";
	for ( var key in ussConstants.APPROVAL_MODE) {
		approvalModeContent += "<option value='" + key + "'>"
				+ ussConstants.APPROVAL_MODE[key] + "</option>";
	}
	$("#approvalMode").html(approvalModeContent);
	
	var captureImageModeContent = "";
	for ( var key in ussConstants.CAPTURE_IMAGE_MODULE) {
		captureImageModeContent += "<option value='" + key + "'>"
				+ ussConstants.CAPTURE_IMAGE_MODULE[key] + "</option>";
	}
	$("#captureImageMode").html(captureImageModeContent);
	
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight
			+ 6 - 50 * 2;
	$("#billTypeParamsTable").jqGrid(
		{
			width : pageContentWidth,
			height : tableHeight,
			url : ctx
					+ "/uss/param/billTypeParamAction_queryList.action",
			multiselect : false,
			rowNum : 20,
			rowList : [ 20, 50, 100 ],
			colNames : [ "机构号", "凭证类型代码", "凭证类型名称",
					"关联印章类型", "授权模式", "用印拍照模式", "视频检测",/* "版面识别",*/
					 "背书用印", "OCR切片", "操作" ],
			colModel : [
					{
						name : "orgNo",
						index : "orgNo",
						align : "center",
						sortable : false
					},
					{
						name : "billCode",
						index : "billCode",
						align : "center",
						sortable : false
					},
					{
						name : "billName",
						index : "billName",
						align : "center",
						sortable : false
					},
					{
						name : "sealType",
						index : "sealType",
						align : "center",
						sortable : false,
						formatter : formatSealType
					},
					{
						name : "approvalMode",
						index : "approvalMode",
						align : "center",
						sortable : false,
						formatter : formatApprovalMode
					},
					{
						name : "captureImageMode",
						index : "captureImageMode",
						align : "center",
						sortable : false,
						formatter : formatCaptureImageMode
					},
					{
						name : "videoDefectStatus",
						index : "videoDefectStatus",
						align : "center",
						sortable : false,
						formatter : formatVideoDefectStatus
					},
					/*{
						name : "ocxStatus",
						index : "ocxStatus",
						align : "center",
						sortable : false,
						formatter : formatOcxStatus
					},*/
					{
						name : "endorsePhotoStatus",
						index : "endorsePhotoStatus",
						align : "center",
						sortable : false,
						formatter : formatEndorsePhotoStatus
					},
					{
						name : "ocrStatus",
						index : "ocrStatus",
						align : "center",
						sortable : false,
						formatter : formatOcxStatus
					},
					{
						name : "autoId",
						index : "autoId",
						align : "center",
						sortable : false,
						formatter : function(value, options, rData) {
							if (rData.billCode != "000") {
								return "<input type='button'  value='修改' onclick='openModifyDLG("
								+ value
								+ ")'/>&nbsp;<input type='button' value='删除' onclick='deleteParam("
								+ value + ", \""+rData.billCode+"\")'  />";
							} else {
								return "";
							}
						}
					} ],
			pager : "#billTypeParamsTablePager"
		});
}

function formatBillCategory(billCategory) {
	return ussConstants.BILL_CATEGORY[billCategory];
}

function formatVideoDefectStatus(videoDefectStatus) {
	return ussConstants.VIDEO_DEFECT_STATUS[videoDefectStatus];
}

function formatOcxStatus(ocxStatus) {
	return ussConstants.OCX_STATUS[ocxStatus];
}

function formatEndorsePhotoStatus(endorsePhotoStatus) {
	return ussConstants.ENDORSE_PHOTO_STATUS[endorsePhotoStatus];
}

function formatApprovalMode(approvalMode) {
	return ussConstants.APPROVAL_MODE[approvalMode];
}

function formatCaptureImageMode(captureImageMode) {
	return ussConstants.CAPTURE_IMAGE_MODULE[captureImageMode];
}

function formatSealType(sealType) {
	return ussConstants.SEAL_BIZ_TYPE[sealType];
}

function queryList() {
	$("#billTypeParamsTable").jqGrid("search", "#billTypeQueryForm");
}

/**
 * 清空查询条件
 */
function clearbillTypeSearch() {
	$("#billTypeQueryForm")[0].reset(); 
	$("#sealTypeCondition").val(" "); 
}

function openModifyDLG(autoId) {
	$.ajax({
		type : "POST",
		url : $.getContextPath()
				+ "/uss/param/billTypeParamAction_queryOneById.action",
		data : {
			"paramBillType.autoId" : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$("#billAutoId").val(data.paramBillType.autoId);
				$("#orgNoInput").val(data.paramBillType.orgNo);
				$("#billCode").val(data.paramBillType.billCode);
				$("#billName").val(data.paramBillType.billName);
				$("#billDescription").val(data.paramBillType.billDescription);
				$("#billCategory").val(data.paramBillType.billCategory);
				$("#sealType").val(data.paramBillType.sealType);
				$("#videoDefectStatus").val(data.paramBillType.videoDefectStatus);
				$("#captureImageMode").val(data.paramBillType.captureImageMode);
				/*$("#ocxStatus").val(data.paramBillType.ocxStatus);*/
				$("#ocxStatus").val("1");//默认开启版面识别
				$("#ocrStatus").val(data.paramBillType.ocrStatus);
				$("#approvalMode").val(data.paramBillType.approvalMode);
				$("#endorsePhotoStatus").val(data.paramBillType.endorsePhotoStatus);
//				if (data.paramBillType.billCode == "000") {
//					$("#billCode").attr("disabled", "disabled");
//					$("#billName").attr("disabled", "disabled");
//				} else {
//					$("#billCode").removeAttr("disabled");
//					$("#billName").removeAttr("disabled");
//				}
				$("#billTypeParamDLG").dialog("open");
			} else {
				alert("失败:" + data.responseMessage.message);
			}
		}
	})
}

function openAddParamDLG(){
	$("#billTypeParamDLG").dialog("open");
}

function addParam() {
	if (!$("#modifyParamForm").validationEngine("validate")) {
		return;
	}
	if(checkBillTypeParamByBillCode()) {
		alert("凭证类型代码已在选择机构中存在");
		return;
	}
	
//	if ($("#billCode").val() == "000"&&$("#ocxStatus").val()==1) {
//		alert("凭证类型编码为(000)，请将版面识别关闭");
//		return;
//	}
	if ($("#endorsePhotoStatus").val() == 1 && $("#approvalMode").val() != ussConstants.REMOTE_APPROVAL_ONLY) {
		alert("启用背书拍照，请选择远程授权模式");
		return;
	}
	if ($("#captureImageMode").val() == "after" && $("#approvalMode").val() == ussConstants.REMOTE_APPROVAL_ONLY) {
		alert("启用远程授权模式，必须开启用印前拍照");
		return;
	}
	$.ajax({
		type : "POST",
		url : $.getContextPath() + "/uss/param/billTypeParamAction_saveOrUpdateParam.action",
		data : {
			"paramBillType.autoId" : $("#billAutoId").val(),
			"paramBillType.orgNo" : $("#orgNoInput").val(),
			"paramBillType.billCode" : $("#billCode").val(),
			"paramBillType.billName" : $("#billName").val(),
			"paramBillType.billDescription" : $("#billDescription").val(),
			"paramBillType.billCategory" : $("#billCategory").val(),
			"paramBillType.sealType" : $("#sealType").val(),
			"paramBillType.videoDefectStatus" : $("#videoDefectStatus").val(),
			"paramBillType.captureImageMode" : $("#captureImageMode").val(),
			"paramBillType.ocxStatus" : $("#ocxStatus").val(),
			"paramBillType.ocrStatus" : $("#ocrStatus").val(),
			"paramBillType.approvalMode" : $("#approvalMode").val(),
			"paramBillType.endorsePhotoStatus" : $("#endorsePhotoStatus").val()
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$("#billTypeParamDLG").dialog("close");
				queryList();
			} else {
				alert("保存失败:" + data.responseMessage.message);
			}
		}
	});
}

function cancelAdd() {
	$("#modifyParamForm").validationEngine("hideAll");
	$("#billTypeParamDLG").dialog("close");
}

function deleteParam(autoId, billCode) {
	if (billCode == "000") {
		alert("不能删除凭证类型编码为("+billCode+")" );
		return;
	}
	var b = confirm("确定要删除该参数吗？");
	if (b) {
		$.ajax({
			type : "POST",
			url : $.getContextPath() + "/uss/param/billTypeParamAction_deleteParam.action",
			data : {
				"paramBillType.autoId" : autoId
			},
			dataType : "json",
			async : false,
			success : function(data) {
				if (data && data.responseMessage && data.responseMessage.success) {
					$("#billTypeParamDLG").dialog("close");
					queryList();
				} else {
					alert("删除失败:" + data.responseMessage.message);
				}
			}
		});
	}

}

/**
 * 选择查询机构
 */
function choseOrgNoCondition() {
	$("#orgNoCondition").dialogOrgTree("radio",top.loginPeopleInfo.orgSid,false,null,null,
			function(event, treeId, treeNode) {
				if (treeNode) {
					$("#orgNoCondition").val(treeNode.organizationNo);
				}
			});
}
function choseOrgNoInput() {
	$("#orgNoInput").dialogOrgTree("radio",top.loginPeopleInfo.orgSid,false,null,null,
			function(event, treeId, treeNode) {
				if (treeNode) {
					$("#orgNoInput").val(treeNode.organizationNo);
					$("#orgNoInput").blur();
				}
			});
}


function checkBillTypeParamByBillCode(){
	var flag = false;
	var orgNo = $("#orgNoInput").val();
	var billCode = $("#billCode").val();
	if(orgNo!=""&&billCode!="") {
		$.ajax({
			type : "POST",
			url : $.getContextPath() +"/uss/param/billTypeParamAction_checkBillTypeParamByBillCode.action",
			data : {
				"paramBillType.autoId" : $("#billAutoId").val(),
				"paramBillType.orgNo" : orgNo,
				"paramBillType.billCode" : billCode
			}, 
			dataType : "json",
			async : false,
			success : function(data) {
				if (data && data.responseMessage && !data.responseMessage.success) {
					flag = true;
				}
			}
		});
	}
	return flag;
}