var imgMap = {};
var currBillType = "";
function billTypeOcrInit() {
	// 1.初始化通用控件(日志/写本地xml/设置分辨率/获取MAC与IP)
	if(!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, ctx+'/activex/api/', 'run', 1, 1)){
		aler("初始化通用控件失败");
		return;
	}
	// 4.初始化文件上传控件，已合并到OCX_CommonTool
//	if(!ocxObject.initOcx(ocxObject.OCX_Libcurl, document.body, ctx+'/activex/api/', 'run', 1, 1)){
//		alert("初始化文件上传控件失败");
//		return;
//	}
	//分页栏按钮
	$("#list").navGrid("#pager",{edit:false,add:false,del:false,search:false,refresh: true});  
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight
			+ 6 - 50 * 2;
	$("#list").jqGrid({
		width : pageContentWidth,
		height : tableHeight,
		   	url: ctx + "/uss/param/billTypeParamAction_queryListOCR.action",
		   	rownumbers: true,
		   	rowNum: 20,
		   	pager: "#pager",
		    colNames:["凭证类型代码", "凭证类型名字", "ocr区域", "处理"],
		   	colModel:[
					{name:"billCode",index:"billCode", width:80, align:"left"},
					{name:"billName",index:"billName", width:80, align:"left"},
					{name:"ocrArea",index:"ocrArea", width:180, align:"left"},
					{name:"autoId",index:"autoId", width:50, align:"center", 
						formatter : function(value, options, rData){
							var html = "<div><div class='icon_edit' onclick='updateType(\"" + options.rowId + "\")' title='更新' style='float:left'></div>";
			   				return html;
						}
					}
		   	]
		});
	
	//窗口
	$("#billTypeConfig").dialog({
		autoOpen: false,
		height: 510,
		width: 790,
		modal: true,
		buttons: {
			"确定": function(event) {
				var ocrArea = {};
				$("#billTypeConfig :text:enabled").each(function() {
					var name = $(this).attr("name").split("_")[0];
					var pos = $(this).attr("name").split("_")[1];
					if(!ocrArea[name]) {
						ocrArea[name] = {};
					}
					ocrArea[name][pos] = parseInt($(this).val());
				});
				var imgSrc = $("#img").attr("src");
				if (!imgSrc) {
					alert("请选择图片");
					return;
				}
				if (imgSrc.indexOf("http://") !=-1 || imgSrc.indexOf("https://") != -1) {
					$(event.target).post(ctx + "/uss/param/billTypeParamAction_updateBillTypeOcrArea.action",{"paramBillType.autoId": $("#autoId").val(), "paramBillType.ocrArea": JSON.stringify(ocrArea), "paramBillType.ocrImgStoreId": $("#ocrImgStoreId").val()},function(data) {
						if(data.responseMessage.success) {
							//成功
							$.success("操作成功");
							$("#list").trigger("reloadGrid");
							$("#billTypeConfig").dialog("close");
						} else {
							//失败
							$.error("操作失败: " + data.responseMessage.message);
						}
					});
				} else {
					
					var result = OCX_Libcurl.HttpUpload(basePath + "extStore/extStoreAction!saveOrUpdateObject2.action", imgSrc, "", function (data, seq, url, file, param) {
						if (data.responseMessage.success) { //成功
							$("#ocrImgStoreId").val(data.storeId);
							$(event.target).post(ctx + "/uss/param/billTypeParamAction_updateBillTypeOcrArea.action",{"paramBillType.autoId": $("#autoId").val(), "paramBillType.ocrArea": JSON.stringify(ocrArea), "paramBillType.ocrImgStoreId": $("#ocrImgStoreId").val()},function(data) {
								if(data.responseMessage.success) {
									//成功
									$.success("操作成功");
									$("#list").trigger("reloadGrid");
									$("#billTypeConfig").dialog("close");
								} else {
									//失败
									$.error("操作失败: " + data.responseMessage.message);
								}
							}); 
						} else {
							alert("保存图片失败");
						}
					});
					if(result.code != "1001"){
						callback({success: false, message:"上传失败"});
					}
				}
				
		   },
		   "取消": function() {
				$(this).dialog("close");
			}
		},
		close: function() {
			$("#billTypeConfig").validationEngine("hideAll");
			$("#billTypeConfig")[0].reset();
			$("#img").attr("src", "");
			$("#mask").css("background-image", "");
		},
		open: function() {
			$(".ui-widget-overlay").height($(".ui-widget-overlay").height() - 9);
		}
	});
	
	$(":button").button();
	
	$(":checkbox").change(function() {
		if($(this).is(":checked")) {
			$(":text[name*=" + $(this).attr("id") + "]").removeAttr("disabled");
		} else {
			$(":text[name*=" + $(this).attr("id") + "]").attr("disabled", "disabled");
			$("#" + $(this).attr("id") + "div").remove();
			delete boxPos[$(this).attr("id")];
		}
	});
	
	$("#billTypeConfig :text").blur(function() {
		var name = $(this).attr("name").split("_")[0];
		boxType = name;
		$(this).val($(this).val().replace(/\D/g, ""));
		if($(this).val() == "") {
			type = "box";
			delete boxPos[boxType];
			$("#" + boxType + "div").remove();
			return;
		}
		
		var flag = true;
		$(":text[name*=" + name + "]").each(function(i, d) {
			if($(d).val() == "") {
				flag = false;
			}
		});
		
		if(flag && $("#" + name + "div").length == 0) {
			addEl(parseInt($(":text[name=" + name + "_x1]").val()), parseInt($(":text[name=" + name + "_y1]").val()), 
					parseInt($(":text[name=" + name + "_x2]").val()), parseInt($(":text[name=" + name + "_y2]").val()));
		}
	});
	
	$("#billTypeConfig :checkbox").change(function() {
		if($(this).is(":checked")) {
			var name = $(this).attr("name").split("_")[0];
			boxType = name;
			type = "box";
			var flag = true;
			$(":text[name*=" + name + "]").each(function(i, d) {
				if($(d).val() == "") {
					flag = false;
				}
			});
			
			if(flag && $("#" + name + "div").length == 0) {
				addEl(parseInt($(":text[name=" + name + "_x1]").val()), parseInt($(":text[name=" + name + "_y1]").val()), 
						parseInt($(":text[name=" + name + "_x2]").val()), parseInt($(":text[name=" + name + "_y2]").val()));
			}
		}
	});
	
};

function search() {
	$("#list").jqGrid("search", "#search");
} 

/**
 * 清空查询条件
 */
function clear() {
	$("#search")[0].reset(); 
}

function updateType(rowId){
	var data = $("#list").jqGrid("getData", rowId);
	$("#billTypeConfig").dialog({title: data.billName}); 
	//$("#billTypeConfig").fillForm(data);
	$("#billTypeConfig").dialog("open");
	$("#autoId").val(data.autoId);
	$("#ocrImgStoreId").val(data.ocrImgStoreId);
	$("#billTypeConfig :text").val("").attr("disabled", "disabled");
	$("#billTypeConfig :checkbox").removeAttr("checked");
	
	currBillType = data.billType;
	var storeId = data.ocrImgStoreId;
	if (storeId) {
		var docObjects = downloadUseSealImg(storeId);
		if (docObjects != null && docObjects.length != 0) {
			for ( var i = 0; i < docObjects.length; i++) {
				var _mediatype = docObjects[i].propertyList.mediatype;
				if ("ocrImage" == _mediatype) {
					$("#img").attr("src", docObjects[i].fileUrl);
					adjustSize();
					break;
				}
			}
		}
	}
//	if(imgMap[data.billType]) {
//		$("#img").attr("src", imgMap[data.billType]);
//		adjustSize();
//	}
	
	var ocrArea = data.ocrArea;
	var json;
	try {
		json = eval("(" + ocrArea + ")");
	} catch (e) {
		json = null;
	}
	if(json) {
		$.each(json, function(i, d) {
			$("#" + i).attr("checked", "checked");
			$.each(d, function(j, dd) {
				$(":text[name=" + i + "_" + j + "]").removeAttr("disabled").val(dd);
			});
		});
	}
	
	initEl();
	
}

function downloadUseSealImg(storeId){
	var success = false;
	var urlList = null;
	$.ajax({
		type : "post",
		url : basePath + "extStore/extStoreAction!findObject.action",
		dataType : "json",
		data: {
			"storeId" : storeId
		},
		async : false,
		success : function(response) {
			if (response.state == "normal") {
				success = true;
			}
			urlList = response.data;
		},
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0"
					|| XMLHttpRequest.status != "200") {
				urlList = 'E204';
			}
		}
	});
	if(success){
		if(urlList != null){
			return urlList;
		}else{
			throw new Error("E202");
		}
	}else{
		throw new Error(urlList);
	}
};


var rate = 1;
var mousedown = false;
var startpoint;
var currEl;
var type = "";
var boxType = "";
var selectBox;
var count = 0;
var lineHeight = 1;
var boxPos = {};

$(function() {
	
	$("#mask").mousedown(function(e) {
		startpoint = {x: roundNumber(e.pageX), y: roundNumber(e.pageY), offsetX: roundNumber(e.pageX - $("#mask").offset().left), offsetY: roundNumber(e.pageY - $("#mask").offset().top)};
		if(type == "box") {
			mousedown = true;
			addEl(startpoint.offsetX, startpoint.offsetY);
		} else if (type == "") {
			mousedown = true;
			addSelectBox(startpoint.offsetX, startpoint.offsetY);
		}
		resetSelectedEls();
	});
	
	$("body").mouseup(function(e) {
		if(type == "move") {
			if(currEl.position().left > $("#mask").width() || (currEl.position().left + currEl.width()) < 0 || currEl.position().top > $("#mask").height() || (currEl.position().top + currEl.height()) < 0) {
				/*if(confirm("确定要删除?")) {
					removeEl(currEl);
					mousedown = false;
					return;
				}*/
			}
		} else if (type == "") {
			
		} else if (type == "box") {
			if(mousedown) {
				type = "";
				updateElPosition(currEl);
			}
			mousedown = false;
			return;
		}
		mousedown = false;
		removeSelectBox();
	});
	
	$("body").mousemove(function(e) {
		if(mousedown) {
			if(type == "box") {
				drawBox(e.pageX, e.pageY);
			} else if (type == "move") {
				moveEl(e.pageX, e.pageY);
			} else if (type == "") {
				resizeSelectBox(e.pageX, e.pageY);
			} else if (type == "resize") {
				resizeBox(e.pageX, e.pageY);
			}
		}
	});
});

function initEl() {
	mousedown = false;
	type = "";
	boxType = "";
	boxPos = {};
	
	$("#mask div[class*=box]").remove();
	
	$(":checkbox:checked").each(function(i, d) {
		var name = $(d).attr("id");
		boxType = name;
		addEl(parseInt($(":text[name=" + name + "_x1]").val()), parseInt($(":text[name=" + name + "_y1]").val()), 
				parseInt($(":text[name=" + name + "_x2]").val()), parseInt($(":text[name=" + name + "_y2]").val()));
	});
	
	
	
}

function addEl(x, y, ex, ey) {
	count++;
	var el;
	
	if(!ex) {
		ex = x + 1;
	}
	if(!ey) {
		ey = y + 1;
	}
	el = $("<div class='box'><div class='resize'></div></div>");
	el.css("width", roundNumber(ex - x)).css("height", roundNumber(ey - y));
	el.attr("id", boxType + "div");
	el.css("left", roundNumber(x)).css("top", roundNumber(y));
	
	$("#mask").append(el);
	setCurrEl(el);
	updateElPosition(currEl);
	el.mousedown(function(e) {
		mousedown = true;
		setCurrEl(el);
		type = "move";
		offsetpoint = {x: e.pageX - currEl.offset().left, y: e.pageY - currEl.offset().top};
		resetSelectedEls();
		addSelectEl(el);
		e.stopPropagation();
	});
	
	el.find("div").mousedown(function(e) {
		mousedown = true;
		setCurrEl(el);
		type = "resize";
		offsetpoint = {x: currEl.offset().left, y: currEl.offset().top};
		e.stopPropagation();
	});
	
}

function updateElPosition(el) {
	var left = roundNumber(el.position().left);
	var top = roundNumber(el.position().top);
	var width = roundNumber(el.width());
	var height = roundNumber(el.height());
	
	var name = $(el).attr("id").replace(/div$/, "");
	boxPos[name] = {
		x1: parseInt(left),
		y1: parseInt(top),
		x2: parseInt(left + width),
		y2: parseInt(top + height)
	};
	$(":text[name=" + name + "_x1]").val(boxPos[name].x1);
	$(":text[name=" + name + "_y1]").val(boxPos[name].y1);
	$(":text[name=" + name + "_x2]").val(boxPos[name].x2);
	$(":text[name=" + name + "_y2]").val(boxPos[name].y2);
	
}

function resetSelectedEls() {
}

function setCurrEl(el) {
	currEl = el;
}

function removeSelectBox() {
	if(selectBox) {
		selectBox.remove();
	}
}

function drawBox(x, y) {
	var width = x - startpoint.x;
	var height = y - startpoint.y;

	width = roundNumber(width);
	height = roundNumber(height);

	if(!currEl) {
		return;
	}
	
	if(width >= rate) {
		currEl.css("width", width).css("height", height).css("left", roundNumber(startpoint.x - $("#mask").offset().left)).css("top", roundNumber(startpoint.y - $("#mask").offset().top));
	} else if (width <= -rate) {
		currEl.css("width", -width).css("height", height).css("left", roundNumber(startpoint.x - $("#mask").offset().left + width)).css("top", roundNumber(startpoint.y - $("#mask").offset().top));
	} else {
		currEl.css("width", rate).css("height", height).css("left", roundNumber(startpoint.x - $("#mask").offset().left)).css("top", roundNumber(startpoint.y - $("#mask").offset().top));
	}
	currEl.data("style", "h");
	updateElPosition(currEl);
}

function resizeSelectBox(x, y) {
	var width = x - startpoint.x;
	var height = y - startpoint.y;
	if(width > 0) {
		selectBox.css("width", width).css("left", startpoint.x - $("#mask").offset().left);
	} else {
		selectBox.css("width", -width).css("left", startpoint.x + width - $("#mask").offset().left);
	}
	
	if(height > 0) {
		selectBox.css("height", height).css("top", startpoint.y - $("#mask").offset().top);
	} else {
		selectBox.css("height", -height).css("top", startpoint.y + height - $("#mask").offset().top);
	}
	
	var sx = selectBox.position().left;
	var sy = selectBox.position().top;
	var ex = selectBox.position().left + selectBox.width();
	var ey = selectBox.position().top + selectBox.height();
	
	resetSelectedEls();
	
}

function addSelectBox(x, y) {
	if(selectBox) {
		selectBox.remove();
	}
	selectBox = $("<div class='selectbox'></div>").css("left", x).css("top", y);
	$("#mask").append(selectBox);
}

function addSelectEl(el) {
	el.addClass("selected");
}

function resizeBox(x, y) {
	var width = roundNumber(x - offsetpoint.x);
	var height = roundNumber(y - offsetpoint.y);
	width = width < rate ? rate : width;
	height = height < rate ? rate : height;
	currEl.css("width", width);
	currEl.css("height", height);
	updateElPosition(currEl);
}

function moveEl(x, y) {
	var x1 = roundNumber(x - $("#mask").offset().left - offsetpoint.x);
	var y1 = roundNumber(y - $("#mask").offset().top - offsetpoint.y);


	currEl.css("left", x1).css("top", y1);
	
	updateElPosition(currEl);
}

function roundNumber(num) {
	return Math.round(num / rate) * rate;
}

function preview(e) {
	e = e || window.event;
	var target = e.target || e.srcElement;
	var jpg = target.value;
	if(jpg == ""){
		alert("请选择图片！");
		return false;
	}else{
		if(/\.(jpg)$/i.test(jpg)){
			$("#img").attr("src", jpg);
			imgMap[currBillType] = jpg;
		}else {
			alert("图片类型必须是.jpg!");
			$(target).replaceWith($(target).clone(true));
			return false;
		}
	}
}

function adjustSize() {
	$("#mask").width($("#img").width()).height($("#img").height());
	$("#mask").css("background-image", "url('" + $("#img").attr("src") + "')");
}