/**
 * 申请用印js
 * 
 * @Description 用于福建中行用印
 * @author HuangKunping
 * @Date 2015-09-09
 */

/*************************************** 页面按钮设置 ********************************************/
/**
 * 设置开始按钮/停止用印按钮状态
 * @param startState	开始用印按钮状态，true:不可用，false：可用
 * @param stopState		停止用印按钮状态，true:不可用，false：可用
 */
function startStopDisabled(startState,stopState){
	if(!startState){ // 如果是开始按钮启用（sartState=false），则延时2秒
		setTimeout(function(){document.getElementById("startgather").disabled = false;},1000);
	}else{
		document.getElementById("startgather").disabled = true; // 如果是停用，则马上停用
	}
	if(!stopState){ // 如果是停用按钮启用（sartState=false），则延时2秒
		setTimeout(function(){document.getElementById("stopgather").disabled = false;},1000);
	}else{
		document.getElementById("stopgather").disabled = true; // 如果是停用，则马上停用
	}
}
