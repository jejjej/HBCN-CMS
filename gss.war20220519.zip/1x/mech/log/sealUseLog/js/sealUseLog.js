var sealTypeMap = new Map();
var sealLogImagesMap = new Map();

/**
 * 用印记录采集加载
 */
function sealLogInit() {
	//用印检查参数
	top.sealLogCheck = {
			sealLogId:"",
			before:false,
			after:false,
			video:false,
			peopleCode:""
			
		};
	
	$("#sealLogDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 320,
		width : 510,
		modal : true,
		buttons : {},
		close : function() {
			$("#chkSealLogIterm")[0].reset();
		}
	});
	var integrationSwitch = Boolean(GPCache.get(GPCache.USS,"integrationSwitch")=="true");
	var sealTypeContent = "<option value=' '>全部</option>";
	// 是否与印章管理系统做交互，如果是，则到印章管理系统查询所有印章类型，如果不是，则使用js常量定义中的印章类型
	if (integrationSwitch) {
		$.ajax({
			type : "POST",
			url : $.getContextPath() + "/sms/config/sealTypeConfig_listAll.action",
			dataType : "json",
			async : false,
			success : function(data) {
				var pageBean = data.pageBean;
				var typeList = pageBean.data;
				for ( var i = 0; i < typeList.length; i++) {
					sealTypeContent += "<option value='"
							+ typeList[i].type + "'>" + typeList[i].name + "</option>";
					sealTypeMap.put(key, ussConstants.SEAL_BIZ_TYPE[key]);
				}

			}
		});
	} else {
		for (var key in ussConstants.SEAL_BIZ_TYPE) {
			sealTypeContent += "<option value='" + key + "'>"
					+ ussConstants.SEAL_BIZ_TYPE[key] + "</option>";
			sealTypeMap.put(key, ussConstants.SEAL_BIZ_TYPE[key]);
		}
	}
	$("#sealTypeIdItem").html(sealTypeContent);
	
	initDisplayParam();
	
	// 用印记录列表
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2-8;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	// 审核机构列表
	$("#sealLogList")
	.jqGrid(
			{
				width : pageContentWidth,
				height : tableHeight,
				url : ctx
						+ "/uss/log/useSealLogQueryAction!sealLogList.action",
				multiselect : false,
				postData : {
					checkSearchFlag : $("#checkSearchFlag").val(),
					lastCheckExceptSealLogTime : $("#lastCheckExceptSealLogTime").val(),
					lastCheckAllSealLogTime : $("#lastCheckAllSealLogTime").val()
				},
				rowNum : 20,
				rownumbers : true,
				rowList : [ 20, 50, 100 ],
				colNames : [ "用印序号", "用印机构", "设备编号", "用印时间", "操作人员",
						"印章名称", top._billTypeParam.ocxStatus ? "凭证代码" : "",top._billTypeParam.ocxStatus ? "凭证名称" : "", "用印状态", top._billTypeParam.before ? "用印前图像" : "", top._billTypeParam.after ? "用印后图像" : "",
								top._billTypeParam.videoDefectStatus ? "用印视频":"", 
								top._billTypeParam.ocrStatus ? "凭证号1":"", top._billTypeParam.ocrStatus ? "账号1":"", top._billTypeParam.ocrStatus ? "金额1":"", top._billTypeParam.ocrStatus ? "申请人1": "", 
								top._billTypeParam.ocrStatus ? "凭证号2":"", top._billTypeParam.ocrStatus ? "账号2":"", top._billTypeParam.ocrStatus ? "金额2": "" , top._billTypeParam.ocrStatus ? "申请人2" : "", "详情" ],
				colModel : [
						{
							name : "autoId",
							index : "autoId",
							align : "center",
							width : 30,
							sortable : false
						},
						{
							name : "orgNo",
							index : "orgNo",
							align : "center",
							width : 90,
							sortable : false,
							formatter : function(value, options, rData) {
								if (value != null && value != "") {
									return rData.orgName + "(" + value + ")";
								} else {
									return "";
								}
							}
						},
						{
							name : "deviceNum",
							index : "deviceNum",
							align : "center",
							width : 70,
							sortable : false
						},
						{
							name : "startTime",
							index : "startTime",
							width : 80,
							align : "center",
							sortable : false,
							formatter : function(value, options, rData) {
								if (value == null || value == "") {
									return "未用印";
								} else {
									return value;
								}
							}
						},
						{
							name : "peopleCode",
							index : "peopleCode",
							align : "center",
							width : 80,
							sortable : false,
							formatter : function(value, options, rData) {
								if (value != null && value != "") {
									return rData.peopleName + "(" + value + ")";
								} else {
									return "";
								}
							}
						},
						{
							name : "sealBizTypeName",
							index : "sealBizTypeName",
							width : 95,
							align : "center",
							sortable : false
						},
						{
							name : "docNo",
							index : "docNo",
							align : "center",
							width : 40,
							hidden:!top._billTypeParam.ocrStatus
						},
						{
							name : "docName",
							index : "docName",
							align : "center",
							width : 40,
							hidden:!top._billTypeParam.ocrStatus
						},
						{
							name : "sealStatus",
							index : "sealStatus",
							align : "center",
							width : 40,
							sortable : false,
							formatter : function(value, options, rData) {
								return ussConstants.USE_SEAL_STATUS[value];
							}
						},
						{
							name : "storeId",
							index : "storeId",
							width : 40,
							align : "center",
							sortable : false,
							hidden:!top._billTypeParam.before,
							formatter : function(value, options, rData) {
								if (null == value || value == "") {
									return "无图像";
								} else {
									var viewUrl = findViewUrl(rData.autoId, value, 'before');
									if (viewUrl) {
										var html = "<img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='用印前图像'  title='用印前图像' " +
										" onclick=\"viewPhoto('"+ rData.autoId + "', 'before', '" + viewUrl + "', '" + rData.peopleCode +  "');\"/>";
										return html;
									} else {
										return "无图像";
									}
								}
							}
						},
						{
							name : "storeId",
							index : "storeId",
							width : 40,
							align : "center",
							sortable : false,
							hidden:!top._billTypeParam.after,
							formatter : function(value, options, rData) {
								if (null == value || value == "") {
									return "无图像";
								} else {
									var viewUrl = findViewUrl(rData.autoId, value, 'after');
									if (viewUrl) {
										var html = "<img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='用印后图像'  title='用印后图像' " +
										" onclick=\"viewPhoto('"+ rData.autoId + "', 'after', '" + viewUrl + "', '" + rData.peopleCode +  "');\"/>";
										return html;
									} else {
										return "无图像";
									}
								}
							}
						},
						{
							name : "storeId",
							index : "storeId",
							width : 35,
							align : "center",
							sortable : false,
							hidden:!top._billTypeParam.videoDefectStatus,
							formatter : function(value, options, rData) {
								if (null == value || value == "") {
									return "无视频";
								} else {
									var viewUrl = findViewUrl(rData.autoId, value, 'video');
									if (viewUrl) {
										var html = "<img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='用印后图像'  title='用印后图像' " +
										" onclick=\"viewPhoto('"+ rData.autoId + "', 'after', '" + viewUrl + "', '" + rData.peopleCode +  "');\"/>";
										return html;
									} else {
										return "无视频";
									}
								}
							}
						},
						/***********************************************   OCR start  **********************************************************/
						{
							name : "storeId",
							index : "storeId",
							width : 30,
							align : "center",
							sortable : false,
							hidden:!top._billTypeParam.ocrStatus,
							formatter : function(value, options, rData) {
								if (null == value || value == "") {
									return "无图像";
								} else {
									var viewUrl = findViewUrl(rData.autoId, value, 'beforeOcrBN');
									if (viewUrl) {
										var html = "<img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='凭证号1'  title='凭证号1'  onclick=\"window.parent.viewImage2('"
												+ viewUrl + "');\"/>";
										return html;
									} else {
										return "无图像";
									}
								}
							}
						},
						{
							name : "storeId",
							index : "storeId",
							width : 30,
							align : "center",
							sortable : false,
							hidden:!top._billTypeParam.ocrStatus,
							formatter : function(value, options, rData) {
								if (null == value || value == "") {
									return "无图像";
								} else {
									var viewUrl = findViewUrl(rData.autoId, value, 'beforeOcrAN');
									if (viewUrl) {
										var html = "<img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='账号1'  title='账号1'  onclick=\"window.parent.viewImage2('"
												+ viewUrl + "');\"/>";
										return html;
									} else {
										return "无图像";
									}
								}
							}
						},
						{
							name : "storeId",
							index : "storeId",
							width : 30,
							align : "center",
							sortable : false,
							hidden:!top._billTypeParam.ocrStatus,
							formatter : function(value, options, rData) {
								if (null == value || value == "") {
									return "无图像";
								} else {
									var viewUrl = findViewUrl(rData.autoId, value, 'beforeOcrMN');
									if (viewUrl) {
										var html = "<img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='金额1'  title='金额1'  onclick=\"window.parent.viewImage('"
												+ viewUrl + "');\"/>";
										return html;
									} else {
										return "无图像";
									}
								}
							}
						},
						{
							name : "storeId",
							index : "storeId",
							width : 30,
							align : "center",
							sortable : false,
							hidden:!top._billTypeParam.ocrStatus,
							formatter : function(value, options, rData) {
								if (null == value || value == "") {
									return "无图像";
								} else {
									var viewUrl = findViewUrl(rData.autoId, value, 'beforeOcrAP');
									if (viewUrl) {
										var html = "<img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='申请人1'  title='申请人1'  onclick=\"window.parent.viewImage2('"
												+ viewUrl + "');\"/>";
										return html;
									} else {
										return "无图像";
									}
								}
							}
						},
						{
							name : "storeId",
							index : "storeId",
							width : 30,
							align : "center",
							sortable : false,
							hidden:!top._billTypeParam.ocrStatus,
							formatter : function(value, options, rData) {
								if (null == value || value == "") {
									return "无图像";
								} else {
									var viewUrl = findViewUrl(rData.autoId, value, 'afterOcrBN');
									if (viewUrl) {
										var html = "<img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='凭证号2'  title='凭证号2'  onclick=\"window.parent.viewImage2('"
												+ viewUrl + "');\"/>";
										return html;
									} else {
										return "无图像";
									}
								}
							}
						},
						{
							name : "storeId",
							index : "storeId",
							width : 30,
							align : "center",
							sortable : false,
							hidden:!top._billTypeParam.ocrStatus,
							formatter : function(value, options, rData) {
								if (null == value || value == "") {
									return "无图像";
								} else {
									var viewUrl = findViewUrl(rData.autoId, value, 'afterOcrAN');
									if (viewUrl) {
										var html = "<img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='账号2'  title='账号2'  onclick=\"window.parent.viewImage2('"
												+ viewUrl + "');\"/>";
										return html;
									} else {
										return "无图像";
									}
								}
							}
						},
						{
							name : "storeId",
							index : "storeId",
							width : 30,
							align : "center",
							sortable : false,
							hidden:!top._billTypeParam.ocrStatus,
							formatter : function(value, options, rData) {
								if (null == value || value == "") {
									return "无图像";
								} else {
									var viewUrl = findViewUrl(rData.autoId, value, 'afterOcrMN');
									if (viewUrl) {
										var html = "<img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='金额2'  title='金额2'  onclick=\"window.parent.viewImage2('"
												+ viewUrl + "');\"/>";
										return html;
									} else {
										return "无图像";
									}
								}
							}
						},
						{
							name : "storeId",
							index : "storeId",
							width : 30,
							align : "center",
							sortable : false,
							hidden:!top._billTypeParam.ocrStatus,
							formatter : function(value, options, rData) {
								if (null == value || value == "") {
									return "无图像";
								} else {
									var viewUrl = findViewUrl(rData.autoId, value, 'afterOcrAP');
									if (viewUrl) {
										var html = "<img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='申请人2'  title='申请人2'  onclick=\"window.parent.viewImage2('"
												+ viewUrl + "');\"/>";
										return html;
									} else {
										return "无图像";
									}
								}
							}
						},
						/***********************************************   OCR end  **********************************************************/
						{
							name : "autoId",
							index : "autoId",
							align : "center",
							width : 30,
							sortable : false,
							formatter : function(value, options, rData) {
								return "<img src='" + ctx + "/gss/common/images/gss/details.png' style='cursor:pointer;margin-left:3px;' alt='查看详情'  title='查看详情'   onclick=\"checkSealLog('"
										+ value + "');\"/>";
							}
						} ],
				pager : "#sealLogListPager"
			});
	
	//$("#checkSearchFlag").val("");
	// 导出
	/* $("#reportDeviceLogExcel").click(function(){$(this).reportExcel($("#sealLogIterm"),ctx+"/gss/sealLogReportAction!report.action")}); */
}

function findViewUrl(autoId, storeId, mediatype) {
	if (!sealLogImagesMap.get(autoId)) {
		try {
			var docObjects = fileStore.syncDownload(storeId);
		} catch (e) {}
		if (docObjects != null && docObjects.length != 0) {
			var mediatypeImagesMap = new Map();
			for (var i = 0; i < docObjects.length; i++) {
				mediatypeImagesMap.put(docObjects[i].propertyList.mediatype, docObjects[i].fileUrl);
			}
			sealLogImagesMap.put(autoId, mediatypeImagesMap);
		}
	}
	var _mediatypeImagesMap = sealLogImagesMap.get(autoId);
	if (_mediatypeImagesMap) {
		var _fileUrl = _mediatypeImagesMap.get(mediatype);
		if (_fileUrl) {
			return _fileUrl;
		}
	}
	return null;
}

/**
 * 查看详情
 */
function checkSealLog(autoId) {
	$.ajax({
		type : "POST",
		url : $.getContextPath()
				+ "/uss/log/useSealLogQueryAction!findSealLogByAutoId.action",
		data : {
			autoId : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.sealLog) {
				var sealLog = data.sealLog;
				$("#recordIdItem").val(sealLog.recordId ||"未用印");
				$("#deviceNumItem").val(sealLog.deviceNum);
				$("#sealTypeItem").val(ussConstants.SEAL_BIZ_TYPE[sealLog.sealBizTypeId]);
				$("#sealModuleSnItem").val(sealLog.sealModuleSn);
				if (null != sealLog.peopleSid && $.trim(sealLog.peopleSid) != "") {
					$("#personnelSidItem").val(sealLog.peopleName + "(" + sealLog.peopleCode + ")");
				}
				$("#recordTimeItem").val(sealLog.finishTime ||"未用印");
				$("#sealStatusItem").val(ussConstants.USE_SEAL_STATUS[sealLog.sealStatus]);
				$("#sealMemoItem").val(sealLog.memo);
				//根据用印类型显示不同的详情
				if(!top._billTypeParam.approval){
					document.getElementById("approvalItem").style.display="none";
				}
				var fstApproval = "";
				var approvalModule = "无需审批";
				if(sealLog.approvalMode == "local") {
					if (sealLog.firstApprovalPeopleName != null && sealLog.firstApprovalPeopleName != "") {
						fstApproval = sealLog.firstApprovalPeopleName + "(" + sealLog.firstApprovalPeopleCode + ")";
					}
					approvalModule = "现场审批";
				} else if(sealLog.approvalMode == "remote") {
					if (sealLog.secondApprovalPeopleName != null && sealLog.secondApprovalPeopleName != "") {
						fstApproval = sealLog.secondApprovalPeopleName + "(" + sealLog.secondApprovalPeopleCode + ")";
					}
					approvalModule = "远程审批";
				}

				$("#fstApprovalItem").val(fstApproval);
				$("#approvalModule").val(approvalModule);
				$("#sealLogDLG").dialog("open");
			}
		}
	});
}

function querySealLogForTerm() {
	$("#sealLogList").jqGrid("search", "#sealLogIterm");
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo) {
	$("#orgSid_Item").dialogOrgTree("radio",top.loginPeopleInfo.orgSid,false,null,null,
			function(event, treeId, treeNode) {
				if (treeNode) {
					$("#" + organizationNo + "_Item").val(
							treeNode.organizationName + "(" + treeNode.organizationNo + ")");
					$("#" + organizationNo).val(treeNode.sid);
				}
			});
}



function initDisplayParam() {
	top._billTypeParam = {
		"before" : false,
		"after" : false,
		"videoDefectStatus" : false,
		"endorsePhotoStatus" : false,
		"ocxStatus" : false,
		"ocrStatus" : false,
		"approval"  : false
	};
	var captureImageMode = false;
	var showDocNoSearch = false;
	var isNeedApproval = false;
	var docNoContent = "<option value=' '>全部</option>";
	var billTypeParams = ussInterface.listBillTypeParams();
	for (var i = 0; i < billTypeParams.keys.length; i++) {
		var val = billTypeParams.data[billTypeParams.keys[i]];
		if (val) {
			if (val.billCode != "000") {
				if (!top._billTypeParam.ocxStatus && val.ocxStatus == 1) {
					top._billTypeParam.ocxStatus = true;
				}
				if (!top._billTypeParam.ocrStatus && val.ocrStatus == 1) {
					top._billTypeParam.ocrStatus = true;
				}
			}
			if (!top._billTypeParam.approval && val.billCode == "000" && val.approvalMode != "none") {
				top._billTypeParam.approval = true;
			}
			
			if (!captureImageMode && val.captureImageMode == "before+after") {
				top._billTypeParam.before = true;
				top._billTypeParam.after = true;
				captureImageMode = true;
			}
			
			if (!captureImageMode && val.captureImageMode == "before") {
				top._billTypeParam.before = true;
				top._billTypeParam.after = false;
				captureImageMode = true;
			}
			
			if (!captureImageMode && val.captureImageMode == "after") {
				top._billTypeParam.before = false;
				top._billTypeParam.after = true;
				captureImageMode = true;
			}
			
			if (!top._billTypeParam.endorsePhotoStatus && val.endorsePhotoStatus == 1) {
				top._billTypeParam.endorsePhotoStatus = true;
			}
			
			if (!top._billTypeParam.videoDefectStatus && val.videoDefectStatus == 1) {
				top._billTypeParam.videoDefectStatus = true;
			}
			
			//检测是否显示DocNo搜索条件
			if(!showDocNoSearch && val.billCode !="000") {
				showDocNoSearch = true;
			}
			//检测是否显示审批结果项查询条件
			if(!isNeedApproval && (val.approvalMode =="local" || val.approvalMode =="remote")) {
				isNeedApproval = true;
			}
			docNoContent += "<option value='" + val.billCode + "'>" + val.billName + "</option>";
		}
	}
	
	$("#docNoItem").html(docNoContent);
	
	$("#docNoSelTD, #docNameTD").hide();
	var sealStatusContent = "<option value=' '>全部</option>";
	for (var key in ussConstants.USE_SEAL_STATUS) {
		if(!isNeedApproval) {
			if(key=="waiting_approval"||key=="approval_pass"||key=="approval_refuse") {
				continue;
			}
		}
		sealStatusContent += "<option value='" + key + "'>" + ussConstants.USE_SEAL_STATUS[key] + "</option>";
	}

	$("#que_sealStatus").html(sealStatusContent);
}



/**
 * 查看图像后，修改用印检查标识
 * @param sealLogId 日志ID
 * @param mediatype 图像文件类型
 * @param viewUrl	视频url
 * @param optPeopleCode	人员代码
 */
function viewPhoto(sealLogId, mediatype, viewUrl, optPeopleCode) {
	var _mediatypeImagesMap = sealLogImagesMap.get(sealLogId);
	if (_mediatypeImagesMap) {
		if (!_mediatypeImagesMap.get("before")) {
			top.sealLogCheck.before = true;
		}
		if (!_mediatypeImagesMap.get("after")) {
			top.sealLogCheck.after = true;
		}
		if (!_mediatypeImagesMap.get("video")) {
			top.sealLogCheck.video = true;
		}
	}
	window.parent.viewImage(viewUrl);
	if (sealLogId != top.sealLogCheck.sealLogId) {
		top.sealLogCheck = {
				sealLogId:"",
				before:false,
				after:false,
				video:false,
				peopleCode:""
				
		};
	}
	top.sealLogCheck.sealLogId = sealLogId;
	top.sealLogCheck.peopleCode = optPeopleCode;
	if (mediatype == "before") {
		top.sealLogCheck.before = true;
	} else if (mediatype == "after") {
		top.sealLogCheck.after = true;
	}
}

/**
 * 查看视频后，修改用印检查标识
 * @param sealLogId 日志ID
 * @param viewUrl	视频url
 * @param optPeopleCode	人员代码
 */
function viewVideo(sealLogId, viewUrl, optPeopleCode) {
	var _mediatypeImagesMap = sealLogImagesMap.get(sealLogId);
	if (_mediatypeImagesMap) {
		if (!_mediatypeImagesMap.get("before")) {
			top.sealLogCheck.before = true;
		}
		if (!_mediatypeImagesMap.get("after")) {
			top.sealLogCheck.after = true;
		}
		if (!_mediatypeImagesMap.get("video")) {
			top.sealLogCheck.video = true;
		}
	}
	window.parent.viewVideo(viewUrl);
	if (!(top.sealLogCheck) || sealLogId != top.sealLogCheck.sealLogId) {
		top.sealLogCheck = {
				sealLogId:"",
				before:false,
				after:false,
				video:false,
				peopleCode:""
				
		};
	}
	top.sealLogCheck.sealLogId = sealLogId;
	top.sealLogCheck.peopleCode = optPeopleCode;
	top.sealLogCheck.video = true;
}


/**
 * 关闭浏览器前需要的操作
 * 1.重置UseSeal对象useSeal属性
 * 2.关闭印控机
 */
$.onunload(function(){
	top._billTypeParam = {
		"before" : false,
		"after" : false,
		"videoDefectStatus" : false,
		"endorsePhotoStatus" : false,
		"ocxStatus" : false,
		"ocrStatus" : false
	};
});

