var sealTypeMap = new Map();
var sealLogImagesMap = new Map();
function sealLogCheckInit() {
	
	$("#sealLogListDLG").dialog({
		autoOpen : false,
		resizable : false,
		width : 870,
		height : 360,
		modal : true
	});
	
	$("#sealLogDLG").dialog({
		autoOpen : false,
		resizable : false,
		width : 510,
		height : 320,
		modal : true,
		buttons : {},
		close : function() {
		}
	});
	
	
	
	// 用印记录列表
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2-8;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	// 审核机构列表
	$("#sealLogCheckList")
			.jqGrid(
					{
						width : pageContentWidth,
						height : tableHeight,
						url : ctx + "/uss/log/useSealLogCheckAction!sealLogCheckList.action",
						multiselect : false,
						rowNum : 20,
						rownumbers : true,
						rowList : [ 20, 50, 100 ],
						colNames : [ "检查机构", "检查人", "检查日期", "检查结果", "详情" ],
						colModel : [
								{
									name : "orgNo",
									index : "orgNo",
									align : "center",
									width : 120,
									sortable : false,
									formatter : function(value, options, rData) {
										if (value != null && value != "") {
											return rData.orgName + "(" + value + ")";
										} else {
											return "";
										}
									}
								},
								{
									name : "peopleCode",
									index : "peopleCode",
									width : 100,
									align : "center",
									sortable : false,
									formatter : function(value, options, rData) {
										if (value != null && value != "") {
											return rData.peopleName + "(" + value + ")";
										} else {
											return "";
										}
									}
								},
								{
									name : "checkDate",
									index : "checkDate",
									width : 85,
									align : "center",
									sortable : false
								},
								{
									name : "checkResult",
									index : "checkResult",
									align : "center",
									width : 120,
									sortable : false
								},
								{
									name : "sealLogId",
									index : "sealLogId",
									align : "center",
									width : 80,
									sortable : false,
									formatter : function(value, options, rData) {
										return "<img src='" + ctx + "/gss/common/images/gss/details.png' style='cursor:pointer;margin-left:3px;' alt='查看详情'  title='查看详情'   onclick=\"viewSealLog('"
												+ value + "');\"/>";
									}
								} ],
						pager : "#sealLogCheckListPager"
					});
}
function viewSealLog(autoId) {
	$("#sealLogList").jqGrid('GridUnload');
	$("#sealLogList").jqGrid({
		width : 850,
		height : 270,
		url : ctx + "/uss/log/useSealLogQueryAction!listSealLogByAutoId.action",
		postData : {
			"autoId":autoId
		},
		multiselect : false,
		rowNum : 20,
		rownumbers : true,
		rowList : [ 20, 50, 100 ],
		colNames : ["用印编号", "设备编号", "用印日期", "用印时间", "操作人员", "印章名称", "用印状态", "用印前图像", "用印后图像", "用印视频" ],
		colModel : [{
			name : "recordId",
			index : "recordId",
			align : "center",
			width : 90,
			sortable : false
		},
		{
			name : "deviceNum",
			index : "deviceNum",
			align : "center",
			width : 120,
			sortable : false
		},
		{
			name : "recordDate",
			index : "recordDate",
			align : "center",
			width : 100,
			sortable : false
		},
		{
			name : "finishTime",
			index : "finishTime",
			align : "center",
			width : 85,
			sortable : false
		},
		{
			name : "peopleCode",
			index : "peopleCode",
			align : "center",
			width : 140,
			sortable : false,
			formatter : function(value, options, rData) {
				if (value != null && value != "") {
					return rData.peopleName + "(" + value + ")";
				} else {
					return "";
				}
			}
		},
		{
			name : "sealBizTypeName",
			index : "sealBizTypeName",
			width : 120,
			align : "center",
			sortable : false
		},
		{
			name : "sealStatus",
			index : "sealStatus",
			align : "center",
			width : 90,
			sortable : false,
			formatter : function(value, options, rData) {
				return useSealConstants.USE_SEAL_STATUS[value];
			}
		},
		{
			name : "storeId",
			index : "storeId",
			width : 100,
			align : "center",
			sortable : false,
			formatter : function(value, options, rData) {
				if (null == value || value == "") {
					return "无图像";
				} else {
					var viewUrl = findViewUrl(rData.autoId, value, 'before');
					if (viewUrl) {
						var html = "<img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='用印前图像'  title='用印前图像'  onclick=\"window.parent.viewImage('"
						+ viewUrl + "');\"/>";
						return html;
					} else {
						return "无图像";
					}
				}
			}
		},
		{
			name : "storeId",
			index : "storeId",
			width : 100,
			align : "center",
			sortable : false,
			formatter : function(value, options, rData) {
				if (null == value || value == "") {
					return "无图像";
				} else {
					var viewUrl = findViewUrl(rData.autoId, value, 'after');
					if (viewUrl) {
						var html = "<img src='" + ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='用印后图像'  title='用印后图像'  onclick=\"window.parent.viewImage('"
						+ viewUrl + "');\"/>";
						return html;
					} else {
						return "无图像";
					}
				}
			}
		},
		{
			name : "storeId",
			index : "storeId",
			width : 90,
			align : "center",
			sortable : false,
			formatter : function(value, options, rData) {
				if (null == value || value == "") {
					return "无视频";
				} else {
					var viewUrl = findViewUrl(rData.autoId, value, 'video');
					if (viewUrl) {
						var content = "<img src='" + ctx + "/gss/common/images/gss/play.png' style='cursor:pointer;margin-left:3px;' alt='用印视频'  title='用印视频'   onclick=\"window.parent.viewVideo('"
						+ viewUrl + "');\"/>";
						return content;
					} else {
						return "无视频";
					}
				}
			}
		} ],
		pager : "#sealLogListPager"
	});
	
	$("#sealLogListDLG").dialog("open");
}

/**
 * 查看详情
 */
function checkSealLog(autoId) {
	$.ajax({
		type : "POST",
		url : $.getContextPath()
				+ "/uss/log/useSealLogQueryAction!findSealLogByAutoId.action",
		data : {
			autoId : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.sealLog) {
				var sealLog = data.sealLog;
				$("#recordIdItem").val(sealLog.recordId ||"未用印");
				$("#deviceNumItem").val(sealLog.deviceNum);
				$("#sealTypeItem").val(sealTypeMap.get(sealLog.sealBizTypeId));
				$("#sealModuleSnItem").val(sealLog.sealModuleSn);
				if (null != sealLog.peopleSid
						&& $.trim(sealLog.peopleSid) != "") {
					var value = sealLog.peopleName + "(" + sealLog.peopleCode
							+ ")"
					$("#personnelSidItem").val(value);
				}
				$("#recordDateItem").val(sealLog.recordDate);
				$("#recordTimeItem").val(sealLog.finishTime ||"未用印");
				$("#sealStatusItem").val(
						useSealConstants.USE_SEAL_STATUS[sealLog.sealStatus]);
				$("#sealMemoItem").val(sealLog.memo);
				var fstApproval = "";
				var approvalModule = "无需审批";
				if (sealLog.firstApprovalPeopleName != null
						&& sealLog.firstApprovalPeopleName != "") {
					fstApproval = sealLog.firstApprovalPeopleName + "("
							+ sealLog.firstApprovalPeopleCode + ")";
					approvalModule = "现场审批";
				} 
				if (sealLog.secondApprovalPeopleName != null
						&& sealLog.secondApprovalPeopleName != "") {
					fstApproval = sealLog.secondApprovalPeopleName + "("
							+ sealLog.secondApprovalPeopleCode + ")";
					approvalModule = "远程审批";
				}
				$("#fstApprovalItem").val(fstApproval);
				$("#approvalModule").val(approvalModule);
				$("#sealLogDLG").dialog("open");
			}
		}
	});
}

function querySealLogForTerm() {
	$("#sealLogCheckList").jqGrid("search", "#sealLogIterm");
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo) {
	$("#orgSid_Item").dialogOrgTree("radio",top.loginPeopleInfo.orgSid,false,null,null,
			function(event, treeId, treeNode) {
				if (treeNode) {
					$("#" + organizationNo + "_Item").val(
							treeNode.organizationName + "("
									+ treeNode.organizationNo + ")");
					$("#" + organizationNo).val(treeNode.organizationNo);
				}
			});
}


function findViewUrl(autoId, storeId, mediatype) {
	if (!sealLogImagesMap.get(autoId)) {
		var imageUrl = null;
		var docObjects = fileStore.downloadUseSealImg(storeId);
		if (docObjects != null && docObjects.length != 0) {
			var mediatypeImagesMap = new Map();
			for (var i = 0; i < docObjects.length; i++) {
				mediatypeImagesMap.put(docObjects[i].propertyList.mediatype, docObjects[i].fileUrl);
			}
			sealLogImagesMap.put(autoId, mediatypeImagesMap);
		}
	}
	var _mediatypeImagesMap = sealLogImagesMap.get(autoId);
	if (_mediatypeImagesMap) {
		var _fileUrl = _mediatypeImagesMap.get(mediatype);
		if (_fileUrl) {
			return _fileUrl;
		}
	}
	return null;
}
