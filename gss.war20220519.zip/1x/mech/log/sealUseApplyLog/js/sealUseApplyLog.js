/**
 * 用印申请记录采集
 * @author HuangKunping
 * @version 1.0.0
 */
var sealTypeMap = new Map();

/**
 * 用印申请记录采集加载
 */
function sealLogInit() {

	$("#applyFormDetailDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 285,
		width : 400,
		modal : true
	});
	
	$("#useApplySealLogDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 340,
		width : 740,
		modal : true
	});
	$("#applyImageDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 340,
		width : 660,
		modal : true
	});
	// 获取所有的印章类型
	var getSealTypesRet = Utils.ajax(ctx + "/sms/config/sealTypeConfig_gainAll.action").doPost();
	var sealTypeContent = "<option value=''>全部</option>";
	if (getSealTypesRet.data.sealTypePageModels) {
		$.each(getSealTypesRet.data.sealTypePageModels, function(index, sealType) {
			sealTypeContent += "<option value='" + sealType.type + "'>" + sealType.name + "</option>";
			sealTypeMap.put(sealType.type + "", sealType.name);
		});
	}
	$("#sealTypeIdItem").html(sealTypeContent);
	initDisplayParam();
	// 用印申请记录列表
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2-8;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight
			+ 6 - 50 * 2-5;
	// 加载列表数据
	$("#useApplySealLogList").jqGrid({
		width : pageContentWidth,
		height : tableHeight + "px",
		url : ctx + "/uss/mech/usApplyFormAction_sealUseApplyList.action",
		multiselect : false,
		rowNum : 20,
		rownumbers : true,
		rowList : [ 20, 50, 100 ],
		colNames : colNames,
		colModel : colModel,
		pager : "#useApplySealLogListPager"
	});

	// 导出
	$("#reportDeviceLogExcel").click(function() {
		$(this).reportExcel($("#sealLogIterm"), ctx + "/uss/report/usApplyLogReportAction!report.action");
	});
}

function querySealLogForTerm() {
	$("#useApplySealLogList").jqGrid("search", "#sealLogIterm");
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo) {
	$("#organizationSid_Item").dialogOrgTree("radio",top.loginPeopleInfo.orgSid,false,null,null,
			function(event, treeId, treeNode) {
				if (treeNode) {
					$("#" + organizationNo + "_Item").val(treeNode.organizationName + "(" + treeNode.organizationNo + ")");
					$("#" + organizationNo).val(treeNode.sid);
				}
			});
}

/**
 * 查看用印图片列表
 * 
 * @param autoId
 */
function checkSealImage(autoId) {
	var applyId = autoId;
	var imageUrl = ctx + "/uss/mech/applyImagesAction_applyImagesList.action?applyId=" + applyId;
	$("#sealImageList").jqGrid({
		width : 630,
		height : 270,
		url : imageUrl,
		multiselect : false,
		rowNum : 1000,
		rowList : [ 20, 50, 100 ],
		colNames : imageColNames,
		colModel : imageColModel
	});

	$("#sealImageList").jqGrid('setGridParam', { url : imageUrl }).trigger("reloadGrid");
	$("#applyImageDLG").dialog("open");
}

/**
 * 查看用印记录列表
 * 
 * @param autoId
 */
function checkSealLog(autoId) {
	var applyFormId = autoId;
	var logUrl = ctx + "/uss/log/useSealLogQueryAction!sealLogList.action?queryBean.params.applyFormId=" + applyFormId;
	$("#sealLogList").jqGrid({
		width : 710,
		height : 270,
		url : logUrl,
		multiselect : false,
		rowNum : 20,
		rowList : [ 20, 50, 100 ],
		colNames : [ "申请单编号", "用印编号", "设备编号", "用印时间", "用印状态", top._billTypeParam.after ? "用印前图像" :"", top._billTypeParam.after ? "用印后图像" : "", top._billTypeParam.videoDefectStatus ? "用印视频":"" ],
		colModel : [
		    		{
		    			name : "applyFormId",
		    			index : "applyFormId",
		    			align : "center",
		    			sortable : false,
		    			hidden : true
		    		},
		    		{
		    			name : "recordId",
		    			index : "recordId",
		    			align : "center",
		    			sortable : false
		    		},
		    		{
		    			name : "deviceNum",
		    			index : "deviceNum",
		    			align : "center",
		    			sortable : false
		    		},
		    		{
		    			name : "startTime",
		    			index : "startTime",
		    			align : "center",
		    			sortable : false
		    		},
		    		{
		    			name : "sealStatus",
		    			index : "sealStatus",
		    			align : "center",
		    			sortable : false,
		    			formatter : function(value, options, rData) {
		    				return ussConstants.USE_SEAL_STATUS[value];
		    			}
		    		},
		    		{
		    			name : "storeId",
		    			index : "storeId",
		    			width : 90,
		    			align : "center",
		    			sortable : false,
		    			hidden:!top._billTypeParam.before,
		    			formatter : function(value, options, rData) {
		    				if (null == value || value == "") {
		    					return "无图像";
		    				} else {
		    					var html = "<img src='"
		    							+ ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' " 
		    							+ " alt='用印图像'  title='用印图像' " 
		    							+ " onclick=\"window.parent.startViewImage('" + value + "', 'before');\"/>";
		    					return html;
		    				}
		    			}
		    		},
		    		{
		    			name : "storeId",
		    			index : "storeId",
		    			width : 90,
		    			align : "center",
		    			sortable : false,
		    			hidden:!top._billTypeParam.after,
		    			formatter : function(value, options, rData) {
		    				if (null == value || value == "") {
		    					return "无图像";
		    				} else {
		    					var html = "<img src='"
		    							+ ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' " 
		    							+ " alt='用印图像'  title='用印图像' " 
		    							+ " onclick=\"window.parent.startViewImage('" + value + "', 'after');\"/>";
		    					return html;
		    				}
		    			}
		    		},
		    		{
		    			name : "storeId",
		    			index : "storeId",
		    			width : 90,
		    			align : "center",
		    			sortable : false,
		    			hidden:!top._billTypeParam.videoDefectStatus,
		    			formatter : function(value, options, rData) {
		    				if (null == value || value == "") {
		    					return "无视频";
		    				} else {
		    					var content = "<img src='" + ctx + "/gss/common/images/gss/play.png' " +
		    							"style='cursor:pointer;margin-left:3px;' alt='用印视频'  title='用印视频'   onclick=\"window.parent.openVideoDialog('" + value + "');\"/>";
		    					return content;
		    				}
		    			}
		    		} ]
	});
	$("#sealLogList").jqGrid('setGridParam', { url : logUrl }).trigger("reloadGrid");
	$("#useApplySealLogDLG").dialog("open");
}


/**
 * 查看详情
 */
function showDetail(rowId) {
	var data = $("#useApplySealLogList").jqGrid("getRowData", rowId);
	$("#projectNameLabel").html(data.projectName);
	$("#projectNameLabel").html(data.projectName);
	$("#sealTypeIdLabel").html(data.sealTypeId);
	$("#toDepartmentLabel").html(data.toDepartment);
	$("#applyPeopleLabel").html(data.applyPeople);
	$("#approvePeopleLabel").html(data.approvePeople);
	$("#applyTimeLabel").html(data.applyTime);
	$("#organizationSidLabel").html(data.organizationSid);
	$("#personnelSidLabel").html(data.personnelSid);
	$("#unitNameLabel").html(data.unitName);
	$("#applyFormDetailDLG").dialog("open");
}

var colNames = [ "项目名称", "印章名称", "申请机构", "发至单位", "申请人", "签准人", "申请时间", "操作机构", "操作人员",
		"图片查看", "用印流水", "用印项目" ];
var colModel = [
		{
			name : "projectName",
			index : "projectName",
			width : 150,
			align : "center",
			sortable : false
		},
		{
			name : "sealTypeId",
			index : "sealTypeId",
			width : 150,
			align : "center",
			sortable : false,
			formatter : function(value, options, rData) {
				return sealTypeMap.get(value);
			}
		},
		{
			name : "toDepartment",
			index : "toDepartment",
			width : 150,
			align : "center",
			sortable : false
		},
		{
			name : "unitName",
			index : "unitName",
			width : 150,
			align : "center",
			sortable : false
		},
		{
			name : "applyPeople",
			index : "applyPeople",
			width : 100,
			align : "center",
			sortable : false
		},
		{
			name : "approvePeople",
			index : "approvePeople",
			width : 100,
			align : "center",
			sortable : false
		},
		{
			name : "applyTime",
			index : "applyTime",
			width : 200,
			align : "center",
			sortable : false
		},
		{
			name : "organizationSid",
			index : "organizationSid",
			width : 120,
			align : "center",
			sortable : false,
			formatter : "organization"
		},
		{
			name : "personnelSid",
			index : "personnelSid",
			width : 120,
			align : "center",
			sortable : false,
			formatter : "formatPersonnel"
		},
		{
			name : "autoId",
			index : "autoId",
			align : "center",
			width : 80,
			sortable : false,
			formatter : function(value, options, rData) {
				return "<img src='"
						+ ctx
						+ "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='图片查看'  title='图片查看'   onclick=\"checkSealImage('"
						+ value + "');\"/>";
			}
		},
		{
			name : "autoId",
			index : "autoId",
			align : "center",
			width : 80,
			sortable : false,
			formatter : function(value, options, rData) {
				return "<img src='"
						+ ctx
						+ "/gss/common/images/gss/details.png' style='cursor:pointer;margin-left:3px;' alt='用印日志详情'  title='用印日志详情'   onclick=\"checkSealLog('"
						+ value + "');\"/>";
			}
		},
		{
			name : "autoId",
			index : "autoId",
			width : 80,
			align : "center",
			sortable : false,
			formatter : function(value, options, rData) {
				return "<img src='"
						+ ctx
						+ "/gss/common/images/gss/details.png' style='cursor:pointer;margin-left:3px;' alt='详情'  title='详情'   onclick=\"showDetail('"
						+ options.rowId + "');\"/>";
			}
		} ];

var imageColNames = [ "序号", "图像" ];
var imageColModel = [
		{
			name : "autoId",
			index : "autoId",
			align : "center",
			sortable : false,
			hidden : true
		},
		{
			name : "imgName",
			index : "imgName",
			align : "center",
			sortable : false,
			formatter : function(value, options, rData) {
				return "<img src='"
						+ ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;'"
						+ " alt='查看图像' title='查看图像' onclick=\"window.parent.startViewImage('"
						+ rData.storeId + "', 'singleCapture');\"/>";
			}
		} ];

function initDisplayParam() {
	top._billTypeParam = {
		"before" : false,
		"after" : false,
		"videoDefectStatus" : false,
		"endorsePhotoStatus" : false,
		"ocxStatus" : false,
		"ocrStatus" : false
	};
	var captureImageMode = false;
	var billTypeParams = ussInterface.listBillTypeParams();
	for (var i = 0; i < billTypeParams.data.length; i++) {
		var val = billTypeParams.data[i];
		if (val) {
			if (val.billCode != "000") {
				if (!top._billTypeParam.ocxStatus && val.ocxStatus == 1) {
					top._billTypeParam.ocxStatus = true;
				}
				if (!top._billTypeParam.ocrStatus && val.ocrStatus == 1) {
					top._billTypeParam.ocrStatus = true;
				}
			}
			
			if (!captureImageMode && val.captureImageMode == "before+after") {
				top._billTypeParam.before = true;
				top._billTypeParam.after = true;
				captureImageMode = true;
			}
			
			if (!captureImageMode && val.captureImageMode == "before") {
				top._billTypeParam.before = true;
				top._billTypeParam.after = false;
				captureImageMode = true;
			}
			
			if (!captureImageMode && val.captureImageMode == "after") {
				top._billTypeParam.before = false;
				top._billTypeParam.after = true;
				captureImageMode = true;
			}
			
			if (!top._billTypeParam.endorsePhotoStatus && val.endorsePhotoStatus == 1) {
				top._billTypeParam.endorsePhotoStatus = true;
			}
			
			if (!top._billTypeParam.videoDefectStatus && val.videoDefectStatus == 1) {
				top._billTypeParam.videoDefectStatus = true;
			}
		}
	}
}


/**
 * 关闭浏览器前需要的操作
 * 1.重置UseSeal对象useSeal属性
 * 2.关闭印控机
 */
$.onunload(function(){
	top._billTypeParam = {
		"before" : false,
		"after" : false,
		"videoDefectStatus" : false,
		"endorsePhotoStatus" : false,
		"ocxStatus" : false,
		"ocrStatus" : false
	};
});