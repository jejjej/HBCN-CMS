/**
 * 创建于:2015-1-26<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 用印申请审核
 * 
 * @author Rickychen
 * @version 1.0.0
 */

var login_people = null; //人员信息

var lookupVideoTimer = null;
var lookupUseSealTimer = null;

$(function() {
	initLoginPeople();
	initDetailForm();
	initPage();
});

/**
 * 初始化机构人员信息
 */
function initLoginPeople(){
	login_people = top.loginPeopleInfo;
}

/**
 * 初始化任务列表
 */
function initPage() {

	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2 -1;
	// 审核机构列表
	$("#useSealList").jqGrid(
		{
			height : tableHeight,
			url : ctx + "/uss/mech/approvalUseSeal!queryUseSealApplyTasks.action",
			multiselect : false,
			rowNum : 20,
			rownumbers:true,
			rowList : [ 20, 50, 100 ],
			colNames : [ "印章类型", "申请人", "电话号码", "申请机构",
			          "申请日期","申请时间", "用印状态","锁章模块编号","详情" ],
			colModel : [
					{
						name : "sealBizTypeName",
						index : "sealBizTypeName",
						align : "center",
						width: 100,
						sortable : false
					},
					{
						name : "peopleName",
						index : "peopleName",
						align : "center",
						width: 100,
						sortable : false
					},
					{
						name : "peoplePhoneNo",
						index : "peoplePhoneNo",
						align : "center",
						width: 100,
						sortable : false
					},
					{
						name : "orgName",
						index : "orgName",
						align : "center",
						width: 100,
						sortable : false
					},
					{
						name : "recordDate",
						index : "recordDate",
						align : "center",
						width : 130,
						sortable : false
					},
					{
						name : "startTime",
						index : "startTime",
						align : "center",
						width : 100,
						sortable : false
					},
					{
						name : "sealStatus",
						index : "sealStatus",
						align : "center",
						sortable : false,
						width: 100,
						formatter : function(value, options, rData) {
							return ussConstants.USE_SEAL_STATUS[value];
						}
					},
					{
						name : "sealModuleSn",
						index : "sealModuleSn",
						align : "center",
						width: 100,
						sortable : false
					},
					{
						name : "autoId",
						index : "autoId",
						align : "center",
						width : 50,
						sortable : false,
						formatter : function(value, options, rData) {
							return "<img src='"+ctx+"/gss/common/images/gss/details.png' " +
									"style='cursor:pointer;margin-left:3px;' alt='查看详情' " +
									"onclick=\"queryUseSealDetail("+value+");\"/>";
						}
					} ],
			pager : "#useSealPager",
			caption : "用印申请审批列表"
		}).trigger("reloadGrid");
	$("#useSealList").navGrid("#useSealPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true,
		refreshstate:"current"
	});
	
}

/**
 * 初始化详情页面
 */
function initDetailForm(){
	$("#useSealApplyInfo").dialog({
		autoOpen : false,
		resizable : false,
		height : $(window).height() - 15, 
		width : $(window).width()-80,
//		position: { at: "top" },
		modal : true,
		buttons : {
			"通过": approvalPassed,
		    "拒绝": approvalRefused,
		    "关闭": closeDetail
		},
		close : function() {
			resetDetail();
			initPage();
		},
		open:function() {
			$("#imgDiv").height($(window).height() - 150-13).css("overflow", "hidden");
		}
	});
	$("#sealUseVideoDialog").dialog({
		autoOpen : false,
		caption : "视频",
		resizable : false,
		width : ($(window).height() - 100)*1.25,//720,// $(window).width() - 200,
		height : $(window).height() - 100,//570,// $(window).height() - 40,
		modal : true,
		buttons : {
			"关闭" : function() {
				if (lookupUseSealTimer != null) {
					clearTimeout(lookupUseSealTimer);
				}
				if (lookupVideoTimer != null) {
					clearTimeout(lookupVideoTimer);
				}
				$("#sealUseVideoDialog").dialog("close");
			}
		},
		close : function() {
		},
		open : function() {
			//$(".ui-widget-overlay").height($(".ui-widget-overlay").height() - 9);
		}
	});
}

/**
 * 查询用印详情
 */
function queryUseSealDetail(autoId){
	var result = null;
	var success = false;
	$.ajax({
		type : "post",
		url : ctx + "/uss/mech/approvalUseSeal!queryUseSealDetail.action",
		data : {
			"autoId" : autoId
		},
		dataType : "json",
		async : false,
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0"
					|| XMLHttpRequest.status != "200") {
				result = '服务器响应失败';
			}
		},
		success : function(response) {
			result = response.data;
			if(response.state == "normal"){
				success = true;
			}
		},
		error : function (XMLHttpRequest, textStatus, errorThrown) {
		    if(textStatus != null){
		    	result = textStatus;
		    }else{
		    	result = errorThrown;
		    }
		}
	});
	if(success){
		showUseSealDetail(result);
	}else{
		alert("锁定任务失败，任务可能已被他人锁定或已被取消。\n请刷新任务列表后重新尝试!");
		$("#useSealList").trigger("reloadGrid");
	}
}

/**
 * 显示用印申请详情
 * 
 * @param detail
 */
function showUseSealDetail(detail){
	// 详情窗口
	$("#useSealApplyInfo").dialog("open");
	$("#imgDiv").html("<table style='width:100%;height:100%;border:0px;position:absolute;' cellPadding=0 cellSpacing=0><tr></tr><tr></tr></table>");
	try{
		if (detail.storeId) {
			var docObjects = fileStore.syncDownload(detail.storeId);
			for(var i=0;i<docObjects.length;i++){
				var mediatype = docObjects[i].propertyList.mediatype;
				if(mediatype != null && mediatype == "endorse"){
					$("#imgDiv tr:eq(0)").append("<td style='background-color:white;border-right: 2px solid #F2F5F7;' align=center valign=middle><img style='width:98%;visibility:hidden;' src='" + docObjects[i].fileUrl + "' title='双击查看大图片' ondblclick='showImage(this);' onload='adjustImage(this)' onerror='loadImageError(this)'></img></td>");
					$("#imgDiv tr:eq(1)").append("<td style='background-color:white;border-right: 2px solid #F2F5F7;' align=center>背书用印图像</td>");
				}
				
				if(mediatype != null && mediatype == "before"){
					$("#imgDiv tr:eq(0)").append("<td style='background-color:white;border-left: 2px solid #F2F5F7;' align=center valign=middle><img style='width:98%;visibility:hidden;' src='" + docObjects[i].fileUrl + "' title='双击查看大图片' ondblclick='showImage(this);' onload='adjustImage(this)' onerror='loadImageError(this)'></img></td>");
					$("#imgDiv tr:eq(1)").append("<td style='background-color:white;border-left: 2px solid #F2F5F7;' align=center>用印前图像</td>");
				}
			}
		} else {
			$("#imgDiv tr:eq(0)").append("<td style='background-color:white;border-right: 2px solid #F2F5F7;' align=center valign=middle><img style='width:98%;visibility:hidden;' src='' title='双击查看大图片' ondblclick='showImage(this);' onload='adjustImage(this)' onerror='loadImageError(this)'></img></td>");
			$("#imgDiv tr:eq(1)").append("<td style='background-color:white;border-right: 2px solid #F2F5F7;' align=center>用印图像</td>");
		}
	}catch(e){
		alert(e.message);
	}
	$("#useSealLogId").val(detail.autoId);
	$("#startTime").val(detail.recordDate +" "+detail.startTime);
	$("#storeId").val(detail.storeId);
	$("#detailAutoId").val(detail.autoId);
	$("#sealBizTypeName").val(detail.sealBizTypeName);
	$("#peopleName").val(detail.peopleName);
	$("#orgName").val(detail.orgName);
	$("#peoplePhoneNo").val(detail.peoplePhoneNo);
}

/**
 * 关闭详情页面
 */
function closeDetail(){
	try{
		var autoId = $("#detailAutoId").val();
		if(Utils.isNotEmpty(autoId)){
			var url = ctx + "/uss/mech/approvalUseSeal!unLockTask.action";
			var data = {"autoId" : autoId};
			Utils.ajax(url, data).doPost();
		}
	}catch(e){
		resetDetail();
		alert(e.message);
	}finally{
		$("#useSealApplyInfo").dialog("close");
	}
}

/**
 * 初始化详情页面
 */
function resetDetail(){
	$("#detailAutoId").val("");
	$("#sealBizTypeName").val("");
	$("#peopleName").val("");
	$("#orgName").val("");
	$("#peoplePhoneNo").val("");
	$("#imgDiv").empty();
	$("#storeId").val("");
	$("#startTime").val("");
	$("#sealMemo").val("");
	$("#useSealLogId").val("");
}

/**
 * 图片加强显示
 * 
 * @param img
 */
function showImage(img){
	var url = img.src;
	//useXvideo.viewImageByUrl(url,'CheckPrintPaperImgDLG','paperImgIterm');
}

/**
 * 调整图片比例
 * @param img
 */
function adjustImage(img) {
	setTimeout(function() {
		if($(img).height() > $("#imgDiv").height() - 20) {
			$(img).width("auto").height($("#imgDiv").height() - 20);
			$(img).closest("td").width("50%");
		}
		$(img).css("visibility", "visible");
		$("#imgDiv").css("overflow", "auto");
	}, 1);
}

function loadImageError(img) {
	$(img).parent().html("<h1>无图像</h1>");
}

/**
 * 审核通过
 */
function approvalPassed() {
	var autoId = $("#detailAutoId").val();
	var sealMemo = $("#sealMemo").val();
	$.ajax({
		type : "post",
		url : ctx + "/uss/mech/approvalUseSeal!approvalPass.action",
		data : {
			"autoId" : autoId,
			"sealMemo":sealMemo
		},
		dataType : "json",
		async : false,
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0"
					|| XMLHttpRequest.status != "200") {
			}
		},
		success : function(response) {
			if (response.state == "normal") {
				//启动查找视频的方法
				var storeId = $("#storeId").val();
				var startTime = $("#startTime").val();
				var useSealLogId = $("#useSealLogId").val();
				$("#useSealApplyInfo").dialog("close");
				if (storeId !=null && $.trim(storeId)!="") {
					document.getElementById("sealUseVideoBody").innerHTML = "<div align='center'><font color='red' size='14px;'>等待用印视频...</font></div>";
					$("#sealUseVideoDialog").dialog("open");
					var approvalTime = response.message;
					var startPos = 0;
					if (startTime !=null && $.trim(startTime)!="") {
						var startDateTime = new Date(startTime.replace(/-/g,"/"));
						var ms = approvalTime -startDateTime.getTime();  //时间差的毫秒数
						var s = parseInt(ms/1000/1.2) - 3;//总秒数
						if (s < 0) {
							s = 0;
						}
						startPos = s;
//						embed 加 属性currentPosition="5"，表示从第几秒开始播放，单位是秒	
					}
//					lookupVideo(storeId, startPos);
					lookupUseSeal(useSealLogId, storeId, startPos);
				}
			} else if (response.state == "exception") {
				alert(response.data);
			}
		}
	});
}

function lookupUseSeal(autoId, storeId, startPos) {
	if (lookupUseSealTimer !=null) {
		clearTimeout(lookupUseSealTimer);
	}
	$.ajax({
		type : "post",
		url : ctx+"/uss/mech/applyUseSeal!findUseUseSealStatus.action",
		dataType : "json",
		async : false,
		data: {"autoId" : autoId},
		success : function(data) {
			if (data.webResponseJson.state == "normal") {
				var result = data.webResponseJson.data;
				if (result == "approval_pass") {//用印未完成，继续查询
					lookupUseSealTimer = setTimeout(function(){lookupUseSeal(autoId, storeId, startPos);}, 2000);
				} else {//查找视频
					document.getElementById("sealUseVideoBody").innerHTML = "<div align='center'><font color='red' size='14px;'>"+ussConstants.USE_SEAL_STATUS[result]+"</font><br/><font color='red' size='13px;'>等待用印视频...</font></div>";
					if (result == "finish" || result == "exe_before_video" || result == "exe_after_video"){
						lookupVideo(storeId, startPos);
					}
				}
			} else if (data.webResponseJson.state == "exception") {
				alert(response.data);
			}
		}
	});
}

function lookupVideo(storeId, startPos) {
	if (lookupVideoTimer !=null) {
		clearTimeout(lookupVideoTimer);
	}
	try{
		var docObjects = fileStore.syncDownload(storeId);
		var videoUrl = "";
		for(var i=0;i<docObjects.length;i++){
			var mediatype = docObjects[i].propertyList.mediatype;
			if(mediatype != null && mediatype == "video"){
				//用印视频获取成功
				videoUrl = docObjects[i].fileUrl;
				break;
			}
		}
		if (videoUrl != null && videoUrl != "") {
			 var html = " <iframe id='videoFrame' frameborder='no' border='0' marginwidth='0' marginheight='0' scrolling='no' src='"+ 
			 		ctx+"/gss/include/video.jsp?filePath=" + videoUrl + "&startPos="+ startPos +"' style='background:#F2F5F7;width:100%;height:98%;'/>";
			 document.getElementById("sealUseVideoBody").innerHTML = html;
		} else {
			lookupVideoTimer = setTimeout(function(){lookupVideo(storeId, startPos);}, 5000);
		}
	}catch(e){
		alert(e.message);
	}
}

/**
 * 审核拒绝
 */
function approvalRefused() {
	var autoId = $("#detailAutoId").val();
	var sealMemo = $("#sealMemo").val();
	if (sealMemo == null || $.trim(sealMemo)=="") {
		alert("审批意见不能为空");
		return;
	}
	$.ajax({
		type : "post",
		url : ctx + "/uss/mech/approvalUseSeal!approvalRefuse.action",
		data : {
			"autoId" : autoId,
			"sealMemo":sealMemo
		},
		dataType : "json",
		async : false,
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0"
					|| XMLHttpRequest.status != "200") {
			}
		},
		success : function(response) {
			if (response.state == "normal") {
				$("#useSealApplyInfo").dialog("close");
			} else if (response.state == "exception") {
				alert(response.data);
			}
		}
	});
}


/**
 * 关闭页面
 */
function closePage(){
	try{
		closeDetail();
	}catch(e){
		alert(e.message);
	}
}
