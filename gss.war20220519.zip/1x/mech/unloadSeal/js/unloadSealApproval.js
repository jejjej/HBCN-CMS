$(function() {

	initPage();

});

function initPage() {

	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight
			+ 6 - 50 * 2;
	// 审核机构列表
	$("#unloadSeallist")
			.jqGrid(
					{
						width : pageContentWidth,
						height : tableHeight + "px",
						url : ctx
								+ "/uss/mech/unloadSealApproval_queryUnloadSealTasks.action",
						multiselect : false,
						rowNum : 20,
						rowList : [ 20, 50, 100 ],
						rownumbers:true,
						colNames : [ "申请人", "设备编号", "印章模块编号", "申请机构", "申请日期",
								"申请时间", "操作" ],
						colModel : [

								{
									name : "unloadPeopleCode",
									index : "unloadPeopleCode",
									align : "center",
									sortable : false,
									formatter : function(value, options, rData) {
										if(value != null && value != ""){
											return rData.unloadPeopleName+"("+value+")";
										}
									}
								},

								{
									name : "deviceNum",
									index : "deviceNum",
									align : "center",
									sortable : false
								},
								{
									name : "sealModuleSn",
									index : "sealModuleSn",
									align : "center",
									sortable : false
								},
								{
									name : "orgSid",
									index : "orgSid",
									align : "center",
									sortable : false,
									formatter : "organization"
								},
								//{
								//	name : "firstApprovalPeopleCode",
								//	index : "firstApprovalPeopleCode",
								//	align : "center",
								//	sortable : false,
								//	formatter : function(value, options, rData) {
								//		if(value != null && value != ""){
								//			return rData.firstApprovalPeopleName+"("+value+")";
								//		}
								//	}
								//},
								{
									name : "unloadDate",
									index : "unloadDate",
									align : "center",
									sortable : false
								},
								{
									name : "unloadTime",
									index : "unloadTime",
									align : "center",
									sortable : false
								},
								{
									name : "autoId",
									index : "autoId",
									align : "center",
									sortable : false,
									formatter : function(value, options, rData) {
										return "<input type='button'  value='通过' onclick='approvalPassed(\""
												+ value
												+ "\")'/><input type='button'  value='拒绝' onclick='approvalRefused(\""
												+ value + "\")'  />";
									}
								} ],
						pager : "#unloadSealPager",
						caption : "审批任务列表"
					}).trigger("reloadGrid");
	$("#unloadSeallist").navGrid("#unloadSealPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
}

function approvalPassed(bizKey) {
	if(confirm("是否确认通过！")){
		$.ajax({
			type : "post",
			url : ctx + "/uss/mech/unloadSealApproval_approvalPassed.action",
			data : {
				"id" : bizKey
			},
			dataType : "json",
			async : false,
			complete : function(XMLHttpRequest, textStatus) {
				if (XMLHttpRequest.readyState == "0"
						|| XMLHttpRequest.status != "200") {
					alert("服务型无响应");
				}
			},
			success : function(response) {
				if (response.success) {
					initPage();
				} else {
					initPage();
					alert("提交失败！");
				}
			}
		});
	}
}
function approvalRefused(bizKey) {
	if(confirm("是否确认拒绝！")){
		$.ajax({
			type : "post",
			url : ctx + "/uss/mech/unloadSealApproval_approvalRefused.action",
			data : {
				"id" : bizKey
			},
			dataType : "json",
			async : false,
			complete : function(XMLHttpRequest, textStatus) {
				if (XMLHttpRequest.readyState == "0"
						|| XMLHttpRequest.status != "200") {
					alert("服务型无响应");
				}
			},
			success : function(response) {
				if (response.success) {
					initPage();
				} else {
					alert("提交失败！");
					initPage();
				}
			}
		});
	}
}