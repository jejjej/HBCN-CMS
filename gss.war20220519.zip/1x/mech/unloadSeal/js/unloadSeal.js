/**
 * 锁章模块装卸js
 *
 * @Description 用于锁章模块装卸
 * @author HuangKunping
 * @Date 2016-03-04
 */

function pageInit() {
	if(!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, ctx+'/activex/api/', 'run', 1, 1)){
		alert("通用控件初始化失败");
		return;
	}
	if (!ocxObject.initOcx(ocxObject.OCX_MachineOrder,document.body,ctx+'/activex/api','run',1,1)) {
		alert("印控机控件初始化失败");
		return;
	}
	//印控机初始化
	var initRet = machineOrder.intMachine(function(result) {
		if (result == 0) {
			showMsg("设备已连接");
		} else {
			showMsg("设备已断开");
			disableUnloadSealModuleBtn(true);
		}
	});
	if (initRet != "0") {
		showMsg(initRet);
	} else {
		showMsg("设备连接正常");
	}
}

/**
 * 页面按钮触发事件
 */
function unloadSealModuleBtn() {
	new unloadSeal(showMsg).start({
		orgSid : LoginPeople.getOrgSid(),
		peopleCode : LoginPeople.getPeopleCode()
	});
}

function unloadSeal(msgHanlder) {
	var bizMode = "unload_seal";//
	var sealLog = null;//印章装卸日志
	var that = this;

	/**
	 * 页面显示
	 * @param msg
	 */
	this.info = function(msg) {
		msgHanlder(msg);
	};

	this.start = function(param) {
		try {
			var queryMachineSNRet = OCX_MachineOrder.queryMachineSN();
			Utils.checkEquals("1001", queryMachineSNRet.code, "获取设备编号失败");
			//锁章模块装卸前初始化
			init(param.orgSid, queryMachineSNRet.data, getSealSN());
			if (isOutStampModule()) {//机械臂已弹出
				this.info("设备机械臂已弹出，请按复位键！");
				unloadSeal();
			} else {//机械臂未弹出
				//预先清除按键信息
				var reVal = OCX_MachineOrder.getSealNumber().data;
				if (reVal > 0 && reVal < 9) {// 如果有印章号则初始化一遍设备
					OCX_MachineOrder.initialization();
				};
				//进行锁章模块装卸操作
				if (Utils.isEmpty(sealLog.sealModuleSn)) {
					unloadSeal();
				} else {
					//进行权限校验
					var checkPowerRet = smsInterface.checkSealModuleHandlingPower(sealLog.sealModuleSn, param.peopleCode);
					Utils.checkEquals("0", checkPowerRet, checkPowerRet);
					auth(param.peopleCode, bizMode);//授权装卸印章
				}
			};
		} catch (e) {
			this.info(e.message);
		}
	};

	function auth(peopleCode, bizMode) {
		//获取审批模式
		var approvalMode = ussInterface.getApprovalModeByOrgAndBiz(peopleCode, bizMode);
		switch (approvalMode) {
			case "none":
				noneAuth();
				break;
			case "local" :
				localAuth();
				break;
			case "remote" :
				remoteAuth();
				break;
			default:
				otherAuth();
				break;
		}
	}

	/**
	 * 无需审批锁章模块装卸模式
	 */
	function noneAuth() {
		saveLog(sealLog, false);
		unloadSeal();
	}

	/**
	 * 本地锁章模块装卸模式
	 */
	function localAuth() {
		var operAuth = new top.OperAuth();
		operAuth.operType = "unloadSeal"; // 权限
		operAuth.authSuccess = function(confirmPersonnel) {
			if (!confirmPersonnel) {
				that.info("未配置现场授权权限，请联系技术人员！");
			} else {
				sealLog.localApprovalPeopleCode = confirmPersonnel;
				saveLog(sealLog, false);
				unloadSeal();
			}
		};
		operAuth.authCancel = function() {
//			sealLog.state = "refuse";
//			sealLog.unloadMemo = "装卸锁章模块现场审核不通过";
//			saveUnloadLog(sealLog);
//			that.info("装卸锁章模块失败,现场审批拒绝.");
		};
		operAuth.auth();
	}

	/**
	 * 远程锁章模块装卸模式
	 */
	function remoteAuth() {
		sealLog = saveLog(sealLog, true);
		openMask({}, "装卸锁章模块远程审批中...", function(){}, true);
		(function getRemoteResult(id) {
			var remoteRet = Utils.ajax(ctx + "/uss/mech/unloadSeal_findUnloadSealModuleResult.action",
				{id : id}).doPost();
			if (remoteRet.data.state == "normal") {
				var remoteState = remoteRet.data.state;
				if (remoteState == "waiting") {
					setTimeout(function(){getRemoteResult(id)}, 2000);
				} else {
					if (remoteState == "pass") {
						that.info("装卸锁章模块远程审核通过");
						unloadSeal();
					} else {//不通过
						if (remoteState == "refuse") {
							sealLog.state = "refuse";
							sealLog.unloadMemo = "装卸锁章模块远程审核不通过";
							saveUnloadLog(sealLog);
							that.info("装卸锁章模块远程审核不通过");
						} else {
							that.info("获取远程审批结果失败");
						}
						closeMask();
					}
				}
			}
		})(sealLog.autoId);
	}

	/**
	 * 其他装卸锁章模块模式
	 */
	function otherAuth() {
		that.info("卸载印章参数有误");
	}


	/**
	 * 锁章模块装卸操作
	 */
	function unloadSeal() {
		openMask({}, "装卸锁章模块正在进行中...", function(){}, true);
		var timeout = 1000;
		if (!isOutStampModule()) {//如果锁章模块没有弹出，则弹出锁章模块
			OCX_MachineOrder.getStampModule();
			timeout = 5000;//延时5000毫秒防止机器由于转章慢，还没移动机械臂就检测到他在原点
		}
		setTimeout(function(){
			checkFinish(finishCallback);
		}, timeout);
	}

	/**
	 * 操作完成后的回调函数
	 */
	function finishCallback() {
		sealLog.newSealModuleSn = getSealSN();
		saveLog(sealLog, false);
		closeMask();
		that.info("锁章模块操作完成！");
	}

	/**
	 * 打开遮罩层
	 * @param data
	 * @param msg
	 * @param callback
	 */
	function openMask(data, msg, callback, hidenCloseBtn) {
		if (!window.parent.document.getElementById("msgMaskDiv")) {
			commonMask.open({data:data, msg:msg}, window.parent.document, callback, hidenCloseBtn);
		}
	}

	/**
	 * 关闭遮罩层
	 */
	function closeMask(doClick) {
		commonMask.close(window.parent.document, doClick);
	}

	/**
	 * 检测机械臂是否已回到原点
	 * @param callback	回到原点后触发的回调函数
	 */
	function checkFinish(callback) {
		var unloadSealTimer = null;
		(function checkOver() {
			if (unloadSealTimer != null) {
				clearTimeout(unloadSealTimer);
				unloadSealTimer = null;
			}
			var pos = OCX_MachineOrder.queryMachinePos().data;
			if (pos >= 500) { // 机器臂回到原点
				setTimeout(function(){callback();}, 500);
			} else {
				unloadSealTimer = setTimeout(checkOver, 1000);
			};
		})();
	}

	/**
	 * 判断机械臂是否弹出
	 * @returns {boolean}
	 */
	function isOutStampModule() {
		var pos = OCX_MachineOrder.queryMachinePos().data;
		return parseInt(pos / 100) == 3;
	}

	/**
	 * 获取锁章模块编号
	 * @returns 锁章模块编号/""
	 */
	function getSealSN() {
		var queryMachineSNRet = OCX_MachineOrder.queryMachineSN();
		Utils.checkEquals("1001", queryMachineSNRet.code, "获取设备编号失败");
		var sealSN = queryMachineSNRet.data;
		if (sealSN != "-1" && sealSN != "-2") {
			return sealSN;
		} else {
			return "";
		}
	}

	/**
	 * 装卸印章前初始化
	 * @param orgSid	机构sid
	 * @param deviceNum	设备编号
	 */
	function init(orgSid, deviceNum, sealSN) {
		try {
			sealLog = {
				autoId : "",
				orgSid : orgSid,//机构sid
				deviceNum : deviceNum,//设备编号
				localApprovalPeopleCode : "",//本地审批人PeopleCode
				sealModuleSn : sealSN,//机械臂出来前锁章模块编号
				newSealModuleSn : "",//回到原点的锁章模块编号
				unloadType : "",//锁章模块装卸类型，锁章模块安装与锁章模块卸载
				unloadMemo : "",//操作说明
				state : "finish"
			};
		} catch (e) {
			throw e;
		}
	}

	/**
	 * 保存日志
	 * @param sealLog	日志
	 * @param isRemote	是否是远程审批
	 * @returns sealLog
	 */
	function saveLog(sealLog, isRemote) {
		sealLog = mappedLog(sealLog);
		if (isRemote) {
			return submitApprovalLog(sealLog);
		} else {
			return saveUnloadLog(sealLog);
		}
	}

	/**
	 * 保存日志
	 * @param sealLog	日志
	 * @returns sealLog
	 */
	function saveUnloadLog(sealLog) {
		try {
			var saveLogRet = Utils.ajax(ctx + "/uss/mech/unloadSeal_addUnloadSealModuleLog.action",
				sealLog).doPost();
			Utils.checkEquals("normal", saveLogRet.data.state, saveLogRet.data.message);
			sealLog = saveLogRet.data.data;
			return sealLog;
		} catch (e) {
			throw e;
		}
	}

	/**
	 * 保存审批日志
	 * @param sealLog	审批日志
	 * @returns sealLog
	 */
	function submitApprovalLog(sealLog) {
		try {
			var saveLogRet = Utils.ajax(ctx + "/uss/mech/unloadSeal_applyUnloadSealModule.action", sealLog).doPost();
			Utils.checkEquals("normal", saveLogRet.data.state, saveLogRet.data.message);
			sealLog = saveLogRet.data.data;
			return sealLog;
		} catch (e) {
			throw e;
		}
	}

	/**
	 * 映射锁章模块操作说明
	 * @param sealLog 印章装卸日志
	 * @returns 印章装卸日志
	 */
	function mappedLog(sealLog) {
		var oldSealSN = sealLog.sealModuleSn;
		var newSealSN = sealLog.newSealModuleSn;
		if (hasSealSN(oldSealSN)) {//原有锁章模块编号=======》卸章
			if (hasSealSN(newSealSN)) {//回到原点也有锁章模块编号
				sealLog.unloadType = "安装锁章模块";
				if (oldSealSN == newSealSN) {//新旧锁章模块编号相同
					sealLog.unloadMemo = ussConstants.UNLOAD_SEAL_MODULE_OPERATE_MEMO.haveSealModuleNoInstallNew;
				} else {//新旧锁章模块编号不相同
					sealLog.unloadMemo = ussConstants.UNLOAD_SEAL_MODULE_OPERATE_MEMO.haveSealModuleUpdate;
				}
			} else {//回到原点后无锁章模块编号
				sealLog.unloadType = "卸载锁章模块";
				sealLog.unloadMemo = ussConstants.UNLOAD_SEAL_MODULE_OPERATE_MEMO.haveSealModuleUnload;
			}

		} else {//原无锁章模块编号===============》装章
			if (hasSealSN(newSealSN)) {//回到原点后有锁章模块
				sealLog.unloadType = "安装锁章模块";
				sealLog.unloadMemo = ussConstants.UNLOAD_SEAL_MODULE_OPERATE_MEMO.noSealModuleInstallNew;
				sealLog.newSealModuleSn = newSealSN;
				//校验人员与锁章模块编号是否匹配

			} else {//回到原点后无锁章模块编号
				sealLog.unloadType = "卸载锁章模块";
				sealLog.unloadMemo = ussConstants.UNLOAD_SEAL_MODULE_OPERATE_MEMO.noSealModuleNoInstall;
			}
		}
		return sealLog;
	}

	/**
	 * 检查有锁章模块编号是否存在
	 * @param sealSN	锁章模块编号
	 * @returns {boolean}
	 */
	function hasSealSN(sealSN) {
		return sealSN != null && sealSN !=""
			&& sealSN != "-1" && sealSN != "-2";
	}
};

/**
 * 显示信息
 * @param msg
 */
function showMsg(msg) {
	$("#gatherSeal_MSG").text(msg);
}

/**
 * 设置印章装卸按钮是否可用
 * @param disable	true/false
 */
function disableUnloadSealModuleBtn(disable) {
	document.getElementById("unloadSealModuleBtn").disabled = disable;
}

/**
 * 离开页面 关闭通讯
 */
$.onunload(function() {
	machineOrder.closeMachine();
});