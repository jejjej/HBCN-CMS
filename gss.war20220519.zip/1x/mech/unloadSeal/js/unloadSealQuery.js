
/**
 * 页面加载
 */
function installSealModuleLogInit(){
	
	var pageDisplayMode = 1;
	var approvalModeRet = getApprovalModeByOrgAndBiz(top.loginPeopleInfo.orgNo, "unload_seal");
	if (approvalModeRet.success) {
		var approvalModel = approvalModeRet.data;
		if (approvalModel == "local" || approvalModel == "remote") {
			pageDisplayMode = 0;
		}
	}
	
	if(pageDisplayMode==1) {
		$("#firstApprovalPeopleCodeTd").html("");
	}
	
	//印控机信息列表
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() -2-8;
	pageHeaderHeight = pageHeaderHeight.substr(0,pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight -pageHeaderHeight + 6 - 50*2-5 ;
	//审核机构列表
	if(pageDisplayMode==0) {
		$("#installSealModuleLogList").jqGrid({width:pageContentWidth,height:tableHeight+"px",url:  ctx+"/uss/mech/unloadSealQueryAction!unloadSealModuleList.action",
			multiselect: false,rowNum: 20, rowList: [20,50,100], colNames:["操作人员","设备编号","旧模块编号","新模块编号","操作说明","操作日期","操作时间","审批人员"],colModel:[
		   		{name:"unloadPeopleCode",index:"unloadPeopleCode", align:"center",sortable:false,
		   			formatter : function(value, options, rData) {
		   				if(value != null && value != ""){
		   					return rData.unloadPeopleName+"("+value+")";
		   				}
		   			}
		   		},
		   		{name:"deviceNum",index:"deviceNum", align:"center",sortable:false},
		   		{name:"sealModuleSn",index:"sealModuleSn", align:"center",sortable:false},
		   		{name:"newSealModuleSn",index:"newSealModuleSn", align:"center",sortable:false},
		   		{name:"unloadMemo",index:"unloadMemo", width : 240,align:"center",sortable:false},
		   		{name:"unloadDate",index:"unloadDate", align:"center",sortable:false},
		   		{name:"unloadTime",index:"unloadTime", align:"center",sortable:false},
		   		{name:"firstApprovalPeopleCode",index:"firstApprovalPeopleCode", align:"center",sortable:false,
		   			formatter : function(value, options, rData) {
		   				if(value != null && value != ""){
		   					return rData.firstApprovalPeopleName+"("+value+")";
		   				} else if(rData.secondApprovalPeopleCode != null && rData.secondApprovalPeopleCode != ""){
			   				return rData.secondApprovalPeopleName+"("+rData.secondApprovalPeopleCode+")";
		   				} else {
		   					return "";
		   				}
		   			}
		   		}/*,
		   		{name:"secondApprovalPeopleCode",index:"secondApprovalPeopleCode", align:"center",sortable:false,
		   			formatter : function(value, options, rData) {
		   				if(value != null && value != ""){
		   					return rData.secondApprovalPeopleName+"("+value+")";
		   				}
		   			}
		   		}*/],
		   	rownumbers:true,
		   	pager: "#installSealModuleLogListPager"
		});
	} else if(pageDisplayMode==1) {
		$("#installSealModuleLogList").jqGrid({width:pageContentWidth,height:tableHeight+"px",url:  ctx+"/uss/mech/unloadSealQueryAction!unloadSealModuleList.action",
			multiselect: false,rowNum: 20, rowList: [20,50,100], colNames:["操作人员","设备编号","旧模块编号","新模块编号","操作说明","操作日期","操作时间"],colModel:[
		   		{name:"unloadPeopleCode",index:"unloadPeopleCode", align:"center",sortable:false,
		   			formatter : function(value, options, rData) {
		   				if(value != null && value != ""){
		   					return rData.unloadPeopleName+"("+value+")";
		   				}
		   			}
		   		},
		   		{name:"deviceNum",index:"deviceNum", align:"center",sortable:false},
		   		{name:"sealModuleSn",index:"sealModuleSn", align:"center",sortable:false},
		   		{name:"newSealModuleSn",index:"newSealModuleSn", align:"center",sortable:false},
		   		{name:"unloadMemo",index:"unloadMemo", width : 240,align:"center",sortable:false},
		   		{name:"unloadDate",index:"unloadDate", align:"center",sortable:false},
		   		{name:"unloadTime",index:"unloadTime", align:"center",sortable:false}],
		   	rownumbers:true,
		   	pager: "#installSealModuleLogListPager"
		});
	}
	
	
	//导出
	//$("#reportInstallSealModuleLogExcel").click(function(){$(this).reportExcel($("#installSealModuleLogIterm"),ctx+"/gss/installSealModuleLogReportAction!report.action");});
}

function queryInstallSealModuleLog(){
	$("#installSealModuleLogList").jqGrid("search", "#installSealModuleLogIterm");
}


/**
 * 选择机构
 */
function checkOrganizationItem(orgSid){
	$("#orgSid_Item").dialogOrgTree("radio",top.loginPeopleInfo.orgSid,false,null,null,
			function(event, treeId, treeNode) {
				if (treeNode) {
					$("#"+orgSid+"_Item").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
					$("#"+orgSid).val(treeNode.sid);
				}
			});
}


function getApprovalModeByOrgAndBiz(orgNo, bizMode) {
	var result = {success: true, message:"", data:""};
	$.ajax({
		type : "post",
		url : ctx + "/uss/param/approvalModeParam_getApprovalModeByOrgAndBiz.action",
		data : { "orgNo" : orgNo, "approvalBiz" : bizMode },
		dataType : "json",
		async : false,
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0" || XMLHttpRequest.status != "200") {
				result.success = false;
				result.message = "网络异常或服务器异常.";
			}
		},
		success : function(response) {
			result.success = response.data.success;
			result.data = response.data.data;
			result.message = response.data.message;
		}
	});
	return result;
}