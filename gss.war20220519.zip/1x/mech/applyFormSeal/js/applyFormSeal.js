var sealTypeMap = new Map();// 印章类型集合
var applyOrgNames = new Array();// 申请机构列表
var imgNo = 0;// 单张拍照图像序号

function initExt() {
	showMsg("初始化中，请稍候……");
	$("#clearHistory, #newApply").attr("disabled","disabled");
	getSealTypes();// 获取印章类型
	getApplyOrgs();// 获取申请机构
	loadListFromCookie();// 加载Cookie信息
	// 显示申请单
	$("#sealUseApplyDLG").dialog({
		autoOpen : false,
		caption : "用印审批单登记",
		resizable : false,
		width : 620,
		height : 265,
		modal : true,
		buttons : {
			"确认" : function(event) {
				confirmApplicationForm();
			},
			"取消" : function() {
				$("#sealUseApplyDLG").dialog("close");
			}
		}
	});
	// 初始化显示历史申请单用印
	$("#applyHistoryDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 450,
		width : 750,
		modal : true,
		buttons : {
			"取消" : function() {
				restHistoryQuery();
				$("#applyHistoryDLG").dialog("close");
			}
		},
		open : function() {
			checkSealHistory();
		}
	});

	// 绑定点击事件
	$("#applyHistory").click(function() {
		$("#applyHistoryDLG").dialog("open");
	});
	$("#clearHistory").click(function() {
		cannelSelectHistory();
	});
	$("#querySealLogForTerm").click(function() {
		$("#applyHistoryList").jqGrid("search", "#sealLogIterm");
	});
	$("#resetBtn").click(function() {
		restHistoryQuery();
	});
	$("#approvePeopleList li,#applyPeopleList li,#unitNameList li").live("mouseover", function() {
				$(this).css("background", "#ccc");
			}).live("mouseout", function() {
		$(this).css("background", "white");
	});
	
	createTipList("approvePeopleList", "approvePeople");
	createTipList("unitNameList", "unitName");
	createTipList("applyPeopleList", "applyPeople");
	
	$("#newApply").click(function() {
		applyID = "";
		$("#clearHistory,#newApply").attr("disabled","disabled");
		$("#sealRecordContent_body, #sealImageContent_body").empty();
		$("#autoId").val("");
		$("#sealUseApply").find(":input").not("#clearHistory, #newApply").removeAttr("disabled");
		$("#stopgather, #singlePicture, #qifgButton").attr("disabled","disabled");//停止用印按钮不可用
		$("#qifgStamp").val("");
		$("#qifgStamp").hide();
		$("#qifgButton").val("骑缝印章");
		$("#startgather").removeAttr("disabled");//开始用印按钮可用
	});
}


/**
 * 获取印章类型
 */
function getSealTypes() {
	try {
		var getSealTypesRet = Utils.ajax(ctx + "/sms/config/sealTypeConfig_gainAll.action").doPost();
		var sealTypeContent = "<option value=' '>请选择</option>";
		if (getSealTypesRet.data.sealTypePageModels) {
			$.each(getSealTypesRet.data.sealTypePageModels,
					function(index, sealType) {
						sealTypeContent += "<option value='" + sealType.type + "'>" + sealType.name + "</option>";
						sealTypeMap.put(sealType.type + "", sealType.name);
					});
		}
		$("#sealTypeId").html(sealTypeContent);
		$("#sealTypeIdItem").html(sealTypeContent);
	} catch (e) {
		alert(e.message)
	}
}

/**
 * 获取申请机构
 */
function getApplyOrgs() {
	try {
		var getApplyOrgsRet = Utils.ajax(ctx + "/uss/param/applyOrgParamAction_applyOrgListNative.action?pageSize=" + 2000).doPost();
		$("#toDepartment").append("<option value=''>请选择</option");
		$.each(getApplyOrgsRet.data.applyOrgs, function(i, applyOrg) {
			$("#toDepartment").append( "<option value='" + applyOrg.applyOrgName + "'>" + applyOrg.applyOrgName + "</option");
		});
	} catch (e) {
		alert(e.message);
	}
}

/**
 * 打开用印申请书界面
 */
function openApplyFormDialog() {
	if ($.trim($("#projectName").val()) == "") {
		alert("请输入项目名称");
		$("#projectName").focus();
		return;
	}
	if ($.trim($("#sealTypeId").val()) == "") {
		alert("请选择印章名称");
		$("#sealTypeId").focus();
		return;
	}
	if ($.trim($("#toDepartment").val()) == "") {
		alert("请选择申请机构");
		$("#toDepartment").focus();
		return;
	}
	if ($.trim($("#applyPeople").val()) == "") {
		alert("请输入申请人");
		$("#applyPeople").focus();
		return;
	}
	if ($.trim($("#approvePeople").val()) == "") {
		alert("请输入签准人");
		$("#approvePeople").focus();
		return;
	}
	if ($.trim($("#unitName").val()) == "") {
		alert("请输入发至单位");
		$("#unitName").focus();
		return;
	}
	$.each($("#sealUseApply").find(":input").not("#applyHistory, select"),
			function(index, ele) {
				$("#" + $(ele).attr("id") + "_show").text($(ele).val());
			});
	$("#sealTypeId_show").text($("#sealTypeId option:selected").text());
	$("#toDepartment_show").text($("#toDepartment option:selected").text());
	$("#sealUseApplyDLG").dialog("open");
}

/**
 * 确认申请单
 */
function confirmApplicationForm() {
	storeListToCookie();
	$("#sealUseApply").find(":input").attr("disabled", true);
	// 初始化用印申请页面
	var applyAutoId = $.trim($("#autoId").val());
	if (Utils.isNotEmpty(applyAutoId)) {
		connectMachine();// 开始用印
		applyID = applyAutoId;
		$("#sealUseApplyDLG").dialog("close");
	} else {
		var url = ctx + "/uss/mech/usApplyFormAction_addSealUseApply.action";
		var param = {
			"usApplyForm.projectName" : $.trim($("#projectName").val()),
			"usApplyForm.sealTypeId" : $.trim($("#sealTypeId").val()),
			"usApplyForm.toDepartment" : $.trim($("#toDepartment").val()),
			"usApplyForm.projectCount" : $.trim($("#projectCount").val()),
			"usApplyForm.approveFile" : $.trim($("#approveFile").val()),
			"usApplyForm.applySealCount" : $.trim($("#applySealCount").val()),
			"usApplyForm.approvePeople" : $.trim($("#approvePeople").val()),
			"usApplyForm.applyPeople" : $.trim($("#applyPeople").val()),
			"usApplyForm.unitName" : $.trim($("#unitName").val())
		};
		try {
			// 添加用印申请记录
			var addSealApplyRet = Utils.ajax(ctx + "/uss/mech/usApplyFormAction_addSealUseApply.action", param).doPost();
			if (addSealApplyRet.success == "SUCCESS") {
				applyID = addSealApplyRet.data.usApplyForm.autoId;
				imgNo = 0; // 重置申请图片序号
				connectMachine();// 开始用印
				$("#applyHistoryList").trigger("reloadGrid");
				$("#sealUseApplyDLG").dialog("close");
			} else {
				showMsg("确认申请单出现错误。");
				Utils.handleExceptions("确认申请单出现错误。");
			}
		} catch (e) {
			alert(e.message);
			return;
		}
	}
	showMsg("设备等待用印...");
}

/**
 * 单张拍照
 */
function singlePicture() {
	var isOpenCamera = false;
	try {
		showMsg("单张拍照开始……");
		var photoPath = ussConstants.DEFAULT_SINGLE_CAPTRUE_IMAGE_PATH + "YZJ_YKMS_" + loginPeople.orgNo + loginPeople.peopleCode + (new Date()).Format("yyyyMMddhhmmssS") + "_singleCapture.jpg";
		var openCameraRet = xUSBVideo.openCamera("PHOTO");
		if(openCameraRet != 0) {//摄像头打开成功
			showMsg(openCameraRet);
			OCX_Logger.debug(LOGGER._1X,"{applyFormSeal.singlePicture}--拍照摄像头打开失败");
			return;
		}
		isOpenCamera = true;
		// 延时拍照
		setTimeout(function() {
			var result = xUSBVideo.captureImage(photoPath, "", singleCaptureCutMode);
			if (result == "0") {//拍照成功
				fileStore.asyncUpload(photoPath, "", function(responseMessage) {
					if (responseMessage.success) {//文件上传成功
						OCX_Logger.info(LOGGER._1X,"{applyFormSeal.singlePicture}--上传用印前图像成功");
						// 添加拍照记录
						var url = ctx + "/uss/mech/applyImagesAction_addApplyImages.action";
						var param = { "applyImages.applyId" : applyID, "applyImages.storeId" : responseMessage.storeId };
						var addApplyImageRet = Utils.ajax(ctx + "/uss/mech/applyImagesAction_addApplyImages.action", param).doPost();
						if (addApplyImageRet.success && addApplyImageRet.success == "SUCCESS") {// 保存成功
							WTFileUtil.deleteFile(photoPath);
							showSingleCapture(addApplyImageRet.data.applyImages);
							showMsg("单张拍照成功");
						} else {
							showMsg("图片信息数据库保存失败.");// 数据库保存异常
						}
					} else {//文件上传失败
						Utils.handleExceptions("用印前图像上传失败...");
						OCX_Logger.error(LOGGER._1X,"{applyFormSeal.singlePicture}--用印前图像上传失败：" + photoPath);
					}
				});
				if (isOpenCamera && xUSBVideo.closeCamera() != 0) {
					OCX_Logger.error(LOGGER._1X,"{applyFormSeal.singlePicture}--摄像头关闭失败");
				}
			} else {
				Utils.handleExceptions("单张拍照失败");
			}
		}, singleCaptureDelay);
	} catch (e) {
		if (isOpenCamera && xUSBVideo.closeCamera() != 0) {
			OCX_Logger.error(LOGGER._1X,"{applyFormSeal.singlePicture}--摄像头关闭失败");
		}
		alert(e.message);
	}
}

/**
 * 单张拍照成功后的处理
 * 
 * @param data
 *            数据
 */
function showSingleCapture(applyImage) {
	imgNo = imgNo + 1;
	var html;
	if (Utils.isEmpty(applyImage.storeId)) {
		html = "<tr><td style='border-left:none;'>" + imgNo + "</td><td style='border-right:none;'>无图像</td></tr>";
	} else {
		html = "<tr><td style='border-left:none;'>" + imgNo + "</td><td style='border-right:none;'><img src='"
			+ ctx + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;'"
			+ " alt='查看图像' title='查看图像' onclick=\"window.parent.startViewImage('"+ applyImage.storeId + "', 'singleCapture');\"/></td></tr>";
	}
	$("#sealImageContent_body").append(html);
	$(".list-div").scrollTop(50000);
	document.getElementById("singlePicture").disabled = false;
}

function qifgButton() {
	if ($("#qifgButton").val() == "骑缝印章") {
		$("#qifgButton").val("取消骑缝");
		$("#qifgStamp").val("");
		$("#qifgStamp").show();
	} else {
		$("#qifgButton").val("骑缝印章");
		$("#qifgStamp").val("");
		$("#qifgStamp").hide();
	}
}

var queryFlag = false;// 解决再次打开对话框还是用以前的检索条件完成查询操作
function checkSealHistory() {
	if (queryFlag) {
		$("#applyHistoryList").jqGrid("search", "#sealLogIterm");
	} else {
		queryFlag = true;
		var pageHeaderHeight = $(".pageHeader").css("height");
		var pageContentWidth = $(".pageContent").width() - 2;
		pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
		var tableHeight = 240;
		var historyUrl = ctx + "/uss/mech/usApplyFormAction_sealUseApplyList.action?usApplyForm.organizationSid=" + LoginPeople.getOrgSid();
		$("#applyHistoryList").jqGrid({
			url : historyUrl,
			multiselect : false,
			rowNum : 20,
			rowList : [ 20, 50, 100 ],
			colNames : historyColNames,
			colModel : historyColModel,
			pager : "#applyHistoryListPager",
			width : pageContentWidth,
			height : tableHeight + "px",
			ondblClickRow : function(id) {
				ondblClickRow(id);
			}
		});
	}
}

function ondblClickRow(id) {
	var rowData = $("#applyHistoryList").jqGrid("getData", id);
	$("#autoId").val(rowData.autoId);
	$("#projectName").val(rowData.projectName);
	$("#sealTypeId").val(rowData.sealTypeId);
	$("#toDepartment").val(rowData.toDepartment);
	$("#projectCount").val(rowData.projectCount);
	$("#approveFile").val(rowData.approveFile);
	$("#applySealCount").val(rowData.applySealCount);
	$("#applyPeople").val(rowData.applyPeople);
	$("#approvePeople").val(rowData.approvePeople);
	$("#unitName").val(rowData.unitName);
	$("#applyMemo").val(rowData.applyMemo);
	$("#sealUseApply").find(":input").not("#clearHistory, #newApply").attr("disabled", "disabled");
	$("#clearHistory, #newApply").removeAttr("disabled");
	$("#clearHistory, #newApply").removeClass("ui-state-disabled").removeClass("ui-state-focus").attr("aria-disabled", "false");
	$("#sealUseApply").validationEngine("hideAll");
	// 用印明细
	var sealDetailUrl = ctx + "/uss/log/useSealLogQueryAction!sealLogList.action?queryBean.params.applyFormId="
			+ rowData.autoId + "&pageSize=" + 2000;
	$.ajax({
		type : "post",
		url : sealDetailUrl,
		dataType : "json",
		async : false,
		success : function(data) {
			if (data.pageBean.data) {
				$.each(data.pageBean.data, function(index, sealLog) {
					showSealLog(sealLog);
				});
			}
		}
	});

	var applyImageUrl = ctx + "/uss/mech/applyImagesAction_applyImagesList.action?applyId=" + rowData.autoId + "&pageSize=" + 2000;
	// 用印申请图片
	$.ajax({
		type : "post",
		url : applyImageUrl,
		dataType : "json",
		async : false,
		success : function(data) {
			if (data.pageBean.data) {
				imgNo = 0;// 重置申请图片序号
				$.each(data.pageBean.data, function(index, applyImage) {// 保存成功
					showApplyImage(index, applyImage);
				});
			}
		}
	});
	$("#applyHistoryDLG").dialog("close");
}

function showApplyImage(index, applyImage) {
	imgNo = imgNo + 1;
	var html;
	if (Utils.isEmpty(applyImage.storeId)) {
		html = "<tr><td style='border-left:none;'>"
			+ imgNo
			+ "</td><td style='border-right:none;'>无图像</td></tr>";
	} else {
		html = "<tr><td style='border-left:none;'>"
				+ imgNo
				+ "</td><td style='border-right:none;'><img src='"
				+ ctx
				+ "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;'"
				+ " alt='查看图像' title='查看图像' onclick=\"window.parent.startViewImage('"
				+ applyImage.storeId + "', 'singleCapture');\"/></td></tr>";
	}
	$("#sealImageContent_body").append(html);
}

/**
 * 显示提示列表信息
 * @param listId	列表ID
 * @param inputId	文本框ID
 */

function createTipList(listId, inputId) {
	$("#"+listId + " li").live("click", function() {
		$("#" + inputId).val($.trim($(this).text()));
	});
	$("#" + inputId).focus(function() {
		$("#" + listId).show();
	}).click(function() {
		$("#" + listId).show();
	}).blur(function() {
		$("#" + listId).fadeOut("fast");
	});
}


/**
 * 从cookie中获取缓存信息
 */
function loadListFromCookie() {
	getValFromCookie("approvePeopleList", "approvePeople");// 签准人
	getValFromCookie("unitNameList", 	  "unitName");// 发至单位
	getValFromCookie("applyPeopleList",   "applyPeople");// 申请人
}

/**
 * 将缓存信息存储到Cookie中
 */
function storeListToCookie() {
	setValToCookie("approvePeople", $("#approvePeople").val());
	setValToCookie("unitName", 	    $("#unitName").val());
	setValToCookie("applyPeople",   $("#applyPeople").val());
}

function getValFromCookie(listId, key) {
	var val = WTCookieUtil.getCookie(key);
	if (val) {
		$("#" + listId).empty();
		var vals = val.split("||");
		$.each(vals, function(i, d) {
			if (d != "") {
				$("#" + listId).append("<li>" + d + "</li>");
			}
		});
	}
}

function setValToCookie(key, val) {
	var cookieVal = WTCookieUtil.getCookie(key);
	if (!cookieVal) {
		cookieVal = "||";
	}
	cookieVal = cookieVal.replace("||" + val + "||", "||");
	cookieVal = "||" + val + cookieVal;
	cookieVal = cookieVal.replace(/^((\|\|[^|]+){0,10}).*$/, "$1||");
	WTCookieUtil.setLongTimeCookie(key, cookieVal);
}

var historyColNames = [ "项目名称", "印章名称", "申请机构", "申请人", "签准人", "发至单位", "操作人员",
		"申请时间" ];
var historyColModel = [ {
	name : "projectName",
	index : "projectName",
	align : "center",
	width : 80,
	sortable : false
}, {
	name : "sealTypeId",
	index : "sealTypeId",
	align : "center",
	sortable : false,
	width : 70,
	formatter : function(value, options, rData) {
		return sealTypeMap.get(value);
	}
}, {
	name : "toDepartment",
	index : "toDepartment",
	align : "center",
	width : 80,
	sortable : false
}, {
	name : "applyPeople",
	index : "applyPeople",
	align : "center",
	width : 70,
	sortable : false
}, {
	name : "approvePeople",
	index : "approvePeople",
	align : "center",
	width : 70,
	sortable : false
}, {
	name : "unitName",
	index : "unitName",
	align : "center",
	width : 90,
	sortable : false
}, {
	name : "personnelSid",
	index : "personnelSid",
	align : "center",
	width : 80,
	sortable : false,
	formatter : "formatPersonnel"
}, {
	name : "applyTime",
	index : "applyTime",
	align : "center",
	width : 120,
	sortable : false
} ];

/**
 * 取消历史选择
 */
function cannelSelectHistory() {
	applyID = "";
	$("#clearHistory,#newApply").attr("disabled", "disabled");
	
	$("#sealUseApply").find(":input").not("#applyHistory, #clearHistory, #newApply, select").val("");
	$("#toDepartment").val("");
	$("#sealTypeId").val(" ");
	$("#sealRecordContent_body, #sealImageContent_body").empty();
	
	$("#sealUseApply").find(":input").not("#clearHistory, #newApply").removeAttr("disabled");
	$("#stopgather, #singlePicture, #qifgButton").attr("disabled", "disabled");// 停止用印按钮不可用
	$("#qifgStamp").val("");
	$("#qifgStamp").hide();
	$("#qifgButton").val("骑缝印章");
	$("#exce11").text("");
	$("#startgather").removeAttr("disabled");// 开始用印按钮可用
}

/**
 * 清空历史申请单的查询条件
 */
function restHistoryQuery() {
	$("#ge_applyTime").val("");
	$("#le_applyTime").val("");
	$("#personnelSid").val("");
	$("#like_applyPeople").val("");
	$("#sealTypeIdItem").val(" ");
}

/*************************************** 页面按钮设置 ********************************************/
/**
 * 设置开始按钮/停止用印按钮状态
 * @param startState	开始用印按钮状态，true:不可用，false：可用
 * @param stopState		停止用印按钮状态，true:不可用，false：可用
 */
/**
 * 设置开始按钮/停止用印按钮状态
 * 
 * @param startState
 * @param stopState
 */
function startStopDisabled(startState,stopState){
	if(!startState){ // 如果是开始按钮启用（sartState=false），则延时2秒
		setTimeout(function(){
			applyID = "";
			$("#toDepartment").val("");
			$("#sealTypeId").val(" ");
			$("#startgather").removeAttr("disabled");// 停止用印按钮不可用
			$("#sealUseApply").find(":input").not("#applyHistory, #clearHistory, #newApply, select").val("");
			$("#sealRecordContent_body, #sealImageContent_body").empty();
			$("#sealUseApply").find(":input").attr("disabled", "disabled");
			$("#sealUseApply").find(":input").not("#clearHistory, #newApply").removeAttr("disabled");
		},1000);
		$("#singlePicture, #qifgButton").attr("disabled", "disabled");
	}else{
		$("#startgather").attr("disabled", "disabled");
	}
	if(!stopState){ // 如果是停用按钮启用（sartState=false），则延时2秒
		setTimeout(function(){
			$("#stopgather, #singlePicture, #qifgButton").removeAttr("disabled");
		},1000);
	}else{
		$("#stopgather").attr("disabled", "disabled");
	}
}
