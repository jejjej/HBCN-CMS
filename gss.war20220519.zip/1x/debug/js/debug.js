/**
 * GSS本地调试JS
 * 
 * @author 李水野
 * @version 1.0
 * @date 2015-05-06
 */

LOGGER = {
			"_1X" : "1x",
			"_3X" : "3x",
			"_SMS": "sms",
			"_GSS": "gss",
			"_ROOT" : "root"
	};

/**
 * 页面初始化
 */
function init() {
	var operateDiv = document.getElementById("operateDiv");
	var operateFrame = document.getElementById("operateFrame");
	operateFrame.style.height = operateDiv.clientHeight;
}

/**
 * 显示设备调试界面
 */
function showMachineDebug() {
	var operateFrame = document.getElementById("operateFrame");
	operateFrame.src = "machineDebug.html";
}

/**
 * 显示设备调试界面
 */
function showCameraDebug() {
	var operateFrame = document.getElementById("operateFrame");
	operateFrame.src = "cameraDebug.html";
}

/**
 * 显示操作结果
 * 
 * @param title
 *            标题
 * @param messgage
 *            操作结果
 */
function showResult(title, message) {
	var content = (new Date()).format("hh:mm:ss") + "  " + title + " " +  (message ||"") + "\r\n"
			+ top.window.document.getElementById("msgTextArea").value;
	if (content.length > 10000)
		content = content.substring(0, 10000);
	top.window.document.getElementById("msgTextArea").value = content;
}

/**
 * 清除日志
 */
function clearLog() {
	top.window.document.getElementById("msgTextArea").value = "";
}

/**
 * 设置按钮不可用
 * 
 * @param obj
 *            按钮
 */
function enableButton(obj) {
	obj.disabled = false;
}

/**
 * 设置按钮可用
 * 
 * @param obj
 *            按钮
 */
function disableButton(obj) {
	obj.disabled = true;
}

/**
 * 休眠指定的时间
 * 
 * @param obj
 * @param iMinSecond
 *            指定的时间
 */
function sleep(obj, iMinSecond) {
	if (window.eventList == null)
		window.eventList = new Array();
	var ind = -1;
	for ( var i = 0; i < window.eventList.length; i++) {
		if (window.eventList[i] == null) {
			window.eventList[i] = obj;
			ind = i;
			break;
		}
	}
	if (ind == -1) {
		ind = window.eventList.length;
		window.eventList[ind] = obj;
	}
	setTimeout("goOn(" + ind + ")", iMinSecond);
}
function goOn(ind) {
	var obj = window.eventList[ind];
	window.eventList[ind] = null;
	if (obj.NextStep)
		obj.NextStep();
	else
		obj();
}