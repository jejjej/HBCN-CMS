
/**
 * G1610控件封装测试
 * 拍照
 * @author huangkunping
 * @version 1.0 
 * @Date 2015-11-19
 */


/**
 * 初始化控件
 */
function init() {
	if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, "../../", "run", 1, 1))
		alert("通用工具类控件初始化失败");
	if (!ocxObject.initOcx(ocxObject.OCX_XUSBVideo, document.getElementById("xUSBVideoView"), "../../", "run", 320, 480))
		alert("拍照控件初始化失败");
	
	var list = getCameras();
	var cameraSelect = window.document.getElementById("cameraIndex");
	for ( var i = 0; i < list.length; ++i) {
		var option = window.document.createElement("option");
		option.setAttribute("value", list[i].index);
		option.innerText = list[i].index + " - " + list[i].name;
		cameraSelect.appendChild(option);
	}
	
	cameraSelect.onchange = function() {
		var resSelect = window.document.getElementById("resolutionInfo");
		var cameraIndex = cameraSelect.value;
		var resList = getResolutions(cameraIndex);
		resSelect.innerHTML = '';
		for ( var i = 0; i < resList.length; ++i) {
			var resOption = window.document.createElement("option")
			resOption.setAttribute("value", resList[i].index);
			resOption.innerText = resList[i].index + "-["
					+ resList[i].format + "]" + resList[i].width + "x"
					+ resList[i].height;
			resSelect.appendChild(resOption);
		}
		if (resList.length > 0) {
			resSelect.options[0].setAttribute("selected", "selected");
		}
	}
	if (list.length > 0) {
		cameraSelect.options[0].setAttribute("selected", "selected");
		cameraSelect.fireEvent("onchange");
	}
}

/**
 * 关闭摄像头
 */
function closeCamera1() {
	var ret = xUSBVideo.closeCamera();
	if (ret == 0) {
		showResult("关闭摄像头", "成功");
	} else {
		showResult("关闭摄像头", "失败");
	}
}

/**
 * 打开摄像头
 */
function openCamera1() {
	try {
		//type: 0拍照摄像头;1环境摄像头;3视频检测摄像头
		var type = window.document.getElementById("cameraIndex").value;
		if (type == 1) {//视频检测摄像头
			type = 3;
		} else if (type == 2) {//环境摄像头
			type = 1;
		}
		var ret = xUSBVideo.openCamera(type);
		if (ret == 0) {
			showResult("打开摄像头", "成功");
		} else {
			showResult("打开摄像头", ret);
		}
	} catch (e) {
		throw e;
	}
}

/**
 * 拍照
 */
function capture() {
	var isChecked = window.document.getElementById("isCut").checked;
	var path = window.document.getElementById("path").value;
    var name = (new Date()).Format("yyyyMMddhhmmssS");
    var filename = path + "\\" + name + ".jpg";
    var src_filename = path + "\\" + name + "_src.jpg";
    var ret = xUSBVideo.captureImage(filename, src_filename, isChecked ? 1 : 0);
    if (ret == 0) {
		try{
		    window.open("file:///" + filename, "_blank", "", "");
		}catch(e){}
			showResult("拍照成功", filename);
	} else {
		showResult("拍照失败", "");
	}
}

/**
 * 获取摄像头信息
 * @returns 摄像头信息数组 
 */
function getCameras() {
	var arr = new Array();
	try {
		var camCountRet = OCX_XUSBVideo.getDevicesCount();//获取摄像头个数
		Utils.checkEquals("1001", camCountRet.code, "获取摄像头个数失败");
		OCX_Logger.debug(LOGGER._1X,"{cameraDebug.getCameras}--摄像头个数:(" + camCountRet.data + ")");
		for (var i = 0; i < camCountRet.data; i++) {
			var device = new Object();
			device.index = i;
			device.name = OCX_XUSBVideo.getDevicesName(i).data; 
			device.videoInfoCount = OCX_XUSBVideo.getVideoInfoCount(i).data;
			arr.push(device);
		}
	} catch(e) {
		showResult("获取摄像头信息失败", e.message);
	}
	return arr;
};

function getResolutions(cameraIndex) {
	var resArray = new Array();
	try {
		var resCount = OCX_XUSBVideo.getVideoInfoCount(cameraIndex).data;
		for (var i = 0; i < resCount; ++i) {
			var res = new Object();
			res.index = i;
			res.width = OCX_XUSBVideo.getVideoInfoWidth(cameraIndex, i).data;
			res.height = OCX_XUSBVideo.getVideoInfoHeight(cameraIndex, i).data;
			res.format = "";
			resArray.push(res);
		};
	} catch (e) {
		showResult("获取摄像头分辨率信息失败", e.message);
	};
	return resArray;
};