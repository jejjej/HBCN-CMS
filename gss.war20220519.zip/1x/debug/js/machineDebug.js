/**
 * 设备本地调试JS
 * 
 * @author 李水野
 * @version 1.0
 * @date 2015-05-06
 */

var testTimes = 0;
var totalTestTimes = 0;
var interval = 0;

/**
 * 页面初始化
 */
function initMachinePage() {
	if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, "../../", "run", 1, 1))
		alert("通用工具类控件初始化失败");
	if (!ocxObject.initOcx(ocxObject.OCX_MachineOrder, document.body, "../../", "run", 1, 1))
		alert("用印控件初始化失败");
	var inputs = document.getElementsByTagName("input");
	for ( var i = 0; i < inputs.length; i++) {
		inputs[i].value="";
	}
	changeBtnEnableAfterCloseMachine();
	clearLog();
}

/**
 * 显示设备调试界面
 */
function showMachineDebug() {
	var operateFrame = document.getElementById("operateFrame");
	operateFrame.src = "machineDebug.html";
}

/**
 * 显示设备调试界面
 */
function showCameraDebug() {
	var operateFrame = document.getElementById("operateFrame");
	operateFrame.src = "cameraDebug.html";
}

/**
 * 初始化设备
 */
function initMachine() {
	var ret = machineOrder.intMachine(function (result) {
		if(result == 0){
			showResult("USB重新连接成功.");
		}else if(result == 1){
			showResult("USB已断开连接，请重新连接.");
		}
	});
	if (ret == 0) {
		changeBtnEnableAfterInitMachine();
		showResult("初始化设备成功");
	} else {
		showResult("初始化设备失败", ret);
	}
}

/**
 * 关闭设备
 */
function closeMachine() {
	var ret = machineOrder.closeMachine();
	if (ret == 0) {
		changeBtnEnableAfterCloseMachine();
		showResult("关闭设备成功");
	} else {
		showResult("关闭设备失败", ret);
	}
}

/**
 * 获取设备编号
 * 
 * @author 李水野
 * @date 2015-05-06
 */
function getMachineSN() {
	// 获取设备号
	var machineNum = OCX_MachineOrder.queryMachineSN().data;
	if (machineNum == "-1" || machineNum == "-2") {
		showResult("获取设备编号：", "出现错误。");
		return;
	}
	document.getElementById("deviceNumInput").value = machineNum;
	showResult("获取设备编号：", "获取成功，设备编号为：" + machineNum);
}

/**
 * 设置设备编号
 * 
 * @author 李水野
 * @date 2015-05-06
 */
function setMachineSN() {
	var machineSN = document.getElementById("deviceNumInput").value;
	var result = OCX_MachineOrder.setMachineSN(machineSN).data;
	if (0 == result) {
		showResult("设置设备编号：", "成功。");
	} else {
		showResult("设置设备编号：", "失败。");
	}
}

/**
 * 获取印章模块的编号
 * 
 * @author 李水野
 * @date 2015-05-06
 * 
 */
function getSealModuleSN() {
	var sealModuleSN = "";
	var deviceType = document.getElementById("deviceTypeSelect").value;
	showResult("获取印章模块的编号：", "选择的型号为：" + deviceType);
	if ("G16" == deviceType) {// G16
		sealModuleSN = OCX_MachineOrder.querySealSN().data;
		if (-1 == sealModuleSN || -2 == sealModuleSN) {
			showResult("获取印章模块的编号：", "机器未连接。");
			return;
		}
		document.getElementById("sealModuleSNInput").value = sealModuleSN;
	}
	if ("G21" == deviceType) {// G21
		// TODO
		alert("未支持此设备。");
		return;
	}
	showResult("获取印章模块的编号：", "获取成功，印章模块的编号为：" + sealModuleSN);
}

/**
 * 设置印章模块编号
 * 
 * @author 李水野
 * @date 2015-05-07
 */
function setSealModuleSN() {
	var deviceType = document.getElementById("deviceTypeSelect").value;
	showResult("设置印章模块编号：", "选择的型号为：" + deviceType);
	var sealModuleSN = document.getElementById("sealModuleSNInput").value;
	if (null == sealModuleSN || "" == sealModuleSN
			|| typeof (sealModuleSN) == "undefined") {
		showResult("设置印章模块编号：", "请输入编号。");
		return;
	}
	showResult("设置印章模块编号：", "输入的编号为：" + sealModuleSN);
	if ("G16" == deviceType) {// G16
		var result = OCX_MachineOrder.setSealSN(sealModuleSN).data;
		if (0 != result) {
			showResult("设置印章模块编号：", "成功。");
		} else {
			showResult("设置印章模块编号：", "失败。");
		}
	}
	if ("G21" == deviceType) {// G21
		alert("未支持此设备。");
		// TODO
		return;
	}
}

/**
 * 获取灯亮度
 */
function getBrightness() {
	var brightness = OCX_MachineOrder.getBrightness().data;
	if (brightness < 1 || brightness > 8) {
		showResult("获取灯亮度：", "失败。");
		return;
	}
	showResult("获取灯亮度：", "成功，灯亮度为：" + brightness)
}

/**
 * 设置灯亮度
 */
function setBrightness() {
	var brightness = document.getElementById("brightnessSelect").value;
	var result = OCX_MachineOrder.setBrightness(brightness).data;
	if (0 == result) {
		showResult("设置灯亮度：", "成功，设置灯的亮度为：" + brightness)
	} else {
		showResult("设置灯亮度：", "失败，设置灯的亮度为：" + brightness)
	}
}

/**
 * 更新设备时间
 */
function updateTime() {
	try {
		var devTime = document.getElementById("devTimeInput").value;
		if (!devTime) {
			devTime = new Date();
		} else {
			devTime = new Date(devTime);
		}
		var serverTime = new Object();
		serverTime.serverYear 		= devTime.format("yyyy");
		serverTime.serverMonth 		= devTime.format("MM");
		serverTime.serverDay 		= devTime.format("dd");
		serverTime.serverHour 		= devTime.format("hh");
		serverTime.serverMinitus 	= devTime.format("mm");
		serverTime.serverSecond 	= devTime.format("ss");
		machineOrder.updateDevTime(serverTime)
		showResult("更新设备时间成功", "");
	} catch (e) {
		showResult("更新设备时间失败");
	}
}

/**
 * 获取设备当前时间
 */
function getDevTime() {
	try {
		var localY = OCX_MachineOrder.queryYear().data;
		var localMD = OCX_MachineOrder.queryMD().data;
		var localT = OCX_MachineOrder.queryTime().data;
		if (localY == "0" || localMD == "0" || localT == "0") {
			throw new Error("获取设备当前时间失败");
		};
		var devTime = localY + "/" + localMD.substr(0, 2) + "/" + localMD.substr(2, 2) + " " + localT.substr(0, 2) + ":" + localT.substr(2, 2) + ":" + localT.substr(4, 2);
		showResult("设备当前时间", devTime);
	} catch (e) {
		showResult("获取设备当前时间失败", "");
	}
}

/**
 * 装卸设备
 */
function unloadSeal() {
	// 初始化设备
	var result = machineOrder.intMachine(function(reVal) {
		showResult("连接检测", reVal == 0 ? "设备已连接" : "设备已断开");
	});
	if (result != 0) {
		return;
	}
	// 装卸之前的准备
	var result = machineOrder
			.beforeUnloadSeal(function(machineType, machineSN, sealSN, type) {
				if (type == 0) {
					showResult("装卸章操作", "本次操作为卸章machineType[" + machineType
							+ "], machineSN[" + machineSN + "], sealSN["
							+ sealSN + "]，可在此处进行卸章身份确认和卸章复核，模拟身份确认成功和复核通过");
					unload(); // 身份确认不通过和复核不通过不要进行这一步
				} else {
					showResult("装卸章操作", "本次操作为装章machineType[" + machineType
							+ "], machineSN[" + machineSN + "], sealSN["
							+ sealSN + "]");
					unload();
				}
			});
	showResult("装卸章开始：", result.errorMessage);
}

/**
 * 卸章？
 */
function unload() {
	var result = machineOrder
			.unloadSeal(function(machineSN, sealSN, newSealSN) {
				if ((sealSN == "-1" || sealSN == "-2")
						&& (newSealSN != "-1" && newSealSN != "-2"))
					showResult("装卸章操作", "设备[" + machineSN + "]检测到装章，新章编号["
							+ newSealSN + "]");
				else if ((sealSN != "-1" && sealSN != "-2")
						&& (newSealSN != "-1" && newSealSN != "-2")
						&& newSealSN != sealSN)
					showResult("装卸章操作", "设备[" + machineSN + "]检测到换章，旧章编号["
							+ sealSN + "]" + "新章编号[" + newSealSN + "]");
				else if ((sealSN != "-1" && sealSN != "-2")
						&& (newSealSN != "-1" && newSealSN != "-2")
						&& newSealSN == sealSN)
					showResult("装卸章操作", "设备[" + machineSN + "]检测到卸章或换章，但未做任何处理");
				else if ((sealSN != "-1" && sealSN != "-2")
						&& (newSealSN == "-1" || newSealSN == "-2"))
					showResult("装卸章操作", "设备[" + machineSN + "]检测到卸章，旧章编号["
							+ sealSN + "]");
				else if ((sealSN == "-1" || sealSN == "-2")
						&& (newSealSN == "-1" || newSealSN == "-2"))
					showResult("装卸章操作", "设备[" + machineSN + "]检测到装章，但未放入新章");

				disableButton(document.getElementById("btnInit"));
				enableButton(document.getElementById("btnUpdateTime"));
				enableButton(document.getElementById("btnUnload"));
				enableButton(document.getElementById("btnClose"));
				enableButton(document.getElementById("btnStart"));
				disableButton(document.getElementById("btnCancle"));
				disableButton(document.getElementById("btnStop"));
			});
	showResult("弹出机器臂", result.errorMessage);
	if (result.returnCode == 0) {
		disableButton(document.getElementById("btnInit"));
		disableButton(document.getElementById("btnUpdateTime"));
		disableButton(document.getElementById("btnUnload"));
		disableButton(document.getElementById("btnClose"));
		disableButton(document.getElementById("btnStart"));
		disableButton(document.getElementById("btnCancle"));
		disableButton(document.getElementById("btnStop"));
	}
}

function loopUseSeal(times) {
	machineOrder.startUseSeal("990011", 1, function(responseMessage) {
		if (responseMessage.success) {
			OCX_MachineOrder.photoFinishReply();//拍照回应
			OCX_MachineOrder.recordSuccess();//清除日志回应
			showResult("用印成功");
			times = times - 1;
			disableButton(document.getElementById("btnInit"));
			disableButton(document.getElementById("btnUpdateTime"));
			disableButton(document.getElementById("btnUnload"));
			disableButton(document.getElementById("btnClose"));
			disableButton(document.getElementById("btnStart"));
			disableButton(document.getElementById("btnCancle"));
			enableButton(document.getElementById("btnStop"));
			if (times > 0) {
				setTimeout(function(){loopUseSeal(times);}, intervalTime) ;
			}
		} else {
			showResult("用印失败", responseMessage.message);
		}
	});
}

function startSeal() {
	loopUseSeal(1); 
}

function stopSeal() {
	var ret = machineOrder.stopSeal();
	if (ret == 0) {
		showResult("停止用印成功");
		disableButton(document.getElementById("btnInit"));
		enableButton(document.getElementById("btnUpdateTime"));
		enableButton(document.getElementById("btnUnload"));
		enableButton(document.getElementById("btnClose"));
		enableButton(document.getElementById("btnStart"));
		disableButton(document.getElementById("btnCancle"));
		disableButton(document.getElementById("btnStop"));
	}else{
		showResult("停止用印失败", ret);
	}
}

function cancleSeal() {
	var ret = machineOrder.cancelSeal();
	showResult("取消用印", ret);
	disableButton(document.getElementById("btnCancle"));
}

/**
 * 在初始设备后，改变按钮是否可用
 * 
 * @author 李水野
 * @date 2015-05-06
 */
function changeBtnEnableAfterInitMachine() {
	disableButton(document.getElementById("btnInit"));
	enableButton(document.getElementById("btnUpdateTime"));
	enableButton(document.getElementById("btnUnload"));
	enableButton(document.getElementById("btnClose"));
	enableButton(document.getElementById("btnStart"));
	disableButton(document.getElementById("btnCancle"));
	disableButton(document.getElementById("btnStop"));

	enableButton(document.getElementById("btnGetMachineSN"));
	enableButton(document.getElementById("btnSetMachineSN"));
	enableButton(document.getElementById("getSealModuleSNBtn"));
	enableButton(document.getElementById("setSealModuleSNBtn"));
	enableButton(document.getElementById("getBrightnessBtn"));
	enableButton(document.getElementById("setBrightnessBtn"));
}

/**
 * 在关闭设备后，改变按钮是否可用
 * 
 * @author 李水野
 * @date 2015-05-06
 */
function changeBtnEnableAfterCloseMachine() {
	enableButton(document.getElementById("btnInit"));
	disableButton(document.getElementById("btnUpdateTime"));
	disableButton(document.getElementById("btnUnload"));
	disableButton(document.getElementById("btnClose"));
	disableButton(document.getElementById("btnStart"));
	disableButton(document.getElementById("btnCancle"));
	disableButton(document.getElementById("btnStop"));

	disableButton(document.getElementById("btnGetMachineSN"));
	disableButton(document.getElementById("btnSetMachineSN"));
	disableButton(document.getElementById("getSealModuleSNBtn"));
	disableButton(document.getElementById("setSealModuleSNBtn"));
	disableButton(document.getElementById("getBrightnessBtn"));
	disableButton(document.getElementById("setBrightnessBtn"));
}
