/**
 * 
 * 创建于:2014-9-24<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 防伪码验证
 * 
 * @author 叶慧雄
 * @version 1.0
 */
var grid;
var flag;

/**
 * 重置查询条件
 */
function resetMethod() {
	$("#queryForm")[0].reset();
	$("#bizInfoTable").hide();
	$("#showMessage").hide();
}

/**
 * 初始化数据
 */
$(document).ready(function() {
	$("#queryBtn").click(function(event) {
		event.preventDefault();
		$("#showMessage").hide();
		var verificationCode = $("#verificationCode").val();
		var reg = /^[A-Za-z0-9]{1,32}$/;
		if(verificationCode == null || verificationCode == ""){
			$("#bizInfoTable").hide();
			$("#showMessage").show();	
			showMessage("防伪码不能为空");
			return;
		}else if(verificationCode =="undefined"){
			$("#showMessage").show();
			showMessage("输入信息有误,可能包含特殊字符");
			return;
		}else if (!reg.test(verificationCode)){
			showMessage("防伪码32位以内数字或字母");
			return;
		}
		queryData();
	});
});

/**
 * 查询数据，执行查询
 */
function queryData() {
	var verificationCode = $("#verificationCode").val();
	$("#showMessage").hide();

	var url = ctx + "/verficationCode/verficationCodeCheckAction_querySealUseBizInfo.action?verificationCode="+verificationCode;
	var data = tool.ajaxRequest(url, '');
	if(data.success){
		if (data.response.webResponseJson.state == "normal") {
			$("#bizInfoTable").show();
			var bizInfo = data.response.webResponseJson.data;
			if(bizInfo.money != null && bizInfo.money != undefined && bizInfo.money != ""){
				bizInfo.money = bizInfo.money/100;
			}
			//$("#queryForm").initForm(bizInfo);
			initBizForm(bizInfo);
		} else {
			$("#queryForm")[0].reset();
			$("#bizInfoTable").hide();
			$("#showMessage").show();
			showMessage("防伪码不存在");
		}
	}else{
		show("服务器响应失败：" + data.response);
	}
}
function initBizForm(bizInfo){
	$("#districtCode").val(bizInfo.districtCode);
	$("#orgNo").val(bizInfo.orgNo);
	$("#applicantCode").val(bizInfo.applicantCode);
	$("#tradeNo").val(bizInfo.tradeNo);
	$("#tradeCode").val(bizInfo.tradeCode);
	$("#bizType").val(bizInfo.bizType);
	//$("#sealType").val(bizInfo["sealType"]);
	if(bizInfo.sealType=='1'){
		$("#sealType").get(0).selectedIndex=0;
	}else{
		$("#sealType").get(0).selectedIndex=1;
	}
	$("#sealCount").val(bizInfo.sealCount);
	$("#cardNo").val(bizInfo.cardNo);
	$("#accNo").val(bizInfo.accNo);
	$("#billNo").val(bizInfo.billNo);
	$("#accName").val(bizInfo.accName);
	//$("#currency").val(bizInfo["currency"]);
	if(bizInfo.currency=='0'){
		$("#currency").get(0).selectedIndex=0;
	}else if(bizInfo.currency=='1'){
		$("#currency").get(0).selectedIndex=1;
	}else if(bizInfo.currency=='2'){
		$("#currency").get(0).selectedIndex=2;
	}else if(bizInfo.currency=='3'){
		$("#currency").get(0).selectedIndex=3;
	}
	$("#money").val(bizInfo.money);
}
/**
 * 显示提示信息
 * @param message 信息
 */
function showMessage(message){
	$("#showMessage").text(message);
}


