/**
 * 创建于:2015-5-14<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 印章业务种类参数
 * 
 * @author Rickychen
 * @version 1.0.0
 */

function bizTypeParamInit() {
	$("#bizTypeParamDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 180,
		width : 350,
		modal : true,
		buttons : {},
		close : function() {
			$("#modifyParamForm")[0].reset();
		}
	});

	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	$("#bizTypeParamsTable").jqGrid(
			{
				width : pageContentWidth,
				height : tableHeight + "px",
				url : ctx + "/param/paramBizTypeAction_list.action",
				multiselect : false,
				rowNum : 20,
				rownumbers : true,
				rowList : [ 20, 50, 100 ],
				colNames : [ "业务种类编号", "业务种类名称", "排列顺序", "操作" ],
				colModel : [
						{
							name : "paramName",
							index : "paramName",
							align : "center",
							sortable : false
						},
						{
							name : "paramValue",
							index : "paramValue",
							align : "center",
							sortable : false
						},
						{
							name : "orderId",
							index : "orderId",
							align : "center",
							sortable : false
						},
						{
							name : "id",
							index : "id",
							align : "center",
							sortable : false,
							formatter : function(value, options, rData) {
								return "<input type='button'  value='修改' onclick='openModifyDLG(" + value
										+ ")'/><input type='button' value='删除' onclick='deleteParam(" + value
										+ ")'  />";
							}
						} ],
				pager : "#bizTypeParamsTablePager"
			});
}

function formatSealMaterialType(sealMaterialType) {
	return sealTypeList[sealMaterialType];
}

function queryList() {
	$("#bizTypeParamsTable").jqGrid("search", "#bizTypeQueryForm");
}

function openModifyDLG(id) {
	$.ajax({
		type : "POST",
		url : $.getContextPath() + "/param/paramBizTypeAction_queryById.action",
		data : {
			"paramBizType.id" : id
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				document.getElementById('idtr').style.display = "none";
				$("#idItem").val(data.paramBizType.id);
				$("#paramName").val(data.paramBizType.paramName);
				$("#paramValue").val(data.paramBizType.paramValue);
				$("#orderId").val(data.paramBizType.orderId);
				$("#bizTypeParamDLG").dialog("open");
				document.getElementById('updateButtonDIV').style.display = "";
				document.getElementById('addButtonDIV').style.display = "none";
				document.getElementById('idItem').removeAttribute('disabled');
			} else {
				alert("失败:" + data.responseMessage.message);
			}
		}
	})
}

function updateParam() {
	if (!$("#modifyParamForm").validationEngine("validate")) {
		return;
	}

	$.ajax({
		type : "POST",
		url : $.getContextPath() + "/param/paramBizTypeAction_update.action",
		data : {
			"paramBizType.id" : $("#idItem").val(),
			"paramBizType.paramName" : $.trim($("#paramName").val()),
			"paramBizType.paramValue" : $.trim($("#paramValue").val()),
			"paramBizType.orderId" : $.trim($("#orderId").val())
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$("#bizTypeParamDLG").dialog("close");
				$("#bizTypeParamsTable").trigger("reloadGrid");
			} else {
				alert("保存失败:" + data.responseMessage.message);
			}
		}
	});
}

function cancelUpdate() {
	$("#bizTypeParamDLG").dialog("close");
}

function openAddParamDLG() {
	$("#bizTypeParamDLG").dialog("open");
	document.getElementById('idtr').style.display = "none";
	document.getElementById('updateButtonDIV').style.display = "none";
	document.getElementById('addButtonDIV').style.display = "";
	document.getElementById('idItem').setAttribute('disabled', 'disabled');
}

function addParam() {
	if (!$("#modifyParamForm").validationEngine("validate")) {
		return;
	}
	$.ajax({
		type : "POST",
		url : $.getContextPath() + "/param/paramBizTypeAction_add.action",
		data : {
			"paramBizType.paramName" : $.trim($("#paramName").val()),
			"paramBizType.paramValue" : $.trim($("#paramValue").val()),
			"paramBizType.orderId" : $.trim($("#orderId").val())
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$("#bizTypeParamDLG").dialog("close");
				$("#bizTypeParamsTable").trigger("reloadGrid");
			} else {
				alert("保存失败:" + data.responseMessage.message);
			}
		}
	});
}

function cancelAdd() {
	$("#bizTypeParamDLG").dialog("close");
}

function deleteParam(id) {
	var b = confirm("确定要删除该参数吗？");
	if (b) {
		$.ajax({
			type : "POST",
			url : $.getContextPath() + "/param/paramBizTypeAction_delete.action",
			data : {
				"paramBizType.id" : id
			},
			dataType : "json",
			async : false,
			success : function(data) {
				if (data && data.responseMessage && data.responseMessage.success) {
					$("#bizTypeParamDLG").dialog("close");
					$("#bizTypeParamsTable").trigger("reloadGrid");
				} else {
					alert("删除失败:" + data.responseMessage.message);
				}
			}
		});
	}

}
