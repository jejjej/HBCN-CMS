/**
 * 创建于:2015-7-7<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 印控机属性参数
 * 
 * @author Rickychen
 * @version 1.0.0
 */


var default_prop = "default_prop";

/**
 * 初始化页面
 */
$(document).ready(function() {
    initMachinePropDialog();

    var ret = ocxbase_messageHandler.initOcx();
	if (!ret.success) {
		alert(ret.data);
		return;
	};
	
	ret = ocxbase_sealMachine.initOcx();
	if (!ret.success) {
		alert(ret.data);
		return;
	};

    initGrid();

    formValidation.init("modifyParamForm", "bottomLeft");

    window.setTimeout(function() {
	initSealMachine();
    }, 500);
});

/**
 * 初始化印控机属性参数编辑页面
 */
function initMachinePropDialog() {
    $("#machinePropParamDLG").dialog({
	autoOpen : false,
	resizable : false,
	height : 'auto',
	width : '600px',
	modal : true,
	position : {
	    at : "center"
	},
	buttons : {},
	close : function() {
	    resetForm();
	    $("#machinePropParamsTable").trigger("reloadGrid");
	}
    });
};

/**
 * 页面初始化
 */
function initGrid() {
    var pageHeaderHeight = $(".pageHeader").css("height");
    var pageContentWidth = $(".pageContent").width() - 2;
    pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
    var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
    $("#machinePropParamsTable").jqGrid(
	    {
		width : pageContentWidth,
		height : tableHeight + "px",
		url : ctx + "/param/paramMachinePropAction_queryList.action",
		multiselect : false,
		rowNum : 20,
		rownumbers : true,
		rowList : [ 20, 50, 100 ],
		colNames : [ "设备编号", "操作" ],
		colModel : [
			{
			    name : "machineNum",
			    index : "machineNum",
			    align : "center",
			    sortable : false,
			    formatter : formatMachineNum
			},
			{
			    name : "id",
			    index : "id",
			    align : "center",
			    sortable : false,
			    formatter : function(value, options, rData) {
				return "<input type='button'  value='修改' onclick='openModifyDLG(\"" + value + "\")'/>"
					+ "<input type='button' value='删除' onclick='deleteParam(\"" + value + "\","
					+ "\"" + rData.machineNum + "\")' />";
			    }
			} ],
		pager : "#machinePropParamsTablePager"
	    });
};

/**
 * 格式化设备编号
 * 
 * @param machineNum
 */
function formatMachineNum(machineNum) {
    if(machineNum == default_prop){
	return "通用属性";
    }else{
	return machineNum;
    }
};

/**
 * 分页查询
 */
function queryList() {
    $("#machinePropParamsTable").jqGrid("search", "#machinePropQueryForm");
};

/**
 * 打开印控机属性编辑页面
 */
function openAddParamDLG() {
    // 读取印控机编码
    try {
	var machineNo = ocxbase_sealMachine._getMachineNum().data;
	$("#machineNumInput").val(machineNo);
	$("#machineNumInput").focus(function() {
	    $(this).blur();
	});
    } catch (e) {
	$("#machineNumInput").unbind('focus');
	$("#showMessage").text(getOCXMsg(e.message.code));
    }

    $("#machinePropParamDLG").dialog("open");
    document.getElementById('idtr').style.display = "none";
    document.getElementById('addButtonDIV').style.display = "";
    document.getElementById('updateButtonDIV').style.display = "none";
    document.getElementById('idItem').setAttribute('disabled', 'disabled');
};

/**
 * 新增印控机属性参数
 */
function addParam() {
    if (!$("#modifyParamForm").validationEngine("validate")) {
	return;
    }

    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramMachinePropAction_addParam.action",
	data : {
	    "paramMachineProp.id" : $("#idItem").val(),
	    "paramMachineProp.machineNum" : $("#machineNumInput").val(),
	    "paramMachineProp.propJson" : getPropParamJson()
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		$("#machinePropParamDLG").dialog("close");
		$("#machinePropParamsTable").trigger("reloadGrid");
	    } else {
		alert("保存失败:" + data.responseMessage.message);
	    }
	}
    });
};

/**
 * 打开印控机属性编辑窗口
 * 
 * @param id
 */
function openModifyDLG(id) {
    $("#machineNumInput").focus(function() {
	$(this).blur();
    });
    document.getElementById('addButtonDIV').style.display = "none";
    document.getElementById('updateButtonDIV').style.display = "";

    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramMachinePropAction_queryOneById.action",
	data : {
	    id : id
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		document.getElementById('idtr').style.display = "none";
		$("#idItem").val(data.paramMachineProp.id);
		$("#machineNumInput").val(data.paramMachineProp.machineNum);
		var propParamObject = JSON.parse(data.paramMachineProp.propJson);
		$("#xMinDistance").val(propParamObject.xMinDistance);
		$("#xMaxDistance").val(propParamObject.xMaxDistance);
		$("#yMinDistance").val(propParamObject.yMinDistance);
		$("#yMaxDistance").val(propParamObject.yMaxDistance);
		$("#machinePropParamDLG").dialog("open");
		document.getElementById('idItem').removeAttribute('disabled');
	    } else {
		$("#showMessage").text(data.responseMessage.message);
		return;
	    }
	}
    })
};

/**
 * 更新印控机属性
 */
function updateParam() {
    if (!$("#modifyParamForm").validationEngine("validate")) {
	return;
    }

    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramMachinePropAction_updateParam.action",
	data : {
	    "paramMachineProp.id" : $("#idItem").val(),
	    "paramMachineProp.machineNum" : $("#machineNumInput").val(),
	    "paramMachineProp.propJson" : getPropParamJson()
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		$("#machinePropParamDLG").dialog("close");
		$("#machinePropParamsTable").trigger("reloadGrid");
	    } else {
		alert("保存失败:" + data.responseMessage.message);
	    }
	}
    });
};

/**
 * 删除参数
 * 
 * @param id
 * @param machineNum
 */
function deleteParam(id, machineNum) {
    if (machineNum == default_prop) {
	alert("通用属性不能删除！");
	return;
    }
    var b = confirm("确定要删除该参数吗？");
    if (b) {
	$.ajax({
	    type : "POST",
	    url : $.getContextPath() + "/param/paramMachinePropAction_deleteParam.action",
	    data : {
		id : id
	    },
	    dataType : "json",
	    async : false,
	    success : function(data) {
		if (data && data.responseMessage && data.responseMessage.success) {
		    $("#machinePropParamDLG").dialog("close");
		    $("#machinePropParamsTable").trigger("reloadGrid");
		} else {
		    alert("删除失败:" + data.responseMessage.message);
		}
	    }
	});
    }
};

/**
 * 重置表单
 */
function resetForm() {
    $("#modifyParamForm")[0].reset();
    $("#idItem").val("");
    $("#machineNumInput").val("");
    $("#xMinDistance").val("");
    $("#xMaxDistance").val("");
    $("#yMinDistance").val("");
    $("#yMaxDistance").val("");
};

/**
 * 拼装可变参数成json串
 */
function getPropParamJson() {
    var propJson = '{';
    propJson += '"xMinDistance":' + $("#xMinDistance").val() + ',';
    propJson += '"xMaxDistance":' + $("#xMaxDistance").val() + ',';
    propJson += '"yMinDistance":' + $("#yMinDistance").val() + ',';
    propJson += '"yMaxDistance":' + $("#yMaxDistance").val();
    propJson += '}';
    return propJson;
};

/**
 * 初始化印控机
 */
function initSealMachine() {
    var initMachResult = ocxbase_sealMachine.initMachine();
    if (initMachResult.success === false) {
	$("#showMessage").text(initMachResult.data);
    }
}

/**
 * 页面关闭响应事件
 */
function closePage() {
	ocxbase_sealMachine.closeMachine();
}
