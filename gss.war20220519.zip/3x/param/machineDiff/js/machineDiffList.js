/**
 * 创建于:2015-5-20<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 印控机用印差异参数
 * 
 * @author Rickychen
 * @version 1.0.0
 */

function machineDiffParamInit() {
    $("#machineDiffParamDLG").dialog({
	autoOpen : false,
	resizable : false,
	height : 'auto',
	width : 'auto',
	modal : true,
	position : {
	    at : "left top"
	},
	buttons : {},
	close : function() {
	    resetForm();
	    $("#machineDiffParamsTable").trigger("reloadGrid");
	}
    });

    var pageHeaderHeight = $(".pageHeader").css("height");
    var pageContentWidth = $(".pageContent").width() - 2;
    pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
    var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
    $("#machineDiffParamsTable").jqGrid({
	width : pageContentWidth,
	height : tableHeight + "px",
	url : ctx + "/param/paramMachineDiffAction_queryList.action",
	multiselect : false,
	rowNum : 20,
	rownumbers : true,
	rowList : [ 20, 50, 100 ],
	colNames : [ "交易代码", "交易代码名称", "设备编号", "操作" ],
	colModel : [ {
	    name : "tradeCode",
	    index : "tradeCode",
	    align : "center",
	    sortable : false
	}, {
	    name : "tradeCodeName",
	    index : "tradeCodeName",
	    align : "center",
	    sortable : false
	}, {
	    name : "machineNum",
	    index : "machineNum",
	    align : "center",
	    sortable : false
	}, {
	    name : "id",
	    index : "id",
	    align : "center",
	    width : 60,
	    sortable : false,
	    formatter : function(value, options, rData) {
		return "<input type='button' value='删除' onclick='deleteParam(\"" + value + "\")' />";
		// return "<input type='button' value='修改'
		// onclick='openModifyDLG(\""+ value+ "\")'/>"
		// +"<input type='button' value='删除' onclick='deleteParam(\""+
		// value + "\")' />";
	    }
	} ],
	pager : "#machineDiffParamsTablePager"
    });
}

function queryList() {
    $("#machineDiffParamsTable").jqGrid("search", "#machineDiffQueryForm");
}

function openModifyDLG(id) {
    document.getElementById('addButtonDIV').style.display = "none";

    var machineNumTemp;
    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramMachineDiffAction_queryOneById.action",
	data : {
	    id : id
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		document.getElementById('idtr').style.display = "none";
		$("#idItem").val(data.paramMachineDiff.id);
		$("#tradeCodeInput").val(data.paramMachineDiff.tradeCode);
		machineNumTemp = data.paramMachineDiff.machineNum;
		$("#machineNumInput").val(data.paramMachineDiff.machineNum);
		var diffParamObject = JSON.parse(data.paramMachineDiff.diffParamJson);
		$("#recogCodeXposition").val(diffParamObject.recogCodeXposition);
		$("#recogCodeYposition").val(diffParamObject.recogCodeYposition);
		$("#useSealXposition0").val(diffParamObject.useSealXposition0);
		$("#useSealYposition0").val(diffParamObject.useSealYposition0);
		$("#useSealXposition90").val(diffParamObject.useSealXposition90);
		$("#useSealYposition90").val(diffParamObject.useSealYposition90);
		$("#useSealXposition180").val(diffParamObject.useSealXposition180);
		$("#useSealYposition180").val(diffParamObject.useSealYposition180);
		$("#useSealXposition270").val(diffParamObject.useSealXposition270);
		$("#useSealYposition270").val(diffParamObject.useSealYposition270);
		$("#machineDiffParamDLG").dialog("open");
		document.getElementById('idItem').removeAttribute('disabled');
	    } else {
		$("#showMessage").text(data.responseMessage.message);
		return;
	    }
	}
    })

    if (!machineOpt.device_normal || machineOpt.machine_num != machineNumTemp) {
	$('#tradeCodeInput').attr("disabled", true);
	$('#machineNumInput').attr("disabled", true);
	// TODO 无印控机测试时注销以下两行代码
	document.getElementById('updateButtonDIV').style.display = "none";
	document.getElementById('recogCodePositionButtonDIV').style.display = "none";
	document.getElementById('useSealButtonDIV').style.display = "none";
    } else {
	document.getElementById('updateButtonDIV').style.display = "";
	machineOpt.openPaperDoor();
    }
}

function updateParam() {
    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramMachineDiffAction_updateParam.action",
	data : {
	    "paramMachineDiff.id" : $("#idItem").val(),
	    "paramMachineDiff.tradeCode" : $("#tradeCodeInput").val(),
	    "paramMachineDiff.tradeCodeName" : $("#tradeCodeInput  option:selected").text(),
	    "paramMachineDiff.machineNum" : $("#machineNumInput").val(),
	    "paramMachineDiff.diffParamJson" : getDiffParamJson()
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		$("#machineDiffParamDLG").dialog("close");
		$("#machineDiffParamsTable").trigger("reloadGrid");
	    } else {
		alert("保存失败:" + data.responseMessage.message);
	    }
	}
    });
}

function openAddParamDLG() {
    if (!machineOpt.device_normal) {
	$("#showMessage").text("请先连接印控机");
    } else {
	$("#machineDiffParamDLG").dialog("open");
	$("#machineNumInput").val(machineOpt.machine_num);
	document.getElementById('idtr').style.display = "none";
	document.getElementById('addButtonDIV').style.display = "";
	document.getElementById('updateButtonDIV').style.display = "none";
	document.getElementById('idItem').setAttribute('disabled', 'disabled');

	machineOpt.openPaperDoor();
    }
}

function addParam() {
    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramMachineDiffAction_addParam.action",
	data : {
	    "paramMachineDiff.id" : $("#idItem").val(),
	    "paramMachineDiff.tradeCode" : $("#tradeCodeInput").val(),
	    "paramMachineDiff.tradeCodeName" : $("#tradeCodeInput  option:selected").text(),
	    "paramMachineDiff.machineNum" : $("#machineNumInput").val(),
	    "paramMachineDiff.diffParamJson" : getDiffParamJson()
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		$("#machineDiffParamDLG").dialog("close");
		$("#machineDiffParamsTable").trigger("reloadGrid");
	    } else {
		alert("保存失败:" + data.responseMessage.message);
	    }
	}
    });
}

function deleteParam(id) {
    var b = confirm("确定要删除该参数吗？");
    if (b) {
	$.ajax({
	    type : "POST",
	    url : $.getContextPath() + "/param/paramMachineDiffAction_deleteParam.action",
	    data : {
		id : id
	    },
	    dataType : "json",
	    async : false,
	    success : function(data) {
		if (data && data.responseMessage && data.responseMessage.success) {
		    $("#machineDiffParamDLG").dialog("close");
		    $("#machineDiffParamsTable").trigger("reloadGrid");
		} else {
		    alert("删除失败:" + data.responseMessage.message);
		}
	    }
	});
    }
}

function resetForm() {
    $("#modifyParamForm")[0].reset();
    $("#idItem").val("");
    $("#tradeCodeInput").val("");
    $("#machineNumInput").val("");
    $("#recogCodeXposition").val("");
    $("#recogCodeYposition").val("");
    $("#useSealXposition0").val("");
    $("#useSealYposition0").val("");
    $("#useSealXposition90").val("");
    $("#useSealYposition90").val("");
    $("#useSealXposition180").val("");
    $("#useSealYposition180").val("");
    $("#useSealXposition270").val("");
    $("#useSealYposition270").val("");
    document.getElementById("voucherImg").src = ctx + "/3x/param/machineDiff/css/voucherImg.png";
    $("#voucherImg").removeAttr("onclick");
    document.getElementById('recogCodePositionButtonDIV').style.display = "none";
    document.getElementById('useSealButtonDIV').style.display = "none";
    $("#sealImageDiv").css('display', 'none');

    machineOpt.img_path = "";
    machineOpt.src_img_path = "";
}

/**
 * 拼装可变参数成json串
 */
function getDiffParamJson() {
    var diffParamJson = '{';
    diffParamJson += '"recogCodeXposition":' + $("#recogCodeXposition").val() + ',';
    diffParamJson += '"recogCodeYposition":' + $("#recogCodeYposition").val() + ',';
    diffParamJson += '"useSealXposition0":' + $("#useSealXposition0").val() + ',';
    diffParamJson += '"useSealYposition0":' + $("#useSealYposition0").val() + ',';
    diffParamJson += '"useSealXposition90":' + $("#useSealXposition90").val() + ',';
    diffParamJson += '"useSealYposition90":' + $("#useSealYposition90").val() + ',';
    diffParamJson += '"useSealXposition180":' + $("#useSealXposition180").val() + ',';
    diffParamJson += '"useSealYposition180":' + $("#useSealYposition180").val() + ',';
    diffParamJson += '"useSealXposition270":' + $("#useSealXposition270").val() + ',';
    diffParamJson += '"useSealYposition270":' + $("#useSealYposition270").val();
    diffParamJson += '}';
    return diffParamJson;
}

/**
 * 拍照
 */
function takePinture() {
    machineOpt.captureImage();
}

/**
 * 添加图片点击事件
 */
function addVoucherClickEvent(type) {
    $("#voucherImg").unbind("click");
    if (type == 'recogCode') {
	$("#voucherImg").bind('click', function() {
	    setRecogCodePosition(this);
	});
    } else if (type == 'useSeal') {
	$("#voucherImg").bind('click', function() {
	    setUseSealPosition(this);
	});
    }
}

function setRecogCodePosition(el) {
    machineOpt.showRecogCodePosition(el);
}

function setUseSealPosition(el) {
    machineOpt.showUseSealCodePosition(el);
}
