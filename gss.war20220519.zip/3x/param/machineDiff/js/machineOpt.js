/**
 * 创建于:2015-5-20<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 印控机用印差异参数
 * 
 * @author Rickychen
 * @version 1.0.0
 */
var machineOpt = new Object();

machineOpt.machine_init_success = false;

machineOpt.camera_open_success = false;

machineOpt.device_normal = false;

machineOpt.machine_num = null;

machineOpt.image_file_path = top.yzjgssRootPath + "\\yzjgss\\resources\\3x\\img\\"; // 凭证拍照图片本地暂存路径

machineOpt.img_path = ""; // 凭证图片全路径

machineOpt.src_img_path = ""; // 凭证裁剪前的原图路径

machineOpt.verification_code_width = 245; // 验证码识别的宽度，单位：px

machineOpt.verification_code_height = 120; // 验证码识别的高度，单位：px

$(document).ready(function() {
    machineOpt.initWaitingDialog();

    var ret = ocxbase_messageHandler.initOcx();
	if (!ret.success) {
		alert(ret.data);
		return;
	};

    ret = ocxbase_xusbVideo.initOcx();
	if (!ret.success) {
		alert(ret.data);
		return;
	};
	ret = ocxbase_sealMachine.initOcx();
	if (!ret.success) {
		alert(ret.data);
		return;
	};
    
    ret = ocxbase_fileStore.initOcx(basePath)
    if (!ret.success) {
    	alert(ret.data);
		return;
	};
    
    // 初始化异常用印日志处理器
    deviceExceptionLogHandler.init(ctx);

    // 初始化印控机
    machineOpt.showWaitingDialog("设备初始化中...");
    window.setTimeout(function() {
	machineOpt.initSealMachine();
    }, 500);
});

/**
 * 初始化印控机
 */
machineOpt.initSealMachine = function() {
    try {
	var initMachResult = ocxbase_sealMachine.initMachine();
	if (initMachResult.success === false) {
	    $("#showMessage").text(initMachResult.data);
	    return;
	} else {
	    machineOpt.machine_init_success = true;
	    machineOpt.machine_num = ocxbase_sealMachine._getMachineNum().data;
	    $("#machineNum").val(machineOpt.machine_num);
	}

	var openResult = ocxbase_xusbVideo._openCamera();
	
	if (openResult.success === false) {
	    $("#showMessage").text(openResult.data);
	    return;
	} else {
	    machineOpt.camera_open_success = true;
	}

	machineOpt.device_normal = true;
    } catch (e) {
	$("#showMessage").text(e.message);
    }
};

/**
 * 摄像头就绪拍照事件
 */
function deviceReady() {
    checkDeviceExceptionLog();
    
    // TODO 检查是否存在异常用印日志
    function checkDeviceExceptionLog() {
	var sniffResult = ocxbase_exceptionLogHandler.startSniffing(ocxbase_sealMachine._getMachineNum().data,true);
	if (sniffResult.success) {
	    // 释放页面
	    machineOpt.hideWaitingDialog();
	} else {
	    machineOpt.showWaitingDialog(sniffResult.data);
	}
    }
}

/**
 * 摄像头设备连接事件
 */
function deviceConnect(nConnectStatus) {
    // TODO
}

/**
 * 申请打开纸板
 */
machineOpt.openPaperDoor = function() {
    var openResult = ocxbase_sealMachine._openPaperDoor(applyOpenPaperDoorCallBack);
    if (openResult.success === false) {
	alert(openResult.data);
    } else {
	machineOpt.showWaitingDialog("请放入并摆正凭证...");
    }

    // 申请打开纸板回调函数
    function applyOpenPaperDoorCallBack(result) {
	try {
	    if (result.code != "1001") {
		var errorMsg = getOCXMsg(result.code);
		alert(errorMsg);
		return;
	    }

	    // 关闭纸板拍照
	    // 此timeout用于等待纸板稳定不再晃动再拍照，此timeout可根据具体情况调整时间的长短
	    // 如果此timeout时间太短，可能造成关闭纸板后拍出来的照片不清晰
	    setTimeout(function() {
		machineOpt.captureImage();
	    }, 500);
	} catch (e) {
	}
    }
};

/**
 * 拍照并显示图片
 */
machineOpt.captureImage = function() {
    try {
	// TODO 无印控机测试时释放一下代码
	/*
	 * var imgSrc = ctx+"/3x/param/machineDiff/css/benPiao.jpg"; var newImg =
	 * new Image(); newImg.onload = function() {
	 * document.getElementById("voucherImg").src = newImg.src; height_ =
	 * newImg.height; width_ = newImg.width; var img =
	 * document.getElementById("voucherImg"); img.style.width = width_;
	 * 
	 * document.getElementById('recogCodePositionButtonDIV').style.display="none";
	 * document.getElementById('useSealButtonDIV').style.display="none"; }
	 * newImg.src = imgSrc; return;
	 */

	machineOpt.showWaitingDialog("正在拍照处理中...");
	var date = (new Date()).Format("yyyyMMddhhmmssS");
	this.img_path = this.image_file_path + date + ".jpg";
	this.src_img_path = this.image_file_path + date + "-src.jpg";
	var success = ocxbase_xusbVideo._captureImage(this.img_path, this.src_img_path, 1);
	if (success.success) {
	    if (voucherHasCut()) {
		var newImg = new Image();
		newImg.onload = function() {
		    document.getElementById("voucherImg").src = newImg.src;
		    var height = newImg.height;
		    var width = newImg.width;
		    var img = document.getElementById("voucherImg");
		    img.style.width = width;

		    document.getElementById('recogCodePositionButtonDIV').style.display = "";
		    document.getElementById('useSealButtonDIV').style.display = "";
		}
		newImg.src = this.img_path;
	    } else {
		alert("凭证裁剪失败，请重新拍照");
	    }
	} else {
	    alert("拍照失败");
	}
    } catch (e) {
	alert(e.message);
    } finally {
	machineOpt.hideWaitingDialog();
    }

    /**
     * 判断拍照控件是否裁剪成功
     * 
     * @returns {Boolean}
     */
    function voucherHasCut() {
	var img = machineOpt.loadImgSize();
	var width = img.width;
	var height = img.height;
	if (tool.isNull(width) || width == 0 || tool.isNull(height) || height == 0) {
	    return false;
	} else if (width != 2048 || height != 1536) {
	    return true;
	}
	return false;
    }
};

/**
 * 加载图片大小
 */
machineOpt.loadImgSize = function() {
    var imageSize = OCX_ImgHelper.getImageSize(machineOpt.img_path).data;
    if (imageSize != null && imageSize != "") {
	var size = imageSize.split("*");
	if (size.length == 2) {
	    var img = new Object();
	    img.width = size[0];
	    img.height = size[1];
	    return img;
	} else {
	    alert("拍照控件获取图像宽高失败:" + size);
	}
    } else {
	alert("拍照控件未获取到图像宽高");
    }
};

document.onmousemove = mouseMove;
var mouse_pos_x = null; // 鼠标X坐标
var mouse_pos_y = null; // 鼠标Y坐标

/**
 * 鼠标移动
 * 
 * @param ev
 */
function mouseMove(ev) {
    try {
	ev = ev || window.event;
	var mousePos = mousePosition(ev);
	mouse_pos_x = mousePos.x;
	mouse_pos_y = mousePos.y;
    } catch (e) {
    }

    // 鼠标位置
    function mousePosition(ev) {
	try {
	    if (ev.pageX || ev.pageY) {
		return {
		    x : ev.pageX,
		    y : ev.pageY
		};
	    }
	    return {
		x : ev.clientX + document.body.scrollLeft - document.body.clientLeft,
		y : ev.clientY + document.documentElement.scrollTop
	    };
	} catch (e) {
	}
    }
};

/**
 * 显示验证码在图片中的坐标
 */
machineOpt.showRecogCodePosition = function(el) {
    var offsetLeft = el.offsetParent.offsetLeft + el.offsetParent.offsetParent.offsetLeft
	    + el.offsetParent.offsetParent.offsetParent.offsetLeft;
    var offsetTop = el.offsetParent.offsetTop + el.offsetParent.offsetParent.offsetTop
	    + el.offsetParent.offsetParent.offsetParent.offsetLeft;
    var x = mouse_pos_x - offsetLeft;
    var y = mouse_pos_y - offsetTop;

    $("#recogCodeXposition").val(x);
    $("#recogCodeYposition").val(y);

    showCodeRect(mouse_pos_x, mouse_pos_y);

    // 显示验证码边框
    function showCodeRect(x, y) {
	clearSealCanvas("regCodeCanvasDiv");
	var pointList = [ [ x, y ], [ x + machineOpt.verification_code_width, y ],
		[ x + machineOpt.verification_code_width, y + machineOpt.verification_code_height ],
		[ x, y + machineOpt.verification_code_height ] ];
	drawRectangle("regCodeCanvasDiv", "voucherImg", pointList);
    }
};

/**
 * 显示用印位置在图片中的坐标
 */
machineOpt.showUseSealCodePosition = function(el) {
    var offsetLeft = el.offsetParent.offsetLeft + el.offsetParent.offsetParent.offsetLeft
	    + el.offsetParent.offsetParent.offsetParent.offsetLeft;
    var offsetTop = el.offsetParent.offsetTop + el.offsetParent.offsetParent.offsetTop
	    + el.offsetParent.offsetParent.offsetParent.offsetLeft;
    var x = mouse_pos_x - offsetLeft;
    var y = mouse_pos_y - offsetTop;

    // 0度坐标(x,y)
    $("#useSealXposition0").val(x);
    $("#useSealYposition0").val(y);

    var voucherImg = machineOpt.loadImgSize();
    var width = voucherImg.width;
    var height = voucherImg.height;

    // TODO 无印控机测试时释放一下代码
    /*
     * var height = height_; var width = width_;
     */

    // 90度坐标(height-y,x)
    $("#useSealXposition90").val(height - y);
    $("#useSealYposition90").val(x);

    // 180度坐标(width-x,height-y)
    $("#useSealXposition180").val(width - x);
    $("#useSealYposition180").val(height - y);

    // 270度坐标(y,width-x)
    $("#useSealXposition270").val(y);
    $("#useSealYposition270").val(width - x);

    showSealImg(x, y);

    // 显示印章图片
    function showSealImg(x, y) {
	$("#sealImageDiv").css('display', "");
	$("#sealImage").src = ctx + "/3x/param/machineDiff/css/seal_0.png";
	$("#sealImageDiv").css('top', y - 68);
	$("#sealImageDiv").css('left', x - 65);
    }
};

/**
 * 初始化等待框
 */
machineOpt.initWaitingDialog = function() {
    $("#waitingDialog").dialog({
	autoOpen : false,
	resizable : false,
	draggable : false,
	closeOnEscape : false,
	height : 290,
	width : 390,
	modal : true,
	open : function(event, ui) {
	    $(".ui-dialog-titlebar").hide();
	    $(".ui-dialog-titlebar-close").hide();
	}
    });
};

/**
 * 展示等待界面
 */
machineOpt.showWaitingDialog = function(msg) {
    $("#waitingDialog").dialog("open");
    $("#waitingMsg").html(msg);
};

/**
 * 关闭等待界面
 */
machineOpt.hideWaitingDialog = function() {
    $("#waitingDialog").dialog("close");
};

/**
 * 页面关闭响应事件
 */
$.onunload(function() {
    try {
    	ocxbase_sealMachine.closeMachine();
    	ocxbase_xusbVideo.closeCamera();
    } catch (e) {
    }
});