function init() {
	$("#delegationDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 180,
		width : 360,
		modal : true,
		buttons : {},
		close : function() {
			$("#form")[0].reset();
		}
    });	

	// 初始化表格
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	$("#RelList").jqGrid(
			{
				width : pageContentWidth,
				height : tableHeight + "px",
				url : ctx + "/param/machineBindAction_list.action",
				rowNum : 20,
				rownumbers : true,
				rowList : [ 20, 50, 100 ],
				autoLoad : false,
				sortname : "operatorTime",
				sortorder : "desc",
				colNames : [ "", "设备编号", "ip", "MAC", "操作人", "操作时间", "操作" ],
				colModel : [ {
					name:"autoID",
					index:"autoID",
					hidden:true,
					width:"0px"
				}, {
					name : "deviceNum",
					index : "deviceNum",
					align : "center",
					width : 100
				}, {
					name : "ipAddress",
					index : "ipAddress",
					align : "center",
					width : 120
				}, {
					name : "macAddress",
					index : "macAddress",
					align : "center",
					width : 120
				}, {
					name : "operatorCode",
					index : "operatorCode",
					align : "center",
					width : 100,
					formatter:function(value, options, rData){
			   			return rData.operatorName + "(" + value + ")";
			   		}
				}, {
					name : "operatorTime",
					index : "operatorTime",
					align : "center",
					width : 100
				}, {
					name : "autoId",
					index : "autoId",
					align : "center",
					width : 120,
					formatter:function(value) {
						return "<input type='button' style=\" width:60px; \"  onclick=\"edit('"+value+"');\" value='修改' />&nbsp;&nbsp;" +  
						"<input type='button' style=\" width:60px; \"  onclick=\"del('"+value+"');\" value='删除' />";
					}
				}
				],
				pager : "#RelListPager"
			});
	$("#RelList").navGrid("#RelListPager",{edit:false,add:false,del:false,search:false,refresh: true, excel: false});
	queryList();
}

function edit(sid) {
	$.ajax({
		type : "POST",
		url : ctx + "/param/machineBindAction_findById.action",
		data : {
			"info.autoId" : sid
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				var info = data.responseMessage.data;
				$("#id").val(info.autoId);
				$("#operatorType").val("update");
				$("#deviceNum").val(info.deviceNum);
				$("#ipAddress").val(info.ipAddress);
				$("#macAddress").val(info.macAddress);
				$("#delegationDLG").dialog("open");
			} else {
				$.error("查询参数信息失败:" + data.responseMessage.message);
			}
		}
	});
}

function add(){
	$("#operatorType").val("add");
	$("#delegationDLG").dialog("open");
}

function del(sid) {
	if (window.confirm('确定删除?')) {
		$.ajax({
			type : "POST",
			url : ctx + "/param/machineBindAction_del.action",
			data : {
				"info.autoId" : sid
			},
			dataType : "json",
			async : false,
			success : function(data) {
				if (data && data.responseMessage && data.responseMessage.success) {
					$.success("操作成功.")
					$("#RelList").trigger("reloadGrid");
				} else {
					$.error("操作失败:" + data.responseMessage.message);
				}
			}
		});
	}
}

function queryList() {
	$("#RelList").jqGrid("search", "#RelSearchForm");
}

function resetForm() {
	$("#RelSearchForm")[0].reset();
}

function submitForm() {
	if($("#deviceNum").val() == "" || $("#ipAddress").val() == "" || $("#macAddress").val() == "") {
		alert("请填写空白项");
		return;
	}
    var param = {
    	"info.autoId" : $("#id").val(),
		"info.deviceNum" : $("#deviceNum").val(),
		"info.ipAddress" : $("#ipAddress").val(),
		"info.macAddress" : $("#macAddress").val(),
		"info.isUsed" : $("#isUsed").val(),
		"info.operatorCode" : top.loginPeopleInfo.peopleCode,
		"info.operatorName" : top.loginPeopleInfo.peopleName,
		"operatorType" : $("#operatorType").val()
    };
    
    $.ajax({
    	type : "POST",
		url : ctx + "/param/machineBindAction_save.action",
		data:param,
		dataType : "json",
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$("#delegationDLG").dialog("close");
				$.success("操作成功!");
				queryList();
			} else {
				$.error("操作失败!" + data.responseMessage.message);
			}
		}
    });
};
