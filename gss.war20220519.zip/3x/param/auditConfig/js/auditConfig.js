/**
 * 创建于:2016-11-07<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 授权中心配置
 * 
 * @author listen
 * @version 1.0.0
 */

var currentTreeId=null;
//确定按钮是新增还是修改 0为新增  1为修改
var ComfirmType=0;

function initAuditConfigDLG() {
	$("#auditConfigDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 310,
		width : 400,
		modal : true,
		buttons : {
			"确定" : function() {
					addAuditConfig();
			},
			"取消" : function() {
				cancelAdd();
			}
		},
		close : function() {
			$("#modifyConfigForm")[0].reset();
			$("#idItem").val("");
			$("#configTypeList").multiselect("enable");
			for (var key in constants.ADAPTERTYPE) {
				$('input[name="auditConfigModel.adapterType"][value="'+key+'"]').attr("disabled",false);
			}
			$("#auditOrgCodeImg").attr("disabled",false);
			$("#orgSpImg").attr("disabled",false);
			ComfirmType=0;
		}
	});
	
	$("#selectSpOrgDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 350,
		width : 280,
		modal : true,
		buttons : {
			"确定":function(){confirmChoseSpOrg();},
			"取消":function(){cancelChoseSpOrg();}
		},
		close : function() {
			//$("#modifyConfigForm")[0].reset();
		}
	});
	
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	$("#auditConfigsTable").jqGrid(
	{
		width : pageContentWidth,
		height : tableHeight + "px",
		url : ctx + "/param/gssAuditConfigAction_list.action",
		multiselect : false,
		rowNum : 20,
		rownumbers : true,
		rowList : [ 20, 50, 100 ],
		colNames : [ "授权中心", "授权中心显示名称","指定机构", "授权机构适用类型", "配置类型", "操作" ],
		colModel : [
				{
					name : "auditOrgCode",
					index : "auditOrgCode",
					align : "center",
					sortable : false,
					formatter : function(value, options, rData) {
						return Organization.getOrganizationByOrgNo(value).organizationNameAndNo;
					}
				},
				{
					name : "auditOrgShowName",
					index : "auditOrgShowName",
					align : "center",
					sortable : false
				},
				{
					name : "orgCode",
					index : "orgCode",
					align : "center",
					sortable : false,
					formatter : function(value, options, rData) {
						return Organization.getOrganizationByOrgNo(value).organizationNameAndNo;
					}
				},
				{
					name : "adapterType",
					index : "adapterType",
					align : "center",
					sortable : false,
					formatter:function(value){
						return constants.ADAPTERTYPE[value];
					}
				},
				{
					name : "configType",
					index : "configType",
					align : "center",
					sortable : false,
					formatter:function(value){
						return constants.CONFIGTYPE[value];
					}
				},
				{
					name : "autoId",
					index : "autoId",
					align : "center",
					sortable : false,
					formatter : function(value, options, rData) {
						return "<input type='button'  value='修改' onclick=openModifyDLG('"
								+ value
								+ "') /><input type='button' value='删除' onclick=delAuditConfig('"
								+ value + "')  />";
					}
				} ],
		pager : "#auditConfigsTablePager"
	});

};

function initAuditConfigQueryForm(){
	//初始化授权机构适用类型选项
	var adapterTypeOptions = "";
	for (var key in constants.ADAPTERTYPE) {
		adapterTypeOptions += ("<option value=\"" + key + "\">" + constants.ADAPTERTYPE[key] + "</option>");
	};
	$("#adapterTypeList").html(adapterTypeOptions);
	adapterTypeOptions = "<option value=' '>全部</option>" + adapterTypeOptions;
	$("#adapterType").html(adapterTypeOptions);
	
	adapterTypeOptions = "";
	
	for(var key in constants.CONFIGTYPE){
		adapterTypeOptions += ("<option value=\"" + key + "\">" + constants.CONFIGTYPE[key] + "</option>");
	};
	$("#configTypeList").html(adapterTypeOptions);
	$("#configTypeList").multiselect({
		noneSelectedText : "请选择",
		checkAllText : "全选",
		uncheckAllText : '全不选',
		selectedList : 2,
		height:"50px"
		
	    });
	adapterTypeOptions = "<option value=' '>全部</option>" + adapterTypeOptions;
	$("#configType").html(adapterTypeOptions);
	$("input:radio[name='auditConfigModel.adapterType']").bind("change");
	$("input:radio[name='auditConfigModel.adapterType']").change(function() {
		var adapterType= $(this).val();
		if(adapterType=="2"){
		    $('#orgtr').css("display","");
		}else{
		    $('#orgtr').css("display","none");
		}
	});
	
};


function openAddConfigDLG(){
	$("#auditConfigDLG").dialog("open");
    $('#autoIdtr').css("display" ,"none");
    $('#orgtr').css("display" ,"none");
    $('#idItem').attr('disabled', 'disabled');
};

function queryList(){
	$("#auditConfigsTable").jqGrid("search", "#auditConfigQueryForm");
}

function choseOrgAuditOrg() {
    $("#auditOrgCode").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, null, null,
	    function(event, treeId, treeNode) {
		if (treeNode) {
		    $("#auditOrgCode").val(treeNode.organizationNo);
		    $("#auditOrgName").val(treeNode.organizationName);
		    $("#auditOrgShowName").val(treeNode.organizationName);
		    $("#auditOrgSid").val(treeNode.sid);
		}
	    });
}

function choseOrgSp() {
	$("#selectSpOrgDLG").dialog("open");
	
    $("#orgTreeItem").orgTreeNoLink("checkbox", top.loginPeopleInfo.orgSid, false, null, 
	    function(event, treeId, treeNode) {
			currentTreeId=treeId;
	    });
}

function confirmChoseSpOrg(){
	var treeObj = $.fn.zTree.getZTreeObj(currentTreeId);
	var checkNodes=treeObj.getCheckedNodes(true);
	
	if(checkNodes){
		var selectOrgCode="";
		var selectOrgSid="";
		var selectOrgName="";
		for (var i = 0; i < checkNodes.length; i++) {
			//if(checkNodes[i].isParent==false){
				selectOrgCode==""?selectOrgCode+=checkNodes[i].organizationNo:selectOrgCode+=","+checkNodes[i].organizationNo;
				selectOrgSid==""?selectOrgSid+=checkNodes[i].sid:selectOrgSid+=","+checkNodes[i].sid;
				selectOrgName==""?selectOrgName+=checkNodes[i].organizationName:selectOrgName+=","+checkNodes[i].organizationName;
			//}
		}
		$("#orgSp").val(selectOrgCode);
		$("#orgSpSid").val(selectOrgSid);
		$("#orgSpName").val(selectOrgName);
	}
	$("#selectSpOrgDLG").dialog("close");
}

function cancelChoseSpOrg(){
	$("#selectSpOrgDLG").dialog("close");
}


function addAuditConfig() {
	//$.success("保存成功");
	//$("#auditConfigDLG").dialog("close");
	if (ComfirmType==0?checkData():true) {
		$.post(ctx + "/param/gssAuditConfigAction_saveAuditConfig.action", 
				$("#modifyConfigForm").serializeForm(), function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$.success("保存成功");
				$("#auditConfigDLG").dialog("close");
				$("#auditConfigsTable").trigger("reloadGrid");
			} else {
				alert("保存失败:" + data.responseMessage.message);
			}

		});
	}
}


function openModifyDLG(id) {
	$.ajax({
		type : "POST",
		url : ctx + "/param/gssAuditConfigAction_queryAuditConfigById.action",
		data : {
		    id : id
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$('#autoIdtr').css("display" ,"none");
				$("#idItem").val(data.auditConfigModel.autoId);
				$("#auditOrgCode").val(data.auditConfigModel.auditOrgCode);
				$("#auditOrgName").val(data.auditConfigModel.auditOrgName);
				$("#auditOrgSid").val(data.auditConfigModel.auditOrgSid);
				
				$('input[name="auditConfigModel.adapterType"][value="'+data.auditConfigModel.adapterType+'"]').attr("checked",true);
				
				for (var key in constants.ADAPTERTYPE) {
					$('input[name="auditConfigModel.adapterType"][value="'+key+'"]').attr("disabled",true);
				}
				
				if(data.auditConfigModel.adapterType=="1"){
					$('#orgtr').css("display" ,"none");
				}else{
					$('#orgtr').css("display" ,"");
				}
				$("#orgSpName").val(Organization.getOrganizationByOrgNo(data.auditConfigModel.orgCode).organizationName);
				$("#orgSpSid").val(data.auditConfigModel.orgSid);
				$("#orgSp").val(data.auditConfigModel.orgCode);
				$("#configTypeList").val(data.auditConfigModel.configType);
				$("#configTypeList").multiselect("refresh");
				$("#configTypeList").multiselect("disable");
				$("#configTypeItem").val(data.auditConfigModel.configType);
				$("#auditOrgCodeImg").attr("disabled",true);
				$("#orgSpImg").attr("disabled",true);
				ComfirmType=1;
				$("#auditConfigDLG").dialog("open");
				$('#idItem').removeAttr('disabled');
				
				$("#auditOrgShowName").focus();
				$("#auditOrgShowName").val(data.auditConfigModel.auditOrgShowName);
			} else {
				alert("失败:" + data.responseMessage.message);
			}
		}
	});
}

function delAuditConfig(id){
	var b = confirm("确定要删除该配置吗？");
	if (b) {
	$.ajax({
	type : "POST",
	url : ctx + "/param/gssAuditConfigAction_delAuditConfig.action",
	data : {
	    id : id
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		$("#auditConfigDLG").dialog("close");
		$("#auditConfigsTable").trigger("reloadGrid");
	    } else {
		alert("删除失败:" + data.responseMessage.message);
	    }
	}
    });
	}
};

function updateAuditConfig(){
	$.ajax({
		type : "POST",
		url : ctx + "/param/gssAuditConfigAction_delAuditConfig.action",
		data : {
		    id : id
		},
		dataType : "json",
		async : false,
		success : function(data) {
		    if (data && data.responseMessage && data.responseMessage.success) {
			$("#auditConfigDLG").dialog("close");
			$("#auditConfigsTable").trigger("reloadGrid");
		    } else {
			alert("删除失败:" + data.responseMessage.message);
		    }
		}
	    });
};

function cancelAdd(){
	$("#auditConfigDLG").dialog("close");
};

function checkData(){
	var result=true;
	if($("#auditOrgCode").val()==""){
		alert("授权中心机构不能为空");
		return false;
	}
	
	if($("#auditOrgShowName").val()==""){
		alert("授权中心显示名称不能为空");
		return false;
	}
	var configTypeList=$("#configTypeList").multiselect("getChecked").map(function(){ return this.value;	}).get();
	if(!configTypeList||configTypeList.length==0){
		alert("配置类型不能为空");
		return false;
	}
	
	$("#configTypeItem").val(configTypeList.toString());
	var mode = $('input[name="auditConfigModel.adapterType"]:checked').val();
	if(mode=="2"&&$("#orgSp").val()==""){
		alert("指定所属机构不能为空");
		return false;
	}
	$.ajax({
		type : "POST",
		url : ctx+ "/param/gssAuditConfigAction_checkAuditConfigExists.action",
		data : {
					auditOrgNo : $("#auditOrgCode").val(),
					adapterType : mode ,//== "1" ? "2" : "1",
					configType : $("#configTypeItem").val(),
					orgNo:$("#orgSpSid").val()
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (!(data && data.responseMessage && data.responseMessage.success)) {
				alert(data.responseMessage.message);
				result= false;
			} 
//			if(data.response.webResponseJson.state=="normal"){
//				
//			}
		}
	    });

	return result;
};
