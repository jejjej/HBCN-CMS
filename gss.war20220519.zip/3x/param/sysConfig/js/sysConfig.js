/**
 * 创建于:2015-5-21<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 系统参数js
 * 
 * @author 孙强
 * @version 1.0.0
 */

function sysConfigParamInit() {
	$("#sysConfigParamDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 320,
		width : 510,
		modal : true,
		buttons : {},
		close : function() {
			$("#modifyParamForm")[0].reset();
		}
	});
	queryRoleGrpIdList();
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight
			+ 6 - 50 * 2;
	// 列表
	$("#sysConfigParamsTable")
			.jqGrid(
					{
						width : pageContentWidth,
						height : tableHeight + "px",
						url : ctx
								+ "/param/paramSysConfigAction_listAll.action",
						multiselect : false,
						rowNum : 20,
						rownumbers:true,
						rowList : [ 20, 50, 100 ],
						colNames : [ "参数键", "参数名", "参数值", "类型" ,"操作"],
						colModel : [
								{
									name : "paramKey",
									index : "paramKey",
									align : "center",
									sortable : false
								},
								{
									name : "paramName",
									index : "paramName",
									align : "center",
									sortable : false
								},
								{
									name : "paramValue",
									index : "paramValue",
									align : "center",
									sortable : false,
									formatter: function(value, options, rData){
										return value;
									}
								},
								{
									name : "paramType",
									index : "paramType",
									align : "center",
									width : 60,
									sortable : false,
									formatter: function(value, options, rData) {
										return constants.sysConfigType[value] ;
									}
								},
								{
									name : "id",
									index : "id",
									align : "center",
									width : 60,
									sortable : false,
									formatter : function(value, options, rData) {
										return "<input type='button'  value='修改' onclick='openModifyDLG("
												+ value
												+ ")'/>";
									}
								} ],
						pager : "#sysConfigParamsTablePager"
					});
}

function queryList() {
	$("#sysConfigParamsTable").jqGrid("search", "#sysConfigQueryForm");
}
/**
 * 显示参数详情
 * @param id
 */
function openModifyDLG(id) {
	$.ajax({
		type : "POST",
		url : $.getContextPath()
				+ "/param/paramSysConfigAction_queryOneById.action",
		data : {
			id : id
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				document.getElementById('idtr').style.display="none";
				$("#idItem").val(data.paramSysConfig.id);
				$("#paramName").val(data.paramSysConfig.paramName);
				$("#paramValue").val(data.paramSysConfig.paramValue);
//				$("#paramValue").append("<option value='"+data.paramSysConfig.paramValue+"'>"
//						+data.paramSysConfig.paramValue+"</option>");
				$("#paramKey").val(data.paramSysConfig.paramKey);
				$("#paramType").val(data.paramSysConfig.paramType);
				$("#sysConfigParamDLG").dialog("open");
				document.getElementById('updateButtonDIV').style.display="";
				document.getElementById('idItem').removeAttribute('disabled');
			} else {
				alert("失败:" + data.responseMessage.message);
			}
		}
	});
	
}
/**
 * 修改参数
 */
function updateParam() {
	$.ajax({
		type : "POST",
		url : $.getContextPath()
				+ "/param/paramSysConfigAction_updateParam.action",
		data : {
			"paramSysConfig.id" : $("#idItem").val(),
			"paramSysConfig.paramName" : $("#paramName").val(),
			"paramSysConfig.paramValue" : $("#paramValue").val(),
			"paramSysConfig.paramKey" : $("#paramKey").val(),
			"paramSysConfig.paramType" : $("#paramType").val()
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$("#sysConfigParamDLG").dialog("close");
				$("#sysConfigParamsTable").trigger("reloadGrid");
			} else {
				alert("保存失败:" + data.responseMessage.message);
			}
		}
	});
}
/**
 * 取消修改
 */
function cancelUpdate() {
	$("#sysConfigParamDLG").dialog("close");
}
/**
 * 加载权限id列表
 */
function queryRoleGrpIdList(){
	var url = ctx +"/param/paramSysConfigAction_queryRoleGrpIdList.action";
	var data = tool.ajaxRequest(url, '');
	if(data.success){
		if (data.response.webResponseJson.state == "normal") {
				var roleGrpList = data.response.webResponseJson.data;
				if(roleGrpList!= null){
					$("#paramValue").append("<option value=''>--请选择--</option>");
					$(roleGrpList).each(function(i, value){
						$("#paramValue").append("<option value='"+roleGrpList[i].sid+"'>"
								+roleGrpList[i].sid+"("+roleGrpList[i].roleGroupName+")</option>");
		    		});
				}
			} else {
				alert("服务器响应失败");
			}
		}else{
			alert(data.response);
		}
}