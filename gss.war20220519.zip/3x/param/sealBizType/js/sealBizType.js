/**
 * 创建于:2015-5-14<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 印章业务种类参数
 * 
 * @author Rickychen
 * @version 1.0.0
 */

function sealBizTypeParamInit() {
    $("#sealBizTypeParamDLG").dialog({
	autoOpen : false,
	resizable : false,
	height : 180,
	width : 350,
	modal : true,
	buttons : {},
	close : function() {
	    $("#modifyParamForm")[0].reset();
	}
    });

    var pageHeaderHeight = $(".pageHeader").css("height");
    var pageContentWidth = $(".pageContent").width() - 2;
    pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
    var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
    $("#sealBizTypeParamsTable").jqGrid(
	    {
		width : pageContentWidth,
		height : tableHeight + "px",
		url : ctx + "/param/paramSealBizTypeAction_queryList.action",
		multiselect : false,
		rowNum : 20,
		rownumbers : true,
		rowList : [ 20, 50, 100 ],
		colNames : [ "印章材质类型", "印章种类编号", "印章种类名称", "操作" ],
		colModel : [
			{
			    name : "sealMaterialType",
			    index : "sealMaterialType",
			    align : "center",
			    sortable : false,
			    formatter : formatSealMaterialType
			},
			{
			    name : "sealBizTypeId",
			    index : "sealBizTypeId",
			    align : "center",
			    sortable : false
			},
			{
			    name : "sealBizTypeName",
			    index : "sealBizTypeName",
			    align : "center",
			    sortable : false
			},
			{
			    name : "id",
			    index : "id",
			    align : "center",
			    sortable : false,
			    formatter : function(value, options, rData) {
				return "<input type='button'  value='修改' onclick='openModifyDLG(" + value
					+ ")'/><input type='button' value='删除' onclick='deleteParam(" + value
					+ ")'  />";
			    }
			} ],
		pager : "#sealBizTypeParamsTablePager"
	    });
}

function formatSealMaterialType(sealMaterialType) {
    return sealTypeList[sealMaterialType];
}

function queryList() {
    $("#sealBizTypeParamsTable").jqGrid("search", "#sealBizTypeQueryForm");
}

function openModifyDLG(id) {
    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramSealBizTypeAction_queryOneById.action",
	data : {
	    id : id
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		document.getElementById('idtr').style.display = "none";
		$("#idItem").val(data.paramSealBizType.id);
		$("#sealMaterialTypeInput").val(data.paramSealBizType.sealMaterialType);
		$("#sealBizTypeIdImput").val(data.paramSealBizType.sealBizTypeId);
		$("#sealBizTypeNameInput").val(data.paramSealBizType.sealBizTypeName);
		$("#sealBizTypeParamDLG").dialog("open");
		document.getElementById('updateButtonDIV').style.display = "";
		document.getElementById('addButtonDIV').style.display = "none";
		document.getElementById('idItem').removeAttribute('disabled');
	    } else {
		alert("失败:" + data.responseMessage.message);
	    }
	}
    });
}

function updateParam() {
    if (!$("#modifyParamForm").validationEngine("validate")) {
	return;
    }

    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramSealBizTypeAction_updateParam.action",
	data : {
	    "paramSealBizType.id" : $("#idItem").val(),
	    "paramSealBizType.sealMaterialType" : $.trim($("#sealMaterialTypeInput").val()),
	    "paramSealBizType.sealBizTypeId" : $.trim($("#sealBizTypeIdImput").val()),
	    "paramSealBizType.sealBizTypeName" : $.trim($("#sealBizTypeNameInput").val())
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		$("#sealBizTypeParamDLG").dialog("close");
		$("#sealBizTypeParamsTable").trigger("reloadGrid");
	    } else {
		alert("保存失败:" + data.responseMessage.message);
	    }
	}
    });
}

function cancelUpdate() {
    $("#sealBizTypeParamDLG").dialog("close");
}

function openAddParamDLG() {
    $("#sealBizTypeParamDLG").dialog("open");
    document.getElementById('idtr').style.display = "none";
    document.getElementById('updateButtonDIV').style.display = "none";
    document.getElementById('addButtonDIV').style.display = "";
    document.getElementById('idItem').setAttribute('disabled', 'disabled');
}

function addParam() {
    if (!$("#modifyParamForm").validationEngine("validate")) {
	return;
    }

    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramSealBizTypeAction_addParam.action",
	data : {
	    "paramSealBizType.id" : $("#idItem").val(),
	    "paramSealBizType.sealMaterialType" : $.trim($("#sealMaterialTypeInput").val()),
	    "paramSealBizType.sealBizTypeId" : $.trim($("#sealBizTypeIdImput").val()),
	    "paramSealBizType.sealBizTypeName" : $.trim($("#sealBizTypeNameInput").val())
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		$("#sealBizTypeParamDLG").dialog("close");
		$("#sealBizTypeParamsTable").trigger("reloadGrid");
	    } else {
		alert("保存失败:" + data.responseMessage.message);
	    }
	}
    });
}

function cancelAdd() {
    $("#sealBizTypeParamDLG").dialog("close");
}

function deleteParam(id) {
    var b = confirm("确定要删除该参数吗？");
    if (b) {
	$.ajax({
	    type : "POST",
	    url : $.getContextPath() + "/param/paramSealBizTypeAction_deleteParam.action",
	    data : {
		id : id
	    },
	    dataType : "json",
	    async : false,
	    success : function(data) {
		if (data && data.responseMessage && data.responseMessage.success) {
		    $("#sealBizTypeParamDLG").dialog("close");
		    $("#sealBizTypeParamsTable").trigger("reloadGrid");
		} else {
		    alert("删除失败:" + data.responseMessage.message);
		}
	    }
	});
    }

}
