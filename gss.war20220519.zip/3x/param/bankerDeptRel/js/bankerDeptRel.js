/**
 * 创建于:2015-6-10<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 行长部门关联参数
 * 
 * @author chenhuang
 * @version 1.0.0
 */

// 当前选中的机构Id，默认为当前登录人员机构id
var currSelectOrgSid = "";
var currSelectOrgType = "";

var currDeptTreeId = null;
var currSelectBanker = null;

/**
 * 初始化机构树及列表信息
 */
function init() {

	// 初始化机构树
	$("#orgTreeItem").orgTree("normal", top.loginPeopleInfo.orgSid, false, function(event, treeId, treeNode) {
		currSelectOrgSid = treeNode.sid;
		currSelectOrgType = treeNode.organizationType;
		resetForm();
		queryList();
	}, null);

	// 初始化表格
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	$("#bankerDeptRelList").jqGrid(
			{
				width : pageContentWidth,
				height : tableHeight + "px",
				url : ctx + "/param/paramBankerDeptRelAction_list.action",
				rowNum : 20,
				rownumbers : true,
				rowList : [ 20, 50, 100 ],
				colNames : [ "用户名称", "部门名称", "操作" ],
				colModel : [
						{
							name : "bankerName",
							index : "bankerName",
							align : "center",
							sortable : true
						},
						{
							name : "deptName",
							index : "deptName",
							align : "center",
							sortable : false
						},
						{
							align : "center",
							width : 60,
							sortable : false,
							formatter : function(value, options, rData) {
								return "<input type='button' value='删除' onclick='deleteBankerDeptRel(\""
										+ rData.bankerId + "\",\"" + rData.deptId + "\")'  />";
							}
						} ],
				pager : "#bankerDeptRelListPager"
			});

	// 初始化弹框信息
	$("#modifyBankerDeptRelDialog").dialog({
		autoOpen : false,
		caption : "修改关联",
		resizable : false,
		height : 450,
		width : 500,
		modal : true,
		close : function() {
			$("#bankerDeptRelList").trigger("reloadGrid");
		}
	});
}

/**
 * 新增管理关系关联
 */
function updateBankerDeptRel() {
	if (currSelectOrgSid == "") {
		alert("请选择当前机构!");
		return;
	}

	if (currSelectOrgType != "" && currSelectOrgType == GSS.ORG_TYPE_DEPT) {
		alert("所选机构机构类型不能为部门!");
		return;
	}

	$("#modifyBankerDeptRelDialog").dialog("open");

	// 初始化部门树
	$("#deptTreeItem").orgTree("checkboxnops", currSelectOrgSid, false, null, function(event, treeId, treeNode) {
		currDeptTreeId = treeId;
	});
	// 初始化行长列表
	listBanker();
}

function saveBankerDeptRel() {
	if (currSelectBanker == null) {
		alert("请选择待关联人员!");
		return;
	}

	// 获取已经选中节点
	if (currDeptTreeId == null) {
		alert("请选择待关联部门!");
		return;
	}
	var treeObj = $.fn.zTree.getZTreeObj(currDeptTreeId);
	var nodes = treeObj.getCheckedNodes(true);
	if (nodes != null && nodes.length > 0) {
		var info = "";
		for ( var i = 0; i < nodes.length; i++) {
			var paramBankerDeptRel = {
				"paramBankerDeptRel.bankerId" : currSelectBanker.sid,
				"paramBankerDeptRel.bankerOrgId" : currSelectBanker.organizeSid,
				"paramBankerDeptRel.bankerName" : currSelectBanker.peopleName,
				"paramBankerDeptRel.deptId" : nodes[i].sid,
				"paramBankerDeptRel.deptName" : nodes[i].organizationName
			}
			$.ajax({
				type : "POST",
				url : ctx + "/param/paramBankerDeptRelAction_addRel.action",
				data : paramBankerDeptRel,
				dataType : "json",
				async : false,
				success : function(data) {
					if (data && data.responseMessage && data.responseMessage.success) {

					} else {
						info = currSelectBanker.peopleName + "," + nodes[i].organizationName + ";";
					}
				}
			});
		}
		if (info == "") {
			$.success("关联关系添加成功!");
		} else {
			$.warn("关联关系部分添加成功,以下关联关系添加失败:[<font color='red' font-weight='bold '>" + info + "</font>]");
		}
		$("#modifyBankerDeptRelDialog").dialog("close");

		// 初始化当前选择值
		currSelectBanker = null;
		currDeptTreeId = null;
	} else {
		alert("请选择待关联部门!");
		return;
	}
}

function deleteBankerDeptRel(bankerId, deptId) {
	if (window.confirm('你确定解除该关联关系?')) {
		$.ajax({
			type : "POST",
			url : ctx + "/param/paramBankerDeptRelAction_delRel.action",
			data : {
				"paramBankerDeptRel.bankerId" : bankerId,
				"paramBankerDeptRel.deptId" : deptId
			},
			dataType : "json",
			async : false,
			success : function(data) {
				if (data && data.responseMessage && data.responseMessage.success) {
					alert("关联关系解除成功.")
					$("#bankerDeptRelList").trigger("reloadGrid");
				} else {
					alert("关联关系解除失败:" + data.responseMessage.message);
				}
			}
		});
	}
}

function queryList() {
	$("#bankerDeptRelList").jqGrid("search", "#bankerDeptRelSearchForm");
}

function listBanker() {
	var setting = {
		check : {
			enable : true,
			chkStyle : "radio",
			radioType : "level"
		},
		data : {
			simpleData : {
				enable : true
			}
		},
		callback : {
			onCheck : function(e, treeId, treeNode) {
				currSelectBanker = {};
				currSelectBanker["sid"] = treeNode.sid;
				currSelectBanker["organizeSid"] = treeNode.organizeSid;
				currSelectBanker["peopleName"] = treeNode.peopleName;
			}
		}
	};
	$.ajax({
		type : "POST",
		url : ctx + "/param/paramBankerDeptRelAction_listBanker.action",
		data : {
			sid : currSelectOrgSid
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data.peopleInfos) {
				var array = [];
				var _id = null, _peopleName = null, _peopleCode = null, _orgSid = null, _orgName;
				$.each(data.peopleInfos, function(index, peopleInfo) {
					_id = peopleInfo.sid;
					_peopleName = peopleInfo.peopleName;
					_peopleCode = peopleInfo.peopleCode;
					_orgSid = peopleInfo.organizeSid;
					_orgName = peopleInfo.orgName;
					array[index] = {
						id : _id,
						name : _peopleName,
						sid : _id,
						peopleName : _peopleName,
						peopleCode : _peopleCode,
						organizeSid : _orgSid,
						orgName : _orgName
					};
				});
				$.fn.zTree.init($("#bankerTreeItem"), setting, array);
			} else {
				alert("数据不存在");
			}
		}
	});

}

function resetForm() {
	$("#bankerDeptRelSearchForm")[0].reset();
	$("#bankerOrgId").val(currSelectOrgSid);
}