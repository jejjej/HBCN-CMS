/**
 * 创建于:2015-5-15<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 交易代码参数
 * 
 * @author Rickychen
 * @version 1.0.0
 */

$(function() {
    // 初始化详情框dialog
    initEditDialog();

    // 初始化表格数据
    tradeCodeParamInit();

});


function initEditDialog() {
    $("#tradeCodeParamDLG").dialog({
	autoOpen : false,
	resizable : false,
	height : 350,
	width : 350,
	modal : true,
	buttons : {},
	close : function() {
	    $("#sealBizTypeNameInput").empty();
	    $("#modifyParamForm")[0].reset();
	}
    });
};

function tradeCodeParamInit() {
    var pageHeaderHeight = $(".pageHeader").css("height");
    var pageContentWidth = $(".pageContent").width() - 2;
    pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
    var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
    $("#tradeCodeParamsTable").jqGrid(
	    {
		width : pageContentWidth,
		height : tableHeight + "px",
		url : ctx + "/gss/tradeInfo/tradeInfo_list.action",
		multiselect : false,
		rowNum : 20,
		rownumbers : true,
		rowList : [ 20, 50, 100 ],
		colNames : ["交易代码", "交易代码名称", "描述", "操作" ],
		colModel : [
			{
			    name : "tradeCode",
			    index : "tradeCode",
			    align : "center",
			    sortable : false
			},
			{
			    name : "tradeName",
			    index : "tradeName",
			    align : "center",
			    sortable : false
			},
			{
			    name : "memo",
			    index : "memo",
			    align : "center",
			    sortable : false
			},
			{
			    name : "autoId",
			    index : "autoId",
			    align : "center",
			    sortable : false,
			    formatter : function(value, options, rData) {
				return "<input type='button'  value='修改' onclick='openModifyDLG(\"" + value
					+ "\")'/><input type='button' value='删除' onclick='deleteParam(\"" + value + "\")' />";
			    }
			} ],
		pager : "#tradeCodeParamsTablePager"
	    });
};

function queryList() {
    $("#tradeCodeParamsTable").jqGrid("search", "#tradeCodeQueryForm");
};

function openModifyDLG(id) {
    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/gss/tradeInfo/tradeInfo_findTradeInfoById.action",
	data : {
	    "tradeInfo.autoId" : id
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
			document.getElementById('idtr').style.display = "none";
			$("#idItem").val(id);
			var ti = data.responseMessage.data;
			$("#tradeCodeId").attr("disabled","disabled");
			$("#tradeCodeId").val(ti.tradeCode);
			$("#tradeCodeName").val(ti.tradeName);
			$("#memo").val(ti.memo);
			$("#tradeCodeParamDLG").dialog("open");
			document.getElementById('updateButtonDIV').style.display = "";
			document.getElementById('addButtonDIV').style.display = "none";
			document.getElementById('idItem').removeAttribute('disabled');
	    } else {
	    	alert("失败:" + data.responseMessage.message);
	    }
	}
    });
};

function updateParam() {
	var tradeCodeName = $.trim($("#tradeCodeName").val());
	if (tradeCodeName == null || tradeCodeName == "") {
		alert("交易代码名称不能为空");
		return;
	}
    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/gss/tradeInfo/tradeInfo_update.action",
	data : {
	    "tradeInfo.autoId" : $("#idItem").val(),
	    "tradeInfo.tradeName":$("#tradeCodeName").val(),
	    "tradeInfo.tradeCode":$("#tradeCodeId").val(),
	    "tradeInfo.memo":$("#memo").val()
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
			$("#tradeCodeParamDLG").dialog("close");
			$("#tradeCodeParamsTable").trigger("reloadGrid");
	    } else {
	    	alert("更新失败:" + data.responseMessage.message);
	    }
	}
    });
};

function cancelUpdate() {
    $("#tradeCodeParamDLG").dialog("close");
};

function openAddParamDLG() {
    $("#tradeCodeParamDLG").dialog("open");
    document.getElementById('tradeCodeId').removeAttribute('disabled');
    document.getElementById('idtr').style.display = "none";
    document.getElementById('updateButtonDIV').style.display = "none";
    document.getElementById('addButtonDIV').style.display = "";
    document.getElementById('idItem').setAttribute('disabled', 'disabled');
};

function addParam() {
	var tradeCode = $.trim($("#tradeCodeId").val());
	if (tradeCode == null || tradeCode == "") {
		alert("交易代码不能为空");
		return;
	}
	var tradeCodeName = $.trim($("#tradeCodeName").val());
	if (tradeCodeName == null || tradeCodeName == "") {
		alert("交易代码名称不能为空");
		return;
	}
    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/gss/tradeInfo/tradeInfo_save.action",
	data : {
	    "tradeInfo.tradeName":$("#tradeCodeName").val(),
	    "tradeInfo.tradeCode":$("#tradeCodeId").val(),
	    "tradeInfo.memo":$("#memo").val()
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
			$("#tradeCodeParamDLG").dialog("close");
			$("#tradeCodeParamsTable").trigger("reloadGrid");
	    } else {
	    	alert("保存失败:" + data.responseMessage.message);
	    }
	}
    });
};


function cancelAdd() {
    $("#tradeCodeParamDLG").dialog("close");
};

function deleteParam(id) {
    var b = confirm("确定要删除该参数吗？");
    if (b) {
	$.ajax({
	    type : "POST",
	    url : $.getContextPath() + "/gss/tradeInfo/tradeInfo_delete.action",
	    data : {
		"tradeInfo.autoId" : id
	    },
	    dataType : "json",
	    async : false,
	    success : function(data) {
		if (data && data.responseMessage && data.responseMessage.success) {
		    $("#tradeCodeParamDLG").dialog("close");
		    $("#tradeCodeParamsTable").trigger("reloadGrid");
		} else {
		    alert("删除失败:" + data.responseMessage.message);
		}
	    }
	});
    }

};

function changeWorkFlowFinalAppr() {
    var workFlowIdInput = $("#workFlowIdInput").val();
    selectUtils.initWorkFlowFinalAppr("workFlowFinalApprInput", workFlowIdInput);
};

function changeSealBizType() {
    var sealMaterialType = $("#sealMaterialTypeInput").val();
    selectUtils.initSealBizTypeByConfig("sealBizTypeNameInput", sealMaterialType);
};

/**
 * 选择查询机构
 */
function choseOrgNoCondition() {
    $("#orgNoCondition").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, null, null,
	    function(event, treeId, treeNode) {
		if (treeNode) {
		    $("#orgNoCondition").val(treeNode.organizationNo);
		}
	    });
};

function choseOrgNoInput() {
    $("#orgNoInput").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, null, null,
	    function(event, treeId, treeNode) {
		if (treeNode) {
		    $("#orgNoInput").val(treeNode.organizationNo);
		}
	    });
};