/**
 * 创建于:2017-4-06<br>
 * 版权所有(C) 2017 深圳市银之杰科技股份有限公司<br>
 * 控件自动加载开关配置
 * 
 * @author 谭述文
 * @version 1.0.0
 */

var currentTreeId = null;
// 确定按钮是新增还是修改 0为新增 1为修改
var ComfirmType = 0;

function initControlSwitchDLG() {
	$("#controlSwitchDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 210,
		width : 400,
		modal : true,
		buttons : {
			"确定" : function() {
				if (ComfirmType == 0) {
					addSwitch();
				} else {
					updateSwitch($("#idItem").val(), $("#controlItem").val());
				}
			},
			"取消" : function() {
				cancelAdd();
			}
		},
		close : function() {
			$("#controlSwitchForm")[0].reset();
			$("#idItem").val("");
			$("#userList").multiselect("enable");
			ComfirmType = 0;
		}
	});

	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight
			+ 6 - 50 * 2;
	$("#controlSwitchTable")
			.jqGrid(
					{
						width : pageContentWidth,
						height : tableHeight + "px",
						url : ctx
								+ "/param/controlSwitchAction_queryList.action",
						multiselect : false,
						rowNum : 20,
						rownumbers : true,
						rowList : [ 20, 50, 100 ],
						colNames : [ "用户", "用户代码", "所属机构", "机构代码", "控件自动加载状态",
								"操作" ],
						colModel : [
								{
									name : "peopleName",
									index : "peopleName",
									align : "center",
									sortable : false
								},
								{
									name : "peopleCode",
									index : "peopleCode",
									align : "center",
									sortable : false
								},
								{
									name : "orgName",
									index : "orgName",
									align : "center",
									sortable : false
								},
								{
									name : "orgNo",
									index : "orgNo",
									align : "center",
									sortable : false
								},
								{
									name : "openSwitch",
									index : "openSwitch",
									align : "center",
									sortable : false,
									formatter : function(value, options, rData) {
										if (value == "0") {
											return "控件自动加载";
										} else {
											return "控件不自动加载";
										}
									}
								},
								{
									name : "sid",
									index : "sid",
									align : "center",
									sortable : false,
									formatter : function(value, options, rData) {
										return "<input type='button'  value='修改' onclick=openModifyDLG('"
												+ value
												+ "') /><input type='button' value='删除' onclick=delSwitch('"
												+ value + "')  />";
									}
								} ],
						pager : "#controlSwitchTablePager"
					});

};

function initQueryForm() {
	// 初始化用户
	var adapterTypeOptions = "";
	$.ajax({
		type : "POST",
		url : ctx + "/param/controlSwitchAction_findAllUserNotControl.action",
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				var length = data.userList.length;
				for (i = 0; i < length; i++) {
					adapterTypeOptions += ("<option value=\""
							+ data.userList[i].sid + "\">"
							+ data.userList[i].peopleName + "</option>");
				}
				;
			} else {
				alert("失败:" + data.responseMessage.message);
			}
		}
	});
	$("#userList").html(adapterTypeOptions);
	$("#userList").multiselect({
		noneSelectedText : "请选择",
		checkAllText : "全选",
		uncheckAllText : '全不选',
		selectedList : 4,
		height : "50px"

	});
	adapterTypeOptions = "<option value=' '>全部</option>" + adapterTypeOptions;

};

function add() {
	$("#controlSwitchDLG").dialog("open");
	$('#autoIdtr').css("display", "none");
	$('#orgtr').css("display", "none");
	$('#idItem').attr('disabled', 'disabled');
	initQueryForm();
	$("#userList").multiselect("refresh");

};

function queryList() {
	$("#controlSwitchTable").jqGrid("search", "#queryForm");
}

function choseOrg() {
	$("#orgNo").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, null,
			null, function(event, treeId, treeNode) {
				if (treeNode) {
					$("#orgNo").val(treeNode.organizationNo);
					$("#orgName").val(treeNode.organizationName);
					$("#orgId").val(treeNode.sid);
				}
			});
}

function addSwitch() {
	if (ComfirmType == 0 ? checkData() : true) {
		$.post(ctx + "/param/controlSwitchAction_addParam.action", {
			userItem : $("#userItem").val(),
			controlItem : $("#controlItem").val()
		}, function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$.success("保存成功");
				$("#controlSwitchDLG").dialog("close");
				$("#controlSwitchTable").trigger("reloadGrid");
			} else {
				alert("保存失败:" + data.responseMessage.message);
			}

		});
	}
}

function openModifyDLG(id) {
	var adapterTypeOptions1 = "";
	$.ajax({
		type : "POST",
		url : ctx + "/param/controlSwitchAction_queryOneById.action",
		data : {
			id : id
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				initQueryForm();
				$("#userList").multiselect("refresh");
				$('#autoIdtr').css("display", "none");
				$("#idItem").val(data.controlSwitch.sid);
				$("#orgNo").val(data.controlSwitch.orgNo);
				$("#orgName").val(data.controlSwitch.orgName);
				$("#orgId").val(data.controlSwitch.orgId);

				$("#userList").multiselect("disable");
				$("#userList").val(data.controlSwitch.peopleName);
				adapterTypeOptions1 += ("<option value=\""
						+ data.controlSwitch.peopleId
						+ "\" selected='selected'>"
						+ data.controlSwitch.peopleName + "</option>");
				$("#userList").html(adapterTypeOptions1);
				$("#userList").multiselect("refresh");
				$("#userList").multiselect({
					noneSelectedText : "请选择",
					checkAllText : "全选",
					uncheckAllText : '全不选',
					selectedList : 4,
					height : "50px"

				});
				$("#userItem").val(data.controlSwitch.peopleId);
				ComfirmType = 1;
				$("#controlSwitchDLG").dialog("open");
				$('#idItem').removeAttr('disabled');
			} else {
				alert("失败:" + data.responseMessage.message);
			}
		}
	});
}

function delSwitch(id) {
	var b = confirm("确定要删除该配置吗？");
	if (b) {
		$.ajax({
			type : "POST",
			url : ctx + "/param/controlSwitchAction_deleteParam.action",
			data : {
				id : id
			},
			dataType : "json",
			async : false,
			success : function(data) {
				if (data && data.responseMessage
						&& data.responseMessage.success) {
					$("#controlSwitchDLG").dialog("close");
					$("#controlSwitchTable").trigger("reloadGrid");
				} else {
					alert("删除失败:" + data.responseMessage.message);
				}
			}
		});
	}
};

function updateSwitch(id, openSwitch) {
	$.ajax({
		type : "POST",
		url : ctx + "/param/controlSwitchAction_updateParam.action",
		data : {
			"id" : id,
			"openSwitch" : openSwitch
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$("#controlSwitchDLG").dialog("close");
				$("#controlSwitchTable").trigger("reloadGrid");
			} else {
				alert("删除失败:" + data.responseMessage.message);
			}
		}
	});
};

function cancelAdd() {
	$("#controlSwitchDLG").dialog("close");
};

function checkData() {
	var result = true;
	var userList = $("#userList").multiselect("getChecked").map(function() {
		return this.value;
	}).get();
	if (!userList || userList.length == 0) {
		alert("用户不能为空");
		return false;
	}
	$("#userItem").val(userList.toString());
	return result;
};
