/**
 * 创建于:2015-5-15<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 审批模式参数
 * 
 * @author Rickychen
 * @version 1.0.0
 */

function approvalModeParamInit() {
    $("#approvalModeParamDLG").dialog({
	autoOpen : false,
	resizable : false,
	height : 210,
	width : 260,
	modal : true,
	buttons : {},
	close : function() {
	    $("#modifyParamForm")[0].reset();
	}
    });

    $("#orgNoCondition").val(top.loginPeopleInfo.orgNo);

    var approvalBizContent = "";
    for ( var key in constants.APPROVAL_BIZ) {
	approvalBizContent += "<option value='" + key + "'>" + constants.APPROVAL_BIZ[key] + "</option>";
    }
    $("#approvalBizItem").html(approvalBizContent);
    approvalBizContent = "<option value=' '>全部</option>" + approvalBizContent;
    $("#approvalBiz").html(approvalBizContent);

    var approvalBizContent = "";
    for ( var key in constants.APPROVAL_MODE) {
	approvalBizContent += "<option value='" + key + "'>" + constants.APPROVAL_MODE[key] + "</option>";
    }
    $("#approvalModeItem").html(approvalBizContent);
    approvalBizContent = "<option value=' '>全部</option>" + approvalBizContent;
    $("#approvalMode").html(approvalBizContent);

    var pageHeaderHeight = $(".pageHeader").css("height");
    var pageContentWidth = $(".pageContent").width() - 2;
    pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
    var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
    $("#approvalModeParamsTable").jqGrid(
	    {
		width : pageContentWidth,
		height : tableHeight + "px",
		url : ctx + "/param/paramApprovalModeAction_queryList.action",
		multiselect : false,
		rowNum : 20,
		rownumbers : true,
		rowList : [ 20, 50, 100 ],
		colNames : [ "机构号", "审批业务类型", "审批模式", "操作" ],
		colModel : [
			{
			    name : "orgNo",
			    index : "orgNo",
			    align : "center",
			    sortable : false
			},
			{
			    name : "approvalBiz",
			    index : "approvalBiz",
			    align : "center",
			    sortable : false,
			    formatter : formatApprovalBiz
			},
			{
			    name : "approvalMode",
			    index : "approvalMode",
			    align : "center",
			    sortable : false,
			    formatter : formatApprovalMode
			},
			{
			    name : "id",
			    index : "id",
			    align : "center",
			    width : 60,
			    sortable : false,
			    formatter : function(value, options, rData) {
				return "<input type='button'  value='修改' onclick='openModifyDLG(" + value
					+ ")'/><input type='button' value='删除' onclick='deleteParam(" + value
					+ ")'  />";
			    }
			} ],
		pager : "#approvalModeParamsTablePager"
	    });
}

function clearQuery() {
    $("#approvalModequeryForm")[0].reset();
    var selectArr = $("select");
    for ( var i = 0; i < selectArr.length; i++) {
	selectArr[i].options[0].selected = true;
    }
}

function formatApprovalBiz(approvalBiz) {
    return constants.APPROVAL_BIZ[approvalBiz];
}

function formatApprovalMode(approvalMode) {
    return constants.APPROVAL_MODE[approvalMode];
}

function queryList() {
    $("#approvalModeParamsTable").jqGrid("search", "#approvalModequeryForm");
}

function openModifyDLG(id) {
    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramApprovalModeAction_queryOneById.action",
	data : {
	    id : id
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		document.getElementById('idtr').style.display = "none";
		$("#idItem").val(data.approvalMode.id);
		$("#orgNoInput").val(data.approvalMode.orgNo);
		$("#approvalBizItem").val(data.approvalMode.approvalBiz);
		$("#approvalModeItem").val(data.approvalMode.approvalMode);
		$("#approvalModeParamDLG").dialog("open");
		document.getElementById('updateButtonDIV').style.display = "";
		document.getElementById('addButtonDIV').style.display = "none";
		document.getElementById('idItem').removeAttribute('disabled');
	    } else {
		alert("失败:" + data.responseMessage.message);
	    }
	}
    });
}

function updateParam() {
    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramApprovalModeAction_updateParam.action",
	data : {
	    "approvalMode.id" : $("#idItem").val(),
	    "approvalMode.orgNo" : $.trim($("#orgNoInput").val()),
	    "approvalMode.approvalBiz" : $.trim($("#approvalBizItem").val()),
	    "approvalMode.approvalMode" : $.trim($("#approvalModeItem").val())
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		$("#approvalModeParamDLG").dialog("close");
		$("#approvalModeParamsTable").trigger("reloadGrid");
	    } else {
		alert("保存失败:" + data.responseMessage.message);
	    }
	}
    });
}

function cancelUpdate() {
    $("#approvalModeParamDLG").dialog("close");
}

function openAddParamDLG() {
    $("#approvalModeParamDLG").dialog("open");
    document.getElementById('idtr').style.display = "none";
    document.getElementById('updateButtonDIV').style.display = "none";
    document.getElementById('addButtonDIV').style.display = "";
    document.getElementById('idItem').setAttribute('disabled', 'disabled');
}

function addParam() {
    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramApprovalModeAction_addParam.action",
	data : {
	    "approvalMode.orgNo" : $.trim($("#orgNoInput").val()),
	    "approvalMode.approvalBiz" : $.trim($("#approvalBizItem").val()),
	    "approvalMode.approvalMode" : $.trim($("#approvalModeItem").val())
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		$("#approvalModeParamDLG").dialog("close");
		$("#approvalModeParamsTable").trigger("reloadGrid");
	    } else {
		alert("保存失败:" + data.responseMessage.message);
	    }
	}
    });
}

function cancelAdd() {
    $("#approvalModeParamDLG").dialog("close");
}

function deleteParam(id) {
    var b = confirm("确定要删除该参数吗？");
    if (b) {
	$.ajax({
	    type : "POST",
	    url : $.getContextPath() + "/param/paramApprovalModeAction_deleteParam.action",
	    data : {
		id : id
	    },
	    dataType : "json",
	    async : false,
	    success : function(data) {
		if (data && data.responseMessage && data.responseMessage.success) {
		    $("#approvalModeParamDLG").dialog("close");
		    $("#approvalModeParamsTable").trigger("reloadGrid");
		} else {
		    alert("删除失败:" + data.responseMessage.message);
		}
	    }
	});
    }

}

/**
 * 选择查询机构
 */
function choseOrgNoCondition() {
    $("#orgNoCondition").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, null, null,
	    function(event, treeId, treeNode) {
		if (treeNode) {
		    $("#orgNoCondition").val(treeNode.organizationNo);
		}
	    });
}
function choseOrgNoInput() {
    $("#orgNoInput").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, null, null,
	    function(event, treeId, treeNode) {
		if (treeNode) {
		    $("#orgNoInput").val(treeNode.organizationNo);
		}
	    });
}