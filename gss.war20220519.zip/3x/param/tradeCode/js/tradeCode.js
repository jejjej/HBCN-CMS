/**
 * 创建于:2015-5-15<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 交易代码参数
 * 
 * @author Rickychen
 * @version 1.0.0
 */

$(function() {
    // 初始化详情框dialog
    initEditDialog();

    // 初始化表格数据
    tradeCodeParamInit();

    // 初始化下拉列表
    selectUtils.initWorkFlowIdSelect("workFlowIdInput");

    // 初始化表单验证
    formValidation.init("modifyParamForm", "bottomLeft");

    // 初始化交易代码下拉列表
    initTradeCodeSelect();

    // 初始化交易代码类型配置
    initTradeCodeType();
});

function initTradeCodeType() {
    var type = GPCache.get(GPCache.G3X, constants.TRADE_CODE_TYPE_KEY);
    if (type == constants.TRADE_CODE_TYPE_ADMIN) {
	$("#tradeCodeTypeInput").append("<option value='" + constants.TRADE_CODE_TYPE_ADMIN + "'>行政</option>");
    } else if (type == constants.TRADE_CODE_TYPE_BIZ) {
	$("#tradeCodeTypeInput").append("<option value='" + constants.TRADE_CODE_TYPE_BIZ + "'>业务</option>");
    } else if (type == constants.TRADE_CODE_TYPE_ALL) {
	$("#tradeCodeTypeInput").append("<option value='" + constants.TRADE_CODE_TYPE_ADMIN + "'>行政</option>");
	$("#tradeCodeTypeInput").append("<option value='" + constants.TRADE_CODE_TYPE_BIZ + "'>业务</option>");
    } else {
	alert("后台GSSParam参数中的tradeCodeType配置有误");
    }
};

function initTradeCodeSelect() {
    var peopleTypeData = top.getSystemParam('tradeCode');
    $("#tradeCodeInput").append("<option value=''>--请选择--</option>");
    $.each(peopleTypeData, function(index, value) {
	$("#tradeCodeInput").append("<option value='" + value.paramName + "'>" + value.paramValue + "</option>");
    });
};

function initEditDialog() {
    $("#tradeCodeParamDLG").dialog({
	autoOpen : false,
	resizable : false,
	height : 350,
	width : 350,
	modal : true,
	buttons : {},
	close : function() {
	    $("#sealBizTypeNameInput").empty();
	    $("#modifyParamForm")[0].reset();
	}
    });
};

function tradeCodeParamInit() {
    var pageHeaderHeight = $(".pageHeader").css("height");
    var pageContentWidth = $(".pageContent").width() - 2;
    pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
    var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
    $("#tradeCodeParamsTable").jqGrid(
	    {
		width : pageContentWidth,
		height : tableHeight + "px",
		url : ctx + "/param/paramTradeCodeAction_queryList.action",
		multiselect : false,
		rowNum : 20,
		rownumbers : true,
		rowList : [ 20, 50, 100 ],
		colNames : [ "机构号", "交易代码", "交易代码名称", "印章材质类型", "印章业务类型名称", "上级审批", "操作" ],
		colModel : [
			{
			    name : "orgNo",
			    index : "orgNo",
			    align : "center",
			    sortable : false
			},
			{
			    name : "tradeCode",
			    index : "tradeCode",
			    align : "center",
			    sortable : false
			},
			{
			    name : "tradeCodeName",
			    index : "tradeCodeName",
			    align : "center",
			    sortable : false
			},
			{
			    name : "sealMaterialType",
			    index : "sealMaterialType",
			    align : "center",
			    sortable : false,
			    formatter : formatSealMaterialType
			},
			{
			    name : "sealBizTypeName",
			    index : "sealBizTypeName",
			    align : "center",
			    sortable : false
			},
			{
			    name : "parentAppr",
			    index : "parentAppr",
			    align : "center",
			    sortable : false,
			    formatter : formatParentAppr
			},
			{
			    name : "id",
			    index : "id",
			    align : "center",
			    sortable : false,
			    formatter : function(value, options, rData) {
				return "<input type='button'  value='修改' onclick='openModifyDLG(" + value
					+ ")'/><input type='button' value='删除' onclick='deleteParam(" + value
					+ ")'  />";
			    }
			} ],
		pager : "#tradeCodeParamsTablePager"
	    });
};

function queryTradeCode() {
    if ($("#tradeCodeInput").val() == null || $("#tradeCodeInput").val() == "") {
	return;
    }
    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramTradeCodeAction_queryByTradeCode.action",
	data : {
	    orgNo : $("#orgNoInput").val(),
	    tradeCode : $("#tradeCodeInput").val()
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		if (data.paramTradeCode != null) {
		    document.getElementById('idtr').style.display = "none";
		    $("#idItem").val(data.paramTradeCode.id);
		    $("#tradeCodeInput").val(data.paramTradeCode.tradeCode);
		    $("#tradeCodeTypeInput").val(data.paramTradeCode.tradeCodeType);
		    $("#sealMaterialTypeInput").val(data.paramTradeCode.sealMaterialType);
		    selectUtils.initSealBizTypeByConfig("sealBizTypeNameInput", data.paramTradeCode.sealMaterialType);
		    $("#sealBizTypeNameInput").val(data.paramTradeCode.sealBizTypeId);
		    $("#parentAppr").val(data.paramTradeCode.parentAppr);
		    $("#printCodeXpositionInput").val(data.paramTradeCode.printCodeXposition);
		    $("#printCodeYpositionInput").val(data.paramTradeCode.printCodeYposition);
		    document.getElementById('updateButtonDIV').style.display = "";
		    document.getElementById('addButtonDIV').style.display = "none";
		    document.getElementById('idItem').removeAttribute('disabled');
		} else {
		    var code = $("#tradeCodeInput").val();
		    $("#modifyParamForm")[0].reset();
		    $("#tradeCodeInput").val(code);
		}
	    }
	}
    });
};

function formatSealMaterialType(sealMaterialType) {
    return sealTypeList[sealMaterialType];
};

function formatParentAppr(result) {
    if (constants.JUDGE[result] != "") {
	return constants.JUDGE[result];
    }
};

function queryList() {
    $("#tradeCodeParamsTable").jqGrid("search", "#tradeCodeQueryForm");
};

function openModifyDLG(id) {
    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramTradeCodeAction_queryOneById.action",
	data : {
	    id : id
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		document.getElementById('idtr').style.display = "none";
		$("#idItem").val(data.paramTradeCode.id);
		$("#orgNoInput").val(data.paramTradeCode.orgNo);
		$("#tradeCodeInput").val(data.paramTradeCode.tradeCode);
		$("#tradeCodeTypeInput").val(data.paramTradeCode.tradeCodeType);
		$("#sealMaterialTypeInput").val(data.paramTradeCode.sealMaterialType);
		selectUtils.initSealBizTypeByConfig("sealBizTypeNameInput", data.paramTradeCode.sealMaterialType);
		$("#sealBizTypeNameInput").val(data.paramTradeCode.sealBizTypeId);
		$("#parentAppr").val(data.paramTradeCode.parentAppr);
		$("#printCodeXpositionInput").val(data.paramTradeCode.printCodeXposition);
		$("#printCodeYpositionInput").val(data.paramTradeCode.printCodeYposition);
		$("#tradeCodeParamDLG").dialog("open");
		document.getElementById('updateButtonDIV').style.display = "";
		document.getElementById('addButtonDIV').style.display = "none";
		document.getElementById('idItem').removeAttribute('disabled');
	    } else {
		alert("失败:" + data.responseMessage.message);
	    }
	}
    });
};

function updateParam() {
    if (!$("#modifyParamForm").validationEngine("validate")) {
	return;
    }

    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramTradeCodeAction_updateParam.action",
	data : {
	    "paramTradeCode.id" : $("#idItem").val(),
	    "paramTradeCode.orgNo" : $.trim($("#orgNoInput").val()),
	    "paramTradeCode.tradeCode" : $.trim($("#tradeCodeInput").val()),
	    "paramTradeCode.tradeCodeName" : $.trim($("#tradeCodeInput  option:selected").text()),
	    "paramTradeCode.tradeCodeType" : $.trim($("#tradeCodeTypeInput").val()),
	    "paramTradeCode.sealMaterialType" : $.trim($("#sealMaterialTypeInput").val()),
	    "paramTradeCode.sealBizTypeId" : $.trim($("#sealBizTypeNameInput").val()),
	    "paramTradeCode.sealBizTypeName" : $.trim($("#sealBizTypeNameInput  option:selected").text()),
	    "paramTradeCode.parentAppr" : $.trim($("#parentAppr").val()),
	    "paramTradeCode.printCodeXposition" : $.trim($("#printCodeXpositionInput").val()),
	    "paramTradeCode.printCodeYposition" : $.trim($("#printCodeYpositionInput").val())
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		$("#tradeCodeParamDLG").dialog("close");
		$("#tradeCodeParamsTable").trigger("reloadGrid");
	    } else {
		alert("保存失败:" + data.responseMessage.message);
	    }
	}
    });
};

function cancelUpdate() {
    $("#tradeCodeParamDLG").dialog("close");
};

function openAddParamDLG() {
    $("#tradeCodeParamDLG").dialog("open");
    $("#orgNoInput").val(top.loginPeopleInfo.orgNo);
    document.getElementById('idtr').style.display = "none";
    document.getElementById('updateButtonDIV').style.display = "none";
    document.getElementById('addButtonDIV').style.display = "";
    document.getElementById('idItem').setAttribute('disabled', 'disabled');

    changeSealBizType();
};

function addParam() {
    if (!$("#modifyParamForm").validationEngine("validate")) {
	return;
    }

    $.ajax({
	type : "POST",
	url : $.getContextPath() + "/param/paramTradeCodeAction_addParam.action",
	data : {
	    "paramTradeCode.id" : $("#idItem").val(),
	    "paramTradeCode.orgNo" : $.trim($("#orgNoInput").val()),
	    "paramTradeCode.tradeCode" : $.trim($("#tradeCodeInput").val()),
	    "paramTradeCode.tradeCodeName" : $.trim($("#tradeCodeInput  option:selected").text()),
	    "paramTradeCode.tradeCodeType" : $.trim($("#tradeCodeTypeInput").val()),
	    "paramTradeCode.sealMaterialType" : $.trim($("#sealMaterialTypeInput").val()),
	    "paramTradeCode.sealBizTypeId" : $.trim($("#sealBizTypeNameInput").val()),
	    "paramTradeCode.sealBizTypeName" : $.trim($("#sealBizTypeNameInput  option:selected").text()),
	    "paramTradeCode.parentAppr" : $.trim($("#parentAppr").val()),
	    "paramTradeCode.printCodeXposition" : $.trim($("#printCodeXpositionInput").val()),
	    "paramTradeCode.printCodeYposition" : $.trim($("#printCodeYpositionInput").val())
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		$("#tradeCodeParamDLG").dialog("close");
		$("#tradeCodeParamsTable").trigger("reloadGrid");
	    } else {
		alert("保存失败:" + data.responseMessage.message);
	    }
	}
    });
};

/**
 * 所有机构都新增此交易代码
 */
function addAll() {
    var t = confirm("确定要新增此交易代码到所有机构吗？");
    if (t) {
	if (!$("#modifyParamForm").validationEngine("validate")) {
	    return;
	}

	$.ajax({
	    type : "POST",
	    url : $.getContextPath() + "/param/paramTradeCodeAction_addTradeCodeToAllOrg.action",
	    data : {
		"paramTradeCode.id" : $("#idItem").val(),
		"paramTradeCode.orgNo" : $.trim($("#orgNoInput").val()),
		"paramTradeCode.tradeCode" : $.trim($("#tradeCodeInput").val()),
		"paramTradeCode.tradeCodeName" : $.trim($("#tradeCodeInput  option:selected").text()),
		"paramTradeCode.tradeCodeType" : $.trim($("#tradeCodeTypeInput").val()),
		"paramTradeCode.sealMaterialType" : $.trim($("#sealMaterialTypeInput").val()),
		"paramTradeCode.sealBizTypeId" : $.trim($("#sealBizTypeNameInput").val()),
		"paramTradeCode.sealBizTypeName" : $.trim($("#sealBizTypeNameInput  option:selected").text()),
		"paramTradeCode.parentAppr" : $.trim($("#parentAppr").val()),
		"paramTradeCode.printCodeXposition" : $.trim($("#printCodeXpositionInput").val()),
		"paramTradeCode.printCodeYposition" : $.trim($("#printCodeYpositionInput").val())
	    },
	    dataType : "json",
	    async : false,
	    success : function(data) {
		if (data && data.responseMessage && data.responseMessage.success) {
		    $("#tradeCodeParamDLG").dialog("close");
		    $("#tradeCodeParamsTable").trigger("reloadGrid");
		} else {
		    alert("保存失败:" + data.responseMessage.message);
		}
	    }
	});
    }
};

/**
 * 更新所有机构的此交易代码
 */
function updateAll() {
    // 尚不支持
};

function cancelAdd() {
    $("#tradeCodeParamDLG").dialog("close");
};

function deleteParam(id) {
    var b = confirm("确定要删除该参数吗？");
    if (b) {
	$.ajax({
	    type : "POST",
	    url : $.getContextPath() + "/param/paramTradeCodeAction_deleteParam.action",
	    data : {
		id : id
	    },
	    dataType : "json",
	    async : false,
	    success : function(data) {
		if (data && data.responseMessage && data.responseMessage.success) {
		    $("#tradeCodeParamDLG").dialog("close");
		    $("#tradeCodeParamsTable").trigger("reloadGrid");
		} else {
		    alert("删除失败:" + data.responseMessage.message);
		}
	    }
	});
    }

};

function changeWorkFlowFinalAppr() {
    var workFlowIdInput = $("#workFlowIdInput").val();
    selectUtils.initWorkFlowFinalAppr("workFlowFinalApprInput", workFlowIdInput);
};

function changeSealBizType() {
    var sealMaterialType = $("#sealMaterialTypeInput").val();
    selectUtils.initSealBizTypeByConfig("sealBizTypeNameInput", sealMaterialType);
};

/**
 * 选择查询机构
 */
function choseOrgNoCondition() {
    $("#orgNoCondition").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, null, null,
	    function(event, treeId, treeNode) {
		if (treeNode) {
		    $("#orgNoCondition").val(treeNode.organizationNo);
		}
	    });
};

function choseOrgNoInput() {
    $("#orgNoInput").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, null, null,
	    function(event, treeId, treeNode) {
		if (treeNode) {
		    $("#orgNoInput").val(treeNode.organizationNo);
		}
	    });
};