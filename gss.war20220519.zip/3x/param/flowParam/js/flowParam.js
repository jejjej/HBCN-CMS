/**
 * 创建于:2018年12月14日<br>
 * 版权所有(C) 2018 深圳市银之杰科技股份有限公司<br>
 * 流程配置action
 * 
 * @author huhongbin
 * @version 1.0.0
 */
var html = "";
var num = 0;
var orgTypeMap = new Map();
var roleGroupMap = new Map();
var orgTypeOptions = null;
var addType = 0;

/**
 * 初始化页面
 */
$(document).ready(function() {
	initGrid();
	initDialog();
	initOrgType();
	initAllRoleGroups();
	selectUtils.initTradeInfoConfig("paperType");
	$("#orgType").live("change", initRoleGroups);
});

/**
 * 初始化印控机属性参数编辑页面
 */
function initDialog() {
	$("#flowParamDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 'auto',
		width : '600px',
		modal : true,
		position : {
			at : "center"
		},
		buttons : {
			"确定":function () {
				addFlowParam();
			},
			"添加节点":function () {
				addType = 1;
				$("#choseParamDLG").dialog("open");
			},
			"指定用印节点":function () {
				addType = 0;
				$("#choseParamDLG").dialog("open");
			}
		},
		close : function() {
			num = 0;
			$("#paramForm").html("<div>交易代码：<select id='paperType' style='width: 320px;'></select></div><br/><div>" +
					"用印节点：<input id='useSealOrgType' disabled='disabled'/>&nbsp;&nbsp;&nbsp;&nbsp;" +
							"<input id='sealUseRoleGroup' disabled='disabled'/></div><br/>");
			selectUtils.initTradeInfoConfig("paperType");
		}
	});
	
	$("#flowParamDLG1").dialog({
		autoOpen : false,
		resizable : false,
		height : 'auto',
		width : '600px',
		modal : true,
		position : {
			at : "center"
		},
		close : function() {
			$("#paramForm1").html("");
		}
	});
	
	$("#choseParamDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 'auto',
		width : '450px',
		modal : true,
		position : {
			at : "center"
		},
		buttons : {
			"确定" : function () {
				if ($("#orgType").val() == null || $("#orgType").val() == "") {
					alert("请选择机构级别");
					return;
				}
				if ($("#roleGroup").val() == null || $("#roleGroup").val() == "") {
					alert("请选择角色");
					return;
				}
				if (addType == 1) {
					num ++;
					$("#paramForm").append("node" + num + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;<input type='text' " +
							"value='"+$("#orgType option:selected").text()+"' disabled='disabled'/>&nbsp;&nbsp;&nbsp;&nbsp;<input " +
							"type='text' disabled='disabled' value='"+$("#roleGroup option:selected").text()+"'/><br/><input " +
							"type='hidden' id='orgType"+num+"' disabled='disabled' value='"+$("#orgType").val()+"'/><input " +
							"type='hidden' id='node"+num+"' disabled='disabled' value='"+$("#roleGroup").val()+"'/><br/>");
				} else {
					$("#useSealOrgType").val($("#orgType option:selected").text());
					$("#sealUseRoleGroup").val($("#roleGroup option:selected").text());
					$("#useSealOrgTypeVal").val($("#orgType").val());
					$("#sealUseRoleGroupVal").val($("#roleGroup").val());
				}
				$("#choseParamDLG").dialog("close");
			}
		},
		close : function() {
			$("#roleGroup").empty();
			$("#roleGroup").html("<option value=''>请选择角色</option>");
			$("#orgType option:first").prop("selected", 'selected');
		}
	});
};

/**
 * 页面初始化
 */
function initGrid() {
    var pageHeaderHeight = $(".pageHeader").css("height");
    var pageContentWidth = $(".pageContent").width() - 2;
    pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
    var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
    $("#flowParamsTable").jqGrid(
	    {
			width : pageContentWidth,
			height : tableHeight + "px",
			url : ctx + "/gss/paramflow/gssParamFlow_list.action",
			multiselect : false,
			rowNum : 20,
			rownumbers : true,
			rowList : [ 20, 50, 100 ],
			colNames : [ "交易代码", "交易名称","用印节点","流程信息","操作"],
			colModel : [
				{
				    name : "tradeCode",
				    index : "tradeCode",
				    align : "center",
				    sortable : false
				},
				{
				    name : "tradeCode",
				    index : "tradeCode",
				    align : "center",
				    sortable : false,
				    formatter:function (value) {
				    	return selectUtils.tradeInfo[value];
				    	
				    }
				},
				{
				    name : "useSealNode",
				    index : "useSealNode",
				    align : "center",
				    sortable : false,
				    formatter:function (value) {
				    	return useSealNodeFormatter(value);
				    }
				},
				{
				    name : "flowParam",
				    index : "flowParam",
				    align : "center",
				    sortable : false,
				    formatter : function(value, options, rData) {
						return "<input type='button' value='详情' onclick='paramFormatter(" + value + ")' />";
					    }
				},
				{
				    name : "autoId",
				    index : "autoId",
				    align : "center",
				    sortable : false,
				    formatter : function(value, options, rData) {
					return "<input type='button' value='删除' onclick='deleteParam(\"" + value + "\")' />";
				    }
				} ],
			pager : "#flowParamsTablePager"
	    });
};


function useSealNodeFormatter (value) {
	if (value != null && value != "") {
		var orgType = value.split("-")[0];
		var roleGroupInfo = value.split("-")[1];
		return orgTypeMap.get(orgType) + ":" + roleGroupMap.get(roleGroupInfo);
	}
}

function paramFormatter(data){
//	var data = eval('(' + value + ')');
	for(var p in data){
		var str = data[p].split("-");
		var orgTypeName = orgTypeMap.get(str[0]);
		var roleGroupName = roleGroupMap.get(str[1]);
 　　　　　   $("#paramForm1").append(p + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;<input type='text' " +
			"value='"+orgTypeName+"' disabled='disabled'/>&nbsp;&nbsp;&nbsp;&nbsp;<input " +
			"type='text' disabled='disabled' value='"+roleGroupName+"'/><br/>");
　　　}
	$("#flowParamDLG1").dialog("open");
}

function openAddParamDLG(){
	$("#flowParamDLG").dialog("open");
}

function queryList() {
	$("#flowParamsTable").jqGrid("search", "#flowParamForm");
}

function closePage() {
	
}

function initOrgType () {
	try {
		var url = ctx + "/gss/paramflow/gssParamFlow_queryOrgType.action";
		var param = {orgType:""};
		var data = tool.ajaxRequest(url,param);
		orgTypeOptions = "<option value=''>请选择机构级别</option>";
		if (data.success) {
			if(data.response.responseMessage.success){
				var orgData = data.response.responseMessage.data;
				$(orgData).each(
						function(i, value) {
							var orgType = value.split(",");
							var orgTypeSid = orgType[0];
							var orgTypeName = orgType[1];
							orgTypeMap.put(orgTypeSid,orgTypeName);
							orgTypeOptions += "<option value='" + orgTypeSid + "'>" + orgTypeName + "</option>";
						});
					$("#orgType").html(orgTypeOptions);
			}
		} else {
			alert(data.response);
		}
	} catch (e) {
		return e.message;
	}
}

function initRoleGroups () {
	try {
		var url = ctx + "/gss/paramflow/gssParamFlow_queryRoleGroupInfo.action";
		var param = {orgType:$("#orgType").val()};
		var data = tool.ajaxRequest(url,param);
		var roleGroupData = null;
		var options = "<option value=''>请选择角色</option>";
		if (data.success) {
			if(data.response.responseMessage.success && data.response.responseMessage.data && data.response.responseMessage.data != null){
				roleGroupData = data.response.responseMessage.data;
				if (roleGroupData && roleGroupData != null && roleGroupData.length > 0) {
					$(roleGroupData).each(
							function(i, value) {
								var roleGroup = value.split(",");
								var roleGroupSid = roleGroup[0];
								var roleGroupName = roleGroup[1];
								options += "<option value='" + roleGroupSid + "'>" + roleGroupName + "</option>";
							});
					$("#roleGroup").html(options);
				}
			} else {
				alert("该机构级别没有配置角色");
			}
		} else {
			alert(data.response.responseMessage.message);
		}
	} catch (e) {
		return e.message;
	}
}

function initAllRoleGroups () {
	try {
		var url = ctx + "/gss/paramflow/gssParamFlow_queryAllRoleGroupInfo.action";
		var param = {};
		var data = tool.ajaxRequest(url,param);
		if (data.success) {
			if(data.response.responseMessage.success && data.response.responseMessage.data && data.response.responseMessage.data != null){
				roleGroupData = data.response.responseMessage.data;
				if (roleGroupData && roleGroupData != null && roleGroupData.length > 0) {
					$(roleGroupData).each(
							function(i, value) {
								var roleGroup = value.split(",");
								var roleGroupSid = roleGroup[0];
								var roleGroupName = roleGroup[1];
								roleGroupMap.put(roleGroupSid,roleGroupName);
							});
				}
			}
		} else {
			alert(data.response);
		}
	} catch (e) {
		return e.message;
	}
}

function addFlowParam() {
	var paramFlow = "{";
	var key = null;
	var value = null;
	for (var i = 0; i < num; i ++) {
		key = "node" + (i+1);
		value = $("#orgType"+(i+1)).val() + "-" + $("#node"+(i+1)).val();
		if ((i + 1) == num) {
			paramFlow += '"'+key+'":"'+value+'"}';
		} else {
			paramFlow += '"'+key+'":"'+value+'",';
		}
	}
	var tradeCode = $("#paperType").val();
	var tradeCodeName = $("#paperType option:selected").text();
	if ($("#sealUseRoleGroupVal").val() == "" || $("#sealUseRoleGroupVal").val() == null) {
		alert("请设置用印角色!");
		return;
	}
	var useSealNode = $("#useSealOrgTypeVal").val() + "-" + $("#sealUseRoleGroupVal").val();
	
	if (tradeCode == "" || tradeCode == null) {
		alert("请选交易代码");
		return;
	}
	
	if (paramFlow == "" || paramFlow == null || paramFlow == "{") {
		alert("请设置流程节点");
		return;
	}
	
	try {
		var url = ctx + "/gss/paramflow/gssParamFlow_addFlowParam.action";
		var param = {
					"paramFlow.tradeCode":tradeCode,
					"paramFlow.flowParam":paramFlow,
					"paramFlow.tradeCodeName":tradeCodeName,
					"paramFlow.useSealNode":useSealNode
					};
		var data = tool.ajaxRequest(url,param);
		if (data.success) {
			if(data.response.responseMessage.success){
				$("#flowParamDLG").dialog("close");
				queryList();
			} else {
				alert(data.response.responseMessage.message);
			}
		} 
	} catch (e) {
		return e.message;
	}

}

function deleteParam (value) {
	if (confirm("确认删除？")) {
		try {
			var url = ctx + "/gss/paramflow/gssParamFlow_deleteFlowParam.action";
			var param = {"paramFlow.autoId":value};
			var data = tool.ajaxRequest(url,param);
			if (data.success) {
				if(data.response.responseMessage.success){
					queryList();
				} else {
					alert(data.response.responseMessage.message);
				}
			} 
		} catch (e) {
			return e.message;
		}
	}
}