/**
 * 用印记录采集加载
 */

function sealLogInit() {
    // 默认本机构
    $("#orgNoCondition").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
	$("#operatorOrgNo_search").val(top.loginPeopleInfo.orgNo);
    // 默认查询一个月以内
	var nowDate = new Date();
	var now = nowDate.pattern("yyyy-MM-dd HH:mm:ss");
	var oldDate = new Date(nowDate.setMonth((new Date().getMonth()-1)));
	var old = oldDate.pattern("yyyy-MM-dd HH:mm:ss");
	$("#ge_operateTime").val(old);
	$("#le_operateTime").val(now);
    // 列表
    $("#sealLogList").jqGrid({
    	caption : "用印操作日志查询",
    	autoLoad: false,
		url : ctx + "/gss/usesealoptlog/useSealOptLogAction!list.action",
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : ["用印申请标题","交易代码", "交易代码名称 ","操作机构", "操作人员","操作时间","状态", "操作"],
		colModel : [{
		    name : "moduleName",
		    index : "moduleName",
		    align : "center",
		    width : 45,
		    sortable : true
		},{
		    name : "tradeCode",
		    index : "tradeCode",
		    align : "center",
		    width : 45,
		    sortable : true
		}, {
		    name : "tradeCodeName",
		    index : "tradeCodeName",
		    align : "center",
		    width : 85,
		    sortable : false
		}, {
		    name : "operatorOrgNo",
		    index : "operatorOrgNo",
		    align : "center",
		    width : 120,
		    sortable : false,
		    formatter : function(value, options, rData) {
		    	if (value != rData.operatorOrgName){
		    		return rData.operatorOrgName + "(" + value + ")";
		    	}else{
		    		return value;
		    	}
			}
		}, {
		    name : "operatorCode",
		    index : "operatorCode",
		    align : "center",
		    width : 100,
		    sortable : false,
		    formatter : function(value, options, rData) {
		    	if (value != rData.operatorName){
		    		return rData.operatorName + "(" + value + ")";
		    	}else{
		    		return value;
		    	}
			}
		}, {
		    name : "operateTime",
		    index : "operateTime",
		    width : 100,
		    align : "center",
		    sortable : false
		}, {
		    name : "result",
		    index : "result",
		    width : 100,
		    align : "center",
		    sortable : false,
			formatter : function(value, options, rData) {
				return sealUseConstants.SealUseApplyStatus[value];
		    }
		}, {
		    name : "bizId",
		    index : "bizId",
		    align : "center",
		    width : 60,
		    sortable : false,
		    formatter : function(value, options, rData) {
			    var html = "<input type='button' onclick=\"showDetail('" + value
				    + "');\" value='详情' />";
			    return html;
		    }
		} ],
		pager : "#sealLogListPager"
	    }).trigger("reloadGrid");
	    $("#sealLogList").navGrid("#sealLogListPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true,
		excel : ctx + "/gss/usesealoptlog/useSealOptLogAction!report.action"
    });
	querySealLogForTerm();
	
	$("#clearForm").click(function() {
		$("#sealLogIterm")[0].reset();
	    // 默认本机构
	    $("#orgNoCondition").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
		$("#operatorOrgNo_search").val(top.loginPeopleInfo.orgNo);
	    // 默认查询一个月以内
		var nowDate1 = new Date();
		var now = nowDate1.pattern("yyyy-MM-dd HH:mm:ss");
		var oldDate = new Date(nowDate1.setMonth((new Date().getMonth()-1)));
		var old = oldDate.pattern("yyyy-MM-dd HH:mm:ss");
		$("#ge_operateTime").val(old);
		$("#le_operateTime").val(now);
	});
	
	$("#sealUseTaskInfo1").dialog({
		autoOpen : false,
		resizable : false,
		width : 650,
		height : 'auto',
		modal : true,
		position : {
			at : "center"
		},
		close : function() {
			$("#sealUseApplyForm1")[0].reset();
		}
	});
};

function showDetail(id) {
	var url = ctx + "/mechseal/task/sealUseApprTaskZHAction_gainTask.action?_t=0005";
	var param = {"bizInfo.id":id};
	var data = tool.ajaxRequest(url, param);
	if(data.success){
		var bizInfo = data.response.bizInfo;
    	var mechSealInfos = data.response.mechSealInfos;
    	var mechSealFiles = data.response.mechSealFiles;
    	scanNum = bizInfo.scanNum;
    	$("#id").val(bizInfo.id);
		$("#tradeCode").val(bizInfo.tradeCode);; 
		$("#applyTitle1").val(bizInfo.title);
		$("#applyReason1").val(bizInfo.materialName);
		$("#memo").val(bizInfo.memo);
		
		$("#seals1").empty();
		if(mechSealInfos != null){
			$.each(mechSealInfos,function(i,item){
				showSealsDetail(item.tradeCodeName,item.applyNum);
			});
		}
		$("#targetOrgMemo1").val(bizInfo.extInfo.targetOrgMemo);
		$("#useSealReason1").val(bizInfo.extInfo.useSealReason);
		$("#runSealfuncs").val(bizInfo.runSealfunc);
		$("#fileType1").val(bizInfo.extInfo.fileType);
		var paramFlow = initFlowParamInfo();
		if(paramFlow == null) {
			alert("查询流程参数配失败，请重试！");
			return;
		} else {
			var nodeId = bizInfo.extInfo.currentNodeId;
			var nowNodeId = nodeId.substring(4) - 1;
			nodeId = "node" + nowNodeId;
			$.each(paramFlow, function(i, d) {
				if (nodeId == i) {
					var roleGroupSid = d.split("-")[1];
					$("#roleGroupSid").val(roleGroupSid);
					$("#nextNodeId").val(nodeId);
				}
			});
		}
		if(_t == "001") {
			if(bizInfo.status == "001" && bizInfo.isGroupAppr == "0") {
				document.getElementById("cancelBtn").style.display = "";
			} else {
				document.getElementById("cancelBtn").style.display = "none";
			}
		} else {
			if(bizInfo.status == "001" && bizInfo.isGroupAppr == "1") {
				document.getElementById("cancelBtn").style.display = "";
			} else {
				document.getElementById("cancelBtn").style.display = "none";
			}
		}
		
		$("#sealUseTaskInfo1").dialog("open");
		showDocDetail(bizInfo.scanNum);
	}else{
		var message = reslut.response.webResponseJson.message;
		alert(message);
	}
}

function showSealsDetail(sealName,sealApplyNum) {
	if(sealName == undefined || sealName == "" || sealName == "undefined") {
		sealName = "印章不存在";
	}
	var str = "<div id='divSealNum'><input disabled='disabled' value='"+sealName+"' style='width:300px;'/><input maxlength='10' style='width:50px;' disabled='disabled' value='"+sealApplyNum+"' /></div>";
	$("#seals1").append(str);
}

function showDocDetail(scanNum){
	var url = ctx + "/sealusetask/create/sealUseTask_queryDocDetail.action";
	var param = {"scanNum":scanNum};
	var result = tool.ajaxRequest(url, param);
	if(result.response.webResponseJson.state == "normal"){
		var files = result.response.webResponseJson.data;
		var html = "";
		for(var i = 0; i < files.length; i ++) {
			html += "<a href='"+files[i].filePath+"' title='"+files[i].fileDesc+"'>"+files[i].fileDesc+"</a><br/>";
		}
		$('#docword').html(html);
	}else{
		var message = result.response.webResponseJson.message;
		alert(message);
	}
}

//var num = 1;
//var sealMap = new Map();
//function initSeals(){
//	//清空下拉列表
//	sealMap = new Map();
//	var url = ctx + "/sealusetask/create/sealUseTask_initAvailableSeal.action";
//	var param = {"orgNo":login_people.orgNo};
//	var result = tool.ajaxRequest(url, param);
//	if(result.response.webResponseJson.state == "normal"){
//		var sealArray = result.response.webResponseJson.data;
//		$.each(sealArray,function(index,seal){
//			sealMap.put(seal.autoId,seal.sealTypeName+"("+seal.deviceNum+")");
//		});
//	}else{
//		var message = result.response.webResponseJson.message;
//		alert(message);
//	}
//}

function cancel() {
	var url = ctx + "/sealusetask/create/sealUseTask_cancelTask.action?_t=" + _t;
	var param = {
			"tableApply.id":$("#id").val(),
			"tableApply.roleGroupSid" : $("#roleGroupSid").val(),
			"tableApply.nextNodeId" : $("#nextNodeId").val()
			};
	var data = tool.ajaxRequest(url, param);
	if(data.success){
		if(data.response.webResponseJson.data) {
			querySealLogForTerm();
			$("#sealUseTaskInfo1").dialog("close");
		} else {
			alert("正在审批中，无法撤回!");
		}
    }else{
		var message = reslut.response.webResponseJson.message;
		alert(message);
	}
}

function initFlowParamInfo() {
	var paramFlow = null;
	try {
		var url = ctx + "/gss/paramflow/gssParamFlow_findParamFlowByFileId.action";
		var param = {"paramFlow.tradeCode":$("#tradeCode").val()};
		var data = tool.ajaxRequest(url,param);
		if (data.success && data.response.responseMessage.success) {
			var paramFlowInfo = data.response.paramFlow
			if (paramFlowInfo != null && paramFlowInfo != "") {
				if (paramFlowInfo.flowParam != null && paramFlowInfo.flowParam != "") {
					paramFlow = eval('(' + paramFlowInfo.flowParam + ')');
				} else {
					$("#paperType option:first").prop("selected", 'selected');
					alert("请先配置业务流程参数");
				}
			} else {
				$("#paperType option:first").prop("selected", 'selected');
				alert("请先配置业务流程参数");
			}
		} else {
			alert(data.response.responseMessage.message);
		}
		return paramFlow;
	} catch (e) {
		return e.message;
	}
	
}

function querySealLogForTerm() {
    $("#sealLogList").jqGrid("search", "#sealLogIterm");
};

/**
 * 选择查询机构
 */
function choseOrgNoCondition() {
    $("#orgNoCondition").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, null, null, function(event, treeId, treeNode) {
		if (treeNode) {
			$("#orgNoCondition").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
		    $("#operatorOrgNo_search").val(treeNode.organizationNo);
		}
    });
};
