/**
 * 我的用印申请加载
 */
function myApplyInit() {
    $("#detail").dialog({
	autoOpen : false,
	resizable : false,
	width : 600,
	modal : true,
	buttons : {},
	close : function() {
	    $("form")[0].reset();
	}
    });
    // 加载申请状态
    var sealStatusContent = "<option value=' '>全部</option>";
    for ( var key in sealUseConstants.SealUseApplyStatus) {
	sealStatusContent += "<option value='" + key + "'>" + sealUseConstants.SealUseApplyStatus[key] + "</option>";
    }
    $("#que_status").html(sealStatusContent);
    // 查询展示该部门下所有人员
    //listDeptAllPeoPles();
    // 我的用印申请列表
    var pageHeaderHeight = $(".pageHeader").css("height");
    var pageContentWidth = $(".pageContent").width() - 2;
    pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
    var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
    
    // 默认查询一个月以内
    var nowDate = new Date();
	var now = nowDate.pattern("yyyy-MM-dd HH:mm:ss");
	var oldDate = new Date(nowDate.setMonth((new Date().getMonth()-1)));
	var old = oldDate.pattern("yyyy-MM-dd HH:mm:ss");
	$("#ge_applyTime").val(old);
	$("#le_applyTime").val(now);
    
    // 列表
    $("#myApplyList")
	    .jqGrid(
		    {
		    autoLoad: false,
			width : pageContentWidth,
			height : tableHeight + "px",
			url : ctx + "/gss/usesealoptlog/useSealOptLogAction!queryUseSealoptLogDetail.action",
			multiselect : false,
			rowNum : 20,
			rownumbers : true,
			rowList : [ 20, 50, 100 ],
			colNames : ["用印模式", "文件类型", "用印事由", "文件持有人", "采集数量", "待用印次数", "已用印次数", "状态",
				/*"待处理人",*/ "申请时间", "备注", "图像", "操作" ],
			colModel : [
				{
				    name : "moduleName",
				    index : "moduleName",
				    align : "center",
				    width : 80,
				    sortable : false,
				    formatter : function(value, options, rData) {
					return constants.MODULE_MAP[value];
				    }
				},
				{
				    name : "tradeCodeName",
				    index : "tradeCodeName",
				    align : "center",
				    width : 100,
				    sortable : false
				},
				{
				    name : "title",
				    index : "title",
				    align : "center",
				    width : 100,
				    sortable : false
				},
				{
				    name : "fileOwnerName",
				    index : "fileOwnerName",
				    align : "center",
				    width : 70,
				    sortable : false
				},
				{
				    name : "fileNum",
				    index : "fileNum",
				    align : "center",
				    width : 50,
				    sortable : false
				},
				{
				    name : "applyNum",
				    index : "applyNum",
				    width : 50,
				    align : "center",
				    sortable : false
				},
				{
				    name : "usedNum",
				    index : "usedNum",
				    align : "center",
				    width : 58,
				    sortable : false
				},
				{
				    name : "status",
				    index : "status",
				    align : "center",
				    width : 75,
				    sortable : false,
				    formatter : function(value, options, rData) {
					return sealUseConstants.SealUseApplyStatus[value];
				    }
				},
			/*	{
				    name : "nextHandlerName",
				    index : "nextHandlerName",
				    align : "center",
				    width : 55,
				    sortable : false
				},*/
				{
				    name : "applyTime",
				    index : "applyTime",
				    align : "center",
				    width : 55,
				    sortable : false
				},
				{
				    name : "memo",
				    index : "memo",
				    align : "center",
				    width : 60,
				    sortable : false
				},
				{
				    name : "storeId",
				    index : "storeId",
				    width : 30,
				    align : "center",
				    sortable : false,
				    formatter : function(value, options, rData) {
					if (null == value || value == "") {
					    return "无";
					} else {
					    var html = "<img src='"
						    + ctx
						    + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='用印图像'  title='用印图像'  onclick=\"startViewImage('"
						    + rData.autoId + "');\"/>";
					    return html;

					}
				    }
				},
				{
				    name : "autoId",
				    index : "autoId",
				    align : "center",
				    width : 60,
				    sortable : false,
				    formatter : function(value, options, rData) {
					    var html = "<input type='button' onclick=\"showDetail('" + rData.autoId
						    + "');\" value='详情' />";
					    return html;
				    }
				}, ],
			pager : "#myApplyListPager"
		    });
    querySealApplyForTerm();
};

function querySealApplyForTerm() {
    $("#myApplyList").jqGrid("search", "#sealApplyIterm");
};

function showDetail(bizId){
	var param = {
		"bizId" : bizId
	};
	var url = ctx + "/gss/usesealoptlog/useSealOptLogAction!queryOptLogByBizId.action"
	var data = tool.ajaxRequest(url, param);
	if (data.success){
		if (data.response.responseMessage.success){
			var details = data.response.pageBean.data;
			$("#detailTable").empty();
			var str = "<tr height=\"25px\"><th>操作时间</th><th>操作机构</th><th>操作人员</th><th>操作类型</th><th>操作结果</th></tr>";
			for (var i = 0; i < details.length; i++){
				str += "<tr height=\"20px\">";
				str += "<td width=\"100px\" height=\"25px\">" + details[i].operateTime + "</td>";
				str += "<td width=\"100px\" height=\"25px\">" + details[i].operatorOrgName + "</td>";
				str += "<td width=\"100px\" height=\"25px\">" + details[i].operatorName + "</td>";
				str += "<td width=\"200px\" height=\"25px\">" + sealUseConstants.SealUseOptOperateType[details[i].operateType] + "</td>";
				str += "<td width=\"100px\" height=\"25px\">" + sealUseConstants.SealUseOptOperateResult[details[i].result] + "</td>";
				str += "</tr>";
			}
			$("#detailTable").append(str);
			$("#detail").dialog("open");
		}else{
			alert(data.response.responseMessage.message);
		}
	}else{
		alert("查询失败");
	}
}

/**
 * 查询获取部门下所有人员
 */
function listDeptAllPeoPles() {
    var url = ctx + "/mechseal/query/listMySealUseApply_listDeptAllPeoPles.action";
    var data = tool.ajaxRequest(url, '');
    if (data.success) {
	var xPeoples = data.response.arrayList;
	if (xPeoples != null) {
	    $("#operatorCode").append("<option value=''>--请选择--</option>");
	    $(xPeoples).each(
		    function(i, value) {
			$("#operatorCode").append(
				"<option value='" + xPeoples[i].peopleCode + "'>" + xPeoples[i].peopleName + "("
					+ xPeoples[i].peopleCode + ")</option>");
		    });
	} else {
	    alert("该机构下无人员");
	}
    } else {
	alert(data.response);
    }
};

/**
 * 图片展示
 * 
 * @param storeId
 */
function startViewImage(bizId) {
	
	var storeIds = new Array();
	var urls = new Array();
	
	storeIds = findAllStoreIdByBizId(bizId);
	if(storeIds !== null){
		for (var i=0; i < storeIds.length; i++){
			var docObjects = wfStoreFancyBox.fetchFile(storeIds[i]);
			if(docObjects != null && docObjects.length > 0){
				for( var j = 0; j < docObjects.length; j++ ){
					urls.push(docObjects[j].fileUrl);
				}
			}
		}
	}
	
	
	wfStoreFancyBox.showAllImageByUrl(urls, "buttons");
   //wfStoreFancyBox.showAllImageByStoreId(storeId, "buttons");
};

function findAllStoreIdByBizId(bizId){
	var success = false;
	var storeIdList = null;
	$.ajax({
		type : "post",
		url : ctx + "/gss/usesealloginfo/useSealLogInfoAction!findAllStoreIdByBizId.action",
		dataType : "json",
		data : {
			"bizId" : bizId
		},
		async : false,
		success : function(response) {
			if (response.responseMessage.success == true) {
				storeIdList = response.storeIdList;
			}
			
		},
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0" || XMLHttpRequest.status != "200") {
				docObjects = '网络异常';
			}
		}
	});
	
	return storeIdList;
	
}
