/**
 * 创建于:2016-11-3<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 印章装卸及维护日志<br>
 * 
 * @author dqq
 * @version 1.0.0
 */

/**
 * 装卸日志页面初始化
 * 
 */
function sealhandleLogInit(){
	
	$("#detailform").dialog({//印章装卸表单
		autoOpen : false,
		resizable : false,
		closeOnEscape : false,
		height : 450,
		width : 500,
		modal : true,
		open : function(event, ui) {
		},
		close : function(){
			$(this)[0].reset();
		}
	});
	
	var date1 = new Date();
    date1.setMonth(date1.getMonth()-1);
	$("#ge_applyTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
	
	$("#le_applyTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
	
    $("#applyOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
	$("#applyOrgNo").val(top.loginPeopleInfo.orgNo);
	
	//审核机构列表
	$("#handleLogList").jqGrid({
		caption : "印章装卸日志列表",
		url : ctx + "/mechseal/sealhandle/sealHandleAndWhAction_querySealHandleInfoList.action",
		multiselect : false,
		rowNum : 15,
		rowList : [ 15, 20, 50, 100 ],
		colNames : [ "操作类型", "设备编号", "申请人", "申请机构", "申请时间", "审批人", "审批机构","审批时间","检查人","检查机构","检查时间","状态","操作"],
		colModel : [ {
			name : "operType",
			index : "operType",
			align : "center",
			width : 80,
			sortable : false,
			formatter : function(cellval,opts){
				return cellval=="1"?"印章装卸":(cellval=="2"?"设备维护":"")
			}
		}, {
			name : "deviceNum",
			index : "deviceNum",
			align : "center",
			sortable : false
		}, {
			name : "applyPeopleCode",
			index : "applyPeopleCode",
			align : "center",
			sortable : false,
			formatter : formterpeople
		}, {
			name : "applyOrgNo",
			index : "applyOrgNo",
			align : "center",
			sortable : false,
			formatter : formaterorg
		}, {
			name : "applyTime",
			index : "applyTime",
			align : "center",
			sortable : false
		}, {
			name : "apprPeopleCode",
			index : "apprPeopleCode",
			align : "center",
			sortable : false,
			formatter : formterpeople
		}, {
			name : "apprOrgNo",
			index : "apprOrgNo",
			align : "center",
			sortable : false,
			formatter : formaterorg
		}, {
			name : "apprTime",
			index : "apprTime",
			align : "center",
			sortable : false
		}, {
			name : "checkPeopleCode",
			index : "checkPeopleCode",
			align : "center",
			sortable : false,
			formatter : formterpeople
		}, {
			name : "checkOrgNo",
			index : "checkOrgNo",
			align : "center",
			sortable : false,
			formatter : formaterorg
		}, {
			name : "checkTime",
			index : "checkTime",
			align : "center",
			sortable : false
		}, {
			name : "state",
			index : "state",
			align : "center",
			sortable : false,
			formatter : function(cellval,opts){
				return formaterstat(cellval);
			}
		}, {
			name : "autoId",
			index : "autoId",
			align : "center",
			sortable : false,
			formatter : function(cellval,opts){
				return "<a href='#;return false;' onclick='showdetail(\""+cellval+"\")'>详情</a>";
			}
		}],
		pager : "#handleLogListPager"
	});
	//导出
	$("#handleLogList").navGrid("#handleLogListPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true,
		excel : ctx + "/gss/sealhandlelog/sealHandAndUnhandReportAction!report.action"
	});
}

function queryHandleLog(){
	$("#handleLogList").jqGrid("search", "#search");
}

function clearForm(){
	$("#search")[0].reset();
	var date1 = new Date();
    date1.setMonth(date1.getMonth()-1);
	$("#ge_applyTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
	
	$("#le_applyTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
	
    $("#applyOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
	$("#applyOrgNo").val(top.loginPeopleInfo.orgNo);
}

function showdetail(id){
	var url = ctx + "/mechseal/sealhandle/sealHandleAndWhAction_querySealHandleInfo.action";
	var param = {
		"sealHandleinfo.autoId" :id
	};
	var data = tool.ajaxRequest(url,param);
	if (data.success) {
		if(data.response.responseMessage.success){
			$("#detailform")[0].reset();
			$("#logfile").html("");
			$("#detailform").fillForm({
				sealHandleinfo : data.response.sealHandleinfo
			});
			$("input[name='sealHandleinfo.applyPeopleCode']")
			.val(Personnel.getPersonnelByPersonnelCode(data.response.sealHandleinfo.applyPeopleCode).personnelNameAndCode);
			$("input[name='sealHandleinfo.applyOrgNo']")
			.val(Organization.getOrganizationByOrgNo(data.response.sealHandleinfo.applyOrgNo).organizationNameAndNo);
			$("input[name='sealHandleinfo.apprPeopleCode']")
			.val(Personnel.getPersonnelByPersonnelCode(data.response.sealHandleinfo.apprPeopleCode).personnelNameAndCode);
			$("input[name='sealHandleinfo.apprOrgNo']")
			.val(Organization.getOrganizationByOrgNo(data.response.sealHandleinfo.apprOrgNo).organizationNameAndNo);
			$("input[name='sealHandleinfo.state']").val(formaterstat(data.response.sealHandleinfo.state));
			if(data.response.sealHandleinfo.operType == WHTYPE){
				$("input[name='sealHandleinfo.checkPeopleCode']").parent().parent().hide();
				$("input[name='sealHandleinfo.checkOrgNo']").parent().parent().hide();
				$("input[name='sealHandleinfo.checkTime']").parent().parent().hide();
				$("textarea[name='sealHandleinfo.checkMemo']").parent().parent().hide();
			}else{
				$("input[name='sealHandleinfo.checkPeopleCode']")
				.val(Personnel.getPersonnelByPersonnelCode(data.response.sealHandleinfo.checkPeopleCode).personnelNameAndCode);
				$("input[name='sealHandleinfo.checkOrgNo']")
				.val(Organization.getOrganizationByOrgNo(data.response.sealHandleinfo.checkOrgNo).organizationNameAndNo);
				$("input[name='sealHandleinfo.checkPeopleCode']").parent().parent().show();
				$("input[name='sealHandleinfo.checkOrgNo']").parent().parent().show();
				$("input[name='sealHandleinfo.checkTime']").parent().parent().show();
				$("textarea[name='sealHandleinfo.checkMemo']").parent().parent().show();
			}
			showauditFile("logfile",data.response.sealHandleinfo.storeId);
			$("#detailform").dialog("open");
		}else{
			alert(data.response.responseMessage.message);
		}
	} else {
		alert(data.response);
	}
}

function showauditFile(elementID,storeid){
	if(storeid=="" || storeid == null){
		return;
	}
	wfStoreFancyBox.showAllThumbnailImageByStoreId(elementID,storeid,"buttons");
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo,type){
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#applyOrgNo_Item").dialogOrgTree("radio", organizationSid, false, null,null, function(event, treeId, treeNode){
		if(treeNode){
			$("#"+organizationNo+"_Item").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
			$("#"+organizationNo).val(treeNode.organizationNo);
		}
	});
}

function formterpeople(cellval,opts){
	var _personnel = Personnel.getPersonnelByPersonnelCode(cellval);
	return _personnel.personnelNameAndCode;
}
function formaterorg(cellval,opts){
	return Organization.getOrganizationByOrgNo(cellval).organizationNameAndNo;
}
function formaterstat(cellval){
	if(cellval=="0"){
		return "等待审批";
	}else if(cellval=="1"){
		return "审批通过";
	}else if(cellval=="2"){
		return "审批拒绝";
	}else if(cellval=="3"){
		return "审批超时";
	}else if(cellval=="4"){
		return "取消申请";
	}else if(cellval=="5"){
		return "等待检查";
	}else if(cellval=="6"){
		return "装卸完成";
	}else if(cellval=="7"){
		return "装卸异常";
	}
}