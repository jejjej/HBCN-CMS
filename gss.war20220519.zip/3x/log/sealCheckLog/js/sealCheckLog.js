/**
 * 
 * 创建于:2016-10-31<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 印章检查日志查询js
 * 
 * @author lxy
 * @version 1.0.0
 */


/** 根据命名空间及key获取wf缓存的值 */
function getParamFromWFCache(namespace, key) {
    try {
        //创建后台设置的命名空间
        var cacheSpace = top.WFCache.getCacheSpace(namespace);
        //获取该命名空间下的所有缓存值
        var cache = top.WFCache.getPageCache(cacheSpace);
        //根据key，获取该缓存下的某个值
        return cache.get(key);
    } catch (e) {
        return null;
    }
};

function pageInit() {
	
	var date1 = new Date();
    date1.setMonth(date1.getMonth()-1);
	$("#ge_applyTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
	
	$("#le_applyTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
	
    $("#operOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
	$("#operOrgNo_Form").val(top.loginPeopleInfo.orgNo);
	
	// 获取印章检查日志列表
    fetchSealCheckList();

	$("#submitForm").click(function() {
		$("#list").jqGrid("search", "#search");
	});

	$("#clearForm").click(function() {
		$("#search")[0].reset();
		var date1 = new Date();
	    date1.setMonth(date1.getMonth()-1);
		$("#ge_applyTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
		
		$("#le_applyTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
		
	    $("#operOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
		$("#operOrgNo_Form").val(top.loginPeopleInfo.orgNo);
	});
	
	

}


/**
 * 获取印章检查日志列表 
 */
function fetchSealCheckList() {
	$("#list").jqGrid({
		caption : "印章检查日志列表",
		url : top.ctx + "/mech/sealcheck/sealCheckAction_list.action",
		rowList:[10,15,20,30],
		rowNum:10,
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "操作机构",  "操作人员", "设备编号" ,"操作时间", "审核人员","检查状态" ,"检查备注", "审核备注","印章影像"],
		colModel : [ {
			name : "applyOrgNo",
			index : "applyOrgNo",
			width : 180,
			formatter : function(value, options, rData) {
				return Organization.getOrganizationByOrgNo(value).organizationNameAndNo;
			}
		}, {
			name : "applyPeopleName",
			index : "applyPeopleName",
			width : 140,
			formatter : function(value, options, rData) {
				return value==null?"":(value+"("+rData.applyPeopleCode+")");
			}
		}, {
			name : "machineNum",
			index : "machineNum",
			width : 160
		}, {
			name : "applyTime",
			index : "applyTime",
			width : 160
		} , {
			name : "checkPeopleName",
			index : "checkPeopleName",
			width : 140,
			formatter : function(value, options, rData) {
				return value==null?"":value+"("+rData.checkPeopleCode+")";
			}
		},{
			name : "state",
			index : "state",
			width : 100,
			formatter : function(value, options, rData) {
				if(value=="0"){
					return "不通过";
				}else if(value=="1"){
					return "通过";
				}else if(value=="2"){
					return "待检查";
				}
			}
		} ,	{
			name : "checkMemo",
			index : "checkMemo",
			width : 160
		},	{
			name : "checkRemark",
			index : "checkRemark",
			width : 160
		} ,	{
			name : "storeId",
			index : "storeId",
			width : 90,
			align : "center",
			sortable : false,
		    formatter : function(value, options, rData) {
				if (null == value || value == "") {
				    return "无图像";
				} else {
				    return "<a onclick=\"startViewImage('"
					    + value
					    + "')\" style='text-decoration:underline;color:blue;cursor: hand;'>图像</a>";
				}
			    }
		}],
		pager : "#pager"
	});
	$("#list").navGrid("#pager",{edit:false,add:false,del:false,search:false,refresh: true, excel: ctx + "/mech/sealcheck/sealCheckAction!report.action"});
}

/**
 * 图片展示
 * 
 * @param storeId
 */
function startViewImage(storeId) {
    wfStoreFancyBox.showAllImageByStoreId(storeId, "buttons");
};


/**
 * 选择机构
 */
function choseOrganizationItem() {
	$("#operOrgNo_Item").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, {
		filterOrgType : "1,2,6,7"
	}, null, function(event, treeId, treeNode) {
		if (treeNode) {
			if (treeNode) {
				$("#operOrgNo_Item").val(treeNode.organizationName + "(" + treeNode.organizationNo + ")");
				$("#operOrgNo_Form").val(treeNode.organizationNo);
			}
		}
	});
}

