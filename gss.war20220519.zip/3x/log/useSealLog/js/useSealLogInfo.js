
var bizInfos = new Map();
$(function() {
	pageInit();
	
	
});

function pageInit() {
	
	$("#detailform").dialog({
		autoOpen : false,
		resizable : false,
		closeOnEscape : false,
		height : 450,
		width : 500,
		modal : true,
		open : function(event, ui) {
		},
		close : function(){
			$(this)[0].reset();
		}
	});
	var date1 = new Date();
    date1.setMonth(date1.getMonth()-1);
	$("#ge_operateTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
	
	$("#le_operateTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
	
    $("#operOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
	$("#operOrgNo_Form").val(top.loginPeopleInfo.orgNo);
	var useSealTypes = GPCache.get(GPCache.GSS, GPType.ESS_USE_TYPE);
	$("#useSealTypeId").html("<option value=\"\">--请选择--</option>");
	for(var i=0;i<useSealTypes.length;i++) {
		$("#useSealTypeId").append("<option value=\""+useSealTypes[i].paramKey+"\">"+useSealTypes[i].paramValue+"</option>");
	}
	var status = GPCache.get(GPCache.GSS, GPType.ESS_USE_STATE);
	$("#statusId").html("<option value=\"\">--请选择--</option>");
	for(var i=0;i<status.length;i++) {
		$("#statusId").append("<option value=\""+status[i].paramKey+"\">"+status[i].paramValue+"</option>");
	}
	
	fetchSealApllyList();
	

	
	$("#submitForm").click(function() {
		$("#list").jqGrid("search", "#search");
	});
	
	$("#clearForm").click(function() {
		$("#search")[0].reset();
		var date1 = new Date();
	    date1.setMonth(date1.getMonth()-1);
		$("#ge_operateTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
		
		$("#le_operateTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
		
	    $("#operOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
		$("#operOrgNo_Form").val(top.loginPeopleInfo.orgNo);
	});
	
}




function fetchSealApllyList() {	
	
	$("#list").jqGrid({
		caption : "用印日志查询",
		url : top.ctx + "/gss/usesealloginfo/useSealLogInfoAction!list.action",
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "用印机构", "用印人", "印章类型名称","用印类型","用印时间","用印状态","影像","其他" ],
		colModel : [{
			name : "operatorOrgNo",
			index : "operatorOrgNo",
			width : 90,
			formatter : myFormatter1			
		}, {
			name : "operatorCode",
			index : "operatorCode",
			width : 90,
			formatter : myFormatter2
			
		},{
			name : "sealTypeName",
			index : "sealTypeName",
			width : 120
			
		},{
			name : "useSealType",
			index : "useSealType",
			width : 120,
			formatter : function(value, options, rData) {
				return GPCache.get(GPCache.GSS, GPType.ESS_USE_TYPE, value);
			}
			
		},{
			name : "operateTime",
			index : "operateTime",
			width : 150
			
		},{
			name : "status",
			index : "status",
			width : 150,
			
			formatter : function(value, options, rData) {
				return GPCache.get(GPCache.GSS, GPType.ESS_USE_STATE, value);
			}
			
		},{
			name : "storeId",
			index : "storeId",
			width : 90,
		    formatter : function(value, options, rData) {
				if (null == value || value == "") {
				    return "无图像";
				} else {
				    return "<a onclick=\"startViewImage('"
					    + value
					    + "')\" style='text-decoration:underline;color:blue;cursor: hand;'>图像</a>";
				}
			}
			
		},{
			name : "autoId",
			index : "autoId",
			width : 90,
			formatter : function(value, options, rData) {
				return  "<input type='button'  value='详情' onclick='openAllDetialInfo(\"" + value + "\")'/>";
			}
		}],
		pager : "#pager"
	});
	$("#list").navGrid("#pager",{edit:false,add:false,del:false,search:false,refresh: true, excel: ctx + "/gss/usesealloginfo/useSealLogInfoAction!report.action"});
}

function myFormatter1(value, options, rData) {
	if  (value == "NULL" || value == undefined || value == "") {return "" ;} else {return rData.operatorOrgName + "(" + value+")";}

}
function myFormatter2(value, options, rData) {
	if  (value == "NULL" || value == undefined || value == "") {return "";} else {return rData.operatorName + "(" + value+")";}

}
function myFormatter3(value, options, rData) {
	if  (value == "NULL" || value == undefined || value == "") {return "";} else {return rData.checkPeopleName + "(" + value+")";}

}

/**
 * 图片展示
 * 
 * @param storeId
 */
function startViewImage(storeId) {
    wfStoreFancyBox.showAllImageByStoreId(storeId, "buttons");
};

function openBizElement(checkCode) {
	
	$("#d").dialog("open");
	
	$.ajax({
		
		type : "POST",
		url : ctx + "/ess/bizElement/bizElementInfoQueryAction!check.action",
		data : {
			"bizElementInfo.checkCode" : checkCode
		},
		dataType : "json",
		async : false,
		success : function(data) {
			var table_list = "";
			if (data && data.responseMessage && data.responseMessage.success) {
				
				for(var i=0;i<data.bizElementInfos.length;i++) {
					var bizInfo = data.bizElementInfos[i];
					bizInfos.put(bizInfo.elementName, bizInfo.elementValue);					
					table_list += "<tr><td>"+bizInfo.elementName+":"+bizInfo.elementValue+"</td></tr>";
					//alert(bizInfo.elementName+bizInfo.elementValue);
				}
							
			}
			$("#de").html(table_list);
		}
		
		
	});
}



function openAllDetialInfo(autoId) {
	
	$.ajax({
		
		type : "POST",
		url : ctx + "/gss/usesealloginfo/useSealLogInfoAction!find.action",
		data : {
			"useSealLogInfo.autoId" : autoId
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				
				$("input[name='useSealLogInfo.autoId']").val(data.useSealLogInfo.autoId);
				
				$("input[name='useSealLogInfo.tradeCode']").val(data.useSealLogInfo.tradeCode);
				$("input[name='useSealLogInfo.tradeCodeName']").val(data.useSealLogInfo.tradeCodeName);
				$("input[name='useSealLogInfo.billCode']").val(data.useSealLogInfo.billCode);
				$("input[name='useSealLogInfo.billName']").val(data.useSealLogInfo.billName);
				
				$("input[name='useSealLogInfo.machineNum']").val(data.useSealLogInfo.machineNum);
				$("input[name='useSealLogInfo.operateTime']").val(data.useSealLogInfo.operateTime);
				$("input[name='useSealLogInfo.status']").val(GPCache.get(GPCache.GSS, GPType.ESS_USE_STATE, data.useSealLogInfo.status));
				$("input[name='useSealLogInfo.useSealType']").val(GPCache.get(GPCache.GSS, GPType.ESS_USE_TYPE, data.useSealLogInfo.useSealType));
				$("input[name='useSealLogInfo.checkCode']").val(data.useSealLogInfo.checkCode);
				
				
				$("#detailform").dialog("open");
				
			} else {
				$.error("操作失败:" + data.responseMessage.message);
			}
		}
	});
}



function choseOrganizationItem(organizationNo,type) {
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#operOrgNo_Item").dialogOrgTree("radio", organizationSid, false, null,null, function(event, treeId, treeNode){
		if(treeNode){
			$("#"+organizationNo+"_Item").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
			$("#"+organizationNo).val(treeNode.organizationNo);
		}
	});
}


