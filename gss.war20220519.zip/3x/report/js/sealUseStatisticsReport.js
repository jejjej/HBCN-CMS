/**
 * 
 * 创建于:2016-11-13<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 机控用印统计查询js
 * 
 * @author lxy
 * @version 1.0.0
 */


/** 根据命名空间及key获取wf缓存的值 */
function getParamFromWFCache(namespace, key) {
    try {
        //创建后台设置的命名空间
        var cacheSpace = top.WFCache.getCacheSpace(namespace);
        //获取该命名空间下的所有缓存值
        var cache = top.WFCache.getPageCache(cacheSpace);
        //根据key，获取该缓存下的某个值
        return cache.get(key);
    } catch (e) {
        return null;
    }
};

function pageInit() {
	
	var bizTypeContent = "";
	var objs = GPCache.get(GPCache.GSS, GPType.ESS_USE_TYPE);
	for (var i = 0; i < objs.length; i++) {
		if(objs[i].paramKey !="4"){
    	bizTypeContent += "<option value='" + objs[i].paramKey + "'>" + objs[i].paramValue + "</option>";
		}
	}
	bizTypeContent = "<option value=''>全部</option>" + bizTypeContent;
	$("#useSealType").html(bizTypeContent);
	
	var date1 = new Date();
    date1.setMonth(date1.getMonth()-1);
	$("#ge_operateTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
	
	$("#le_operateTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
	
    $("#operOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
	$("#operOrgNo_Form").val(top.loginPeopleInfo.orgNo);
	
	
	
	var options = "<option value=''>--请选择--</option>";		
	var objs = GPCache.get(GPCache.SMS, GPType.SMS_SEAL_TYPE);
	for (var o in objs) {
		options += ("<option value=\"" + o + "\">" + objs[o] + "</option>");
	}
	$("#sealName").html(options);
	
	
	// 获取电子印章信息列表
	fetchSealInfoList();

	$("#submitForm").click(function() {
		$("#list").jqGrid("search", "#search");
	});

	$("#clearForm").click(function() {
		$("#search")[0].reset();
	    $("#operOrgNo_Item").val(top.loginPeopleInfo.orgName+"(" + top.loginPeopleInfo.orgNo+")");
		$("#operOrgNo_Form").val(top.loginPeopleInfo.orgNo);
		var date1 = new Date();
	    date1.setMonth(date1.getMonth()-1);
		$("#ge_operateTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
		
		$("#le_operateTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
	});
	
	

}



/**
 * 获取电子印章信息列表
 */
function fetchSealInfoList() {
	$("#list").jqGrid({
		caption : "机控用印统计列表",
		url : top.ctx + "/report/useSealReport/sealUseStatisticsReportAction!list.action", 
		rowList:[10,15,20,30],
		rowNum:10,
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "交易码",  "交易码名称", "印章类型" ,"用印类型" ,"用印次数"],
		colModel : [ {
			name : "tradeCode",
			index : "tradeCode",
			width : 120
		}, {
			name : "tradeCodeName",
			index : "tradeCodeName",
			width : 120
		},  {
			name : "sealName",
			index : "sealName",
			width : 160
		},  {
			name : "useSealType",
			index : "useSealType",
			width : 160,
			formatter : function(value, options, rData) {
				return GPCache.get(GPCache.GSS, GPType.ESS_USE_TYPE, value);
			}
		},{
			name : "allnums",
			index : "allnums",
			width : 160
		} ],
		pager : "#pager"
	});
	$("#list").navGrid("#pager",{edit:false,add:false,del:false,search:false,refresh: true, excel: ctx + "/report/useSealReport/sealUseStatisticsReportAction!report.action"});
}



/**
 * 选择机构
 */
function choseOrganizationItem() {
	$("#operOrgNo_Item").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, {
		filterOrgType : "1,2,6,7"
	}, null, function(event, treeId, treeNode) {
		if (treeNode) {
			if (treeNode) {
				$("#operOrgNo_Item").val(treeNode.organizationName + "(" + treeNode.organizationNo + ")");
				$("#operOrgNo_Form").val(treeNode.organizationNo);
			}
		}
	});
}

function resetForm() {
	$("#sealInfoDetailForm")[0].reset();
	$("#sealInfoDetail").dialog("close");
}

/**
 * 电子印章印油格式化
 * 
 * @param value
 * @returns {String}
 */
function sealColorFmt(value) {
	if (value == "0") {
		return "<font color='red'>红色</font>";
	} else if (value == "1") {
		return "<font color='black'>黑色</font>";
	} else if (value == "2") {
		return "<font color='blue'>蓝色</font>";
	} else {
		return "未知参数";
	}
}

/**
 * 电子印章状态
 */
function processStatusFmt(value) {
    var objs = GPCache.get(GPCache.ESS,GPType.ESS_SEAL_STATE);
    return GPCache.get(GPCache.ESS,GPType.ESS_SEAL_STATE, value);
}

/**
 * 电子印章类型格式化
 * 
 * @param value
 * @returns {String}
 */
function moulageTypeFmt(value) {
    return GPCache.get(GPCache.ESS, GPType.ESS_SEAL_TYPE, value);
}
/**
 * 用印类型
 * @param value
 * @returns
 */
function essUesType(value){
	return GPCache.get(GPCache.GSS, GPType.ESS_USE_TYPE, value);
}
