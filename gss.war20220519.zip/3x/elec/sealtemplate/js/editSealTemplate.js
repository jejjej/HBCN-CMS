/**
 * 删除印模
 * @param id
 */
function delElecSealModel(id){
	if (confirm("是否确认删除此印模？")){
		var url = ctx + "/elecseal/sealTemplateAction_delElecSealModel.action?id="+id;
		var data = tool.ajaxRequest(url, '');
		if(data.success){
			show(data.response.webResponseJson.data);
			queryElectronicSealModelList();
		}else{
			show("服务器响应失败：" + data.response);
		}
	}
}
/**
 * 查询详情
 * @param id
 */
function queryElecSealModelDetail(id) {
	var url = ctx + "/elecseal/sealTemplateAction_queryElecSealModelDetail.action?id="+id;
	var data = tool.ajaxRequest(url, '');
	if(data.success){
		if (data.response.webResponseJson.state == "normal") {
			showElecSealModelDetail(data.response.webResponseJson.data);
		} else {
			show(data.response.webResponseJson.data);
		}
	}else{
		show("服务器响应失败：" + data.response);
	}
}
/**
 * 打开电子印章印模编辑页面
 */
function showElecSealModelDetail(detail){
	
	var generatorF= document.getElementById("sealGenerator");
	ocxObject.initOcx(ocxObject.OCX_SealGenerator, generatorF, ctx + "/activex/api/","run", 300, 300);
	$("#electronicSealModelDialog").attr("class","son2_div");
	$("#pmodelName").val(detail.modelName);
	$("#id").val(detail.id);
	 var pro='{';
	    if(detail.modelEditableProp!=""){
	    	pro+=detail.modelEditableProp.replace("\{","").replace("\}","");
	    	if(detail.modelNEditableProp!=""){
	    		pro+=','+detail.modelNEditableProp.replace("\{","").replace("\}","");
	    	}
	    
	    }else{
	    	if(detail.modelNEditableProp!=""){
	    		pro+=detail.modelNEditableProp.replace("\{","").replace("\}","");
	    	}
	    }
	   pro+='}';

	var sealJSON=generateElectronicSeal(detail.modelAllProp,pro);
	var modelAllProp=$.parseJSON(detail.modelAllProp);
	var round=modelAllProp.seal.round;
	var text=modelAllProp.seal.text;
	$(round).each(function(i,item){
		if(item.main=="1"){//主体圆
			$("#borderwidth").val(item.borderwidth);
			var rect=item.rect.split(",");
			$("#rectLeft").val(rect[0]);
			$("#rectTop").val(rect[1]);
			$("#rectRight").val(rect[2]);
			$("#rectBottom").val(rect[3]);
		}else{//非主体圆
			//创建行
			var row = $("<tr></tr>");
			$("#paramList").append(row);
			$(row).attr("id",rowCount);
			$(row).attr("class","count");
			//第一个单元格 序号
			$(row).append("<td><input class='tdCount' type='checkbox' value='"+rowCount+"'>"+rowCount+"</input></td>")
			//第二个单元格 参数类型
			$(row).append("<td><select onchange='changParam("+rowCount+")' id='paramType"+rowCount+"' name='paramType"+rowCount+"' style='width: 60px;height: 23px;'><option value='round' selected='selected'>圆形</option><option value='text'>文字</option></select></td>");
			$("#paramType"+rowCount).val("round");
			//第三个单元格 参数名称
			var cell3= $("<td></td>");
			$(row).append(cell3);
			$(cell3).attr("id","pName"+rowCount);
			//第四个单元格 参数属性
			var roundTable=createRoundTable(rowCount);
			var cell4=$("<td>"+roundTable+"</td>");
			$(row).append(cell4);
			$(cell4).attr("id","paramModel"+rowCount);
			
			$("#borderwidth"+rowCount).val(item.borderwidth);
			var rect=item.rect.split(",");
			$("#rectLeft"+rowCount).val(rect[0]);
			$("#rectTop"+rowCount).val(rect[1]);
			$("#rectRight"+rowCount).val(rect[2]);
			$("#rectBottom"+rowCount).val(rect[3]);
			
			//第五个单元格 数据来源
			var cell5=$("<td></td>");
			$(row).append(cell5);
			$(cell5).attr("id","souceType"+rowCount);
			rowCount++;
			lastRow++;
		}
	});
	$(text).each(function(i,item){
		//创建行
		var row = $("<tr></tr>");
		$("#paramList").append(row);
		$(row).attr("id",rowCount);
		$(row).attr("class","count");
		//第一个单元格 序号
		$(row).append("<td><input class='tdCount' type='checkbox' value="+rowCount+">"+rowCount+"</input></td>");
		//第二个单元格 参数类型
		$(row).append("<td><select onchange='changParam("+rowCount+")' id='paramType"+rowCount+"' name='paramType"+rowCount+"' style='width: 60px;height: 23px;' ><option value='round'>圆形</option><option value='text'>文字</option></select></td>");
		$("#paramType"+rowCount).val("text");
		//第三个单元格 参数名称
		var cell3= $("<td><select  id='paramName"+rowCount+"' name='paramName"+rowCount+"' onchange='changParamName("+rowCount+")' style='width: 80px;height: 23px;'><option value='sealText'>印章正文</option><option value='sealCode'>印章编码</option><option value='sealRider'>印章附文</option><option value='verificationCode'>验证码</option></select></td>");
		$(row).append(cell3);
		$(cell3).attr("id","pName"+rowCount);
		//第四个单元格 参数属性
		var textTable=createTextTable(rowCount);
		var cell4=$("<td>"+textTable+"</td>");
		$(row).append(cell4);
		$(cell4).attr("id","paramModel"+rowCount);
		//第五个单元格 数据来源
		var cell5=$("<td><select id='source"+rowCount+"' name='source"+rowCount+"'  style='width: 80px;height: 23px;' ><option value='0'>外部输入</option><option value='1'>内部来源</option></select></td>");
		$(row).append(cell5);
		$(cell5).attr("id","souceType"+rowCount);
		
		$("#familyname"+rowCount).val(item.familyname);//字体
		$("#fontsize"+rowCount).val(item.fontsize);//字号
		var rect=item.rect.split(",");
		$("#rectLeft"+rowCount).val(rect[0]);
		$("#rectTop"+rowCount).val(rect[1]);
		$("#rectRight"+rowCount).val(rect[2]);
		$("#rectBottom"+rowCount).val(rect[3]);
		$("#content"+rowCount).val(item.content);//内容
		$("#bold"+rowCount).val(item.bold);//粗体
		$("#angle"+rowCount).val(item.angle);//弧度
		$("#offset"+rowCount).val(item.offset);//偏移
		rowCount++;
		lastRow++;
	});
	//根据内容判断参数名
	var rowList=$(".count");
	$(rowList).each(function(i,item){
		if($("#paramType"+$(item).attr("id")).val()=="text"){
			if(detail.modelEditableProp!=""){
				var modelEditableProp=$.parseJSON(detail.modelEditableProp);
				for(var key in modelEditableProp ){
					 if($("#content"+$(item).attr("id")).val()==key){
						 $("#content"+$(item).attr("id")).val(modelEditableProp[key]);//内容
						 $("#paramName"+$(item).attr("id")).val(key);//参数名称
						 $("#source"+$(item).attr("id")).val("0");	//外部输入					
					 }
				}
			}
			if(detail.modelNEditableProp!=""){
				var modelNEditableProp=$.parseJSON(detail.modelNEditableProp);
				for(var key in modelNEditableProp ){
					 if($("#content"+$(item).attr("id")).val()==key){
						 $("#content"+$(item).attr("id")).val(modelNEditableProp[key]);//内容
						 $("#paramName"+$(item).attr("id")).val(key);//参数名称
						 $("#source"+$(item).attr("id")).val("1");	//内部输入
						 if("verificationCode"==key){
							 $("#content"+$(item).attr("id")).attr("disabled","disabled");
							 $("#source"+$(item).attr("id")).attr("disabled","disabled");
						 }
					 }
				}
			}
		}
	});
}