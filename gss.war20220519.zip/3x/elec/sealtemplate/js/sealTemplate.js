var rowCount=1;//总行数
var lastRow=1;//最大下标
var modelAllProp="";// 印模全量属性JSON串
var modelEditableProp="";// 印模可变属性JSON串
var modelNEditableProp="";//印模不可变属性JSON串
var editableProp="";
var neditableProp="";
var width=0;
var height=0;
var pview=false;//点击保存前  先提示预览
$(document).ready(function() {
	
	// 弹出新增参数框
	$("#addBtn").click(function(event) {
		event.preventDefault();
		showelElectronicSealModelDialog();
	});
	// 查询
	$("#queryBtn").click(function(event) {
		event.preventDefault();
		queryElectronicSealModelList();
	});
	// 增加参数
	$("#addParam").click(function(event) {
		event.preventDefault();
		addParam();
	});
	// 删除参数
	$("#delParam").click(function(event) {
		event.preventDefault();
		delParam();
	});
	// 保存参数
	$("#saveParam").click(function(event) {
		event.preventDefault();
		saveParam();
	});
	// 取消
	$("#dParam").click(function(event) {
		event.preventDefault();
		reset();
	});

	// 印章预览
	$("#preview").click(function(event) {
		event.preventDefault();
		showSeal();
	});

	// 绘制表格
	initGrid();
});

/**
 * 初始化分页界面
 */
function initGrid() {
	
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	$("#sealTemplateList").jqGrid(
		{
			width : pageContentWidth,
			height : tableHeight + "px",
			url : ctx + "/elecseal/sealTemplateAction_queryElectronicSealModelList.action",
			multiselect : false,
			rowNum : 10,
			rownumbers:true,
			rowList : [ 10 ],
			colNames : [ "印模名称", "操作人员", "操作日期",
			          "印章宽度","印章高度", "操作"],
			colModel : [
					{
						name : "modelName",
						index : "modelName",
						width : 110,
						align : "center",
						sortable : false
					}, {
						name : "operName",
						index : "operName",
						width : 110,
						align : "center",
						sortable : false
					}, {
						name : "operDate",
						index : "operDate",
						width : 110,
						align : "center",
						sortable : false
					}, {
						name : "width",
						index : "width",
						width : 110,
						align : "center",
						sortable : false
					}, {
						name : "height",
						index : "height",
						width : 110,
						align : "center",
						sortable : false
					}, {
						name : "id",
						index : "id",
						width : 110,
						align : "center",
						sortable : false,
						formatter : function(value, options, rData) {
							return "<button onClick=\"queryElecSealModelDetail('"+value+"');return false;\">详情</button>" +
							"<button onClick=\"delElecSealModel('"+value+"');return false;\">删除</button>";
						}
					} 
					],
			pager : "#sealTemplatePager",
			caption : "印模信息查询"
		}).trigger("reloadGrid");
	$("#sealTemplateList").navGrid("#sealTemplatePager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

/**
 * 查询电子印章印模列表
 */
function queryElectronicSealModelList() {
	$("#sealTemplateList").jqGrid('search',"#form");
}

/**
 * 弹出参数Dialog
 */
function showelElectronicSealModelDialog() {
	var generatorF=document.getElementById("sealGenerator");
	ocxObject.initOcx(ocxObject.OCX_SealGenerator, generatorF, ctx + "/activex/api/","run", 300, 300);
	$("#electronicSealModelDialog").attr("class","son2_div");
}
/**
 * 印模预览
 */
function showSeal(){
	// 设置默认值
	pview=true;
	if($("#rectLeft").val()==""){
		$("#rectLeft").val(0);
	}
	if($("#rectTop").val()==""){
		$("#rectTop").val(0);
	}
	if($("#rectRight").val()==""){
		$("#rectRight").val(40);
	}
	if($("#rectBottom").val()==""){
		$("#rectBottom").val(40);
	}
	if($("#borderwidth").val()==""){
		$("#borderwidth").val(4);
	}
	// 先拼写主体园
	var mainM='"main":1';
	var rectM='"rect":"'+$("#rectLeft").val()+','+$("#rectTop").val()+','+$("#rectRight").val()+','+$("#rectBottom").val()+'"';
	var borderwidthM='"borderwidth":'+$("#borderwidth").val();
	var roundM="{"+mainM+","+rectM+","+borderwidthM+"}";
	width=$("#rectRight").val()-$("#rectLeft").val();
	height=$("#rectBottom").val()-$("#rectTop").val();
	var roundAll=roundM;
	var textAll="";
	var editableProp="";
	var paramName=new Array();
	var rowList=$(".count");
	$(rowList).each(function(i,item){
		var id=$(item).attr("id");
		if($("#paramType"+id).val()=="round"){
			
			// 设置默认值
			if($("#rectLeft"+id).val()==""){
				$("#rectLeft"+id).val(0);
			}
			if($("#rectTop"+id).val()==""){
				$("#rectTop"+id).val(0);
			}
			if($("#rectRight"+id).val()==""){
				$("#rectRight"+id).val(10);
			}
			if($("#rectBottom"+id).val()==""){
				$("#rectBottom"+id).val(10);
			}
			if($("#borderwidth"+id).val()==""){
				$("#borderwidth"+id).val(4);
			}
			// 参数为非主体圆
			var main='"main":0';
			
			var rect='"rect":"'+$("#rectLeft"+id).val()+','+$("#rectTop"+id).val()+','+$("#rectRight"+id).val()+','+$("#rectBottom"+id).val()+'"';
			var borderwidth='"borderwidth":'+$("#borderwidth"+id).val();
			
			var round="{"+main+","+rect+","+borderwidth+"}";
			roundAll+=","+round;
			
		}else if($("#paramType"+id).val()=="text"){
			// 数据来源---外部来源
			if($("#content"+id).val()==""){
				alert("文字不能为空！");
				pview=false;
				return;
			}else{
				if($("#paramName"+id).val()=="sealCode"){
					if(isNaN($("#content"+id).val())||$("#content"+id).val().length!=3){
						alert("印章编码应为3位数字");
						pview=false;
						return;
					}
				}
				var content='"content":"'+$("#paramName"+id).val()+'"';
				paramName.push($("#paramName"+id).val());
				if($("#source"+id).val()==0){
					if(editableProp==""){
						editableProp='"'+$("#paramName"+id).val()+'"'+':"'+$("#content"+id).val()+'"';
					}else{
						editableProp+=','+'"'+$("#paramName"+id).val()+'"'+':"'+$("#content"+id).val()+'"';
					}
					
				}else{
					if(neditableProp==""){
						neditableProp='"'+$("#paramName"+id).val()+'"'+':"'+$("#content"+id).val()+'"';
					}else{
						neditableProp+=','+'"'+$("#paramName"+id).val()+'"'+':"'+$("#content"+id).val()+'"';
					}
				}
					// 设置默认值
					if($("#rectLeft"+id).val()==""){
						$("#rectLeft"+id).val(0);
					}
					if($("#rectTop"+id).val()==""){
						$("#rectTop"+id).val(0);
					}
					if($("#rectRight"+id).val()==""){
						$("#rectRight"+id).val(40);
					}
					if($("#rectBottom"+id).val()==""){
						$("#rectBottom"+id).val(40);
					}
					if($("#familyname"+id).val()==""){
						$("#familyname"+id).val("Arial");// 宋体
					}
					if($("#fontsize"+id).val()==""){
						$("#fontsize"+id).val(15);
					}
					if($("#bold"+id).val()==""){
						$("#bold"+id).val(0);
					}
					if($("#angle"+id).val()==""){
						$("#angle"+id).val(0);
					}
					if($("#offset"+id).val()==""){
						$("#offset"+id).val(0);
					}
					var rect='"rect":"'+$("#rectLeft"+id).val()+','+$("#rectTop"+id).val()+','+$("#rectRight"+id).val()+','+$("#rectBottom"+id).val()+'"';
					var familyname='"familyname":"'+$("#familyname"+id).val()+'"';
					
					var fontsize='"fontsize":'+$("#fontsize"+id).val();
					
					var bold='"bold":'+$("#bold"+id).val();
					
					var angle='"angle":'+$("#angle"+id).val();
					
					var offset='"offset":'+$("#offset"+id).val();
					
					var text="{"+content+","+rect+","+familyname+","+fontsize+","+bold+","+angle+","+offset+"}";
					if(textAll==""){
						textAll=text;
					}else{
						textAll+=","+text;
					}
				}
			
			}
			
	});	
	if(repeatArray(paramName)){
		alert("不能有重复的可变参数");
		pview=false;
		return
	}
    modelAllProp = '{'+
						'"seal":{'+
								'"round":['+roundAll+'],'+
								'"text":['+textAll+']'
								
							  +'}'+
					'}';
    var pro='{';
    if(editableProp!=""){
    	modelEditableProp='{'+editableProp+'}';
    	pro+=editableProp;
    	if(neditableProp!=""){
    	    	modelNEditableProp='{'+neditableProp+'}';
    	    	pro+=','+neditableProp;
    	    }
    }else{
    	if(neditableProp!=""){
	    	modelNEditableProp='{'+neditableProp+'}';
	    	pro+=neditableProp;
	    }
    }
   pro+='}';
	editableProp="";
   	neditableProp="";
	generateElectronicSeal(modelAllProp,pro);
	
}
/**
 * 添加参数
 */
function addParam(){
	pview=false;
	var roundTable=createRoundTable(lastRow);
	var row = $("<tr></tr>");
	$("#paramList").append(row);
	$(row).attr("id",lastRow);
	$(row).attr("class","count");
	$(row).append("<td><input class='tdCount' type='checkbox' value="+lastRow+">"+lastRow+"</input></td>");
	$(row).append("<td><select onchange='changParam("+lastRow+")' id='paramType"+lastRow+"' name='paramType"+lastRow+"' style='width: 60px;height: 23px;' ><option value='round'>圆形</option><option value='text'>文字</option></select></td>");
	var cell3= $("<td></td>");
	$(row).append(cell3);
	$(cell3).attr("id","pName"+lastRow);
	var cell4=$("<td>"+roundTable+"</td>");
	$(row).append(cell4);
	$(cell4).attr("id","paramModel"+lastRow);
	var cell5=$("<td></td>");
	$(row).append(cell5);
	$(cell5).attr("id","souceType"+lastRow);
	rowCount++;
	lastRow++;
}
/**
 * 删除参数
 */
function delParam(){
	pview=false;
	/*var rowList=$(".tdCount");
	$(rowList).each(function(i,item){
		alert("test");
		if($(item).prop('checked')==true){
			$("#"+$(item).val()).remove();
			rowCount--;
		}
	});*/
	var rowList=$("#paramList").find(".tdCount");
	$(rowList).each(function(i,item){
		if($(item).prop('checked')==true){
			$("#paramList").find("#"+$(item).val()).remove();
			rowCount--;
		}
	});
	if(rowCount==0){
		lastRow=1;
	}
	
}
/**
 * 保存
 */
function saveParam(){
	if($("#pmodelName").val()==""){
		alert("请输入印模名称！");
		return;
	}
	if(!isChn($("#pmodelName").val())){
		return;
	}
	if(!pview){
		alert("请先预览！");
		return;
	}
	var url = ctx + "/elecseal/sealTemplateAction_saveOrUpdateElectronicSealModel.action";
	var content={"id":$("#id").val(),"modelName":$("#pmodelName").val(),"width":width,"height":height,"modelAllProp":modelAllProp,"modelEditableProp":modelEditableProp,"modelNEditableProp":modelNEditableProp};
	var data = tool.ajaxRequest(url, content);
	if(data.success){
		show(data.response.webResponseJson.data);
		reset();
		queryElectronicSealModelList();
	}else{
		show("服务器响应失败：" + data.response);
		reset();
	}
}
/**
 * 取消
 */
function reset(){
	$("#electronicSealModelDialog").attr("class","son1_div");
	$("#sealGenerator").empty();// 移除控件
	/**
	 * 删除参数行
	 */
	var rowList=$("#paramList").find(".count");
	$(rowList).each(function(i,item){
		$("#paramList").find("#"+$(item).attr("id")).remove();
	});
	/**
	 * 清空数据
	 */
	modelAllProp="";
	modelEditableProp="";
	modelNEditableProp="";
	editableProp="";
	neditableProp="";
	width=0;
	height=0;
	lastRow=1;
	rowCount=1;
	pview=false;
	$("#pmodelName").val("");
	$("#id").val("");
	$("#borderwidth").val("");
	$("#rectLeft").val("");
	$("#rectTop").val("");
	$("#rectRight").val("");
	$("#rectBottom").val("");
}
/**
 * 响应参数类型
 */
function changParam(rowCount){
	$("#paramModel"+rowCount).empty();
	
	if($("#paramType"+rowCount).val()=="round"){
		$("#paramModel"+rowCount).empty().html(createRoundTable(rowCount));
		$("#pName"+rowCount).empty();
		$("#souceType"+rowCount).empty();
	}else{
		$("#paramModel"+rowCount).empty().html(createTextTable(rowCount));
		$("#pName"+rowCount).empty().html("<select  id='paramName"+rowCount+"' name='paramName"+rowCount+"' onchange='changParamName("+rowCount+")' style='width: 80px;height: 23px;' ><option value='sealText'>印章正文</option><option value='sealCode'>印章编码</option><option value='sealRider'>印章附文</option><option value='verificationCode'>验证码</option></select>");
		$("#souceType"+rowCount).empty().html("<select id='source"+rowCount+"' name='source"+rowCount+"'  style='width: 60px;height: 23px;' ><option value='0'>外部输入</option><option value='1'>内部来源</option></select>");
	}
	
}
/**
 * 相应参数名字
 * 
 * @param rowCount
 */
function changParamName(rowCount){
	if($("#paramName"+rowCount).val()=="verificationCode"){
		$("#content"+rowCount).val("000000000000");
		$("#content"+rowCount).attr("disabled","disabled");
		$("#source"+rowCount).val("1");
		$("#source"+rowCount).attr("disabled","disabled");
	}else{
		$("#content"+rowCount).val("");
		$("#content"+rowCount).removeAttr("disabled");
		$("#source"+rowCount).removeAttr("disabled");
	}
}
/**
 * 判断数组是否有重复值
 * 
 * @param paramName
 * @returns {Boolean}
 */
function repeatArray(paramName){
	var s = paramName.join(",")+","; 
    for(var i=0;i<paramName.length;i++) 
    { 
    	if(s.replace(paramName[i]+",","").indexOf(paramName[i]+",")>-1) 
    	{ 
    		return true;
    	}
    }
    return false;
}
/**
 * 是否为中文
 * @param str
 * @returns {Boolean}
 */
function isChn(str){ 
	var reg = /^[\u4E00-\u9FA5]+$/; 
	if(!reg.test(str)){ 
	alert("印模名称不是中文！"); 
	return false; 
	}  
	return true; 
} 

function createRoundTable(rowCount){
	var roundTable="<table style='border:0'>" +
	"<td style='border:0'>圆边宽度</td>" +
	"<td style='border:0'>" +
	"<input id='borderwidth"+rowCount+"' name='borderwidth"+rowCount+"' style='width: 40px;height: 23px;'></input>&nbsp;&nbsp;" +
	"</td>" +
	"<td style='border:0'>左边距</td>" +
	"<td style='border:0'><input id='rectLeft"+rowCount+"' name='rectLeft"+rowCount+"' style='width: 40px;height: 23px;'></input>&nbsp;&nbsp;" +
	"</td>" +
	"<td style='border:0'>上边距</td>" +
	"<td style='border:0'><input id='rectTop"+rowCount+"' name='rectTop"+rowCount+"' style='width: 40px;height: 23px;'></input>&nbsp;&nbsp;</td>" +
	"<td style='border:0'>右边距</td>" +
	"<td style='border:0'><input id='rectRight"+rowCount+"' name='rectRight"+rowCount+"' style='width: 40px;height: 23px;'></input>&nbsp;&nbsp;</td>" +
	"<td style='border:0'>下边距</td>" +
	"<td style='border:0'><input id='rectBottom"+rowCount+"' name='rectBottom"+rowCount+"' style='width: 40px;height: 23px;'></input></td>" +
	"</tr>" +
	"</table>";
	return roundTable;
}

function createTextTable(rowCount){
	var textTable="<table style='border:0'>" +
			"<tr>" +
			"<td style='border:0;'>字体</td>" +
			"<td style='border:0'><select id='familyname"+rowCount+"' name='familyname"+rowCount+"'  style='width: 60px;height: 23px;'>" +
							"<option value='Arial'>宋体</option>" +
							"</select>&nbsp;&nbsp;" +
			"</td>" +
			"<td style='border:0'>字号</td>" +
			"<td style='border:0'><input id='fontsize"+rowCount+"' name='fontsize"+rowCount+"' style='width: 30px;height: 23px;'></input>&nbsp;&nbsp;&nbsp;" +
			"</td>" +
			"<td style='border:0'>左边距</td>" +
			"<td style='border:0'><input id='rectLeft"+rowCount+"' name='rectLeft"+rowCount+"' style='width: 30px;height: 23px;'></input>&nbsp;&nbsp;&nbsp;" +
			"</td>" +
			"<td style='border:0'>上边距</td>" +
			"<td style='border:0'><input id='rectTop"+rowCount+"' name='rectTop"+rowCount+"' style='width: 30px;height: 23px;'></input>&nbsp;&nbsp;&nbsp;" +
			"</td>" +
			"<td style='border:0'>右边距</td>" +
			"<td style='border:0'><input id='rectRight"+rowCount+"' name='rectRight"+rowCount+"' style='width: 30px;height: 23px;'></input>&nbsp;&nbsp;&nbsp;" +
			"</td>" +
			"<td style='border:0'>下边距</td>" +
			"<td style='border:0'><input id='rectBottom"+rowCount+"' name='rectBottom"+rowCount+"' style='width: 30px;height: 23px;'></input>" +
			"</td>" +
			"</tr>" +
			"<tr>" +
			"<td style='border:0'>内容</td>" +
			"<td style='border:0' colspan='5' align='left'><input id='content"+rowCount+"' name='content"+rowCount+"' style='width: 227px;height: 23px;'></input>" +
			"</td>" +
			"<td style='border:0'>粗&nbsp;&nbsp;体</td>" +
			"<td style='border:0' align='left'><input id='bold"+rowCount+"' name='bold"+rowCount+"' style='width: 30px;height: 23px;'></input>" +
			"</td>" +
			"<td style='border:0'>弧&nbsp;&nbsp;度</td>" +
			"<td style='border:0' align='left'><input id='angle"+rowCount+"' name='angle"+rowCount+"' style='width: 30px;height: 23px;'></input>°" +
			"</td>" +
			"<td style='border:0'>偏&nbsp;&nbsp;移</td>" +
			"<td style='border:0' align='left'><input id='offset"+rowCount+"' name='offset"+rowCount+"' style='width: 30px;height: 23px;'></input>" +
			"</td>" +
			"</tr>" +
			"</table>";
	return textTable;
}