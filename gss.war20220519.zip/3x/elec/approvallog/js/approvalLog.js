/**
 * 
 * 创建于:2014-9-11<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 数据导入结果查询
 * 
 * @author 叶慧雄
 * @author Rickychen
 * @version 1.0
 */

/**
 * 初始化Grid数据
 */
$(function() {
	initPage();
});

function initPage(){
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	$("#approvalLogList").jqGrid(
		{
			width : pageContentWidth,
			height : tableHeight + "px",
			url : ctx + "/elecseal/approvalLogAction_queryApproLog.action",
			multiselect : false,
			rowNum : 20,
			rownumbers:true,
			rowList : [ 20, 50, 100 ],
			colNames : [ "印章流水号", "工号", "机构号", "操作类型",
			          "操作日期","操作时间", "审批结果","备注","拒绝理由" ],
			colModel : [
					{
						name : "bizId",
						index : "bizId",
						align : "center",
						width : 260,
						sortable : false
					},
					{
						name : "operatorCode",
						index : "operatorCode",
						width : 80,
						align : "center",
						sortable : false
					},
					{
						name : "operatorOrgNo",
						index : "operatorOrgNo",
						align : "center",
						width : 100,
						sortable : false
					},
					{
						name : "operateType",
						index : "operateType",
						align : "center",
						width : 100,
						sortable : false,
						formatter : function(value, options, rData) {
							return operateType[value];
						}
					},
					{
						name : "operateDate",
						index : "operateDate",
						align : "center",
						width : 100,
						sortable : false
					},
					{
						name : "operateTime",
						index : "operateTime",
						align : "center",
						width : 80,
						sortable : false
					},
					{
						name : "result",
						index : "result",
						align : "center",
						width : 80,
						sortable : false,
						formatter : function(value, options, rData) {
							return sealApprovalReasult[value];
						}
					},
					{
						name : "memo",
						index : "memo",
						align : "center",
						sortable : false
					},
					{
						name : "refuseReason",
						index : "refuseReason",
						align : "center",
						sortable : false
					} ],
			pager : "#approvalLogPager",
			caption : "用印申请审批列表"
		}).trigger("reloadGrid");
	$("#approvalLogList").navGrid("#approvalLogPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
}

/**
 * 查询数据，执行查询
 */
function queryData() {
	$("#approvalLogList").jqGrid("search", "#queryForm");
}

/**
 * 重置查询条件
 */
function resetMethod() {
	$("#queryForm")[0].reset();
}
