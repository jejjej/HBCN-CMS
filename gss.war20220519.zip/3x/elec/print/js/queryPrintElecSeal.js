$(document).ready(function() {
    selectUtils.initSealBizType("sealUseId", 0);

    $("#queryBtn").click(function(event) {
	event.preventDefault();
	queryPrintElecSealList();
    });
    $("#resetBtn").click(function(event) {
	$("#form")[0].reset();
    });
    // 绘制表格
    initGrid();

    // $("#sealType").get(0).options.add(new Option("全部", ""));
    $("#sealType").get(0).options.add(new Option("电子印章", "0"));
    // $("#sealType").get(0).options.add(new Option("机控印章", "1"));

    $("#useType").get(0).options.add(new Option("全部", ""));
    $("#useType").get(0).options.add(new Option("独立用印", "0"));
    $("#useType").get(0).options.add(new Option("一体化用印", "1"));

    initDialog();
});

/**
 * 初始化分页界面
 */
function initGrid() {
    //
    var pageHeaderHeight = $(".pageHeader").css("height");
    var pageContentWidth = $(".pageContent").width() + 10;
    pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
    var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
    $("#queryPrintElecSealList").jqGrid({
	width : pageContentWidth,
	height : tableHeight + "px",
	url : ctx + "/elecseal/queryPrintElecSealAction_queryPrintElecSealList.action",
	multiselect : false,
	rowNum : 10,
	rownumbers : true,
	rowList : [ 10, 20 ],
	colNames : [ "业务验证码", "业务流水号", "印章材质", "用印模式", "印章类型", "操作类型", "结果", "用印日期", "用印时间", "人员代码", "机构号", "图像" ],
	colModel : [ {
	    name : "verificationCode",
	    index : "verificationCode",
	    align : "center",
	    sortable : false
	}, {
	    name : "bizId",
	    index : "bizId",
	    align : "center",
	    sortable : false
	}, {
	    name : "sealType",
	    index : "sealType",
	    align : "center",
	    sortable : false,
	    formatter : function(value, options, rData) {
		return sealTypeList[value];
	    }
	}, {
	    name : "useType",
	    index : "useType",
	    align : "center",
	    sortable : false,
	    formatter : function(value, options, rData) {
		return useTypeList[value];
	    }
	}, {
	    name : "sealUseId",
	    index : "sealUseId",
	    align : "center",
	    sortable : false,
	    formatter : function(value, options, rData) {
		return selectUtils.sealBizTypeCache[value];
	    }
	}, {
	    name : "operateType",
	    index : "operateType",
	    align : "center",
	    sortable : false,
	    formatter : function(value, options, rData) {
		return sealUseOptTypeList[value];
	    }
	}, {
	    name : "result",
	    index : "result",
	    align : "center",
	    sortable : false,
	    formatter : function(value, options, rData) {
		return sealUseOptResult[value];
	    }
	}, {
	    name : "operateDate",
	    index : "operateDate",
	    align : "center",
	    sortable : false
	}, {
	    name : "operateTime",
	    index : "operateTime",
	    align : "center",
	    sortable : false
	}, {
	    name : "operatorCode",
	    index : "operatorCode",
	    align : "center",
	    sortable : false
	}, {
	    name : "operatorOrgNo",
	    index : "operatorOrgNo",
	    align : "center",
	    sortable : false
	}, {
	    name : "bizId",
	    index : "bizId",
	    align : "center",
	    sortable : false,
	    formatter : function(value, options, rData) {
		var type = rData["SealUseLog.operateType"];
		if (type == "005") {
		    return "<a href='#' onClick='imgContast(\"" + value + "\");' style='color:black;'>详情</a>";
		} else {
		    return null;
		}

	    }
	} ],
	pager : "#queryPrintElecSealPage",
	caption : "用印查询"
    }).trigger("reloadGrid");
    $("#queryPrintElecSealList").navGrid("#queryPrintElecSealPage", {
	edit : false,
	add : false,
	del : false,
	search : false,
	refresh : true
    });
};

/**
 * 查询电子印章审批列表
 */
function queryPrintElecSealList() {
    $("#queryPrintElecSealList").jqGrid('search', "#form");

};

function initDialog() {
    $("#dialog").dialog({
	autoOpen : false,
	resizable : false,
	// height : $(window).height(), 不起作用
	width : 500,
	modal : true,
	position : {
	    at : "center top"
	}
    });
};
/**
 * 用印前后图像对比
 * 
 * @param imgStoreId
 * @returns
 */

function imgContast(autoId) {
    $("#dialog").dialog("open");
    var url = ctx + "/elecseal/queryPrintElecSealAction_imgContast.action?autoId=" + autoId;
    var data = tool.ajaxRequest(url, '');
    if (data.success) {
	if (data.response.webResponseJson.state == "normal") {
	    var urlList = data.response.webResponseJson.data;
	    var url_1 = urlList[0];
	    var url_2 = urlList[urlList.length - 1];
	    $("#dialog").dialog("open");
	    document.getElementById("beforeImg").src = url_1;
	    document.getElementById("afterImg").src = url_2;
	} else {
	    show(data.response.webResponseJson.data);
	}
    } else {
	show("服务器响应失败：" + data.response);
    }
};

function cancel() {
    $("#dialog").dialog("close");
};