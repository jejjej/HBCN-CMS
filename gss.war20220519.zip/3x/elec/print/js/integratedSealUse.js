﻿﻿var sealType;
var tdNum = 0;
var inputParam;

var id;
var url;

/**
 * 用印输入项参数
 */
var inputParamList = [ "tradeNo", "cardNo", "accNo", "billNo", "accName", "currency", "money" ];

/**
 * 用印输入项名称参数
 */
var inputParamNameList = [ "交易序号：", "卡号：", "账号：", "票据号：", "账户名称：", "币种：", "金额：" ];

// 打印模板
var template1 = '<?xml version="1.0" encoding="UTF-8"?><CONFIGS><CONFIG SYSTEMNAME="1"><FIELD NAME="ReceiptParam"><PARAM NAME="ORDER">0</PARAM><PARAM NAME="MAXCNT">1</PARAM><PARAM NAME="IFCHANGE">0</PARAM><PARAM NAME="ORIENTATION">1</PARAM><PARAM NAME="PAGEW">210</PARAM><PARAM NAME="PAGEH">297</PARAM><PARAM NAME="IMAGEX">0</PARAM><PARAM NAME="IMAGEY">0</PARAM><PARAM NAME="IMAGEW">0</PARAM><PARAM NAME="IMAGEH">0</PARAM><PARAM NAME="ORIENTATIONSEC">0</PARAM><PARAM NAME="PAGEWSEC">148</PARAM><PARAM NAME="PAGEHSEC">210</PARAM><PARAM NAME="IMAGEXSEC">0</PARAM><PARAM NAME="IMAGEYSEC">0</PARAM><PARAM NAME="IMAGEWSEC">0</PARAM><PARAM NAME="IMAGEHSEC">0</PARAM><PARAM NAME="BLANK">10</PARAM><PARAM NAME="PAGEFONTNAME">宋体</PARAM><PARAM NAME="PAGEFONTSTYLE">5</PARAM><PARAM NAME="PAGEFONTSIZE">10</PARAM><PARAM NAME="PRINTTYPE">1</PARAM></FIELD><FIELD NAME="printarea107"><PARAM NAME="ORDER">19</PARAM><PARAM NAME="VALUENAME">printarea107</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">126</PARAM><PARAM NAME="Y">48</PARAM><PARAM NAME="WIDTH">38</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea105"><PARAM NAME="ORDER">17</PARAM><PARAM NAME="VALUENAME">printarea105</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">126</PARAM><PARAM NAME="Y">39</PARAM><PARAM NAME="WIDTH">53</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea106"><PARAM NAME="ORDER">18</PARAM><PARAM NAME="VALUENAME">printarea106</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">53</PARAM><PARAM NAME="Y">48</PARAM><PARAM NAME="WIDTH">46</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea100"><PARAM NAME="ORDER">23</PARAM><PARAM NAME="VALUENAME">printarea100</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">132</PARAM><PARAM NAME="Y">12</PARAM><PARAM NAME="WIDTH">23</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea103"><PARAM NAME="ORDER">15</PARAM><PARAM NAME="VALUENAME">printarea103</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">126</PARAM><PARAM NAME="Y">30</PARAM><PARAM NAME="WIDTH">38</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea101"><PARAM NAME="ORDER">24</PARAM><PARAM NAME="VALUENAME">printarea101</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">174</PARAM><PARAM NAME="Y">12</PARAM><PARAM NAME="WIDTH">26</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea104"><PARAM NAME="ORDER">16</PARAM><PARAM NAME="VALUENAME">printarea104</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">53</PARAM><PARAM NAME="Y">39</PARAM><PARAM NAME="WIDTH">46</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea13"><PARAM NAME="ORDER">13</PARAM><PARAM NAME="VALUENAME">printarea13</PARAM><PARAM NAME="WIDTH">0</PARAM><PARAM NAME="TYPE">3</PARAM><PARAM NAME="X">0</PARAM><PARAM NAME="Y">20</PARAM><PARAM NAME="X2">236</PARAM><PARAM NAME="Y2">20</PARAM><PARAM NAME="GRAY">10</PARAM><PARAM NAME="SHAPETYPE">0</PARAM></FIELD><FIELD NAME="printarea102"><PARAM NAME="ORDER">14</PARAM><PARAM NAME="VALUENAME">printarea102</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">53</PARAM><PARAM NAME="Y">30</PARAM><PARAM NAME="WIDTH">46</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea11"><PARAM NAME="ORDER">11</PARAM><PARAM NAME="VALUENAME">printarea11</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">时间:</PARAM><PARAM NAME="X">158</PARAM><PARAM NAME="Y">12</PARAM><PARAM NAME="WIDTH">13</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea12"><PARAM NAME="ORDER">12</PARAM><PARAM NAME="VALUENAME">printarea12</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">日期：</PARAM><PARAM NAME="X">116</PARAM><PARAM NAME="Y">12</PARAM><PARAM NAME="WIDTH">14</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea3"><PARAM NAME="ORDER">3</PARAM><PARAM NAME="VALUENAME">printarea3</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">业务类型：</PARAM><PARAM NAME="X">105</PARAM><PARAM NAME="Y">30</PARAM><PARAM NAME="WIDTH">22</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea109"><PARAM NAME="ORDER">21</PARAM><PARAM NAME="VALUENAME">printarea109</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">126</PARAM><PARAM NAME="Y">57</PARAM><PARAM NAME="WIDTH">37</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea2"><PARAM NAME="ORDER">2</PARAM><PARAM NAME="VALUENAME">printarea2</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">交易序号：</PARAM><PARAM NAME="X">31</PARAM><PARAM NAME="Y">30</PARAM><PARAM NAME="WIDTH">21</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea108"><PARAM NAME="ORDER">20</PARAM><PARAM NAME="VALUENAME">printarea108</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">53</PARAM><PARAM NAME="Y">57</PARAM><PARAM NAME="WIDTH">45</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">1</PARAM></FIELD><FIELD NAME="图1"><PARAM NAME="ORDER">10</PARAM><PARAM NAME="VALUENAME">图1</PARAM><PARAM NAME="TYPE">2</PARAM><PARAM NAME="PATH">D:\\a.jpg</PARAM><PARAM NAME="X">130</PARAM><PARAM NAME="Y">78</PARAM><PARAM NAME="WIDTH">SEALWIDTH</PARAM><PARAM NAME="HEIGHT">SEALHEIGHT</PARAM><PARAM NAME="GETPATH">1</PARAM></FIELD><FIELD NAME="printarea1"><PARAM NAME="ORDER">1</PARAM><PARAM NAME="VALUENAME">printarea1</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">汇票业务测试</PARAM><PARAM NAME="X">66</PARAM><PARAM NAME="Y">1</PARAM><PARAM NAME="WIDTH">82</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">20</PARAM><PARAM NAME="HORALLIGN">1</PARAM></FIELD><FIELD NAME="printarea6"><PARAM NAME="ORDER">6</PARAM><PARAM NAME="VALUENAME">printarea6</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">户名：</PARAM><PARAM NAME="X">105</PARAM><PARAM NAME="Y">48</PARAM><PARAM NAME="WIDTH">14</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea5"><PARAM NAME="ORDER">5</PARAM><PARAM NAME="VALUENAME">printarea5</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">票据号：</PARAM><PARAM NAME="X">31</PARAM><PARAM NAME="Y">48</PARAM><PARAM NAME="WIDTH">20</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea4"><PARAM NAME="ORDER">4</PARAM><PARAM NAME="VALUENAME">printarea4</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">帐号：</PARAM><PARAM NAME="X">105</PARAM><PARAM NAME="Y">39</PARAM><PARAM NAME="WIDTH">14</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea9"><PARAM NAME="ORDER">9</PARAM><PARAM NAME="VALUENAME">printarea9</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">金额：</PARAM><PARAM NAME="X">105</PARAM><PARAM NAME="Y">57</PARAM><PARAM NAME="WIDTH">14</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea8"><PARAM NAME="ORDER">8</PARAM><PARAM NAME="VALUENAME">printarea8</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">币种：</PARAM><PARAM NAME="X">31</PARAM><PARAM NAME="Y">57</PARAM><PARAM NAME="WIDTH">19</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea99"><PARAM NAME="ORDER">100</PARAM><PARAM NAME="VALUENAME">printarea99</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">卡号：</PARAM><PARAM NAME="X">31</PARAM><PARAM NAME="Y">39</PARAM><PARAM NAME="WIDTH">19</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD></CONFIG></CONFIGS>';

var template2 = '<?xml version="1.0" encoding="UTF-8"?><CONFIGS><CONFIG SYSTEMNAME="2"><FIELD NAME="ReceiptParam"><PARAM NAME="ORDER">0</PARAM><PARAM NAME="MAXCNT">1</PARAM><PARAM NAME="IFCHANGE">0</PARAM><PARAM NAME="ORIENTATION">1</PARAM><PARAM NAME="PAGEW">210</PARAM><PARAM NAME="PAGEH">297</PARAM><PARAM NAME="IMAGEX">0</PARAM><PARAM NAME="IMAGEY">0</PARAM><PARAM NAME="IMAGEW">0</PARAM><PARAM NAME="IMAGEH">0</PARAM><PARAM NAME="ORIENTATIONSEC">0</PARAM><PARAM NAME="PAGEWSEC">148</PARAM><PARAM NAME="PAGEHSEC">210</PARAM><PARAM NAME="IMAGEXSEC">0</PARAM><PARAM NAME="IMAGEYSEC">0</PARAM><PARAM NAME="IMAGEWSEC">0</PARAM><PARAM NAME="IMAGEHSEC">0</PARAM><PARAM NAME="BLANK">10</PARAM><PARAM NAME="PAGEFONTNAME">宋体</PARAM><PARAM NAME="PAGEFONTSTYLE">5</PARAM><PARAM NAME="PAGEFONTSIZE">10</PARAM><PARAM NAME="PRINTTYPE">1</PARAM></FIELD><FIELD NAME="printarea107"><PARAM NAME="ORDER">19</PARAM><PARAM NAME="VALUENAME">printarea107</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">126</PARAM><PARAM NAME="Y">48</PARAM><PARAM NAME="WIDTH">38</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea105"><PARAM NAME="ORDER">17</PARAM><PARAM NAME="VALUENAME">printarea105</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">126</PARAM><PARAM NAME="Y">39</PARAM><PARAM NAME="WIDTH">53</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea106"><PARAM NAME="ORDER">18</PARAM><PARAM NAME="VALUENAME">printarea106</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">53</PARAM><PARAM NAME="Y">48</PARAM><PARAM NAME="WIDTH">46</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea100"><PARAM NAME="ORDER">23</PARAM><PARAM NAME="VALUENAME">printarea100</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">132</PARAM><PARAM NAME="Y">12</PARAM><PARAM NAME="WIDTH">23</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea103"><PARAM NAME="ORDER">15</PARAM><PARAM NAME="VALUENAME">printarea103</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">126</PARAM><PARAM NAME="Y">30</PARAM><PARAM NAME="WIDTH">38</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea101"><PARAM NAME="ORDER">24</PARAM><PARAM NAME="VALUENAME">printarea101</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">174</PARAM><PARAM NAME="Y">12</PARAM><PARAM NAME="WIDTH">26</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea104"><PARAM NAME="ORDER">16</PARAM><PARAM NAME="VALUENAME">printarea104</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">53</PARAM><PARAM NAME="Y">39</PARAM><PARAM NAME="WIDTH">46</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea13"><PARAM NAME="ORDER">13</PARAM><PARAM NAME="VALUENAME">printarea13</PARAM><PARAM NAME="WIDTH">0</PARAM><PARAM NAME="TYPE">3</PARAM><PARAM NAME="X">0</PARAM><PARAM NAME="Y">20</PARAM><PARAM NAME="X2">236</PARAM><PARAM NAME="Y2">20</PARAM><PARAM NAME="GRAY">10</PARAM><PARAM NAME="SHAPETYPE">0</PARAM></FIELD><FIELD NAME="printarea102"><PARAM NAME="ORDER">14</PARAM><PARAM NAME="VALUENAME">printarea102</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">53</PARAM><PARAM NAME="Y">30</PARAM><PARAM NAME="WIDTH">46</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea11"><PARAM NAME="ORDER">11</PARAM><PARAM NAME="VALUENAME">printarea11</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">时间:</PARAM><PARAM NAME="X">158</PARAM><PARAM NAME="Y">12</PARAM><PARAM NAME="WIDTH">13</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea12"><PARAM NAME="ORDER">12</PARAM><PARAM NAME="VALUENAME">printarea12</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">日期：</PARAM><PARAM NAME="X">116</PARAM><PARAM NAME="Y">12</PARAM><PARAM NAME="WIDTH">14</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea3"><PARAM NAME="ORDER">3</PARAM><PARAM NAME="VALUENAME">printarea3</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">业务类型：</PARAM><PARAM NAME="X">105</PARAM><PARAM NAME="Y">30</PARAM><PARAM NAME="WIDTH">22</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea109"><PARAM NAME="ORDER">21</PARAM><PARAM NAME="VALUENAME">printarea109</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">126</PARAM><PARAM NAME="Y">57</PARAM><PARAM NAME="WIDTH">37</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea2"><PARAM NAME="ORDER">2</PARAM><PARAM NAME="VALUENAME">printarea2</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">交易序号：</PARAM><PARAM NAME="X">31</PARAM><PARAM NAME="Y">30</PARAM><PARAM NAME="WIDTH">21</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea108"><PARAM NAME="ORDER">20</PARAM><PARAM NAME="VALUENAME">printarea108</PARAM><PARAM NAME="TYPE">1</PARAM><PARAM NAME="VALUE"></PARAM><PARAM NAME="X">53</PARAM><PARAM NAME="Y">57</PARAM><PARAM NAME="WIDTH">45</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">1</PARAM></FIELD><FIELD NAME="图1"><PARAM NAME="ORDER">10</PARAM><PARAM NAME="VALUENAME">图1</PARAM><PARAM NAME="TYPE">2</PARAM><PARAM NAME="PATH">D:\\a.jpg</PARAM><PARAM NAME="X">130</PARAM><PARAM NAME="Y">78</PARAM><PARAM NAME="WIDTH">SEALWIDTH</PARAM><PARAM NAME="HEIGHT">SEALHEIGHT</PARAM><PARAM NAME="GETPATH">1</PARAM></FIELD><FIELD NAME="printarea1"><PARAM NAME="ORDER">1</PARAM><PARAM NAME="VALUENAME">printarea1</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">本票业务测试</PARAM><PARAM NAME="X">66</PARAM><PARAM NAME="Y">1</PARAM><PARAM NAME="WIDTH">82</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">20</PARAM><PARAM NAME="HORALLIGN">1</PARAM></FIELD><FIELD NAME="printarea6"><PARAM NAME="ORDER">6</PARAM><PARAM NAME="VALUENAME">printarea6</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">户名：</PARAM><PARAM NAME="X">105</PARAM><PARAM NAME="Y">48</PARAM><PARAM NAME="WIDTH">14</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea5"><PARAM NAME="ORDER">5</PARAM><PARAM NAME="VALUENAME">printarea5</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">票据号：</PARAM><PARAM NAME="X">31</PARAM><PARAM NAME="Y">48</PARAM><PARAM NAME="WIDTH">20</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea4"><PARAM NAME="ORDER">4</PARAM><PARAM NAME="VALUENAME">printarea4</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">帐号：</PARAM><PARAM NAME="X">105</PARAM><PARAM NAME="Y">39</PARAM><PARAM NAME="WIDTH">14</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea9"><PARAM NAME="ORDER">9</PARAM><PARAM NAME="VALUENAME">printarea9</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">金额：</PARAM><PARAM NAME="X">105</PARAM><PARAM NAME="Y">57</PARAM><PARAM NAME="WIDTH">14</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea8"><PARAM NAME="ORDER">8</PARAM><PARAM NAME="VALUENAME">printarea8</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">币种：</PARAM><PARAM NAME="X">31</PARAM><PARAM NAME="Y">57</PARAM><PARAM NAME="WIDTH">19</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD><FIELD NAME="printarea99"><PARAM NAME="ORDER">100</PARAM><PARAM NAME="VALUENAME">printarea99</PARAM><PARAM NAME="TYPE">0</PARAM><PARAM NAME="VALUE">卡号：</PARAM><PARAM NAME="X">31</PARAM><PARAM NAME="Y">39</PARAM><PARAM NAME="WIDTH">19</PARAM><PARAM NAME="FONTNAME">宋体</PARAM><PARAM NAME="FONTSTYLE">5</PARAM><PARAM NAME="FONTSIZE">10</PARAM><PARAM NAME="HORALLIGN">0</PARAM></FIELD></CONFIG></CONFIGS>';

/**
 * 初始化
 */
$(document).ready(function() {
    var path = ctx + "/activex/api/";
    if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, path, "run")){
    	alert("通用控件初始化失败");
    }
    if (!ocxObject.initOcx(ocxObject.OCX_SealGenerator, document.body, path, "run")){
    	alert("印章生成控件初始化失败");
    }
    if (!ocxObject.initOcx(ocxObject.OCX_Print, document.body, path, "run")){
    	alert("模板打印控件初始化失败");
    }
    // 新建表单提交数据验证
    $("#form").validationEngine({
	showOnMouseOver : true,
	validationEventTrigger : "keyup blur",
	promptPosition : "centerRight",
	autoPositionUpdate : true,
	onValidationComplete : function() {
	}
    });

    $("#printBtn").click(function(event) {
	event.preventDefault();
	if ((inputParam & 6 != 0) && $("#accNo").val() == "" && $("#cardNo").val() == "") {
	    show("账号与卡号不能都为空");
	    $("#printBtn").val("");
	    return;
	}
	if (!$("#form").validationEngine("validate") || !flagTradeCode) {
	    $("#printBtn").val("");
	    return;
	}
	if (!flagTradeCode) {
	    $("#printBtn").val("");
	    return;
	}
	$("#printBtn").attr("disable", true);
	printElecSeal();
    });

    $("#resetBtn").click(function(event) {
	event.preventDefault();
	reset();
    });

    $("#tradeCode").blur(function() {
	var tradeCode = $("#tradeCode").val();
	var reg = /^[1-9](\d{3})$/;
	if (reg.test(tradeCode)) {
	    $(this).unbind('blur');
	    $(this).focus(function() {
		$(this).blur();
	    });
	    queryTradeCode();
	}

    });

    // 初始化表单
    initPrintElecSealForm();
});

/**
 * 初始化表单
 */
function initPrintElecSealForm() {
    var url = ctx + "/elecseal/inteSealUseAction_initPrintElecSealForm.action";
    var data = tool.ajaxRequest(url, '');
    if (data.success) {
	if (data.response.webResponseJson.state == "normal") {
	    $("#districtCode").val("000");
	    $("#orgNo").val(data.response.webResponseJson.data.orgNo);
	    $("#peopleCode").val(data.response.webResponseJson.data.peopleCode);
	} else {
	    show("服务器响应失败");
	}
    } else {
	show("服务器响应失败：" + data.response);
    }
};

/**
 * 交易代码查询业务信息
 */
function queryTradeCode() {
    var url = ctx + "/elecseal/printElecSealAction_queryByTradeCode.action";
    var formData = $('#form').serialize();
    var data = tool.ajaxRequest(url, formData);
    if (data.success) {
	if (data.response.webResponseJson.state == "normal") {
	    // 临时代码，后续会合并，不存在单独判断
	    if (data.response.webResponseJson.data.useType != "1") {
		show("此交易非一体化用印业务，请使用印章用印");
		return;
	    }
	    flagTradeCode = true;
	    $("#bizType").val(data.response.webResponseJson.data.bizType);
	    $("#sealType").val(sealTypeList[data.response.webResponseJson.data.sealType]);
	    $("#sealCount").val(data.response.webResponseJson.data.printTime);
	    inputParam = data.response.webResponseJson.data.inputParam;
	    showInputParam(inputParam);
	    if (data.response.webResponseJson.data.sealType == "0") {
		sealType = 0;
	    } else {
		sealType = 1;
	    }
	} else {
	    $("#bizType").val("");
	    $("#sealType").val("");
	    $("#sealCount").val("");
	    show(data.response.webResponseJson.data);
	    flagTradeCode = false;
	}
    } else {
	show("服务器响应失败：" + data.response);
    }
};

/**
 * 一体化申请用印
 */
function printElecSeal() {

    if (sealType == 0) {
	// 电子印章
	var data = $('#form').serializeArray();
	// 金额单位采用单位为“分”来存储
	$.each(data, function(i, field) {
	    if (field.name == "sealUseBizInfo.money") {
		data[i].value = multiply(field.value, 100);
	    }
	});
	var url = ctx + "/elecseal/inteSealUseAction_printElecSeal.action";
	data = tool.ajaxRequest(url, data);
	if (data.success) {
	    // 按钮恢复可用
	    // dijit.byId("printBtn").cancel();
	    $("#printBtn").attr("disable", false);
	    if (data.response.webResponseJson.state == "normal") {
		// 打印
		var elecInfo = data.response.webResponseJson.data;
		genSealPic(elecInfo.json);
		id = elecInfo.id;
		url = "/elecseal/printElecSealAction_updateSealSuccess.action";
		for ( var i = 0; i < elecInfo.printTime; i++) {
		    OCX_Print._startPrint(elecInfo.templateString, elecInfo.templateData, printFail, printSuccess);
		}
		setTimeout(function() {
		    show("用印成功");
		}, 5000);
	    } else {
		show(data.response.webResponseJson.data);
	    }
	} else {
	    $("#printBtn").attr("disable", false);
	    show("用印失败：" + data.response);
	}
    } else {
	// 机控印章
	show("机控印章无一体化打印");
	return;

	var data = $('#form').serialize();
	// 金额单位采用单位为“分”来存储
	if (data["sealUseBizInfo.money"] != undefined) {
	    data["sealUseBizInfo.money"] = multiply(data["sealUseBizInfo.money"], 100);
	}
	var url = ctx + "/elecseal/inteSealUseAction_printCode.action";
	data = tool.ajaxRequest(url, data);
	if (data.success) {
	    // 按钮恢复可用
	    // dijit.byId("printBtn").cancel();
	    $("#printBtn").attr("disable", false);
	    if (data.response.webResponseJson.state == "normal") {
		// 打印
		var elecInfo = data.response.webResponseJson.data;
		genSealPic(elecInfo.json);
		OCX_ElecSealPrint.startPrintPic("D:\\a.jpg", elecInfo.xPosition, elecInfo.yPosition, elecInfo.width,
			elecInfo.height);
		printSuccess(elecInfo.id, "/elecseal/printElecSealAction_updateCodeSuccess.action");
	    } else {
		show(data.response.webResponseJson.data);
	    }
	} else {
	    show("服务器响应失败：" + data.response);
	}
    }
};
/**
 * 生成印章图片
 */
function genSealPic(json) {
    // var prop =
    // '{"seal":{"round":[{"main":1,"rect":"100,100,350,250","borderwidth":6}],"text":[{"content":"外部设置字体","familyname":"楷体","fontsize":25,"offset":0,"angle":225,"rect":"100,100,350,250"}],"image":[{"path":"C:\\3.png","rect":"200,170,250,220","angle":0}]}}';
    OCX_SealGenerator.setSealProperty(json);
    OCX_SealGenerator.saveSealImage("D:\\a.jpg");
};

/**
 * 用印成功
 */
function printSuccess() {

    var url = ctx + "/elecseal/printElecSealAction_initPrintElecSealForm.action?id=" + id;
    var data = tool.ajaxRequest(url, '');
    if (data.success) {
	if (data.response.webResponseJson.state == "normal") {
	    reset();
	} else {
	    showMessage(response.webResponseJson.data);
	}
    } else {
	showMessage("更新用印状态服务器响应失败：" + data.response);
    }
};

/**
 * 用印失败
 */
function printFail() {
    show("用印失败");
};

/**
 * 显示可输入项
 * 
 * @param inputParam
 */
function showInputParam(param) {
    var trNode;

    for ( var i = 0; i < inputParamList.length; i++) {
	// 创建两个td
	if ((param & Math.pow(2, i)) != 0) {
	    if (tdNum % 3 == 0) {
		trNode = $('<tr id="tr' + parseInt(tdNum / 3) + '" class="form_row_height_40"></tr>');
		$("#table").append(trNode);
	    }
	    tdNum++;
	    // label
	    var tdNod = $('<td class="form_label_100">' + inputParamNameList[i] + "</td>");
	    $(trNode).append(tdNod);
	    tdNode = $('<td></td>');
	    divNode = $('<div class="form_textfiled_160"></div>');

	    $(tdNode).append(divNode);
	    $(trNode).append(tdNode);
	    var box = createByNum(i);
	    divNode.prepend(box);
	}
    }
};

function createByNum(num) {
    switch (num) {
    case 0:

	//
	var node = $('<input id="' + inputParamList[num] + '" name="sealUseBizInfo.' + inputParamList[num]
		+ '" class="validate[required,custom[onlyNumber], form_textfiled_160" maxlength="5"></input>');
	return node;
    case 1:

	//
	var node = $('<input id="' + inputParamList[num] + '" name="sealUseBizInfo.' + inputParamList[num]
		+ '" class="validate[required,custom[onlyNumber], form_textfiled_160" maxlength="16"></input>');
	return node;
    case 2:
	var node = $('<input id="' + inputParamList[num] + '" name="sealUseBizInfo.' + inputParamList[num]
		+ '" class="validate[required,custom[onlyNumber], form_textfiled_160" maxlength="16"></input>');
	return node;
    case 3:
	var node = $('<input id="' + inputParamList[num] + '" name="sealUseBizInfo.' + inputParamList[num]
		+ '" class="validate[required,custom[onlyNumber], form_textfiled_160" maxlength="5"></input>');
	return node;
    case 4:
	var node = $('<input id="' + inputParamList[num] + '" name="sealUseBizInfo.' + inputParamList[num]
		+ '" class="form_textfiled_160" maxlength="64"></input>');
	return node;
    case 5:
	var node = $('<select id="' + inputParamList[num] + '" name="sealUseBizInfo.' + inputParamList[num]
		+ '" class="form_textfiled_160" maxlength=16>'
		+ '<option value="0">人民币</option><option value="1">美元</option>'
		+ '<option value="2">日元</option><option value="3">英镑</option>' + '</select>');
	return node;
    case 6:
	var node = $('<input id="' + inputParamList[num] + '" name="sealUseBizInfo.' + inputParamList[num]
		+ '" class="validate[required,onlyNumber,length[1,12]] form_textfiled_160" maxlength="12"></input>');
	return node;
    }
};

/**
 * 删除生成的tr
 */
function destroyTr() {
    if (tdNum == 0) {
	return;
    }

    for ( var i = 0; i < inputParamList.length; i++) {
	if ((inputParam & Math.pow(2, i)) != 0) {
	    $("#" + inputParamList[i]).remove();
	}
    }

    for ( var i = 0; i <= parseInt((tdNum - 1) / 3); i++) {

	$("#tr" + i).remove();
    }
};

/**
 * 重置
 */
function reset() {
    $("#form")[0].reset();
    destroyTr();
    tdNum = 0;
    flagTradeCode = false;
    inputParam = 0;
    $("#tradeCode").unbind('focus');
    $("#tradeCode").blur(function() {
	var tradeCode = $("#tradeCode").val();
	var reg = /^[1-9](\d{3})$/;
	if (reg.test(tradeCode)) {
	    $(this).unbind('blur');
	    $(this).focus(function() {
		$(this).blur();
	    });
	    queryTradeCode();
	}

    });
};