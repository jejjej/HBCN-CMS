﻿﻿var sealType;
var tdNum = 0;
var inputParam;

/**
 * 用印输入项参数
 */
var inputParamList = [ "tradeNo", "cardNo", "accNo", "billNo", "accName", "currency", "money" ];

/**
 * 用印输入项名称参数
 */
var inputParamNameList = [ "交易序号：", "卡号：", "账号：", "票据号：", "账户名称：", "币种：", "金额：" ];

/**
 * 初始化
 */
$(document).ready(function() {
    var path = ctx + "/activex/api/";
    if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, path, "run")){
    	alert("通用控件初始化失败");
    }
    if (!ocxObject.initOcx(ocxObject.OCX_ElecSealPrint, document.body, path, "run")){
    	alert("电子印章打印控件初始化失败");
    }
    if (!ocxObject.initOcx(ocxObject.OCX_SealGenerator, document.body, path, "run")){
    	alert("印章生成控件初始化失败");
    }
    // 新建表单提交数据验证
    $("#form").validationEngine({
	showOnMouseOver : true,
	validationEventTrigger : "keyup blur",
	promptPosition : "centerRight",
	autoPositionUpdate : true,
	onValidationComplete : function() {
	}
    });

    $("#printBtn").click(function(event) {
	event.preventDefault();
	if ((inputParam & 6 != 0) && $("#accNo").val() == '' && $("#cardNo").val() == '') {
	    showMessage("账号与卡号不能都为空");
	    // 回复button可操作
	    $("#printBtn").attr("disable", false);
	    return;
	}
	if (!$("#form").validationEngine("validate") || !flagTradeCode) {
	    $("#printBtn").attr("disable", false);
	    return;
	}
	$("#printBtn").attr("disable", true);
	printElecSeal();
    });

    $("#resetBtn").click(function(event) {
	event.preventDefault();
	reset();
    });

    /*
     * $("#tradeCode").bind('onKeyPress', function(event) { if (event.keyCode ==
     * 13){ event.preventDefault(); } if (event.keyCode == 13 &&
     * dijit.byId("tradeCode").validate()){ queryTradeCode(); } });
     */

    $("#tradeCode").bind('blur', function() {
	var tradeCode = $("#tradeCode").val();
	var reg = /^[1-9](\d{3})$/;
	if (reg.test(tradeCode)) {
	    $(this).unbind('blur');
	    $(this).focus(function() {
		$(this).blur();
	    });
	    queryTradeCode();
	}
    });

    initPrintElecSealForm();
});

/**
 * 初始化表单
 */
function initPrintElecSealForm() {

    var url = ctx + "/elecseal/printElecSealAction_initPrintElecSealForm.action";
    var data = tool.ajaxRequest(url, '');
    if (data.success) {
	if (data.response.webResponseJson.state == "normal") {
	    $("#districtCode").val("000");
	    $("#orgNo").val(data.response.webResponseJson.data.orgNo);
	    $("#peopleCode").val(data.response.webResponseJson.data.peopleCode);
	} else {
	    showMessage("服务器响应失败");
	}
    } else {
	showMessage("服务器响应失败：" + data.response);
    }
};

/**
 * 交易代码查询业务信息
 */
function queryTradeCode() {

    var formData = $('#form').serialize();
    var url = ctx + "/elecseal/printElecSealAction_queryByTradeCode.action";
    var data = tool.ajaxRequest(url, formData);
    if (data.success) {
	if (data.response.webResponseJson.state == "normal") {
	    flagTradeCode = true;
	    $("#bizType").val(data.response.webResponseJson.data.bizType);
	    $("#sealType").val(sealTypeList[data.response.webResponseJson.data.sealType]);
	    $("#sealCount").val(data.response.webResponseJson.data.printTime);
	    inputParam = data.response.webResponseJson.data.inputParam;
	    showInputParam(inputParam);
	    if (data.response.webResponseJson.data.sealType == "0") {
		sealType = 0;
	    } else {
		sealType = 1;
	    }
	} else {
	    $("#bizType").val("");
	    $("#sealType").val("");
	    $("#sealCount").val("");
	    showMessage(data.response.webResponseJson.data);
	    flagTradeCode = false;
	}
    } else {
	showMessage("服务器响应失败：" + data.response);
    }
};

// 申请用印
function printElecSeal() {

    var formData = $("#form").serializeArray();
    $.each(formData, function(i, field) {
	if (field.name == "sealUseBizInfo.money") {
	    formData[i].value = multiply(field.value, 100);
	}
    });
    var url = ctx + "/elecseal/printElecSealAction_printElecSeal.action";
    var data = tool.ajaxRequest(url, formData);

    if (sealType == 0) {
	// 电子印章用印

	if (data.success) {

	    $("#printBtn").attr("disable", false);
	    if (data.response.webResponseJson.state == "normal") {
		// 打印
		var elecInfo = data.response.webResponseJson.data;
		genSealPic(elecInfo.json);
		for ( var i = 0; i < elecInfo.printTime; i++) {
		    OCX_ElecSealPrint.startPrintPic("D:\\a.jpg", elecInfo.xPosition, elecInfo.yPosition, elecInfo.width,
			    elecInfo.height);
		    printSuccess(elecInfo.id, "/elecseal/printElecSealAction_updateSealSuccess.action");
		}
		setTimeout(function() {
		    showMessage("用印成功");
		}, 4000);
	    } else {
		showMessage(data.response.webResponseJson.data);
	    }
	} else {
	    showMessage("服务器响应失败：" + data.response);
	}
    } else {
	show("只支持电子印章用印!");
	return;

	// 机控印章用印, 只打印验证码
	if (data.success) {
	    $("#printBtn").attr("disable", false);
	    if (data.response.webResponseJson.state == "normal") {
		// 打印
		var elecInfo = data.response.webResponseJson.data;
		for ( var i = 0; i < elecInfo.printTime; i++) {
		    OCX_ElecSealPrint.startPrintStr(elecInfo.verificationCode, elecInfo.xPosition, elecInfo.yPosition,
			    elecInfo.width, elecInfo.height);
		    printSuccess(elecInfo.id, "/elecseal/printElecSealAction_updateCodeSuccess.action");
		}
		setTimeout(function() {
		    showMessage("用印成功");
		}, 4000);
	    } else {
		showMessage(data.response.webResponseJson.data);
	    }
	} else {
	    showMessage("服务器响应失败：" + data.response);
	}
    }
};

/**
 * 生成印章图片
 */
function genSealPic(json) {
    OCX_SealGenerator.setSealProperty(json);
    OCX_SealGenerator.saveSealImage("D:\\a.jpg");
};

/**
 * 用印成功
 */
function printSuccess(id, url) {

    var url = ctx + url;
    var data = tool.ajaxRequest(url, {
	'id' : id
    });
    if (data.success) {
	if (data.response.webResponseJson.state == "normal") {
	    // showMessage(response.webResponseJson.data);
	    reset()
	} else {
	    showMessage(data.response.webResponseJson.data);
	}
    } else {
	showMessage("更新用印状态服务器响应失败：" + data.response);
    }
};

/**
 * 用印失败
 */
function printFail() {
    showMessage("用印失败");
};

/**
 * 显示可输入项
 * 
 * @param inputParam
 */
function showInputParam(param) {

    //
    var trNode;
    for ( var i = 0; i < inputParamList.length; i++) {
	// 创建两个td
	if ((param & Math.pow(2, i)) != 0) {
	    if (tdNum % 3 == 0) {
		trNode = $('<tr id="tr' + parseInt(tdNum / 3) + '" class="form_row_height_40"></tr>');
		$("#table").append(trNode);
	    }
	    tdNum++;
	    // label

	    var tdNod = $('<td class="form_label_100">' + inputParamNameList[i] + "</td>");
	    $(trNode).append(tdNod);
	    tdNode = $('<td></td>');
	    divNode = $('<div class="form_textfiled_160"></div>');

	    $(tdNode).append(divNode);
	    $(trNode).append(tdNode);
	    var box = createByNum(i);
	    divNode.prepend(box);
	}
    }
    $("#form").validationEngine({
	showOnMouseOver : true,
	validationEventTrigger : "keyup blur",
	promptPosition : "centerRight",
	autoPositionUpdate : true,
	onValidationComplete : function() {
	}
    });

};
// 对于验证文本框暂时统一使用input替代
function createByNum(num) {
    switch (num) {
    case 0:
	//
	var node = $('<input id="' + inputParamList[num] + '" name="sealUseBizInfo.' + inputParamList[num]
		+ '" class="validate[required,custom[fiveNumber]] form_textfiled_160" maxlength="5"></input>');
	return node;
    case 1:
	var node = $('<input id="' + inputParamList[num] + '" name="sealUseBizInfo.' + inputParamList[num]
		+ '" class="validate[required,custom[sixteenNumber]] form_textfiled_160" maxlength="16"></input>');
	return node;
    case 2:
	var node = $('<input id="' + inputParamList[num] + '" name="sealUseBizInfo.' + inputParamList[num]
		+ '" class="validate[required,custom[sixteenNumber]] form_textfiled_160" maxlength="16"></input>');
	return node;
    case 3:
	var node = $('<input id="' + inputParamList[num] + '" name="sealUseBizInfo.' + inputParamList[num]
		+ '" class="validate[required,custom[fiveNumber]] form_textfiled_160" maxlength="5"></input>');
	return node;
    case 4:
	var node = $('<input id="' + inputParamList[num] + '" name="sealUseBizInfo.' + inputParamList[num]
		+ '" class="form_textfiled_160" maxlength="64"></input>');
	return node;
    case 5:
	var node = $('<select id="' + inputParamList[num] + '" name="sealUseBizInfo.' + inputParamList[num]
		+ '" class="form_textfiled_160" maxlength=16>'
		+ '<option value="0">人民币</option><option value="1">美元</option>'
		+ '<option value="2">日元</option><option value="3">英镑</option>' + '</select>');
	return node;
    case 6:
	var node = $('<input id="' + inputParamList[num] + '" name="sealUseBizInfo.' + inputParamList[num]
		+ '" class="validate[required,onlyNumber,length[1,12]] form_textfiled_160" maxlength="12"></input>');
	return node;
    }
};

/**
 * 删除生成的tr
 */
function destroyTr() {
    if (tdNum == 0) {
	return;
    }

    for ( var i = 0; i < inputParamList.length; i++) {
	if ((inputParam & Math.pow(2, i)) != 0) {
	    $("#" + inputParamList[i]).remove();
	}
    }

    for ( var i = 0; i <= parseInt((tdNum - 1) / 3); i++) {
	$("#tr" + i).remove();
    }
};

/**
 * 重置
 */
function reset() {
    $("#form")[0].reset();
    destroyTr();
    tdNum = 0;
    flagTradeCode = false;
    inputParam = 0;
    $("#tradeCode").unbind('focus');
    $("#tradeCode").bind('blur', function() {
	var tradeCode = $("#tradeCode").val();
	var reg = /^[1-9](\d{3})$/;
	if (reg.test(tradeCode)) {
	    $(this).unbind('blur');
	    $(this).focus(function() {
		$(this).blur();
	    });
	    queryTradeCode();
	}
    });

};

function showMessage(msg) {
    alert(msg);
};
