/**
 * 创建于:2014-9-3<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 电子印章申请查询JS<br>
 * 
 * @author 叶慧雄
 * @author guoshixuan
 * @version 1.0.0
 */

/**
 * 全量可变印章参数tr标签ID<br>
 * 一个tr标签只包含一个可变参数
 */
var all_editable_prop_id = ["sealTextArea","sealCodeArea","sealRiderArea"];


$(document).ready(function() {
	$("#queryBtn").click(function (event) {
		
		event.preventDefault();
		initGrid();
	});

	// 初始化拒绝界面 
	initapprovalRefuseDialog();
	
	// 初始化印章种类下拉框
	selectUtils.initSealBizType("sealUse", 0);
	
	// 初始化表格数据
	initGrid();
	
	//初始化电子印章生成控件
	if(!ocxObject.initOcx(ocxObject.OCX_SealGenerator, document.getElementById("generateElecSeal"),
			ctx + "/activex/api/", 'run', 300, 300)){
		alert("初始化电子印章生成控件失败");
	}
});

function initapprovalRefuseDialog(){
	$("#approvalRefuseDialog").dialog({
		autoOpen : false,
		resizable : false,
		draggable: false,
		closeOnEscape : false,
		height : $(window).height()/2 + 30,
		width : $(window).width()/2+70,
		modal : true,
		open : function(event,ui){
			$(".ui-dialog-titlebar").hide();
			$(".ui-dialog-titlebar-close").hide();
		}
	});
}

/**
 * 初始化分页界面
 */
function initGrid() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	$("#approvalElecSealList").jqGrid(
		{
			width : pageContentWidth,
			height : tableHeight + "px",
			url : ctx + "/elecseal/approvalElecSealAction_queryElecSeal.action",
			multiselect : false,
			rowNum : 20,
			rownumbers:true,
			rowList : [ 20, 50 ],
			colNames : [ "申请流水号", "申请日期", "申请时间",
			          "申请机构号","申请机构名称", "印章种类","申请状态","详情"],
			colModel : [
					{
						name : "autoId",
						index : "autoId",
						width : 150,
						align : "center",
						sortable : false
					}, {
						name : "applyDate",
						index : "applyDate",
						width : 65,
						align : "center",
						sortable : false
					}, {
						name : "applyTime",
						index : "applyTime",
						width : 65,
						align : "center",
						sortable : false
					}, {
						name : "orgNo",
						index : "orgNo",
						width : 65,
						align : "center",
						sortable : false
					}, {
						name : "orgName",
						index : "orgName",
						width : 70,
						align : "center",
						sortable : false
					}, {
//						name : "sealType",
//						index : "sealType",
//						width : 60,
//						align : "center",
//						sortable : false,
//						formatter : function(value, options, rData) {
//							return sealTypeList[value];
//						}
//					}, {
						name : "sealUse",
						index : "sealUse",
						width : 60,
						align : "center",
						sortable : false,
						formatter : function(value, options, rData) {
							return selectUtils.sealBizTypeCache[value];
						}
					}, {
						name : "sealState",
						index : "sealState",
						width : 55,
						align : "center",
						sortable : false,
						formatter : function(value, options, rData) {
							return elecSealStateList[value];
						}
					}, {
						name : "autoId",
						index : "autoId",
						width : 70,
						align : "center",
						sortable : false,
						formatter : function(value, options, rData) {
							return "<a href='#' onClick='queryElecSealDetail(\""+value+"\");'>详情</a>";
						}
					} 
					],
			pager : "#approvalElecSealPager",
			caption : "电子印章审核"
		}).trigger("reloadGrid");
	$("#approvalElecSealList").navGrid("#approvalElecSealPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

/**
 * 查询电子印章审批列表
 */
function queryApprovalElecSeal() {
	$("#approvalElecSealList").jqGrid('search',"#queryForm"); 
}

/**
 * 查询电子印章建模详情
 */
function queryElecSealDetail(autoId) {
	
	var url = ctx + "/elecseal/approvalElecSealAction_queryElecSealDetail.action";
	var data = tool.ajaxRequest(url, {'id':autoId});
	if(data.success){
		if (data.response.webResponseJson.state == "normal") {
			// 显示印章明细
			showElecSealDetail(data.response.webResponseJson.data.detail);

			// 显示印章模板
			initElecSealModelSelect(data.response.webResponseJson.data.model);
		} else {
			alert("服务器响应失败");
		}
	}else{
		alert("服务器响应失败：" + data.response);
	}
}

/**
 * 取消审批
 */
function cancelApproval() {
	unlockApproval();
	hideElecSealDetail();
}

/**
 * 取消锁定
 */
function unlockApproval() {
	var autoId = $("#autoId").val();
	if(autoId == null || autoId == ""){
		return;
	}
	$("#sealUse").attr("disabled",false);
	$("#sealType").attr("disabled",false);
	$("#sealModel").attr("disabled",false);
	var formData = $('#approvalForm').serialize();
	var url = ctx + "/elecseal/approvalElecSealAction_unlockApproval.action";
	var data = tool.ajaxRequest(url, formData);
	if(data.success){
		if (data.response.webResponseJson.state == "normal") {
			// 解锁成功，前台不做任何操作
		} else {
			alert(data.response.webResponseJson.data);
		}
	}else{
		alert("服务器响应失败：" + data.response);
	}
}

/**
 * 填充印模select
 * @param model 印模
 */
function initElecSealModelSelect(model){
	$("#sealModel").empty();
	$("#sealModel").get(0).options.add(new Option(model.modelName,model.id));
}

/**
 * 打开电子印章申请审批页面
 */
function showElecSealDetail(detail) {
	try{
		$("#approvalElecSealDialog").show();
		$("#approvalElecSealDialog").removeClass().addClass("dialog_full_screen");
		
		$("#autoId").val(detail["autoId"]);
		$("#orgNo").val(detail["orgNo"]);
		$("#orgName").val(detail["orgName"]);
		$("#peopleName").val(detail["peopleName"]);
		$("#sealType").val(detail["sealType"]);
		$("#sealType").attr("disabled",true);
		$("#sealUse").val(detail["sealUse"]);
		$("#sealUse").attr("disabled",true);
		$("#applyReason").val(detail["applyReason"]);
		$("#sealModel").val(detail["sealModel"]);
		$("#sealModel").attr("disabled",true);
		$("#memo").val(detail["memo"]);
		
		// 全量显示可变参数
		$("#sealText").val(detail["sealText"]);
		$("#sealCode").val(detail["sealCode"]);
		$("#sealRider").val(detail["sealRider"]);
		
		// 显示印章
		setSealProperty(detail["elecSealJson"]);
	}catch(e){
		alert("显示电子印章建模信息失败");
	}
}

/**
 * 关闭电子印章申请审批页面
 */
function hideElecSealDetail(){
	$("#approvalForm")[0].reset();
	$("#autoId").val("");
	$("#approvalElecSealDialog").css('display' , "none");
}

/**
 * 审核通过
 */
function approvalPass() {
	var memo = $("#memo").val();
	if(memo != undefined && memo != "" && memo.length > 100){
		$("#memo").focus();
		alert("备注信息最多只能输入100个字符");
		return;
	}
	$("#sealUse").attr("disabled",false);
	$("#sealType").attr("disabled",false);
	$("#sealModel").attr("disabled",false);
	var formData = $('#approvalForm').serialize();
	var url = ctx + "/elecseal/approvalElecSealAction_approvalPass.action";
	var data = tool.ajaxRequest(url, formData);
	if(data.success){
		if (data.response.webResponseJson.state == "normal") {
			hideElecSealDetail();
			queryApprovalElecSeal();
		} else {
			alert(data.response.webResponseJson.data);
		}
	}else{
		alert("服务器响应失败：" + data.response);
	}
}
/**
 * 打开拒绝原因页面
 */
function openRefuseReasonForm() {

	$("#generateElecSeal").hide();
	$("#approvalRefuseDialog").dialog("open");
	$("#approvalRefuseDialog").css("title", "请选择拒绝理由");
	
	$("#refuseAutoId").val($("#autoId").val());
	$("#refuseMemo").val($("#memo").val());
}

/**
 * 关闭拒绝原因页面
 */
function hideRefuseReasonForm() {
	$("#approvalRefuseDialog").dialog("close");
	$("#generateElecSeal").show();
}

/**
 * 审核拒绝
 */
function approvalRefuse() {
	var hasInputReason = false;
	var bizInfo = $('#approvalRefuseForm').serializeArray();
	$.each(bizInfo, function(i, field){
		if(field.name == "electronicSeal.refuseReason" 
			&& field.value != undefined && field.value != null && field.value != ""){
			hasInputReason = true;
		}
	});
	if(!hasInputReason){
		alert("请选择拒绝原因");
		return;
	}
	var othersReason = $("#othersReason").val();
	if(othersReason != undefined && othersReason != null && othersReason != "" && othersReason.length > 100){
		$("#othersReason").focus();
		alert("其他理由最多只能输入100个字符");
		return;
	}
	
	var refuseForm = $('#approvalRefuseForm').serialize();
	var url = ctx + "/elecseal/approvalElecSealAction_approvalRefuse.action";
	var data = tool.ajaxRequest(url, refuseForm);
	if(data.success){
		if (data.response.webResponseJson.state == "normal") {
			hideRefuseReasonForm();
			hideElecSealDetail();
			queryApprovalElecSeal();
		} else {
			alert(data.response.webResponseJson.data);
		}
	}else{
		alert("服务器响应失败：" + data.response);
	}
}

/**
 * 拒绝原因checkBox onchange事件
 * @param reasonId
 * @deprecated 拒绝原因不互斥
 */
function applyReasonOnChange(reasonId){
	var checked = $("#"+reasonId).attr("checked");
	if(checked){
		$("#others").attr("checked", false);
	}
}

/**
 * 其他原因checkBox onchange事件
 * @deprecated 拒绝原因不互斥
 */
function othersOnChange() {
	var checked = $("#others").attr("checked");
	if(checked){
		$("#applyReason1").attr("checked", false);
		$("#applyReason2").attr("checked", false);
		$("#applyReason3").attr("checked", false);
		$("#othersReason").attr("disabled", false);
	}else{
		$("#othersReason").attr("disabled", true);
		$("#othersReason").val("");
	}
}

/**
 * 其他原因鼠标移过事件
 */
function othersReasonOnMouseOver() {
	$("#others").attr("checked", true);
}

/**
 * 对全部可变参数设置为display:none
 * @deprecated 窗口不够大的时候，动态显示可变属性和控件rowspan不兼容，导致浏览器崩溃，
 * 			   现静态显示全部可变属性
 */
function unDisplayAllEditableProp(){
	for(var i=0;i<all_editable_prop_id.length;i++){
		$("#"+all_editable_prop_id[i]).css("display","none");
	}
}

/**
 * 改变模板显示相应印章参数输入框
 * @param needShowPropJson 可变参数的json字符串
 * @deprecated 窗口不够大的时候，动态显示可变属性和控件rowspan不兼容，导致浏览器崩溃，
 * 			   现静态显示全部可变属性
 */
function initAndShowProp(needShowPropJson) {
	var editableProp = (new Function("return " + needShowPropJson))();
	for(var key in editableProp){
		$("#"+key+"Area").style.display = "";
		$("#"+key).value = editableProp[key];
	}
}