﻿/**
 * 
 * 创建于:2014-9-11<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 电子印章信息查询
 * 
 * @author 叶慧雄
 * @author guoshxiuan
 * @version 1.0
 */
var grid;
var flag;

/**
 * 初始化数据
 */
$(document).ready(function() {
    // 初始化印章种类下拉框
    selectUtils.initSealBizType("sealUse", 0);

    queryCurrentPeopleData();
    initGrid();

    initElecSealDetailDialg();
});

/**
 * 初始化分页界面,查询数据
 */
function initGrid() {
    var pageHeaderHeight = $(".pageHeader").css("height");
    var pageContentWidth = $(".pageContent").width() - 2;
    pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
    var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
    $("#elecSealList").jqGrid({
	width : pageContentWidth,
	height : tableHeight + "px",
	url : ctx + "/elecseal/listElecSealAction_queryElecSeal.action",
	multiselect : false,
	rowNum : 10,
	rownumbers : true,
	rowList : [ 10 ],
	colNames : [ "印章编号", "印章类型", "印章种类", "印章编码", "印章正文", "申请人", "申请机构号", "申请机构名称", "详情" ],
	colModel : [ {
	    name : "sealId",
	    index : "sealId",
	    width : 230,
	    align : "center",
	    sortable : false
	}, {
	    name : "sealType",
	    index : "sealType",
	    width : 76,
	    align : "center",
	    sortable : false,
	    formatter : function(value, options, rData) {
		return sealTypeList[value];
	    }
	}, {
	    name : "sealUse",
	    index : "sealUse",
	    width : 76,
	    align : "center",
	    sortable : false,
	    formatter : function(value, options, rData) {
		return selectUtils.sealBizTypeCache[value];
	    }
	}, {
	    name : "sealCode",
	    index : "sealCode",
	    width : 76,
	    align : "center",
	    sortable : false
	}, {
	    name : "sealText",
	    index : "sealText",
	    width : 150,
	    align : "center",
	    sortable : false
	}, {
	    name : "peopleName",
	    index : "peopleName",
	    width : 76,
	    align : "center",
	    sortable : false
	}, {
	    name : "orgNo",
	    index : "orgNo",
	    width : 76,
	    align : "center",
	    sortable : false
	}, {
	    name : "orgName",
	    index : "orgName",
	    width : 86,
	    align : "center",
	    sortable : false
	}, {
	    name : "autoId",
	    index : "autoId",
	    width : 76,
	    align : "center",
	    sortable : false,
	    formatter : function(value, options, rData) {
		return "<a href='#' onClick='queryElecSealDetail(\"" + value + "\");'>详情</a>";
	    }
	} ],
	pager : "#elecSealPager",
	caption : "电子印章信息查询"
    }).trigger("reloadGrid");
    $("#elecSealList").navGrid("#elecSealPager", {
	edit : false,
	add : false,
	del : false,
	search : false,
	refresh : true
    });
};

/**
 * 重置查询条件
 */
function resetMethod() {
    var orgNo = $("#orgNo").val();
    $("#queryForm")[0].reset();
    $("#orgNo").val(orgNo);
    queryListElecSeal();
};

function queryCurrentPeopleData() {

    var url = ctx + "/elecseal/listElecSealAction_queryCurrentPeopledata.action";
    var data = tool.ajaxRequest(url, '');
    if (data.success) {
	if (data.response.state == "normal") {
	    $("#orgNo").val(data.response.data.orgNo);
	} else {
	    show("服务器响应失败");
	}
    } else {
	show("服务器响应失败：" + data.response);
    }
};

/**
 * 查询数据，执行查询
 */
function queryListElecSeal() {

    $("#elecSealList").jqGrid('search', "#queryForm");
};

/**
 * 初始化详情对话框
 */
function initElecSealDetailDialg() {
    $("#elecSealDetailDialog").dialog({
	autoOpen : false,
	resizable : false,
	// height : $(window).height(), 不起作用
	width : $(window).width() * 2 / 3 + 50,
	modal : true
    });
};

/**
 * 查询单个印章的详细信息，执行查询
 */
function queryElecSealDetail(id) {

    var url = ctx + "/elecseal/listElecSealAction_queryElecSealDetail.action";
    var data = tool.ajaxRequest(url, {
	'id' : id
    });
    if (data.success) {
	if (data.response.webResponseJson.state == "normal") {
	    showElecSealDetail(data.response.webResponseJson.data);
	} else {
	    show("服务器响应失败");
	}
    } else {
	show("服务器响应失败：" + data.response);
    }
    $("#elecSealDetailDialog").dialog("open");
};

function hideDetailForm() {
    $("#elecSealDetailDialog").dialog("close");
    clearElecSealDetail();
};

/**
 * 打开电子印章详情页面
 */
function showElecSealDetail(detail) {
    try {
	$("#orgName").val(detail["orgName"]);
	$("#applyDate").val(detail["applyDate"]);
	$("#sealType").val(detail["sealType"]);
	$("#sealUseText").val(selectUtils.sealBizTypeCache[detail["sealUse"]]);
	$("#sealText").val(detail["sealText"]);
	$("#sealCodeText").val(detail["sealCode"]);
	$("#autoIdText").val(detail["autoId"]);
	$("#peopleName").val(detail["peopleName"]);
	$("#finishDate").val(detail["finishDate"]);
	$("#finishPeopleCode").val(detail["finishPeopleCode"]);
	$("#finishOrgNo").val(detail["finishOrgNo"]);
	$("#sealState").val(elecSealStateList[detail["sealState"]]);
	$("#startDate").val(detail["startDate"]);
	$("#stopDate").val(detail["stopDate"]);
	$("#destoryDate").val(detail["destoryDate"]);
	$("#applyReason").val(detail["applyReason"]);
	$("#refuseReason").val(detail["refuseReason"]);
	$("#memo").val(detail["memo"]);
	// 显示印章
	// setSealProperty(detail["elecSealJson"]);
    } catch (e) {
	show("显示电子印章建模信息失败");
    }
};

/**
 * 清空电子印章详情页面
 */
function clearElecSealDetail() {
    try {
	$("#orgName").val("");
	$("#applyDate").val("");
	$("#sealType").val("");
	$("#sealUse").val("");
	$("#sealText").val("");
	$("#sealCodeText").val("");
	$("#autoIdText").val("");
	$("#peopleName").val("");
	$("#finishDate").val("");
	$("#finishPeopleCode").val("");
	$("#finishOrgNo").val("");
	$("#sealState").val("");
	$("#startDate").val("");
	$("#stopDate").val("");
	$("#destoryDate").val("");
	$("#applyReason").val("");
	$("#refuseReason").val("");
	$("#memo").val("");
	// 显示印章
	// setSealProperty(detail["elecSealJson"]);
    } catch (e) {
	show("显示电子印章建模信息失败");
    }
};