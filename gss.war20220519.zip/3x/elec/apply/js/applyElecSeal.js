/**
 * 创建于:2014-9-3<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 电子印章申请JS<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

/**
 * 电子印章模板缓存数据
 */
var all_elec_seal_model = "";

/**
 * 电子印章模板全量属性全局变量
 */
var elec_seal_model_all_prop = "";

/**
 * 电子印章模板可变属性全局变量
 */
var editable_prop = "";

/**
 * 全量可变印章参数tr标签ID<br>
 * 一个tr标签只包含一个可变参数
 */
var all_editable_prop_id = ["sealTextArea", "sealCodeArea", "sealRiderArea"];
var all_editable_prop_input_id = ["sealText", "sealCode", "sealRider"];

/**
 * 初始化
 */
$().ready(
		function() {
			// 初始化电子印章生成控件
			if (!ocxObject.initOcx(ocxObject.OCX_SealGenerator, document.getElementById("generateElecSeal"), ctx + "/activex/api/", 'run', 300, 300)) {
				alert("初始化电子印章生成控件失败");
			}

			initElecSealForm();
			initElecSealModelOption();

			// 绑定按钮事件
			$('#sealModel').change(function() {
				findElecSealModel();
			});
			$('#sealText').change(function() {
				changeSealContent();
			});
			$('#sealCode').change(function() {
				changeSealContent();
			});
			$('#sealRiderArea').change(function() {
				changeSealContent();
			});

			selectUtils.initSealBizType("sealUse", 0);

			formValidation.init("electronicSeal", "bottomLeft");
		});

/**
 * 初始化表单
 */
function initElecSealForm() {
	var url = ctx + "/elecseal/applyElecSealAction_initElecSealForm.action";
	var data = tool.ajaxRequest(url, "");
	if (data.success) {
		if (data.response.webResponseJson.state == "normal") {
			$("#orgNo").val(data.response.webResponseJson.data.orgNo);
			$("#orgName").val(data.response.webResponseJson.data.orgName);
			$("#peopleName").val(data.response.webResponseJson.data.peopleName);
		} else {
			alert("服务器响应失败");
		}
	} else {
		alert(data.response);
	}
}

/**
 * 初始化电子印章模板
 */
function initElecSealModelOption() {
	var url = ctx + "/elecseal/applyElecSealAction_listAllElecSealModel.action";
	var data = tool.ajaxRequest(url, "");
	if (data.success) {
		if (data.response.webResponseJson.state == "normal") {
			all_elec_seal_model = data.response.webResponseJson.data;
			if (all_elec_seal_model != null) {
				$("#sealModel").append("<option value=''>---请选择---</option>");
				$(all_elec_seal_model).each(
						function(i, value) {
							$("#sealModel").append(
									"<option value='" + all_elec_seal_model[i].id + "'>"
											+ all_elec_seal_model[i].modelName + "</option>");
						});
				dispalyAllEditableProp();
			} else {
				alert("未建立印章模板信息,请先建立印章模板");
			}
		} else {
			alert("服务器响应失败");
		}
	} else {
		alert(data.response);
	}
}

/**
 * 电子印章建模申请
 */
function applyElecSeal() {
	if (!$("#electronicSeal").validationEngine("validate")) {
		return;
	}

	var formData = $('#electronicSeal').serialize();
	var url = ctx + "/elecseal/applyElecSealAction_applyElecSeal.action";
	var data = tool.ajaxRequest(url, formData);
	if (data.success) {
		if (data.response.webResponseJson.state == "normal") {
			alert("申请成功");
			reset();
		} else {
			alert(data.response.webResponseJson.data);
		}
	} else {
		alert(data.response);
	}
}

/**
 * 重置表单
 */
function reset() {
	$('#electronicSeal')[0].reset();
	initElecSealForm();
	setSealProperty("");
}

/**
 * 改变模板
 */
function findElecSealModel() {
	var modelId = $("#sealModel").val();
	if (modelId == "") {
		// 初始化所有可变参数
		dispalyAllEditableProp();
		setSealProperty("");
		return;
	}
	var model = "";
	for ( var i = 0; i < all_elec_seal_model.length; i++) {
		if (all_elec_seal_model[i].id == modelId) {
			model = all_elec_seal_model[i];
		}
	}
	elec_seal_model_all_prop = model.modelAllProp;
	var uneditableProp = all_elec_seal_model[0].modelNEditableProp;
	elec_seal_model_all_prop = replaceEditableProp(elec_seal_model_all_prop, uneditableProp);
	editable_prop = model.modelEditableProp;

	// 初始化所有可变参数
	unDisplayAllEditableProp();

	// 显示此模板的可变参数
	initAndShowProp(editable_prop);

	// 显示此模板的电子印章
	var elecSealJson = generateElectronicSeal(elec_seal_model_all_prop, editable_prop);
	$("#elecSealJson").val(elecSealJson);
	$("#modelEditableProp").val(editable_prop);
	$("#width").val(model.width);
	$("#height").val(model.height);
}

/**
 * 对全部可变参数设置为display:none
 */
function unDisplayAllEditableProp() {
	for (i = 0; i < all_editable_prop_id.length; i++) {
		$('#' + all_editable_prop_id[i]).css('display', 'none');
	}
}

/**
 * 现在所有可变参数
 */
function dispalyAllEditableProp() {
	for (i = 0; i < all_editable_prop_id.length; i++) {
		$('#' + all_editable_prop_id[i]).css('display', '');
	}
	for (i = 0; i < all_editable_prop_input_id.length; i++) {
		$('#' + all_editable_prop_input_id[i]).val("");
	}
}

/**
 * 改变模板显示相应印章参数输入框
 * 
 * @param needShowPropJson
 *            可变参数的json字符串
 */
function initAndShowProp(needShowPropJson) {
	var editableProp = (new Function("return " + needShowPropJson))();
	for ( var key in editableProp) {
		$('#' + key + "Area").css('display', '');
		$('#' + key).val(editableProp[key]);
	}
}

/**
 * 可变参数空值校验
 * 
 * @deprecated
 * @returns {Boolean}
 */
function editablePropValidation() {
	var editableProp = (new Function("return " + editable_prop))();
	for ( var key in editableProp) {
		if (isNull($('#' + key).val())) {
			$('#' + key).focus();
			alert("印章参数项为必填项!");
			return false;
		}
	}
	return true;
}

/**
 * 改变印章内容
 */
function changeSealContent() {
	if (null == elec_seal_model_all_prop || "" == elec_seal_model_all_prop) {
		return;
	}

	var newValueJson = "{";
	var editableProp = (new Function("return " + editable_prop))();
	for ( var key in editableProp) {
		var value = $('#' + key).val();
		var json = "";
		if (value != null && value != "") {
			json = "'" + key + "':'" + value + "',";
		} else {
			json = "'" + key + "':'" + editableProp[key] + "',";
		}
		newValueJson = newValueJson + json;
	}
	newValueJson = newValueJson + "}";
	var elecSealJson = generateElectronicSeal(elec_seal_model_all_prop, newValueJson);
	$("#elecSealJson").val(elecSealJson);
}

/**
 * 非空检查
 * 
 * @param value
 * @returns {Boolean}
 */
function isNull(value) {
	if (value == null || value == "undefined" || value == "") {
		return true;
	}
	return false;
}
