
$(function(){
	
	
	initCheckDialog();
	
	initTaskList();
	
	$("#searchBtn").closest("form").css("margin-bottom", "10px").css("margin-top", "10px");
	
	$("#searchOrgNo").click(function(){
		$("#applyOrgNoSearch").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, null,null, function(event, treeId, treeNode){
			if(treeNode){
				$("#applyOrgNoSearch").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
				$("#eq_applyOrgNo").val(treeNode.organizationNo);
			}
		});
	});
	
	$("#searchBtn").click(function(){
		$("#list").jqGrid("search", "#search");
	});
	
	$("#clearBtn").click(function(){
		$(this).closest("form")[0].reset();
	});
});

function showauditFile(elementID,storeid){
	 wfStoreFancyBox.showAllThumbnailImageByStoreId(elementID,storeid,"buttons");
}

function check(autoId) {
	$.post(
			top.ctx + "/sealhandle/task/sealHandleTaskListAction_gainTask.action", 
			{ "bizInfo.autoId" : autoId }, 
			function(data) {
				if (data.responseMessage.success) {
					if (data.bizInfo == null) {
						alert("此任务正在处理或者已处理");
					} else {
						$("#opCheck").fillForm({
							bizInfo : data.bizInfo
						});
						showauditFile("files",data.bizInfo.storeId);
						$("#applyOrgNo").val(Organization.getOrganizationByOrgNo(data.bizInfo.applyOrgNo).organizationNameAndNo);
						$("#opCheck").data("autoId", data.bizInfo.autoId).dialog("open");
					}
				} else {
					$.error("读取数据出错: " + data.responseMessage.message);
				}
	});
}

function unlockTask(url, data) {
	$.post(url, data, function(data) {});
}

function commitTask(url, data, dialogId, listId, callback) {
	$.post( url,
			data,
	function(data) {
		if (data.responseMessage.success) {
			$.success("操作成功");
			$(listId).trigger("reloadGrid");
			$(dialogId).dialog("close");
			if (callback) {
				callback(data);
			}
		} else {
			$.error("操作失败: " + data.responseMessage.message);
		}
	});
}

function initCheckDialog() {
	$("#opCheck").dialog({
        autoOpen : false,
        height : 350, 
		width : 450,
        resizable : false,
        modal : true,
        buttons : {
            "同意" : function() {
            	var url = $.getContextPath() + "/sealhandle/task/sealHandleTaskListAction_commitTask.action";
            	var data = $("#opCheck").serializeForm();
            	data.taskResult = "yes";
            	commitTask(url, data, "#opCheck", "#list");
            },
            "拒绝" : function() {
            	var checkMemo = $("#checkMemo").val();
            	if (!checkMemo) {
					alert("审批意见不能为空.");
					return;
				}
            	var url = $.getContextPath() + "/sealhandle/task/sealHandleTaskListAction_commitTask.action";
            	var data = $("#opCheck").serializeForm();
            	data.taskResult = "no";
            	commitTask(url, data, "#opCheck", "#list");
            },
            "关闭" : function() {
            	$(this).dialog("close");
            }
        },
        close : function() {
        	var url = $.getContextPath() + "/sealhandle/task/sealHandleTaskListAction_unlockTask.action";
        	var data = {"bizInfo.autoId" : $("#opCheck").data("autoId")};
        	$("#opCheck")[0].reset();
        	unlockTask(url, data);
        },
        open : function() {
        	
        }
    });
}

function initTaskList() {
	$("#list").jqGrid({
		caption : "设备维护待审核申请列表",
		url : top.ctx + "/sealhandle/task/sealHandleTaskListAction_gainTaskList.action",
		postData: {"moduleId" : moduleId},
		rowList:[10, 15, 20, 30],
		rowNum:15,
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "设备编号", "申请人姓名", "申请人账号", "申请机构", "申请时间", "操作" ],
		colModel : [ {
		    name : "deviceNum",
		    index : "deviceNum"
		}, {
		    name : "applyPeopleName",
		    index : "applyPeopleName"
		}, {
		    name : "applyPeopleCode",
		    index : "applyPeopleCode"
		}, {
		    name : "applyOrgNo",
		    index : "applyOrgNo",
		    formatter : function(value, options, rData) {
				return Organization.getOrganizationByOrgNo(value).organizationNameAndNo;
			}
		},{
		    name : "applyTime",
		    index : "applyTime"
		},{
		    name : "autoId",
		    index : "autoId",
		    formatter : function(value, options, rData) {
				return "<div class='icon_edit' onclick='check(\"" + value + "\")' title='审核' style='float:left;'></div>";;
			}
		}],
		pager : "#pager"
	});
	
	$("#list").navGrid("#pager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
}


