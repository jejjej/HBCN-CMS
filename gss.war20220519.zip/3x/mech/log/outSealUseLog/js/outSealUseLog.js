/**
 * 创建于:2017-4-06<br>
 * 版权所有(C) 2017 深圳市银之杰科技股份有限公司<br>
 * 机外用印日志js
 * 
 * @author 谭述文
 * @version 1.1.0
 */
function init() {
	initVideoDialog();
	// 用印记录列表
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight
			+ 6 - 50 * 2;

	// 默认查询一个月以内
	var nowDate = new Date();
	var now = nowDate.pattern("yyyy-MM-dd");
	var oldDate = new Date(nowDate.setMonth((new Date().getMonth() - 1)));
	var old = oldDate.pattern("yyyy-MM-dd");
	$("#ge_applyDate").val(old);
	$("#le_applyDate").val(now);

	// 默认本机构
	$("#orgNoCondition")
			.val(
					top.loginPeopleInfo.orgName + "("
							+ top.loginPeopleInfo.orgNo + ")");
	$("#operatorOrgNo_search").val(top.loginPeopleInfo.orgNo);

	$("#outSealUseLogList")
			.jqGrid(
					{
						autoLoad : false,
						width : pageContentWidth,
						height : tableHeight + "px",
						url : ctx
								+ "/mechseal/log/outSealUseLogAction_queryLog.action",
						multiselect : false,
						rowNum : 20,
						rownumbers : true,
						rowList : [ 20, 50, 100 ],
						colNames : [ "申请机构", "申请人", "申请日期", "申请时间", "结果", "影像" ],
						colModel : [
								{
									name : "applyOrgName",
									index : "applyOrgName",
									align : "center",
									width : 85,
									sortable : false
								},
								{
									name : "applyPeopleName",
									index : "applyPeopleName",
									align : "center",
									width : 85,
									sortable : false
								},
								{
									name : "applyDate",
									index : "applyDate",
									align : "center",
									width : 85,
									sortable : false
								},
								{
									name : "applyTime",
									index : "applyTime",
									align : "center",
									width : 85,
									sortable : false
								},
								{
									name : "result",
									index : "result",
									align : "center",
									width : 85,
									formatter : function(value, options, rData) {
										if (value === "upload") {
											return "正常用印";
										} else if (value === "unopen") {
											return "未打开侧门";
										} else if (value === "overtime") {
											return "操作超时";
										} else if (value === "error") {
											return "通讯出现异常";
										} else if (value === "exception") {
											return "视频检测发现有异常";
										} else if (value === "open") {
											return "打开侧门但因意外情况未上传影像";
										} else if (value === "initError") {
											return "视频检测初始化异常";
										}
									},
									sortable : false
								},
								{
									name : "storeId",
									index : "storeId",
									align : "center",
									width : 85,
									formatter : function(value, options, rData) {
										if (rData.result != "upload"
												&& rData.result != "exception"
												&& rData.result != "overtime"
												&& rData.result != "initError") {
											return "无";
										} else {
											var html = "<img src='"
													+ ctx
													+ "/gss/common/images/gss/play.png' style='cursor:pointer;margin-left:3px;' alt='播放视频'  title='播放视频'  onclick=\"playVideo('"
													+ value + "');\"/>";
											return html;
										}
									},
									sortable : false
								} ],
						pager : "#outSealUseLogPager"
					});
	$("#outSealUseLogList").navGrid("#outSealUseLogPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true,
		excel : ctx + "/mechseal/log/outSealUseLogAction_report.action"
	});
	queryLog();
}

function fmtResult(result) {
	return sealUseConstants.outSealUseApplyResult[result];
}

function initVideoDialog() {
	$("#video").dialog({
		autoOpen : false,
		resizable : false,
		draggable : false,
		closeOnEscape : false,
		height : 520,
		width : 680,
		modal : true
	});
};

function playVideo(storeId) {
	var url = ctx + "/mechseal/log/outSealUseLogAction_queryVideoPath.action";
	var param = {
		"storeId" : storeId
	};
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		var url = data.response.videoUrl;
		$("#video")
				.html(
						'<embed src="'
								+ url
								+ '" type="video/x-msvideo" height="480" width="640"/>');
		$("#video").dialog("open");
	} else {
		alert("查询失败：" + data.response);
	}
}

/**
 * 选择查询机构
 */
function choseOrgNoCondition() {
	$("#orgNoCondition").dialogOrgTree(
			"radio",
			top.loginPeopleInfo.orgSid,
			false,
			null,
			null,
			function(event, treeId, treeNode) {
				if (treeNode) {
					$("#orgNoCondition").val(
							treeNode.organizationName + "("
									+ treeNode.organizationNo + ")");
					$("#operatorOrgNo_search").val(treeNode.organizationNo);
				}
			});
};

function queryLog() {
	$("#outSealUseLogList").jqGrid("search", "#search");
}

function resetQuery() {
	$("#search")[0].reset();
	// 默认查询一个月以内
	var nowDate = new Date();
	var now = nowDate.pattern("yyyy-MM-dd");
	var oldDate = new Date(nowDate.setMonth((new Date().getMonth() - 1)));
	var old = oldDate.pattern("yyyy-MM-dd");
	$("#ge_applyDate").val(old);
	$("#le_applyDate").val(now);
}