
function show(event, showMouseFn, showSealImgFn) {
	var point = getMousePosition(event);
	alert(point.x +", "+point.y);
//	var x = point.x - event.offsetParent.offsetLeft - event.offsetParent.offsetParent.offsetLeft;
//	var y = point.y - event.offsetParent.offsetTop - event.offsetParent.offsetParent.offsetTop;
//	var xPos = Math.round(multiply(x / event.offsetWidth, 100));
//	var yPos = Math.round(multiply(y / event.offsetHeight, 100));
//	if (showMouseFn) {
//		showMouseFn(xPos, yPos);
//	}
//	if (showSealImgFn) {
//		showSealImgFn(point.x, point.y);
//	}
	
	function getMousePosition(event) {
		event = event || window.event;
		var point = {
			x : 0,
			y : 0
		};
		if (event.pageX || event.pageY) {
			point.x = event.pageX;
			point.y = event.pageY;
		} else {// 兼容ie
			point.x = event.clientX + document.body.scrollLeft - document.body.clientLeft;
			point.y = event.clientY + document.documentElement.scrollTop;
		}
		return point;
	};
}

