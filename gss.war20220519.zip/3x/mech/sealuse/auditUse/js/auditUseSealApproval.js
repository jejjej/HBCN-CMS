/**
 * 创建于:2016-11-11<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 后台审批用印
 * 
 * @author 黄坤平
 * @version 1.0.0
 */

$(function() {
	
	initDialog();
	initTaskList();
});

function initDialog() {
	$("#bizInfo").dialog({
        autoOpen : false,
        height : $(window).height() - 15, 
		width : $(window).width()-320,
        resizable : false,
        modal : true,
        buttons : {
            "同意" : function() {
            	var url = $.getContextPath() + "/mechseal/sealuse/auditUseSealTaskAction_commitTask.action";
            	var data = $("#bizInfo").serializeForm();
            	$("#bizInfo").data("autoId", "");
            	data.taskResult = "yes";
            	commitTask(url, data, "#bizInfo", "#list");
            },
            "拒绝" : function() {
            	var checkMemo = $("#checkMemo").val();
            	if (!checkMemo) {
					alert("拒绝审批意见不能为空！");
					return;
				}
            	var url = $.getContextPath() + "/mechseal/sealuse/auditUseSealTaskAction_commitTask.action";
            	var data = $("#bizInfo").serializeForm();
            	$("#bizInfo").data("autoId", "");
            	data.taskResult = "no";
            	commitTask(url, data, "#bizInfo", "#list");
            }
        },
        close : function() {
        	var autoId = $("#bizInfo").data("autoId");
        	if (autoId) {
        		var url = $.getContextPath() + "/mechseal/sealuse/auditUseSealTaskAction_unlockTask.action";
        		var data = {"bizInfo.autoId" : autoId};
        		unlockTask(url, data);
			}
        	$("#bizInfo")[0].reset();
        	$("#bizInfo").data("autoId", "");
        },
        open : function() {
        	
        }
    });
}

function unlockTask(url, data) {
	$.post(url, data, function(data) {});
}

function commitTask(url, data, dialogId, listId, callback) {
	$.post( url,
			data,
	function(data) {
		if (data.responseMessage.success) {
			$.success("操作成功");
			$(listId).trigger("reloadGrid");
			$(dialogId).dialog("close");
			if (callback) {
				callback(data);
			}
		} else {
			$.error("操作失败: " + data.responseMessage.message);
		}
	});
}

function initTaskList() {
	$("#list").jqGrid({
		caption : "用印待审核申请列表",
		url : top.ctx + "/mechseal/sealuse/auditUseSealTaskAction_gainTaskList.action",
		postData: {"moduleId" : moduleId},
		rowList:[10, 15, 20, 30],
		rowNum:15,
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "交易码", "交易名称", "印章类型", "申请人姓名", "申请人账号", "申请机构", "申请时间","操作" ],
		colModel : [ {
		    name : "tradeCode",
		    index : "tradeCode"
		}, {
		    name : "tradeCodeName",
		    index : "tradeCodeName"
		},{
		    name : "sealType",
		    index : "sealType",
		    formatter : function(value, options, rData) {
				return GPCache.get(GPCache.SMS, GPType.SMS_SEAL_TYPE, value);
			}
		}, {
		    name : "applyPeopleName",
		    index : "applyPeopleName"
		}, {
		    name : "applyPeopleCode",
		    index : "applyPeopleCode"
		}, {
		    name : "applyOrgNo",
		    index : "applyOrgNo",
		    formatter : function(value, options, rData) {
				return Organization.getOrganizationByOrgNo(value).organizationNameAndNo;
			}
		},{
		    name : "applyTime",
		    index : "applyTime"
		},{
		    name : "autoId",
		    index : "autoId",
		    formatter : function(value, options, rData) {
				return "<div class='icon_edit' onclick='check(\"" + value + "\")' title='审核' style='float:left;'></div>";;
			}
		}],
		pager : "#pager"
	});
	
	$("#list").navGrid("#pager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
}

function syncDownload(storeId){
	var success = false;
	var urlList = null;
	$.ajax({
		type : "post",
		url : top.ctx + "/extStore/extStoreAction!findObject.action",
		dataType : "json",
		data: { "storeId" : storeId },
		async : false,
		success : function(response) {
			success = (response.state == "normal");
			urlList = response.data;
		},
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0" || XMLHttpRequest.status != "200") {
				urlList = "网络异常或服务器异常.";
			}
		}
	});
	if(success){
		if(urlList != null){
			return urlList;
		}else{
			throw new Error("无相应文件信息.");
		}
	}else{
		throw new Error(urlList);
	}
};

function check(autoId) {
	$.post(
			top.ctx + "/mechseal/sealuse/auditUseSealTaskAction_gainTask.action", 
			{ "bizInfo.autoId" : autoId }, 
			function(data) {
				if (data.responseMessage.success) {
					if (data.bizInfo == null) {
						alert("此任务正在处理或者已处理");
					} else {
						$("#bizInfo").fillForm({
							bizInfo : data.bizInfo
						});
						var sealTypeName = GPCache.get(GPCache.SMS, GPType.SMS_SEAL_TYPE, data.bizInfo.sealType);
						$("#sealTypeName").val(sealTypeName);
						var docObjects = syncDownload(data.bizInfo.storeId);
						$("#fileImg").attr("src", docObjects[0].fileUrl);
						$("#bizInfo").data("autoId", data.bizInfo.autoId).dialog("open");
					}
				} else {
					$.error("读取数据出错: " + data.responseMessage.message);
				}
	});
}


window.onbeforeunload = function(){
	if($("#bizInfo").data("autoId")) {
		$("#bizInfo").dialog("close");
	}
};