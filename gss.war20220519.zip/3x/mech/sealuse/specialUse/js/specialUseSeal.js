/**
 * 创建于:2015-10-27<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 机控印章远程审批用印JS（一客户端申请另一客户端实时审核用印）<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var machine_num;

// 使用的摄像头分辨率常数
var CAMERA_RES_WIDTH = 2048;
var CAMERA_RES_HEIGHT = 1536;

// 凭证图像
var use_cut_img = true;
var src_img_path, cut_img_path;
var big_pic_width = 0, big_pic_height = 0;
var small_pic_width = 0, small_pic_height = 0;
var display_pic_width = 0, display_pic_height = 0;

// 实时审核
var wait_approving = "wait_approving"; // 用印审核默认值
var approval_result = wait_approving; // 用印审核结果，pass/refuse/approving

$().ready(function() {
	// 初始化控件
	var ret = ocxbase_messageHandler.initOcx();
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	ret = ocxbase_fileStore.initOcx(basePath);
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	ret = ocxbase_xusbVideo.initOcx();
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	ret = ocxbase_sealMachine.initOcx();
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};

	// 绑定onclick事件
	$("#applyBtn").bind("click", openPaperDoor);
	$("#commitBtn").bind("click", applySpecialUseSeal);
	$("#switchVoucherImage").bind("click", switchVoucherImage);

	ocxbase_messageHandler.bindNextUseSealClickEvent(startNextUseSeal);
	ocxbase_messageHandler.bindCompleteClickEvent(completeUseSeal);

	// 初始化设备
	ocxbase_messageHandler.showTipMessage("设备初始化中，请稍候...");
	window.setTimeout(function() {
		var connResult = ocxbase_machineAndCameraConnProxy.connect(machineReady);
		if (!connResult.success) {
			ocxbase_messageHandler.dealErrorMssage(connResult.data);
		}
	}, 500);
});

// 设备连接结果回调事件
function machineReady(ret) {
	if (ret.success) {
		machine_num = ocxbase_sealMachine.getMachineNum();

		openPaperDoor();
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}
};

// 用印前打开纸板
function openPaperDoor() {
	$('#applyBtn').attr("disabled", true);

	var ret = ocxbase_sealMachine.openPaperDoor(doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	} else {
		ocxbase_messageHandler.showTipMessage("请放入凭证...");
	}

	// 纸板关闭回调函数
	function doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		setTimeout(function() {
			dealUseSealProcess("start", null, null);
		}, 500);
	}
};

/**
 * 用印过程处理<br>
 * 
 * @param state：'start'、'end'
 * @param useSealSuccess：true/false(非用印结束时可传入null)
 * @param useSealErrorMsg：用印异常信息(非用印结束时可传入null)
 */
function dealUseSealProcess(state, useSealSuccess, useSealErrorMsg) {
	var srcImgPath, cutImgPath, transImagePath;
	var ret = ocxbase_xusbVideo.captureImage(false, state);
	if (ret.success) {
		srcImgPath = ret.data.srcImagePath;
		cutImgPath = ret.data.cutImagePath;
		transImagePath = ret.data.transImagePath;
		src_img_path = srcImgPath;
		cut_img_path = cutImgPath;

		// 显示凭证图像
		document.getElementById("voucherImg").src = transImagePath;
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
		return;
	}

	if ("start" == state) {
		// 计算图像裁剪前后的大小
		var cutSize = ocxbase_xusbVideo.getLastCutImageSize();
		if (cutSize.success) {
			small_pic_width = cutSize.data.width;
			small_pic_height = cutSize.data.height;
			big_pic_width = CAMERA_RES_WIDTH;
			big_pic_height = CAMERA_RES_HEIGHT;
		} else {
			ocxbase_messageHandler.dealErrorMssage(cutSize.data);
			return;
		}

		// 释放相应按钮
		$("#commitBtnTd").css('display', "");
		showSwitchVoucherImageBtn();
		ocxbase_messageHandler.hideWaittingDialog();
	} else if ("end" == state) {
		var uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cutImgPath, "append");
		if (!uploadRet.success) {
			ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
			return;
		}
		if (useSealSuccess) {
			ocxbase_messageHandler.showTipMessage("盖章完毕，请取凭证！</br>如果要继续下一笔业务，请先放入凭证，再关纸盒！");
			useSealCompletedOpenPaperDoor();
		} else {
			ocxbase_messageHandler.dealErrorMssage(useSealErrorMsg);
			return;
		}
	}

	$('#applyBtn').attr("disabled", false);
};

// 向服务器提交用印申请
function applySpecialUseSeal() {
	// 上传用印前凭证图像
	var uploadRet;
	if (use_cut_img) {
		uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cut_img_path, "add");
	} else {
		uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(src_img_path, "add");
	}
	if (!uploadRet.success) {
		ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
		return;
	}

	// 提交用印申请信息
	var bizInfo = $('#mechSealUseApplyInfo').serialize();
	var url = ctx + "/mechseal/sealuse/specialUseMechSealAction_applyUseMechSeal.action";
	var data = tool.ajaxRequest(url, bizInfo);
	if (data.success) {
		var result = data.response.webResponseJson.data;
		if (data.response.webResponseJson.state == "normal") {
			$("#bizId").val(data.response.mechSealUseApplyInfo.id);

			ocxbase_messageHandler.showTipMessage("正在等待审核，请稍候....");

			// 等待用印
			waitUseMechSeal();
		} else {
			ocxbase_messageHandler.dealErrorMssage(result);
		}
	} else {
		ocxbase_messageHandler.dealErrorMssage("服务器响应失败：" + data.response);
	}
};

// 用印
function useSeal() {
	ocxbase_messageHandler.showTipMessage("准备开始用印...");

	// 隐藏切换图片按钮
	$("#switchVoucherImageId").css('display', 'none');

	// 获取盖章信息
	$("#machineNum").val(machine_num);
	var useSealInfoRet = findSpecialUseSealInfo();
	if (!useSealInfoRet.success) {
		ocxbase_messageHandler.dealErrorMssage(useSealInfoRet.data);
		return;
	}

	// 用原图还是裁剪图片
	var imgWidth = big_pic_width;
	var imgHeight = big_pic_height;
	if (use_cut_img) {
		imgWidth = small_pic_width;
		imgHeight = small_pic_height;
	}
	// 用印裁剪图片并裁剪成功时需计算在原图中的坐标
	var useSealXpos = multiply(useSealInfoRet.data.xposition / 100, imgWidth);
	var useSealYpos = multiply(useSealInfoRet.data.yposition / 100, imgHeight);
	if (!ocxbase_xusbVideo.imageIs2048_1536(imgWidth, imgHeight)) {
		var ret = ocxbase_xusbVideo.getLastCutInSrcPosition(useSealXpos, useSealXpos);
		if (ret.success) {
			useSealXpos = ret.data.x;
			useSealYpos = ret.data.y;
		} else {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
	}

	// 新增用印业务信息
	var creatRet = ocxbase_bizInfoAjax.bizInfo.createStartUseMechSeal(ctx
			+ "/mechseal/sealuse/specialUseMechSealAction_creatStartUseMechSealLog.action");
	if (!creatRet.success) {
		ocxbase_messageHandler.dealErrorMssage(creatRet.data);
		return;
	}

	ocxbase_messageHandler.showTipMessage("正在用印...");

	// 开始用印
	var useRet = ocxbase_sealMachine.useSeal(useSealInfoRet.data.tradeCode, false, 0, useSealXpos, useSealYpos,
			useSealCallback);
	if (!useRet.success) {
		ocxbase_messageHandler.dealErrorMssage(useRet.data);
		return;
	}

	// 用印结束回调函数
	function useSealCallback(ret) {
		// 保存用印信息
		var memo, status;
		if (ret.success) {
			status = sealUseConstants.USE_SEAL_SUCCESS;
			memo = ret.data.message;
			$("#sealPosition").val(ret.data.sealPos);
		} else {
			memo = ret.data.errMsg;
			if (ret.data.errCode == "USE_SEAL_DISCONNECT") {
				status = sealUseConstants.USE_SEAL_DISCONNECT;
			} else if (ret.data.errCode == "USE_SEAL_ERROR") {
				status = sealUseConstants.USE_SEAL_EXCEPTION;
			}
		}
		$("#status").val(status);
		$("#bizMemo").val(memo);
		$("#logMemo").val(memo);
		var updateRet = ocxbase_bizInfoAjax.bizInfo.updateUseMechSealResult(ctx
				+ "/mechseal/sealuse/specialUseMechSealAction_updateUseMechSealResult.action");
		if (!updateRet.success) {
			ocxbase_messageHandler.dealErrorMssage(updateRet.data);
			return;
		}

		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		setTimeout(function() {
			dealUseSealProcess("end", ret.success, memo);
		}, 500);
	}
};

// 用印结束弹出纸板
function useSealCompletedOpenPaperDoor() {
	var ret = ocxbase_sealMachine.openPaperDoor(_doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}

	// 纸板关闭回调函数
	function _doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}

		ocxbase_messageHandler.showTipMessage("是否继续下一笔业务？");
		ocxbase_messageHandler.showAllButton();
	}
};

// 开始下一笔用印
function startNextUseSeal() {
	resetPropsCache();
	ocxbase_messageHandler.showTipMessage("正在拍照处理中...");
	dealUseSealProcess("start", null, null);
};

// 结束用印
function completeUseSeal() {
	resetPropsCache();
};

// 切换凭证裁剪前后图像
function switchVoucherImage() {
	// 切换凭证图像
	if (use_cut_img) {
		use_cut_img = false;
		document.getElementById("voucherImg").src = src_img_path;
	} else {
		use_cut_img = true;
		document.getElementById("voucherImg").src = img_path;
	}
};

function showSwitchVoucherImageBtn() {
	if (fast_switch_voucher_image) {
		$("#switchVoucherImageId").css('display', '');
	}
};

// 重置属性缓存
function resetPropsCache() {
	document.getElementById("voucherImg").onload = null;
	document.getElementById("voucherImg").src = ctx + "/3x/ocxbase/useSealFramework/ocxbase_voucherImg.png";
	ocxbase_messageHandler.hideWaittingDialog();
	use_cut_img = true;
	src_img_path = null;
	cut_img_path = null;
	$("#applyBtnTd").css('display', '');
	$('#applyBtn').attr("disabled", false);
	$("#mechSealUseApplyInfo")[0].reset();
	$("#commitBtnTd").css('display', 'none');
	ocxbase_messageHandler.hideAllButton();
	$("#status").val("");

	approval_result = wait_approving;
};

/**
 * 页面关闭响应事件
 */
function closePage() {
	ocxbase_machineAndCameraConnProxy.disconnect();
};

/**
 * 等待用印
 */
function waitUseMechSeal() {
	// 等待审核结果
	waitApprovalResult();

	// 处理审核结果
	dealApprovalResult();
};

// 循环获取审核结果，直到审核完毕
function waitApprovalResult() {
	// 重置审核结果
	approval_result = wait_approving;

	var approving = false;

	var result = getApprovalResult();
	if (result == sealUseConstants.WAITTING_APPROVAL) {
		approving = true;
	} else {
		approving = false;
	}

	if (approving) {
		// 向服务器获取审核结果的请求频率，在此加timeout可缓解服务器的压力，可适当调整timeout时间
		setTimeout("waitApprovalResult()", 2000);
	} else {
		approval_result = result;
	}
};

// 处理审核结果
function dealApprovalResult() {
	if (approval_result == wait_approving) {
		// 向本地全局变量获取审核结果的请求频率，可适当调整timeou的时间来调节处理审核结果的时间
		setTimeout("dealApprovalResult()", 2000);
	} else if (approval_result == sealUseConstants.APPROVAL_PASS) {
		useSeal();
	} else if (approval_result == sealUseConstants.APPROVAL_REFUSE) {
		ocxbase_messageHandler.showTipMessage("用印申请审核不通过!");
		// 审核不通过时，先提示“不通过”再延迟弹出纸板，可以调整timeout的时间亦可去掉timeout
		setTimeout(function() {
			useSealCompletedOpenPaperDoor();
		}, 3000);
	} else {
		ocxbase_messageHandler.hideWaittingDialog();
		ocxbase_messageHandler.showTipMessage("审核失败:" + approval_result);
	}
};

/**
 * 获取审核的状态
 * 
 * @returns 审核状态approving:001/pass:002/refuse:003
 */
function getApprovalResult() {
	try {
		var id = $("#bizId").val();
		var param = {
			'id' : id
		};
		var url = ctx + "/mechseal/sealuse/specialUseMechSealAction_findApprovalResult.action";
		var data = tool.ajaxRequest(url, param);
		if (data.success) {
			return data.response.webResponseJson.data;
		} else {
			return "服务器响应失败：" + data.response;
		}
	} catch (e) {
		return e.message;
	}
};

// 获取特殊机控用印信息
function findSpecialUseSealInfo() {
	var param = {
		'id' : $("#bizId").val(),
		'sealMachineCode' : $("#machineNum").val()
	};
	var url = ctx + "/mechseal/sealuse/specialUseMechSealAction_findSpecialUseSealInfo.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		var useSealInfo = data.response.webResponseJson.data;
		if (data.response.webResponseJson.state == "normal") {
			return ocxbase_utils.genOptResult(true, useSealInfo);
		} else {
			return ocxbase_utils.genOptResult(false, useSealInfo);
		}
	} else {
		return ocxbase_utils.genOptResult(false, "服务器响应失败：" + data.response);
	}
};