/**
 * 创建于:2014-9-10<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 特殊机控用印审核JS
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var mouse_pos_x = null; // 鼠标X坐标

var mouse_pos_y = null; // 鼠标Y坐标

$().ready(function() {
	queryBizInfo();

	// 初始化交易代码下拉框
	selectUtils.initTradeCode("tradeCode", 1);
})

/**
 * 获取业务信息
 */
function queryBizInfo() {
	var url = ctx + "/mechseal/sealuse/specialUseSealApprovalAction_queryBizInfo.action";
	var data = tool.ajaxRequest(url, '');
	if (data.success) {
		var result = data.response.webResponseJson;
		if (result.state == "normal") {
			if (result.data == null) {
				showMessage1("暂无用印申请");
				resetForm();
				return;
			}
			showBtn();
			showInput();
			showMessage("");
			$("#id").val(result.data["id"]);
			document.getElementById("fileImg").src = data.response.url;
		} else {
			alert(result.data);
		}
	} else {
		alert("服务器响应失败：" + data.response);
	}
};

/**
 * 审核通过
 */
function approvalPass() {
	var specialSealXposition = $("#specialSealXposition").val();
	var specialSealYposition = $("#specialSealYposition").val();
	var tradeCode = $("#tradeCode").val();
	if (isNull(specialSealXposition) || isNull(specialSealYposition)) {
		alert("请选择盖章坐标!");
		return;
	}
	if (isNull(tradeCode)) {
		alert("请选择交易代码!");
		return;
	} else {
		$("#tradeCodeName").val($.trim($("#tradeCode  option:selected").text()));
	}
	var formData = $('#bizInfo').serialize();
	var url = ctx + "/mechseal/sealuse/specialUseSealApprovalAction_approvalPass.action";
	var data = tool.ajaxRequest(url, formData);
	if (data.success) {
		if (data.response.state == "normal") {
			showMessage(data.response.data);
			queryBizInfo();
		} else {
			alert(data.response.data);
		}
	} else {
		alert("服务器响应失败：" + data.response);
	}
};

/**
 * 审核拒绝
 */
function approvalRefuse() {
	var tradeCode = $("#tradeCode").val();
	if (!(isNull(tradeCode))) {
		$("#tradeCodeName").val($.trim($("#tradeCode  option:selected").text()));
	}
	var formData = $('#bizInfo').serialize();
	var url = ctx + "/mechseal/sealuse/specialUseSealApprovalAction_approvalRefuse.action";
	var data = tool.ajaxRequest(url, formData);
	if (data.success) {
		if (data.response.state == "normal") {
			showMessage(data.response.data);
			queryBizInfo();
		} else {
			alert(data.response.data);
		}
	} else {
		alert("服务器响应失败：" + data.response);
	}
};

/**
 * 取消锁定
 */
function unlockApproval() {
	var url = ctx + "/mechseal/sealuse/specialUseSealApprovalAction_unlockApproval.action";
	var data = tool.ajaxRequest(url, '');
	if (data.success) {
		if (data.response.state == "normal") {
			// 解锁成功，前台不做任何操作
		} else {
			alert(data.response.data);
		}
	} else {
		if (!data.response == "") {
			alert("解锁时服务器响应失败：" + data.response);
		}
	}
};

document.onmousemove = mouseMove;

/**
 * 鼠标位置
 * 
 * @param ev
 * @returns
 */
function mousePosition(ev) {
	try {
		if (ev.pageX || ev.pageY) {
			return {
				x : ev.pageX,
				y : ev.pageY
			};
		}
		return {
			x : ev.clientX + document.body.scrollLeft - document.body.clientLeft,
			y : ev.clientY + document.documentElement.scrollTop
		};
	} catch (e) {
	}
};

/**
 * 鼠标移动
 * 
 * @param ev
 */
function mouseMove(ev) {
	try {
		ev = ev || window.event;
		var mousePos = mousePosition(ev);
		mouse_pos_x = mousePos.x;
		mouse_pos_y = mousePos.y;
	} catch (e) {
	}
};

/**
 * 显示鼠标在图片中的坐标
 * 
 * @param el
 */
function showPosition(el) {
	var x = mouse_pos_x - el.offsetParent.offsetLeft - el.offsetParent.offsetParent.offsetLeft;
	var y = mouse_pos_y - el.offsetParent.offsetTop - el.offsetParent.offsetParent.offsetTop;
	var xPos = Math.round(multiply(x / el.offsetWidth, 100));
	var yPos = Math.round(multiply(y / el.offsetHeight, 100));
	$("#specialSealXposition").val(xPos);
	$("#specialSealYposition").val(yPos);
};

/**
 * 显示印章图片
 * 
 * @param xPos
 * @param yPos
 */
function showSealImage(xPos, yPos) {
	$("#sealImageDiv").css('display', '');
	document.getElementById("sealImage").src = ctx + "/3x/common/images/seal_0.png";
	$("#sealImageDiv").css('top', yPos - 40);
	$("#sealImageDiv").css('left', xPos - 40);
};

/**
 * 点击凭证图片事件
 * 
 * @param el
 */
function voucherImgOnClick(el) {
	try {
		var id = $("#id").val();
		if (!isNull(id)) {
			// 显示在图片中的位置
			showPosition(el);

			// 显示印章图片
			showSealImage(mouse_pos_x, mouse_pos_y);
		}
	} catch (e) {
	}
};

/**
 * 显示提示信息
 * 
 * @param message
 *            信息
 */
function showMessage(message) {
	$("#showMessage").html(message);

};

function showMessage1(message) {
	$("#showMessage1").html(message);
};

/**
 * 隐藏按钮
 */
function showBtn() {
	$("#btn").css('display', '');
};

/**
 * 隐藏输入框
 */
function showInput() {
	$("#inputText").css('display', '');
};

/**
 * 重置页面
 */
function resetForm() {
	mouse_pos_x = null;
	mouse_pos_y = null;
	$("#btn").css('display', 'none');
	$("#inputText").css('display', 'none');
	$("#bizInfo")[0].reset();
	document.getElementById("fileImg").src = ctx + "/3x/ocxbase/useSealFramework/ocxbase_voucherImg.png";
	$("#sealImageDiv").css('display', 'none');
	document.getElementById("sealImage").src = ctx + "/3x/common/images/seal_0.png";
};

/**
 * 非空检查
 * 
 * @param value
 * @returns {Boolean}
 */
function isNull(value) {
	if (value == null || value == "undefined" || value == "") {
		return true;
	}
	return false;
};