/**
 * 创建于:2014-11-21<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 行政章批量用印JS<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var login_people = null; // 人员信息

var approval_mode = null; // 审批模式

var batch_use_appr_mode = null; // 批量用印审批模式

var use_seal_mode = null; // 用印模式 normal:普通 batch:批量

var first_appr_code = null; // 第一审核人员

$(function() {
	initLoginPeople();
	initParam();
	initUseSealPage();
	initTaskList();
});

/**
 * 初始化机构人员信息
 */
function initLoginPeople() {
	login_people = top.loginPeopleInfo;
};

/**
 * 初始化参数配置
 */
function initParam() {
	// 审批模式
	approval_mode = tool.getApprovalModeByOrgAndBiz(login_people.orgNo, constants.ADMIN_SEAL_USE_APPLY, false);

	// 批量用印审批模式
	batch_use_appr_mode = tool.getApprovalModeByOrgAndBiz(login_people.orgNo, constants.ADMIN_BATCH_USE_APPLY, false);
};

/**
 * 初始化任务列表
 */
function initTaskList() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	// 用印信息列表
	$("#useSealList")
			.jqGrid(
					{
						width : pageContentWidth,
						height : tableHeight + "px",
						url : ctx + "/mechseal/sealuse/batchUseSealTaskAction_gainTaskList.action?moduleId=" + moduleId,
						multiselect : false,
						rowNum : 20,
						rownumbers : true,
						sortable : true,// 是否排序
						sortname : "autoId",
						sortorder : "desc",
						rowList : [20, 50, 100],
						colNames : ["交易代码", "用印事由", "影像数量", "待用印次数", "已用印次数", "申请人", "机构名称", "申请时间", "文件持有人",
								"用印文件", "操作"],
						colModel : [
								{
									name : "tradeCode",
									index : "tradeCode",
									align : "center",
									width : 100,
									sortable : false
								},
								{
									name : "title",
									index : "title",
									align : "center",
									sortable : false
								},
								{
									name : "fileNum",
									index : "fileNum",
									align : "center",
									width : 100,
									sortable : false
								},
								{
									name : "applyNum",
									index : "applyNum",
									align : "center",
									width : 100,
									sortable : false
								},
								{
									name : "usedNum",
									index : "usedNum",
									align : "center",
									width : 100,
									sortable : false,
									formatter : function(value, options, rData) {
										return "<font color='red'>" + value + "</font>";
									}
								},
								{
									name : "applyPeopleName",
									index : "applyPeopleName",
									align : "center",
									width : 100,
									sortable : false
								},
								{
									name : "applyOrgName",
									index : "applyOrgName",
									align : "center",
									sortable : false
								},
								{
									name : "applyTime",
									index : "applyTime",
									align : "center",
									width : 100,
									sortable : false
								},
								{
									name : "fileOwnerName",
									index : "fileOwnerName",
									align : "center",
									width : 100,
									sortable : false
								},
								{
									name : "storeId",
									index : "storeId",
									width : 80,
									align : "center",
									sortable : false,
									formatter : function(value, options, rData) {
										if (null == value || value == "") {
											return "无图像";
										} else {
											var html = "<img src='"
													+ ctx
													+ "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='用印资料图像'  title='用印资料图像'  onclick=\"startViewImage('"
													+ value + "');\"/>";
											return html;

										}
									}
								},
								{
									name : "autoId",
									index : "autoId",
									align : "center",
									width : 150,
									sortable : false,
									formatter : function(value, options, rData) {
										return "<button onclick=\"startUseSeal('" + value + "','"+rData.tradeCode+"');\">用印</button>"
												+ "<button onclick=\"startBatchUseSeal('" + value
												+ "','"+rData.tradeCode+"');\">批量用印</button>";
									}
								}],
						pager : "#useSealPager",
						caption : "用印任务列表"
					}).trigger("reloadGrid");
	$("#useSealList").navGrid("#useSealPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

/**
 * 开始用印
 * 
 * @param autoId
 *            用印申请ID
 */
function startUseSeal(autoId,tradeCode) {
	use_seal_mode = "normal";
	first_appr_code = "";
	$("#batchUseSealNumTr").css('display', "none");
	
	approval_mode = constants.NOT_NEED_APPROVAL;
	if (approval_mode == constants.NOT_NEED_APPROVAL) {// 无需审批
		notNeedApproval(autoId,tradeCode);
	} else if (approval_mode == constants.LOCAL_APPROVAL_ONLY) { // 只本地审核
		localApprovalOnly(autoId,tradeCode);
	} else if (approval_mode == constants.REMOTE_APPROVAL_ONLY) { // 只远程审核
		remoteApprovalOnly(autoId,tradeCode);
	} else if (approval_mode == constants.LOCAL_AND_REMOTE_APPROVAL) { // 本地 &
		// 远程审核
		localAndRemoteApproval(autoId,tradeCode);
	} else if (approval_mode == constants.LOCAL_OR_REMOTE_APPROVAL) { // 本地 |
		// 远程
		localOrRemoteApproval(autoId,tradeCode);
	} else {
		alert("请先到“用印审批模式参数”中配置『此机构』的【行政章文件审批用印】审核模式");
	}

	// 无需审批
	function notNeedApproval(autoId,tradeCode) {
		queryUseSealDetail(autoId,tradeCode);
	}

	// 只本地审批
	function localApprovalOnly(autoId,tradeCode) {
		var operAuth = new top.OperAuth();
		operAuth.operType = "adminBatchUseSeal"; // 权限 (action-auth.xml)
		operAuth.authSuccess = function(peopleCode) {
			if (!tool.isNull(peopleCode)) {
				first_appr_code = peopleCode;
				queryUseSealDetail(autoId,tradeCode);
			} else {
				alert("前台授权方式配置错误，请联系技术人员!");
			}
		};
		operAuth.authCancel = function() {
			// alert("用印申请未通过现场审核");
		};
		operAuth.auth();
	}

	// 仅远程审批
	function remoteApprovalOnly(autoId) {
		alert("暂不支持【仅远程审批】模式！");
	}

	// 现场且远程审批
	function localAndRemoteApproval(autoId) {
		alert("暂不支持【现场且远程审批】模式！");
	}

	// 现场或远程审批
	function localOrRemoteApproval(autoId) {
		alert("暂不支持【现场或远程审批】模式！");
	}
};

/**
 * 批量用印
 * 
 * @param autoId
 *            用印申请ID
 */
function startBatchUseSeal(autoId,tradeCode) {
	use_seal_mode = "batch";
	first_appr_code = "";
	$("#batchUseSealNumTr").css('display', "");
	
	batch_use_appr_mode = constants.NOT_NEED_APPROVAL;
	if (batch_use_appr_mode == constants.NOT_NEED_APPROVAL) {// 无需审批
		notNeedApproval(autoId,tradeCode);
	} else if (batch_use_appr_mode == constants.LOCAL_APPROVAL_ONLY) { // 只本地审核
		localApprovalOnly(autoId,tradeCode);
	} else if (batch_use_appr_mode == constants.REMOTE_APPROVAL_ONLY) { // 只远程审核
		remoteApprovalOnly(autoId,tradeCode);
	} else if (batch_use_appr_mode == constants.LOCAL_AND_REMOTE_APPROVAL) { // 本地 &
		// 远程审核
		localAndRemoteApproval(autoId,tradeCode);
	} else if (batch_use_appr_mode == constants.LOCAL_OR_REMOTE_APPROVAL) { // 本地 |
		// 远程
		localOrRemoteApproval(autoId,tradeCode);
	} else {
		alert("请先到“用印审批模式参数”中配置『此机构』的【行政章文件审批批量用印】审核模式");
	}

	// 无需审批
	function notNeedApproval(autoId,tradeCode) {
		queryUseSealDetail(autoId,tradeCode);
	}

	// 只本地审批
	function localApprovalOnly(autoId,tradeCode) {
		var operAuth = new top.OperAuth();
		operAuth.operType = "adminBatchUseSeal"; // 权限 (action-auth.xml)
		operAuth.authSuccess = function(peopleCode) {
			if (!tool.isNull(peopleCode)) {
				first_appr_code = peopleCode;
				queryUseSealDetail(autoId,tradeCode);
			} else {
				alert("前台授权方式配置错误，请联系技术人员!");
			}
		};
		operAuth.authCancel = function() {
			// alert("用印申请未通过现场审核");
		};
		operAuth.auth();
	}

	// 仅远程审批
	function remoteApprovalOnly(autoId) {
		alert("暂不支持【仅远程审批】模式！");
	}

	// 现场且远程审批
	function localAndRemoteApproval(autoId) {
		alert("暂不支持【现场且远程审批】模式！");
	}

	// 现场或远程审批
	function localOrRemoteApproval(autoId) {
		alert("暂不支持【现场或远程审批】模式！");
	}
};

/**
 * 查询用印详情
 */
function queryUseSealDetail(autoId,tradeCode) {
	OCX_Logger.info(LOGGER._3X,"{fileApprUseSealTaskList.queryUseSealDetail}--开始查询用印业务信息,用印流水号为：" + autoId);
	var result = null;
	var success = false;
	$.ajax({
		type : "post",
		url : ctx + "/mechseal/sealuse/batchUseSealTaskAction_gainTask.action",
		data : {
			"bizInfo.autoId" : autoId,
			"bizInfo.tradeCode" : tradeCode
		},
		dataType : "json",
		async : false,
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0" || XMLHttpRequest.status != "200") {
				result = '服务器响应失败';
			}
		},
		success : function(response) {
			result = response;
			if (response.responseMessage.success == true) {
				success = true;
			}
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
			if (textStatus != null) {
				result = textStatus;
			} else {
				result = errorThrown;
			}
		}
	});
	if (success) {
		OCX_Logger.info(LOGGER._3X,"{fileApprUseSealTaskList.queryUseSealDetail}--查询用印业务信息成功。");
		showUseSealPage(result);
	} else {
		OCX_Logger.info(LOGGER._3X,"{fileApprUseSealTaskList.queryUseSealDetail}--查询用印业务信息失败。" + autoId);
		alert("锁定任务失败，请刷新任务列表后重新尝试!");
	}
};

/**
 * 初始化用印页面
 */
function initUseSealPage() {
	$("#useSealApplyInfo").dialog({
		autoOpen : false,
		resizable : false,
		// height : $(window).height(), 不起作用
		width : multiply($(window).width(), 59) / 60,
		modal : true,
		position : {
			at : "left top"
		},
		close : function() {
			closeDetail();
			initTaskList();
		}
	});
};

/**
 * 显示用印页面
 * 
 * @param response
 */
function showUseSealPage(response) {
	OCX_Logger.info(LOGGER._3X,"{fileApprUseSealTaskList.showUseSealPage}--开始处理用印业务信息。");
	try {
		if (response.webResponseJson.state == "normal") {
			var bizInfo = response.bizInfo;
			$("#useSealApplyInfo").dialog("open");
			// $("#useSealApplyInfo").css("width",1000); 不起作用
			$("#useSealApplyInfo").css("height", $(window).height());

			$("#detailAutoId").val(bizInfo.autoId);
			$("#fileOwnerName").val(bizInfo.fileOwnerName);
			
			$("#sealUse").empty();
			var options = "<option value=''>--请选择--</option>";
			for(var i=0;i<response.configlist.length;i++){
				var config_ = response.configlist[i];
				var sealBizTypeName = GPCache.get(GPCache.SMS, GPType.SMS_SEAL_TYPE, config_.sealTypeId)
										+ " -- " + bizInfo.usedNum + "\\" + bizInfo.applyNum;
				options += "<option value='" + config_.sealTypeId + "'>" + sealBizTypeName + "</option>";
			}
			$("#sealUse").append(options);
			$("#tradeCode").val(bizInfo.tradeCode);
			if (bizInfo.usedNum == bizInfo.applyNum || bizInfo.status == sealUseConstants.USE_SEAL_SUCCESS) {
				biz_finish = true; // batchUseSeal.js
				ocxbase_messageHandler.showTipMessage("本用印申请单已全部盖章完毕！"); // batchUseSeal.js
				$("#completeUseSealBtnId").css('display', ""); // batchUseSeal.js
			} else {
				OCX_Logger.info(LOGGER._3X,"{fileApprUseSealTaskList.showUseSealPage}--用印业务信息处理完毕，准备打开纸板。");
				// 打开纸板
				openPaperDoor(); // batchUseSeal.js
			}

			left_over_use_num = bizInfo.applyNum - bizInfo.usedNum; // batchUseSeal.js
		} else {
			alert(response.webResponseJson.data);
		}
	} catch (e) {
		alert(e.message);
	}
};

function startViewImage(storeId) {
	wfStoreFancyBox.showAllImageByStoreId(storeId, "buttons");
};

/**
 * 关闭详情页面
 */
function closeDetail() {
	try {
		var autoId = $("#detailAutoId").val();
		if (!tool.isNull(autoId)) {
			var url = ctx + "/mechseal/sealuse/batchUseSealTaskAction_unlockTask.action";
			var data = {
				"bizInfo.autoId" : autoId
			};
			tool.ajaxRequest(url, data);
		}
	} catch (e) {
		alert(e.message);
	} finally {
		resetDetail();
	}
};

/**
 * 重置详情页面属性
 */
function resetDetail() {
	$("#detailAutoId").val("");
	$("#fileOwnerName").val("");
	$("#storeId").val("");
	$("#sealNum").val("");
	biz_finish = false; // batchUseSeal.js
	left_over_use_num = null; // batchUseSeal.js
};

function isBatchUseSeal() {
	return (use_seal_mode == "batch") ? true : false;
}
