/**
 * 创建于:2015-10-29<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 机控文件审批用印JS（可以单独用印或者多张凭证盖在同一个位置上多票据用印）<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var machine_num;

// 图片尺寸误差
var size_deviation = 0.05;

// 凭证图像
var use_cut_img = true;
var src_img_path, cut_img_path;
var big_pic_width = 0, big_pic_height = 0;
var small_pic_width = 0, small_pic_height = 0;
var display_pic_width = 0, display_pic_height = 0;

//标记是否下一笔用印 1是下一笔 
var nextSeal_left_over_use_num = 0;

// 用印数据
var use_model = {
	"isFirst" : true,
	"firstImgWidth" : 0,
	"firstImgHeight" : 0
};

var biz_finish = false; // 一笔业务盖章完毕
var left_over_use_num = null; // 剩余的用印数量
var batch_used_num = 0; // 一次批量用印，已用印的次数

$().ready(
		function() {
			// 初始化控件
			var ret = ocxbase_messageHandler.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			ret = ocxbase_fileStore.initOcx(basePath);
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			ret = ocxbase_xusbVideo.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			ret = ocxbase_sealMachine.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};

			// 盖章位置印章图片处理
			ocxbase_utils.sealImageHandler.init("imageListDiv", "voucherImg",
					ocxbase_utils.sealImageHandler.external.imageClickCallback);
			
			// 绑定onclick事件
			$("#applyBtn").bind("click", openPaperDoor);
			$("#commitBtn").bind("click", useSeal);
			$("#switchVoucherImage").bind("click", switchVoucherImage);
			$("#rotateSealImage").bind("click", ocxbase_utils.sealImageHandler.rotateSealImage);
			
			ocxbase_messageHandler.bindNextUseSealClickEvent(startNextUseSeal);
			ocxbase_messageHandler.bindCompleteClickEvent(completeUseSeal);
			
			var queryurl = ocxbase_exceptionLogHandler.ctx + "/3xbase/useSealExceptionAction_findErrorRecord.action";
			var dealurl = ocxbase_exceptionLogHandler.ctx + "/3xbase/useSealExceptionAction_updateErrorRecord.action";
			ocxbase_exceptionLogHandler.setExceptionData(queryurl, null, dealurl, null);
			
			// 初始化设备
			ocxbase_messageHandler.showTipMessage("设备初始化中，请稍候...");
			window.setTimeout(function() {
				var connResult = ocxbase_machineAndCameraConnProxy.connect(machineReady);
				if (!connResult.success) {
					ocxbase_messageHandler.dealErrorMssage(connResult.data);
				}
			}, 500);
		});

// 设备连接结果回调事件
function machineReady(ret) {
	if (ret.success) {
		machine_num = ocxbase_sealMachine.getMachineNum();

		// 初始化用印范围红框顶点数据 sealBoundaryUtil.js
		var boundaryRet = setMaxMinDistance(machine_num, ocxbase_xusbVideo.defaultProp);
		if (!boundaryRet) {
			return;
		}

		ocxbase_messageHandler.hideWaittingDialog();
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}
};

// 用印前打开纸板
function openPaperDoor() {
	$('#applyBtn').attr("disabled", true);

	ocxbase_utils.sealImageHandler.clearSealImage();
	var ret = ocxbase_sealMachine.openPaperDoor(doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	} else {
		ocxbase_messageHandler.showTipMessage("请放入凭证...");
	}

	// 纸板关闭回调函数
	function doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		var captureInterval = ocxbase_iniHelper.configParam.closecapture_maincamera_dealy;
		OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.doorCloseCallback}--执行用印前纸板关闭回调，准备开始处理用印流程，延时[" + captureInterval + "ms]");
		setTimeout(function() {
			dealUseSealProcess("start", null, null);
		}, captureInterval);
	}
};

/**
 * 用印过程处理<br>
 * 
 * @param state：'start'、'end'
 * @param useSealSuccess：true/false(非用印结束时可传入null)
 * @param useSealErrorMsg：用印异常信息(非用印结束时可传入null)
 */
function dealUseSealProcess(state, useSealSuccess, useSealErrorMsg) {
	OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.dealUseSealProcess}--用印流程处理开始，当前流程为:[" + state + "]~~~~~~~~~~~");
	var srcImgPath, cutImgPath, transImagePath;
	OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.dealUseSealProcess}--用印流程处理，拍照开始");
	var ret = ocxbase_xusbVideo.captureImage(false, state);
	if (ret.success) {
		OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.dealUseSealProcess}--用印流程处理，拍照成功");
		srcImgPath = ret.data.srcImagePath;
		cutImgPath = ret.data.cutImagePath;
		transImagePath = ret.data.transImagePath;
		src_img_path = srcImgPath;
		cut_img_path = cutImgPath;

		// 显示凭证图像
		document.getElementById("voucherImg").src = transImagePath;
	} else {
		OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.dealUseSealProcess}--用印流程处理，拍照失败");
		ocxbase_messageHandler.dealErrorMssage(ret.data);
		return;
	}

	if ("start" == state) {
		OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.dealUseSealProcess}--用印流程处理，盖章前流程处理开始...");
		// 计算图像裁剪前后的大小
		var cutSize = ocxbase_xusbVideo.getLastCutImageSize();
		if (cutSize.success) {
			small_pic_width = cutSize.data.width;
			small_pic_height = cutSize.data.height;
			big_pic_width = ocxbase_xusbVideo.cameraInfo.width;
			big_pic_height = ocxbase_xusbVideo.cameraInfo.height;
		} else {
			ocxbase_messageHandler.dealErrorMssage(cutSize.data);
			return;
		}

		// 显示用印边界线
		queryCornerPoints(small_pic_width, small_pic_height, big_pic_width, big_pic_height);
		document.getElementById("voucherImg").onload = function() {
			var img = document.getElementById("voucherImg");
			display_pic_width = img.width;
			display_pic_height = img.height;
			if (use_cut_img) {
				showBoundaryCanvas("sealCanvasDiv", "voucherImg", use_cut_img, small_pic_width, small_pic_height);
			} else {
				showBoundaryCanvas("sealCanvasDiv", "voucherImg", use_cut_img, small_pic_width, small_pic_height);
			}
		};

		// 释放相应按钮
		$("#commitBtnTd").css('display', "");
		showSwitchVoucherImageBtn();
		ocxbase_messageHandler.hideWaittingDialog();
		OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.dealUseSealProcess}--用印流程处理，盖章前流程处理结束...");
	} else if ("end" == state) {
		OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.dealUseSealProcess}--用印流程处理，盖章后流程处理——>开始...");
		OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.dealUseSealProcess}--用印流程处理，盖章后流程处理——>上传用印后图像开始");
		var uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cutImgPath, "append");
		if (!uploadRet.success) {
			OCX_Logger.error(LOGGER._3X,"{fileApprUseSeal.dealUseSealProcess}--用印流程处理，盖章后流程处理——>上传用印后图像失败");
			ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
			return;
		}
		if (useSealSuccess) {
			OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.dealUseSealProcess}--用印流程处理，盖章后流程处理——>上传用印后图像成功");
			ocxbase_messageHandler.showTipMessage("盖章完毕，请取凭证！</br>如果要继续下一笔业务，请先放入凭证，再关纸盒！");
			OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.dealUseSealProcess}--用印流程处理，盖章后流程处理——>打开纸板");
			useSealCompletedOpenPaperDoor();
		} else {
			ocxbase_messageHandler.dealErrorMssage(useSealErrorMsg);
			return;
		}
		OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.dealUseSealProcess}--用印流程处理，盖章后流程处理结束");
	}

	$('#applyBtn').attr("disabled", false);
	OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.dealUseSealProcess}--用印流程处理结束，当前流程为:[" + state + "]~~~~~~~~~~~");
};

// 用印
function useSeal() {
	OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.useSeal}--***********用印函数处理开始***********");
	var xPosition = $("#xPosition").val();
	var yPosition = $("#yPosition").val();
	var sealTypeCode = $("#sealUse").val();
	var batchUseSealNum = $("#batchUseSealNum").val();
	if (!xPosition || !yPosition) {
		alert("请选择盖章坐标!");
		ocxbase_messageHandler.hideWaittingDialog();
		return;
	}
	if(!sealTypeCode){
		alert("请选择印章种类");
		ocxbase_messageHandler.hideWaittingDialog();
		return;
	}
	if (isBatchUseSeal()) { // -> batchUseSealTaskList.js
		var format = /^\+?[1-9][0-9]*$/;
		if (!format.test(batchUseSealNum) || batchUseSealNum <= 0 || batchUseSealNum > left_over_use_num) {
			alert("请输入有效的用印次数");
			ocxbase_messageHandler.hideWaittingDialog();
			$("#batchUseSealNum").focus();
			return;
		}
	}

	ocxbase_messageHandler.showTipMessage("准备开始用印...");

	// 隐藏切换图片按钮
	$("#switchVoucherImageId").css('display', 'none');

	// 上传用印前凭证图像
	var uploadRet;
	OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.useSeal}--用印开始，上传用印前图像开始");
	if (use_cut_img) {
		uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cut_img_path, "add");
	} else {
		uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(src_img_path, "add");
	}
	if (!uploadRet.success) {
		OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.useSeal}--用印开始，上传用印前图像成功，图像存储ID为：" + $("#storeId").val());
		ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
		return;
	}

	// 是否盖骑缝章
	var isAcrossPageSeal = false;
	var useSealPattern = $("#useSealPattern").val();
	if (useSealPattern == "2") {
		isAcrossPageSeal = true;
	}

	// 计算盖章角度
	var angle;
	var cutAngle = ocxbase_xusbVideo.getLastCutImageAngle();
	if (cutAngle.success) {
		angle = cutAngle.data + ocxbase_utils.sealImageHandler.getSealAngle();
		angle = (angle + 360) % 360;
	} else {
		ocxbase_messageHandler.dealErrorMssage(cutAngle.data);
		return;
	}

	// 计算盖章坐标
	// 用原图还是裁剪图片
	var imgWidth = big_pic_width;
	var imgHeight = big_pic_height;
	if (use_cut_img) {
		imgWidth = small_pic_width;
		imgHeight = small_pic_height;
	}
	// 用印裁剪图片并裁剪成功时需计算在原图中的坐标
	var useSealXpos = multiply(xPosition / 100, imgWidth);
	var useSealYpos = multiply(yPosition / 100, imgHeight);
	if (!ocxbase_xusbVideo.imageMateWidthHeight(imgWidth, imgHeight)) {
		var ret = ocxbase_xusbVideo.getLastCutInSrcPosition(useSealXpos, useSealXpos);
		if (ret.success) {
			useSealXpos = ret.data.x;
			useSealYpos = ret.data.y;
		} else {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
	}

	if (isBatchUseSeal()) { // -> batchUseSealTaskList.js
		// 记录第一次用印信息
		if (use_model["isFirst"]) {
			use_model["isFirst"] = false;
			use_model["firstImgWidth"] = imgWidth;
			use_model["firstImgHeight"] = imgHeight;
		} else {
			// 判断是否与原纸大小一致
			if (!checkPaper(use_model["firstImgWidth"], use_model["firstImgHeight"], imgWidth, imgHeight)) {
				alert("检测到更换了纸张，请重新选章并设置盖章位置后进行用印!");
				ocxbase_messageHandler.hideWaittingDialog();
				return;
			}
		}
	}

	// 新增用印业务信息
	$("#machineNum").val(machine_num);
	OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.useSeal}--用印开始，创建用印日志...");
	var creatRet = updateBatchUseSealApplyInfo(sealUseConstants.LOG_STATUS_START_USE, "开始用印");
	if (!creatRet.success) {
		ocxbase_messageHandler.dealErrorMssage(creatRet.data);
		return;
	}
	
	ocxbase_messageHandler.showTipMessage("正在用印...");
	
	// 开始用印
	var useRet = ocxbase_sealMachine.startUseSeal(sealTypeCode, isAcrossPageSeal, angle, useSealXpos, useSealYpos,
			useSealCallback);
	if (!useRet.success) {
		ocxbase_messageHandler.dealErrorMssage(useRet.data);
		return;
	}

	// 用印结束回调函数
	function useSealCallback(ret) {
		OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.useSealCallback}--用印结束，用印结束回调函数执行开始...");
		// 保存用印信息
		var memo, status, logStatus;
		if (ret.success) {
			if (isBatchUseSeal()) { // -> batchUseSealTaskList.js
				batch_used_num++;
			}
			status = sealUseConstants.USE_SEAL_SUCCESS;
			logStatus = sealUseConstants.LOG_STATUS_SUCCESS;
			memo = ret.data.message;
			$("#sealPosition").val(ret.data.sealPos);
		} else {
			memo = ret.data.errMsg;
			if (ret.data.errCode == "USE_SEAL_DISCONNECT") {
				status = sealUseConstants.USE_SEAL_DISCONNECT;
				logStatus = sealUseConstants.LOG_STATUS_DISCONNECT;
			} else if (ret.data.errCode == "USE_SEAL_ERROR") {
				logStatus = sealUseConstants.LOG_STATUS_FAIL;
			}
		}
		$("#status").val(status);
		$("#bizMemo").val(memo);
		$("#logMemo").val(memo);
		var updateRet = updateBatchUseSealApplyInfo(logStatus, memo);
		OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.useSealCallback}--用印结束，用印结束回调函数执行——>更新用印状态");;
		if (!updateRet.success) {
			ocxbase_messageHandler.dealErrorMssage(updateRet.data);
			return;
		}
		
		var captureInterval = ocxbase_iniHelper.configParam.overcapture_maincamera_delay;
		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.useSealCallback}--用印结束，用印结束回调函数执行——>准备用印后拍照，延时[" + captureInterval + "]");;
		setTimeout(function() {
			dealUseSealProcess("end", ret.success, memo);
		}, captureInterval);
	}
	OCX_Logger.info(LOGGER._3X,"{fileApprUseSeal.useSealCallback}--***********用印函数处理结束***********");
};

// 用印结束弹出纸板
function useSealCompletedOpenPaperDoor() {
	var ret = ocxbase_sealMachine.openPaperDoor(_doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}

	// 纸板关闭回调函数
	function _doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}

		if (biz_finish) {
			ocxbase_messageHandler.showTipMessage("本次用印申请单已全部盖章完毕！");
			ocxbase_messageHandler.showCompleteButton();
		} else {
			if (isBatchUseSeal()) { // -> batchUseSealTaskList.js
				// 批量用印不用再选印章和位置，直接继续用印
				if (batch_used_num >= $("#batchUseSealNum").val()) {
					ocxbase_messageHandler.showTipMessage("是否继续下一笔业务？");
					ocxbase_messageHandler.showAllButton();
				} else {
					ocxbase_messageHandler.showTipMessage("正在拍照处理中...");
					dealUseSealProcess("start", null, null);
					useSeal();
				}
			} else {
				ocxbase_messageHandler.showTipMessage("是否继续下一笔业务？");
				ocxbase_messageHandler.showAllButton();
			}
		}
	}
};

// 开始下一笔用印
function startNextUseSeal() {
	left_over_use_num = nextSeal_left_over_use_num;
	resetPropsCache();
	ocxbase_messageHandler.showTipMessage("正在拍照处理中...");
	dealUseSealProcess("start", null, null);
};

// 结束用印
function completeUseSeal() {
	resetPropsCache();

	// 用印完成
	if (biz_finish) {
		$("#useSealApplyInfo").dialog("close");
		resetDetail(); // batchUseSealTaskList.js
		initTaskList(); // batchUseSealTaskList.js
	}
};

// 切换凭证裁剪前后图像
function switchVoucherImage() {
	// 切换凭证图像
	if (use_cut_img) {
		use_cut_img = false;
		document.getElementById("voucherImg").src = src_img_path;
	} else {
		use_cut_img = true;
		document.getElementById("voucherImg").src = img_path;
	}

	// 重置用印位置信息
	$("#xPosition").val("");
	$("#yPosition").val("");
	ocxbase_utils.sealImageHandler.clearSealImage();
	$("#rotateSealImageId").css('display', 'none');
};

function showSwitchVoucherImageBtn() {
	if (fast_switch_voucher_image) {
		$("#switchVoucherImageId").css('display', '');
	}
};

// 重置属性缓存
function resetPropsCache() {
	document.getElementById("voucherImg").onload = null;
	clearSealCanvas("sealCanvasDiv");
	document.getElementById("voucherImg").src = ctx + "/3x/ocxbase/useSealFramework/ocxbase_voucherImg.png";
	ocxbase_messageHandler.hideWaittingDialog();
	use_cut_img = true;
	src_img_path = null;
	cut_img_path = null;
	$("#applyBtnTd").css('display', '');
	$('#applyBtn').attr("disabled", false);
	$("#commitBtnTd").css('display', 'none');
	ocxbase_messageHandler.hideAllButton();
	ocxbase_utils.sealImageHandler.clearSealImage();
	$("#rotateSealImageId").css('display', 'none');
	$("#status").val("");
	use_model["isFirst"] = true;
	use_model["firstImgWidth"] = 0;
	use_model["firstImgHeight"] = 0;

	$("#xPosition").val("");
	$("#yPosition").val("");

	batch_used_num = 0;
	$("#batchUseSealNum").val("");
};

// 页面关闭响应事件
function closePage() {
	ocxbase_machineAndCameraConnProxy.disconnect();

	closeDetail();// -> batchUseSealTaskList.js
};

/**
 * 保存用印信息
 * 
 * @param sealUseStatus
 *            {@see sealUseConstants.sealUseLogStatus}
 */
var log_autoid = "";
function updateBatchUseSealApplyInfo(sealUseLogStatus, memo) {
	var param = {
		"bizInfo.autoId" : $("#detailAutoId").val(),
		"mechSealUseLog.autoId" : log_autoid,
		"mechSealUseLog.sealPosition" : $("#sealPosition").val(),
		"mechSealUseLog.status" : sealUseLogStatus,
		"mechSealUseLog.machineNum" : $("#machineNo").val(),
		"mechSealUseLog.storeId" : $("#storeId").val(),
		"mechSealUseLog.memo" : memo,
		"mechSealUseLog.firstApprPeopleCode" : first_appr_code,
		"mechSealUseLog.sealTypeCode" : $("#sealUse").val()
	};
	log_autoid = null;
	var url = ctx + "/mechseal/sealuse/batchUseSealTaskAction_updateBatchUseSealApplyInfo.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		if (data.response.webResponseJson.state == "normal") {
			log_autoid = data.response.mechSealUseLog.autoId;
			var bizInfo = data.response.bizInfo;
			
			$("#sealUse").empty();
			var options = "<option value=''>--请选择--</option>";
			for(var i=0;i<data.response.configlist.length;i++){
				var config_ = data.response.configlist[i];
				var sealBizTypeName = GPCache.get(GPCache.SMS, GPType.SMS_SEAL_TYPE, config_.sealTypeId)
										+ " -- " + bizInfo.usedNum + "\\" + bizInfo.applyNum;
				options += "<option value='" + config_.sealTypeId + "'>" + sealBizTypeName + "</option>";
			}
			$("#sealUse").append(options);
			if (bizInfo.usedNum == bizInfo.applyNum || bizInfo.status == sealUseConstants.USE_SEAL_SUCCESS) {
				var activeRet = activeFinishUseSealWorkFlow();
				if (!activeRet.success) {
					return activeRet;
				}
				biz_finish = true;
			}
			
			nextSeal_left_over_use_num = bizInfo.applyNum - bizInfo.usedNum;
			return ocxbase_utils.genOptResult(true, null);
		} else {
			return ocxbase_utils.genOptResult(false, data.response.webResponseJson.data);
		}
	} else {
		return ocxbase_utils.genOptResult(false, "更新用印结果服务器响应失败：" + data.response);
	}

	// 结束用印工作流
	function activeFinishUseSealWorkFlow() {
		var param = {
			"bizInfo.autoId" : $("#detailAutoId").val(),
			"bizInfo.status" : sealUseConstants.USE_SEAL_SUCCESS,
			"bizInfo.memo" : "用印成功",
			"taskResult" : sealUseConstants.USE_SEAL_SUCCESS
		};
		var url = ctx + "/mechseal/sealuse/batchUseSealTaskAction_commitTask.action";
		var data = tool.ajaxRequest(url, param);
		if (data.success) {
			if (data.response.responseMessage.success == true) {
				return ocxbase_utils.genOptResult(true, null);
			} else {
				return ocxbase_utils.genOptResult("结束行政章文件审批用印工作流服务器响应失败：" + data.response.responseMessage.message);
			}
		} else {
			return ocxbase_utils.genOptResult(false, "结束行政章文件审批用印工作流服务器响应失败：" + data.response);
		}
	};
};

/**
 * 判断纸张大小是否发生改变
 * 
 * @param modlex
 * @param modley
 * @param picx
 * @param picy
 * @returns {Boolean}
 */
function checkPaper(modlex, modley, picx, picy) {
	var xVerify = Math.abs(modlex - picx) / modlex;
	var yVerify = Math.abs(modley - picy) / modley;
	if (xVerify > size_deviation || yVerify > size_deviation)
		return false;
	return true;
};
