/**
 * 创建于:2016-11-15<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 全自动用印
 * 
 * @author dqq
 * @version 1.0.0
 */

var machine_num;
var waitting_apprresult_timeout_clear;

// 使用的摄像头分辨率常数
var CAMERA_RES_WIDTH = 2048;
var CAMERA_RES_HEIGHT = 1536;

// 凭证图像
var src_img_path, cut_img_path;

$().ready(function() {
	// 初始化控件
	var ret = ocxbase_messageHandler.initOcx();
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	ret = ocxbase_fileStore.initOcx(basePath);
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	ret = ocxbase_xusbVideo.initOcx();
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	ret = ocxbase_sealMachine.initOcx();
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	ret = ocxbase_imageProcessing.initOcx();
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	ocxbase_imageProcessing.setRegVerCode();//设置识别验证码
	
	// 绑定onclick事件
	$("#applyBtn").bind("click", openPaperDoor);
	$("#commitBtn").bind("click", function(){//提交申请
		var res_ = checkUseSealInfo();
		if(!res_.success){
			return;
		}
		showMessage("");
		$("#applyDialog").dialog("open");
	});
	
	ocxbase_messageHandler.bindNextUseSealClickEvent(startNextUseSeal);
	ocxbase_messageHandler.bindCompleteClickEvent(completeUseSeal);
	ocxbase_messageHandler.bindCancelClickEvent(applycancel);
	// 初始化设备
	ocxbase_messageHandler.showTipMessage("设备初始化中，请稍候...");
	OCX_Logger.info(LOGGER._3X,"访问自动用印模块");
	
	var queryurl = ocxbase_exceptionLogHandler.ctx + "/3xbase/useSealExceptionAction_findErrorRecord.action";
	var dealurl = ocxbase_exceptionLogHandler.ctx + "/3xbase/useSealExceptionAction_updateErrorRecord.action";
	ocxbase_exceptionLogHandler.setExceptionData(queryurl, null, dealurl, null);
	
	window.setTimeout(function() {
		var connResult = ocxbase_machineAndCameraConnProxy.connect(machineReady);
		if (!connResult.success) {
			ocxbase_messageHandler.dealErrorMssage(connResult.data);
		}
	}, 500);
	
	$("#applyDialog").dialog({
		autoOpen : false,
		resizable : false,
		draggable : true,
		closeOnEscape : false,
		height : 300,
		width : 400,
		modal : true,
		close : function(){
			$(".ui-dialog-titlebar").hide();
			$(".ui-dialog-titlebar-close").hide();
			$(this)[0].reset();
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
			$("#bizInfo input[name='taskOrg']").val("");
		},
		buttons : {
			"提交":function() {
				var taskOrg = $("#bizInfo input[name='taskOrg']").val();
				if(taskOrg == null || taskOrg == ""){
					alert("授权机构不能为空");
					return;
				}
				$(this).dialog("close");
				applyUseSeal();
			},
			"取消":function() {
				$(this).dialog("close");
			}
		}
	});
	$("#verificationCode").on("keydown", function (e) {
		if (e.keyCode == 13) {
			e.keyCode = 0;
			e.returnValue = false;
			return false;
		}
	});
});

// 设备连接结果回调事件
function machineReady(ret) {
	if (ret.success) {
		machine_num = ocxbase_sealMachine.getMachineNum();

		openPaperDoor();
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}
};

// 用印前打开纸板
function openPaperDoor() {
	$('#applyBtn').attr("disabled", true);
	showMessage("");
	
	var ret = ocxbase_sealMachine.openPaperDoor(doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	} else {
		ocxbase_messageHandler.showTipMessage("请放入凭证...");
	}

	// 纸板关闭回调函数
	function doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		setTimeout(function() {
			dealUseSealProcess("start", null, null);
		}, ocxbase_iniHelper.configParam.closecapture_maincamera_dealy);
	}
};

/**
 * 用印过程处理<br>
 * 
 * @param state：'start'、'end'
 * @param useSealSuccess：true/false(非用印结束时可传入null)
 * @param useSealErrorMsg：用印异常信息(非用印结束时可传入null)
 */
function dealUseSealProcess(state, useSealSuccess, useSealErrorMsg) {
	var srcImgPath, cutImgPath, transImagePath;
	var ret = ocxbase_xusbVideo.captureImage(true, state);
	if (ret.success) {
		srcImgPath = ret.data.srcImagePath;
		cutImgPath = ret.data.cutImagePath;
		transImagePath = ret.data.transImagePath;
		src_img_path = srcImgPath;
		cut_img_path = cutImgPath;
		
		// 显示凭证图像
		document.getElementById("voucherImg").src = transImagePath;
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
		return;
	}

	if ("start" == state) {
		// 识别业务验证码及凭证号
		var regRet = ocxbase_imageProcessing.recognizeVoucher(machine_num, cutImgPath);
		if (regRet.success) {
			document.getElementById("voucherImg").src = regRet.data.voucherInfo.revolvedImg;
			$("#verificationCode").val(regRet.data.verificationCodeInfo.code);
//			$("#billNo").val(regRet.data.billCodeInfo.code);
//			$("#billNo").attr("disabled",true);
			var res_ = checkUseSealInfo();
			if(res_.success){
				useSeal();
			}
		} else {
			if (regRet.data.voucherInfo != null && regRet.data.voucherInfo.revolvedImg != null) {
				document.getElementById("voucherImg").src = regRet.data.voucherInfo.revolvedImg;
			}
			dealRegCodeFail(regRet.data.errorMsg);
		}
		
	} else if ("end" == state) {
		var uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cutImgPath, "append");
		if (!uploadRet.success) {
			ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
			return;
		}
		if (useSealSuccess) {
			ocxbase_messageHandler.showTipMessage("盖章完毕，请取凭证！</br>如果要继续下一笔业务，请先放入凭证，再关纸板！");
			useSealCompletedOpenPaperDoor();
		} else {
			ocxbase_messageHandler.dealErrorMssage(useSealErrorMsg);
			return;
		}
	}

	$('#applyBtn').attr("disabled", false);
};

//需要授权并提交用印申请
function applyUseSeal() {
	// 上传用印前凭证图像
	var uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cut_img_path, "add");
	if (!uploadRet.success) {
		ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
		return;
	}
	
	// 提交用印申请信息
	var bizInfo = $('#bizInfo').serializeArray();
	$("#verificationCode").attr("disabled", true);
	var url = ctx + "/mechseal/task/autoSealTaskAction_createTask.action?processDefKey=GSS_AUTO_USESEAL&time_"+new Date().getTime();
	var data = tool.ajaxRequest(url, bizInfo);
	if (data.success) {
		var result = data.response.responseMessage.message;
		if (data.response.responseMessage.success){
			$("#bizid").val(data.response.bizInfo.autoId);
			ocxbase_messageHandler.showTipMessage("正在等待审核，请稍候....");
			ocxbase_messageHandler.showCancelButton();
			//开始倒计时
			countapplytime(GPCache.get(GPCache.GSS, GPType.GSS_DOWNTIME,"AUDIT_DOWNTIME"));
			//等待审批结果
			var param = {
				'bizInfo.autoId' : $("#bizid").val()
			};
			var url = ctx + "/mechseal/sealuse/autoSealAction_findApprResult.action";
			ocxbase_bizInfoAjax.approvalHandler.startWaitApproalResultThread(url, param, endApprovalCallback,islocked);
		} else {
//			showMessage(result);
			dealRegCodeFail(result);
		}
	} else {
		ocxbase_messageHandler.dealErrorMssage("服务器响应失败：" + data.response);
	}

	// 审批结束
	function endApprovalCallback(ret) {
		ocxbase_messageHandler.hideButton(ocxbase_messageHandler.messageDialogHelper.btnTdId.ceTdId);
		window.clearTimeout(waitting_apprresult_timeout_clear);
		if (ret.success) {//已同意
			useSeal();
		} else {
			if(ocxbase_bizInfoAjax.approvalHandler.approval_result == sealUseConstants.APPROVAL_REFUSE){//拒绝
				ocxbase_messageHandler.showTipMessage(ret.data + "</br>如果要继续下一笔业务，请先放入凭证，再关纸板！");
				// 审核不通过时，先提示“不通过”再延迟弹出纸板，可以调整timeout的时间亦可去掉timeout
				setTimeout(function() {
					useSealCompletedOpenPaperDoor();
				}, 2000);
			}else if(ocxbase_bizInfoAjax.approvalHandler.approval_result == sealUseConstants.APPROVAL_TIMEOUT){//已超时
				ocxbase_messageHandler.showTipMessage("审核已超时，取消成功");
				setTimeout(function(){
					ocxbase_messageHandler.hideWaittingDialog();
				}, 1500);
			}else if(ocxbase_bizInfoAjax.approvalHandler.approval_result == sealUseConstants.USE_SEAL_CANCEL){//已取消
				ocxbase_messageHandler.showTipMessage("用印申请取消成功");
				setTimeout(function(){
					ocxbase_messageHandler.hideWaittingDialog();
				}, 1500);
			}
		}
	}
	
	/**
	 * 任务是否锁定
	 */
	function islocked(){
		var param = {'bizInfo.autoId' : $("#bizid").val()};
		var url = ctx + "/mechseal/task/autoSealTaskAction_isLockedTask.action?processDefKey=GSS_AUTO_USESEAL";
		var data = tool.ajaxRequest(url, param);
		if(data.success){
			if(data.response.taskLocked){//锁定
				window.clearTimeout(waitting_apprresult_timeout_clear);
				waitting_apprresult_timeout_clear = null;
				ocxbase_messageHandler.showTipMessage("正在审核中，请等待...");
				ocxbase_messageHandler.hideButton(ocxbase_messageHandler.btnTdId().ceTdId);
			}else{
				
			}
		}
	}
};

// 用印
function useSeal() {
	if($("#storeId").val()==null || $("#storeId").val()==""){//无需授权,直接通过  先上传用印前图像，并用印
		// 上传用印前凭证图像
		var uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cut_img_path, "add");
		if (!uploadRet.success) {
			ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
			return;
		}
		ocxbase_messageHandler.showTipMessage("准备开始用印...");
	}
	
	// 获取盖章信息
	setInputValue("logInfo.machineNum",machine_num);
	setInputValue("logInfo.storeId",$("#storeId").val());
	setInputValue("logInfo.billCode",ocxbase_imageProcessing.getRecognitionResult().voucherInfo.code);
	setInputValue("logInfo.billName",ocxbase_imageProcessing.getSealConfig().billName);
	setInputValue("logInfo.sealTypeCode",ocxbase_imageProcessing.getSealConfig().sealType);
	setInputValue("logInfo.sealTypeName",ocxbase_imageProcessing.getSealConfig().sealTypeName);
	//获取裁剪后图像的宽高
	var cutimgsize = ocxbase_xusbVideo.getLastCutImageSize();
	if(!cutimgsize.success){
		ocxbase_messageHandler.dealErrorMssage(cutimgsize.data);
		return;
	}
	var cutwidth_ = cutimgsize.data.width,
	cutheight_ = cutimgsize.data.height;
	var paperDirection, voucherUseSealXpos, voucherUseSealYpos;
	paperDirection = ocxbase_imageProcessing.getRecognitionResult().voucherInfo.direction;
	var configdata = ocxbase_imageProcessing.getSealConfig();
	if (paperDirection == 0) {
		voucherUseSealXpos = configdata.sealPos.startX;
		voucherUseSealYpos = configdata.sealPos.startY;
	} else if (paperDirection == 90) {
		voucherUseSealXpos = cutwidth_ - configdata.sealPos.startY;
		voucherUseSealYpos = configdata.sealPos.startX;
	} else if (paperDirection == 180) {
		voucherUseSealXpos = cutwidth_ - configdata.sealPos.startX;
		voucherUseSealYpos = cutheight_ - configdata.sealPos.startY;
	} else if (paperDirection == 270) {
		voucherUseSealXpos = configdata.sealPos.startY;
		voucherUseSealYpos = cutheight_ - configdata.sealPos.startX;
	} else {
		ocxbase_messageHandler.dealErrorMssage("凭证旋转角度未定义");
		return;
	}
	
	// 用印裁剪图片并裁剪成功时需计算在原图中的坐标
	var xPosInPictrue, yPosInPictrue;
	var ret = ocxbase_xusbVideo.getLastCutInSrcPosition(voucherUseSealXpos, voucherUseSealYpos);
	if (ret.success) {
		xPosInPictrue = ret.data.x;
		yPosInPictrue = ret.data.y;
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
		return;
	}

	// 计算盖章角度
	var angle = 0;
	var cutAngle = ocxbase_xusbVideo.getLastCutImageAngle();
	if (cutAngle.success) {
		angle = cutAngle.data + paperDirection;
		angle = (angle + 360) % 360;
	} else {
		ocxbase_messageHandler.dealErrorMssage(cutAngle.data);
		return;
	}
	
	var creatRet = ocxbase_bizInfoAjax.bizInfo.createStartUseSeal(ctx+
			"/mechseal/sealuse/autoSealAction_createUseSealLog.action",
			"#bizInfo",createStartUseSeal_callback);
	if (!creatRet.success) {
		ocxbase_messageHandler.dealErrorMssage(creatRet.data);
		return;
	}
	
	ocxbase_messageHandler.showTipMessage("正在用印...");
	// 开始用印
	var useRet = ocxbase_sealMachine.startUseSeal(ocxbase_imageProcessing.getSealConfig().sealType,
			false, angle, xPosInPictrue, yPosInPictrue,useSealCallback);
	if (!useRet.success) {
		ocxbase_messageHandler.dealErrorMssage(useRet.data);
		return;
	}

	// -------内部函数--------
	//创建任务完成回调
	function createStartUseSeal_callback(response){
		setInputValue("logInfo.autoId", response.logInfo.autoId);
	};
	
	// 用印结束回调函数
	function useSealCallback(ret) {
		// 保存用印信息
		var memo, status;
		if (ret.success) {
			status = sealUseConstants.USE_SEAL_SUCCESS;
			memo = ret.data.message;
			$("#logInfo.sealPos").val(ret.data.sealPos);
		} else {
			memo = ret.data.errMsg;
			if (ret.data.errCode == "USE_SEAL_DISCONNECT") {
				status = sealUseConstants.USE_SEAL_DISCONNECT;
			} else if (ret.data.errCode == "USE_SEAL_ERROR") {
				status = sealUseConstants.USE_SEAL_EXCEPTION;
			}
		}
		setInputValue("bizInfo.status", status);
		$("#bizMemo").val(memo);
		setInputValue("logInfo.memo", memo);
		var updateRet = ocxbase_bizInfoAjax.bizInfo.updateUseSealResult(ctx
				+ "/mechseal/sealuse/autoSealAction_updateUseSealLog.action","#bizInfo",null);
		if (!updateRet.success) {
			ocxbase_messageHandler.dealErrorMssage(updateRet.data);
			return;
		}

		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		setTimeout(function() {
			dealUseSealProcess("end", ret.success, memo);
		}, ocxbase_iniHelper.configParam.overcapture_maincamera_delay);
	};
	
};

// 用印结束弹出纸板
function useSealCompletedOpenPaperDoor() {
	var ret = ocxbase_sealMachine.openPaperDoor(_doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}

	// 纸板关闭回调函数
	function _doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
		
		ocxbase_messageHandler.showTipMessage("是否继续下一笔业务？");
		ocxbase_messageHandler.showAllButton();
		ocxbase_messageHandler.hideButton(ocxbase_messageHandler.messageDialogHelper.btnTdId.ceTdId);
	}
};

// 开始下一笔用印
function startNextUseSeal() {
	resetPropsCache();
	ocxbase_messageHandler.showTipMessage("正在拍照处理中...");
	dealUseSealProcess("start", null, null);
};

// 结束用印
function completeUseSeal() {
	resetPropsCache();
};

//取消申请
function applycancel(){
	ocxbase_messageHandler.hideButton(ocxbase_messageHandler.messageDialogHelper.btnTdId.ceTdId);
	$("#verificationCode").attr("disabled", false);
	var url = ctx + "/mechseal/sealuse/autoSealAction_cancelTask.action";
	var param = {
			'bizInfo.autoId' : $("#bizid").val()
		};
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		ocxbase_messageHandler.hideWaittingDialog();
		if(data.response.responseMessage.success){
//			ocxbase_messageHandler.showTipMessage("用印任务取消成功");
		}else{
			ocxbase_messageHandler.showTipMessage(data.response.responseMessage.message);
			setTimeout(function(){
				ocxbase_messageHandler.hideWaittingDialog();
			}, 2000);
		}
	}else{
		ocxbase_messageHandler.showTipMessage(data.response);
		setTimeout(function(){
			ocxbase_messageHandler.hideWaittingDialog();
		},2000);
	}
}

// 重置属性缓存
function resetPropsCache() {
	clearBizElement();
	document.getElementById("voucherImg").onload = null;
	document.getElementById("voucherImg").src = ctx + "/3x/ocxbase/useSealFramework/ocxbase_voucherImg.png";
	ocxbase_messageHandler.hideWaittingDialog();
	src_img_path = null;
	cut_img_path = null;
	showMessage("");
	$("#applyBtnTd").css('display', '');
	$('#applyBtn').attr("disabled", false);
	$("#verificationCode").attr("disabled",false);
//	$("#billNo").attr("disabled",false);
	$("#bizInfo")[0].reset();
	$("#commitBtnTd").css('display', 'none');
	ocxbase_messageHandler.hideAllButton();
	$("#status").val("");
};

/**
 * 页面关闭响应事件
 */
function closePage() {
	ocxbase_machineAndCameraConnProxy.disconnect();
};
$.onunload(function() {
	ocxbase_machineAndCameraConnProxy.disconnect();
});

function showMessage(message) {
	$("#showMessage").html(message);
};

// 识别验证码失败处理
function dealRegCodeFail(errorMsg) {
	if (ocxbase_xusbVideo.lastImageCutSuccess()) {
		ocxbase_messageHandler.hideWaittingDialog();
		$("#verificationCode").attr("disabled", false);
		$("#verificationCode").focus();
		showMessage(errorMsg);
	} else {
		ocxbase_messageHandler.showTipMessage("凭证识别失败！</br>如果要继续下一笔业务，请先放入凭证，再关纸板！");
		useSealCompletedOpenPaperDoor();
	}
};

/**
 * 加载业务要素
 */
function initBizElement(elelist){
	clearBizElement();
	var bizhtml = '';
	$(elelist).each(function(i, value) {
	    bizhtml += '<tr class="bizelement"><td class="">'+
	    value.elementName+'</td><td><input disabled="disabled" class="form_textfiled_160" value="'+
	    value.elementValue+'"></input></td></tr>';
	});
	$("#biztable").append(bizhtml);
}

function clearBizElement(){
	$(".bizelement").remove();
}

// 用业务验证码识别业务信息
function checkUseSealInfo() {
	var checkRe = new Object();
	checkRe.success = false;
	checkRe.message = "";
	var code = $("#verificationCode").val();
	if (null == code || undefined == code || "" == code) {
		dealRegCodeFail("验证码识别错误");
		return;
	}
	var isAudit = false;//是否需要授权
	
	var param = {
		'bizInfo.checkCode' : code
	};
	var url = ctx + "/mechseal/sealuse/autoSealAction_queryUseSealBizinfo.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		var bizInfo = data.response.bizInfo;
		if (data.response.responseMessage.success) {
			if (bizInfo != null && bizInfo) {
				if(!(bizInfo.status == sealUseConstants.WAITTING_USE_SEAL 
						|| bizInfo.status == sealUseConstants.USE_SEAL_CANCEL 
						|| bizInfo.status == sealUseConstants.APPROVAL_TIMEOUT)){//不等于等待用印及已取消 则已处理
					ocxbase_messageHandler.showTipMessage("验证码已处理，不能继续用印<br>如果要继续下一笔业务，请先放入凭证，再关纸板！");
					showMessage("");
					useSealCompletedOpenPaperDoor();
				}else{
					$("#bizid").val(bizInfo.autoId);
					initBizElement(data.response.elementList);
					
					//验证码无需再校验，已匹配出交易数据
					checkRe.success = true;
					return checkRe;
					//校验凭证号
//					if(bizInfo.billNo == $("#billNo").val()){
//						$("#billNo").attr("disabled",true);
//						checkRe.success = true;
//						return checkRe;
//					}else{
//						isAudit = true;//需要授权
//						dealRegCodeFail("凭证号校验不通过");
//					}
				}
			} else {
				isAudit = true;//需要授权
				dealRegCodeFail("验证码校验不通过");
				ocxbase_messageHandler.hideWaittingDialog();
			}
		} else {
			isAudit = true;//需要授权
			ocxbase_messageHandler.showTipMessage("data.response.responseMessage.message");
		}
		if(isAudit){
			$("#commitBtnTd").css('display', "");
		}
		return checkRe;
	} else {
		showMessage("服务器响应失败：" + data.response);
		return checkRe;
	}
};

function setInputValue(inputname,vals){
	$("input[name='"+inputname+"']").val(vals);
}

/**
 * 用印申请倒计时
 */
function countapplytime(seconds) {
	if (seconds > 0) {
		ocxbase_messageHandler.showTipMessage("正在等待审核，请稍候....任务还剩" + seconds + "秒超时");
		seconds--;
		waitting_apprresult_timeout_clear = setTimeout("countapplytime(" + seconds + ")", 1000);
	} else {// 任务超时
		var autoId = $("#bizid").val();
		if (autoId) {
			window.clearTimeout(waitting_apprresult_timeout_clear);
			waitting_apprresult_timeout_clear = null;
			ocxbase_messageHandler.hideButton(ocxbase_messageHandler.btnTdId().ceTdId);
			var param = {
				'bizInfo.autoId' : autoId
			};
			var url = ctx + "/mechseal/sealuse/autoSealAction_tasktimeout.action";
			var data = tool.ajaxRequest(url, param);
			if(data.success){
				if (data.response.responseMessage.success){
					ocxbase_messageHandler.showTipMessage("用印审批超时, 取消用印成功.");
				}else{
					ocxbase_messageHandler.showTipMessage(data.response.responseMessage.message);
				}
			}else{
				ocxbase_messageHandler.showTipMessage(data.response);
			}
		}
	}
}
/**
 * 选择授权中心
 */
function checkAuditOrg(){
	var optParam = {
			isOrgNo:false,
			configType:3
	};
	$("#applyDialog").dialogAuditOrgTree("radio", top.loginPeopleInfo.orgSid, optParam, null,function(event, treeId, treeNode){
		if(treeNode){
			$("#auditorg").val(treeNode.organizationShowNameCode);
			setInputValue("taskOrg", treeNode.organizationNo);
		}
	},null,null);
}