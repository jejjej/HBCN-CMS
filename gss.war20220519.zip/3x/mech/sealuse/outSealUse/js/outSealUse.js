/**
 * 创建于:2017-3-23<br>
 * 版权所有(C) 2017 深圳市银之杰科技股份有限公司<br>
 * 机外用印js
 * 
 * @author 谭述文
 * @version 1.1.0
 */

var has_init_machine = false; // 印控机初始化标识
var is_side_door_open = false; // 侧门打开标识
var take_result = "upload"; // 取章用印结果
var open_camera_time = 0;
var video_folder = top.yzjgssRootPath + "\\yzjgss\\resources\\3x\\video\\";
var video_path = "";
var video_name = "";
var machine_order_success = "0"; // 印控机封装层返回成功
var login_people = null; // 人员信息
var chipSoftVersionTag = 0;// 主板备板标记 0主板 1版本
var memo = "主板取章";
var sparePartsNo = "G3600104";
var isDetectException;// 视频检测是否有异常，默认为false
// 视频检测模式 0为detect方法取mask， 1为detect方法， 2为watch方法。
// 设置1和2可在视频处理过程中切换处理的方法，常用watch方法
var detectMethod = 2;
// --------------------------------------------------------------
// -------------初始化-----------
// --------------------------------------------------------------
$().ready(
		function() {
			isDetectException = false;// 视频检测是否有异常，默认为false
			detectMethod = detectMethod || 2;
			initWaitingDialog();
			$("#id").val("");
			var ret = ocxbase_messageHandler.initOcx();
			if (!ret.success) {
				alert(ret.data);
				return;
			}
			;
			ret = ocxbase_xusbVideo.initOcx();
			if (!ret.success) {
				alert(ret.data);
				return;
			}
			;
			ret = ocxbase_sealMachine.initOcx();
			if (!ret.success) {
				alert(ret.data);
				return;
			}
			;

			ret = ocxbase_fileStore.initOcx(basePath)
			if (!ret.success) {
				alert(ret.data);
				return;
			}
			;

			// 初始化视频控件
			if (!ocxObject.initOcx(ocxObject.OCX_VideoRecorder, document.body,
					ctx + '/activex/api/', 'run')) {
				alert("初始化视频控件失败");
				return;
			}
			// 初始化视频检测控件
			if (!ocxObject.initOcx(ocxObject.OCX_VideoPaperSafeDetect,
					document.body, ctx + "/activex/api/", "run", 1, 1)) {
				alert("初始化视频检测控件失败");
				return;
			}
			// 初始化登录信息
			initLoginPeople();
			// 初始化异常用印日志处理器
			// deviceExceptionLogHandler.init(ctx);
			// 延时设备初始化
			showWaitingDialog("设备初始化中，请稍候...");
			window.setTimeout(function() {
				initMachine();
			}, 500);
		});

/**
 * 页面关闭响应事件
 */
$.onunload(function() {
	try {
		closeSealMachine();
	} catch (e) {
		// alert(e.message);
	}
});
/**
 * 初始化机构人员信息
 */
function initLoginPeople() {
	login_people = top.loginPeopleInfo;
};

/**
 * 初始化印控机
 */
function initMachine() {
	// 初始化印控机及打开摄像头
	initMachineAndOpenCamera();

	// 打开摄像头
	// openCameraDivice();
};

/**
 * 初始化印控机
 */
function initMachineAndOpenCamera() {
	if (!has_init_machine) {
		var initMachResult = ocxbase_sealMachine.initMachineForTakeSeal();

		if (initMachResult.success === false) {
			showWaitingDialog(initMachResult.data);
		}
		if (initMachResult.data.substr(0, 8) == sparePartsNo) {
			chipSoftVersionTag = 1;
			hideWaitingDialog();
		}
		has_init_machine = true;
		if (chipSoftVersionTag == 0) {
			openCameraDivice();
		}
	}
};

/**
 * 打开摄像头
 */
var has_open_camera_divice = false; // 摄像头打开标识
function openCameraDivice() {
	if (!has_open_camera_divice) {
		var openResult = ocxbase_xusbVideo._openCamera();
		if (openResult.success === false) {
			var message = openResult.data;
			showWaitingDialog(message);
		}
	}
};

/**
 * 摄像头就绪拍照事件
 */
function deviceReady1() {
	is_side_door_open = false;// 侧门未打开
	if (startRecord1() == false) {
		return;
	}
	setTimeout("openSideDoor()", 3000);
};
function openSideDoor() {
	var result = ocxbase_sealMachine.openSideDoor(closeBackdoorCallback,
			openBackdoorCallBack);
	if (result.success) {
		updateToOpenBackDoor();
		take_result = "upload";
		showWaitingDialog("已打开电子锁20秒之内打开侧门，并在90秒内取章用印....");
		countdown(90, 20);
	} else {
		showWaitingDialog("打开电子锁失败");
		setTimeout("hideWaitingDialog()", 5000);
	}
}

/**
 * 摄像头设备连接事件
 */
function deviceConnect(nConnectStatus) {
	// TODO
};

/**
 * 关闭印控机
 */
function closeSealMachine() {
	try {
		ocxbase_sealMachine.closeMachine();
	} catch (e) {
	}
};
/**
 * 打开电子锁
 * 
 * @returns
 */
function openMachineElecDoor() {
	// 关闭主摄像头
	ocxbase_xusbVideo.closeCamera();
	has_open_camera_divice = false;
	showWaitingDialog("请等待视频检测初始化");
	deviceReady1();
};

function conuntdown_(sec) {
	if (sec > 0) {
		if (!$("#waitingMsg").dialog('isOpen')) {
			$("#waitingMsg").dialog('open');
		}
		sec = sec - 1;
		$("#waitingMsg").html("已打开电子锁，请在" + sec + "秒内打开侧门");
		interval_down_clear = setTimeout("countdown_(" + sec + ")", 1000);
	} else {
		window.clearTimeout(interval_down_clear);
		setTimeout("hideWaitingDialog()", 1000);
		return;
	}

}

/**
 * 关闭印控机
 */
function closeSealMachine() {
	ocxbase_sealMachine.closeMachine();
};

/**
 * 更新打开侧门信息至机外用印日志
 */
function updateToOpenBackDoor() {
	var id = $("#id").val();
	var param = {
		"id" : id,
	};
	var url = ctx
			+ "/mechseal/sealuse/outSealUseAction_updateToOpenBackdoor.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		$("#id").val(data.response.id);
	} else {
		alert("更新日志状态失败：" + data.response);
	}
}

/**
 * 更新影像信息至机外用印日志
 * 
 * @param storeId
 *            存储id
 */
function updateToUploadVideo(storeId) {
	var id = $("#id").val();
	var param = {
		"id" : id,
		"storeId" : storeId,
		"result" : take_result
	};
	var url = ctx
			+ "/mechseal/sealuse/outSealUseAction_updateToUploadVideo.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		// return data.response.state;
		take_result = "upload";
	} else {
		alert("更新日志storeId失败：" + data.response);
	}
}

/**
 * 开始录像
 */
function startRecord1() {

	var date = (new Date()).Format("yyyyMMddhhmmssS");
	video_name = date + ".asf";
	video_path = video_folder + video_name;
	ocxbase_sealMachine.sealStartForLG();// 打开侧门处照明灯
	OCX_VideoPaperSafeDetect.getObj().SetExposure(-3);
	var result = OCX_VideoPaperSafeDetect.startAsfRecord3X(video_path,
			function(re) {
				hideWaitingDialog();
				window.clearTimeout(interval_down_clear);
				$("#waitingMsg").html("视频检测初始化异常");
				take_result = "initError";
			}, function(re) {
				if (take_result != "exception") {
					window.clearTimeout(interval_down_clear);
					$("#waitingMsg").html("视频检测发现异常");
					take_result = "exception";
				}
			});
	if (result.code != "1001") {
		alert("视频摄像头开启失败");
		return false;
	}
	return true;
}

var interval_down_clear;
// 设备连接异常计数 连续超过5次以上，计为设备连接异常
var connect_exception_count = 0;
/**
 * 关闭侧门倒计时 sec 关闭侧门倒计时 sec2 电子锁关闭倒计时
 */
function countdown(sec, sec2) {
	var status = ocxbase_sealMachine.sealQuery();
	if (!status.success) {
		connect_exception_count++;
		if (connect_exception_count >= 5) {
			// 通讯异常，断电检测
			$("#waitingMsg").html("设备连接异常");
			take_result = "error";
			setTimeout("closeBackdoorCallback()", 1000);
			return;
		}
	}
	connect_exception_count = 0;
	if ((!is_side_door_open && sec2 > 0) || (sec > 0 && is_side_door_open)) {
		if (is_side_door_open) {// 侧门打开
			if (!$("#waitingMsg").dialog('isOpen')) {
				$("#waitingMsg").dialog('open');
			}
			$("#waitingMsg").html("已打开电子锁，侧门，请在" + sec + "秒内完成取章用印并关闭侧门...");
			sec = sec - 1;
			interval_down_clear = setTimeout("countdown(" + sec + "," + sec2
					+ ")", 1000);
		} else {// 侧门未打开
			if (!$("#waitingMsg").dialog('isOpen')) {
				$("#waitingMsg").dialog('open');
			}
			sec2 = sec2 - 1;
			sec = sec - 1;
			$("#waitingMsg")
					.html(
							"已打开电子锁，请在" + sec2 + "秒内打开侧门，并在" + sec
									+ "秒内完成取章用印并关闭侧门...");
			interval_down_clear = setTimeout("countdown(" + sec + "," + sec2
					+ ")", 1000);
		}
	} else {
		window.clearTimeout(interval_down_clear);
		// 倒计时归零
		if (!is_side_door_open) {
			take_result = "unopen";
			is_side_door_open = false;
		} else {
			take_result = "overtime";
		}
		closeBackdoorCallback();
		return;
	}
}

/**
 * 侧门打开，继续录制
 */
function openBackdoorCallBack() {
	is_side_door_open = true;// 侧门已打开
}

/**
 * 关闭侧门->停止录制
 */
function closeBackdoorCallback() {
	// console.log("回调测试：侧门已关闭");
	window.clearTimeout(interval_down_clear);
	if (is_side_door_open) {
		showWaitingDialog("正在上传影像文件...");
		is_side_door_open = false;
		stopRecord();
	} else {
		endAsfVideo();
		hideWaitingDialog();
		updateToUploadVideo(null);
	}

}
/**
 * 关闭侧门摄像头，停止录制
 */
function endAsfVideo() {
	OCX_VideoPaperSafeDetect.endVideo(0);
	if (take_result == "exception" || take_result == "initError") {
		OCX_VideoPaperSafeDetect.endAsf();
	}
	ocxbase_sealMachine.closeOutLayLight();// 关闭外置照明灯
}
/**
 * 停止录制->上传影像
 */
function stopRecord() {
	endAsfVideo();
	has_open_camera_divice = false;
	wait_approving = "wait_approving";
	approval_result = wait_approving;
	setTimeout("uploadVideo()", 1000);
}

/**
 * 上传影像
 */
function uploadVideo() {
	var url = basePath + "store/curlFileStoreAction_addObject.action";
	// video_path = video_folder + "20151023170254108.avi";
	// video_name = "20151023170254108.avi";
	OCX_Libcurl.HttpUpload(url, video_path, {
		"fileFileName" : video_name
	}, function(data, seq, rurl, file, param) {
		if (data.state == "normal") {
			showWaitingDialog("上传影像成功");
			setTimeout("hideWaitingDialog()", 2000);
			var storeId = data.data;
			updateToUploadVideo(storeId);
		} else {
			hideWaitingDialog();
			alert("上传影像失败：" + data.responseMessage.message);
		}
	});
}

// --------------------------------------------------------------
// -----------等待界面------------
// --------------------------------------------------------------
function initWaitingDialog() {
	$("#waitingDialog").dialog({
		autoOpen : false,
		resizable : false,
		draggable : false,
		closeOnEscape : false,
		height : 290,
		width : 390,
		modal : true,
		open : function(event, ui) {
			$(".ui-dialog-titlebar").hide();
			$(".ui-dialog-titlebar-close").hide();
		}
	});
};

/**
 * 展示等待界面
 */
function showWaitingDialog(msg) {
	$("#waitingDialog").dialog("open");
	$("#waitingMsg").html(msg);
};

/**
 * 关闭等待界面
 */
function hideWaitingDialog() {
	$("#waitingDialog").dialog("close");
};