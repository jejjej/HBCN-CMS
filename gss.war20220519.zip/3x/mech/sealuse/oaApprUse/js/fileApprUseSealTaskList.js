/**
 * 创建于:2014-11-21<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 行政章批量用印JS<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var login_people = null; // 人员信息

var approval_mode = null; // 审批模式

var batch_use_appr_mode = null; // 批量用印审批模式

var use_seal_mode = null; // 用印模式 normal:普通 batch:批量

var first_appr_code = null; // 第一审核人员

var isShowDetailPage = true;//是否显示用印详情界面

var applyNum = null;//申请盖章数目

var usedNum = null;//已盖章数目

var now_applyNum = 0;//当前已选印章申请数目

var now_usedNum = 0;//当前已选印章已使用数目

var fileFtpUploadFlag = true;//当該值为true时,会将当前用印任务的所有图片一并上传;否则将不会向FTP服务器上传文件

var localMemo = "";//设置全局变量的memo(用印业务要素)

var autoSelect = false;

$(function() {
	initLoginPeople();
	initParam();
	initUseSealPage();
//	initTaskList();
});

/**
 * 初始化机构人员信息
 */
function initLoginPeople() {
	login_people = top.loginPeopleInfo;
};

/**
 * 初始化参数配置
 */
function initParam() {
	// 审批模式
	//approval_mode = tool.getApprovalModeByOrgAndBiz(login_people.orgNo, constants.ADMIN_SEAL_USE_APPLY, false);

	// 批量用印审批模式
	//batch_use_appr_mode = tool.getApprovalModeByOrgAndBiz(login_people.orgNo, constants.ADMIN_BATCH_USE_APPLY, false);
	var date1 = new Date();
    date1.setMonth(date1.getMonth()-1);
	$("#ge_applyTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
	
	$("#le_applyTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
	
	initTaskList();
	

	
	$("#submitForm").click(function() {
		$("#useSealList").jqGrid("search", "#search");
	});
	
	$("#clearForm").click(function() {
		$("#search")[0].reset();
		var date1 = new Date();
	    date1.setMonth(date1.getMonth()-1);
		$("#ge_applyTime").val(date1.Format("yyyy-MM-dd hh:mm:ss"));
		
		$("#le_applyTime").val((new Date()).Format("yyyy-MM-dd hh:mm:ss"));
		
	});
};


/**
 * 初始化任务列表
 */
function initTaskList() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 5;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight + 20 - pageHeaderHeight - 50 * 2;
	// 用印信息列表
	$("#useSealList")
			.jqGrid(
					{
						width : pageContentWidth,
						height : tableHeight + "px",
						url : ctx + "/mechseal/sealuse/autoSealAction_initUseSealList.action?moduleId=" + moduleId,
						multiselect : false,
						rowNum : 20,
						rownumbers : true,
						rowList : [20, 50, 100],
						colNames : [/*"OA流水号",*//* "印章类型id","印章类型名称",*/ "用印事由", "申请时间", "申请人","申请机构"/*"待用印次数", "已用印次数", "用印申请人", "用印机构" "印章所属机构",*/ /*"申请日期",*/ /*, "附件"*/, "操作"],
						colModel : [
								/*{
									name : "requestId",
									index : "requestId",
									align : "center",
									width : 120,
									sortable : false
								},*/
								/*{
									name : "tradeCode",
									index : "tradeCode",
									align : "center",
									width : 80,
									sortable : false
								},{
									name : "tradeCodeName",
									index : "tradeCodeName",
									align : "center",
									width : 80,
									sortable : false
								},*/
								{
									name : "materialName",
									index : "materialName",
									align : "center",
									sortable : false
								},	
								{
									name : "applyTime",
									index : "applyTime",
									align : "center",
									width : 80,
									sortable : false
								},
								{
									name : "applyPeopleName",
									index : "applyPeopleName",
									align : "center",
									width : 80,
									sortable : false,
									formatter: function(value, index, rData){
										return rData.applyPeopleName + "(" + rData.applyPeopleCode + ")";
									}
								},
								{
									name : "applyOrgNo",
									index : "applyOrgNo",
									align : "center",
									width : 80,
									sortable : false,
									formatter: function(value, index, rData){
										return rData.applyOrgName + "(" + rData.applyOrgNo + ")";
									}
								},
								/*{
									name : "applyNum",
									index : "applyNum",
									align : "center",
									width : 90,
									sortable : false
								},
								{
									name : "usedNum",
									index : "usedNum",
									align : "center",
									width : 90,
									sortable : false,
									formatter : function(value, options, rData) {
										return "<font color='red'>" + value + "</font>";
									}
								},
								{
									name : "applyPeopleName",
									index : "applyPeopleName",
									align : "center",
									width : 80,
									sortable : false
								},{
									name : "applyOrgName",
									index : "applyOrgName",
									align : "center",
									width : 80,
									sortable : false
								},
								{
									name : "sealOrgName",
									index : "sealOrgName",
									align : "center",
									width : "100",
									sortable : false
								},*/
								/*{
									name : "applyDeptName",
									index : "applyDeptName",
									align : "center",
									width : 90,
									sortable : false
								},*/
								/*{
									name : "batchNo",
									index : "batchNo",
									align : "center",
									width : 80,
									sortable : false,
									formatter : function(value, options, rData) {
										if (null == value || value == "") {
										    return "无附件";
										} else {
										    return "<a onclick=\"showBatch('"
											    + value + "')\" style='text-decoration:underline;color:blue;cursor: hand;'>附件下载</a>";
										}
									}
								},*/{
									name : "autoId",
									index : "autoId",
									align : "center",
									width : 85,
									sortable : false,
									formatter : function(value, options, rData) {
//										specialSing = rData.special;
										if("10" == rData.moduleName){
											return "<input type='button' style=\" width:65px; \"  onclick=\"startAutoSeal('"+value+"');\" value='自动用印' />"
											/*+ "<input type='button'  onclick=\"memoStartUseSeal('" + value + "','"+rData.bizMemo+"','"+rData.special+"','"+rData.applyMode+"');\" style=\" width:40px; \" value='用印' />"*/
											/*+ "<input type='button' onclick=\"startBatchUseSeal('" + value+ "');\" style=\" width:65px; \" value='批量用印'>"*/
											+ "<input type='button' style=\" width:65px; \"  onclick=\"finishSealUse('"+value+"');\" value='结束业务' />";
										}else{
											return "<input type='button'  onclick=\"memoStartUseSeal('" + value + "','"+rData.materialName+"','"+rData.special+"','"+rData.applyMode+"');\" style=\" width:65px; \" value='手动用印' />"
											/*+ "<input type='button' onclick=\"startBatchUseSeal('" + value+ "');\" style=\" width:65px; \" value='批量用印'>"*/
											+ "<input type='button' style=\" width:65px; \"  onclick=\"finishSealUse('"+value+"');\" value='结束业务' />";
										}
										
									}
								}],
						pager : "#useSealPager",
						caption : "用印任务列表"
					}).trigger("reloadGrid");
	$("#useSealList").navGrid("#useSealPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

/**
 * 用印开始前将memo设置到全局变量里面
 */
function memoStartUseSeal(autoId, bizMemo, special,applyMode){
//	alert("---" + applyMode);
	applyModeSing = applyMode;
	autoIdSing = autoId;
	specialSing = special;
	$("#localMemo").html("<span style='margin-top:100px;font-size:15px'>"+bizMemo+"</span>");
	startUseSeal(autoId);
}

function startAutoSeal(autoId){
//	window.location.href = "${ctx}/3x/mech/sealuse/autoUse/ui/seal.jsp";
//	var url = ctx + "/3x/mech/sealuse/autoUse/ui/seal.jsp?"+autoId+"";
	var url = ctx + "/3x/mech/sealuse/autoUse/ui/seal.jsp";
	window.location.href =url;
}

function showBatch(batchNo) {
   /* console.log("ajaxDownloadDirectly");
    var param = {
    "requestId" : $("#requestId").val(),
	"previewId" : $("#previewId").val()
    };
    var url = ctx + "/store/curlFileStoreAction_findImageData.action?storeId=" + batchNo;
    var data = tool.ajaxRequest(url, param);
    if (data.success) {
//	window.open("/"+requestId+"/"+fileName);
//    		$("#delegationDLG").dialog("close");
    }*/
	var url = ctx + "/store/curlFileStoreAction_findBatchData.action?storeId=" + batchNo;
	window.location.href =url;
//	window.open("www.baidu.com");
}

/**
 * 开始用印
 * 
 * @param autoId
 *            用印申请ID
 */
function startUseSeal(autoId) {
//	$("#detailAutoId").val(autoId);
	use_seal_mode = "normal";
	first_appr_code = "";
	$("#batchUseSealNumTr").css('display', "none");

	notNeedApproval(autoId);

	// 无需审批
	function notNeedApproval(autoId) {
		queryUseSealDetail(autoId);
	}

	// 只本地审批
	function localApprovalOnly(autoId) {
		var operAuth = new top.OperAuth();
		operAuth.operType = "adminBatchUseSeal"; // 权限 (action-auth.xml)
		operAuth.authSuccess = function(peopleCode) {
			if (!tool.isNull(peopleCode)) {
				first_appr_code = peopleCode;
				queryUseSealDetail(autoId);
			} else {
				alert("前台授权方式配置错误，请联系技术人员!");
			}
		};
		operAuth.authCancel = function() {
			// alert("用印申请未通过现场审核");
		};
		operAuth.auth();
	}

	// 仅远程审批
	function remoteApprovalOnly(autoId) {
		alert("暂不支持【仅远程审批】模式！");
	}

	// 现场且远程审批
	function localAndRemoteApproval(autoId) {
		alert("暂不支持【现场且远程审批】模式！");
	}

	// 现场或远程审批
	function localOrRemoteApproval(autoId) {
		alert("暂不支持【现场或远程审批】模式！");
	}
};

/**
 * 批量用印
 * 
 * @param autoId
 *            用印申请ID
 */
function startBatchUseSeal(autoId) {
	use_seal_mode = "batch";
	first_appr_code = "";
	$("#batchUseSealNumTr").css('display', "");

	notNeedApproval(autoId);

	// 无需审批
	function notNeedApproval(autoId) {
		queryUseSealDetail(autoId);
	}

	// 只本地审批
	function localApprovalOnly(autoId) {
		var operAuth = new top.OperAuth();
		operAuth.operType = "adminBatchUseSeal"; // 权限 (action-auth.xml)
		operAuth.authSuccess = function(peopleCode) {
			if (!tool.isNull(peopleCode)) {
				first_appr_code = peopleCode;
				queryUseSealDetail(autoId);
			} else {
				alert("前台授权方式配置错误，请联系技术人员!");
			}
		};
		operAuth.authCancel = function() {
			// alert("用印申请未通过现场审核");
		};
		operAuth.auth();
	}

	// 仅远程审批
	function remoteApprovalOnly(autoId) {
		alert("暂不支持【仅远程审批】模式！");
	}

	// 现场且远程审批
	function localAndRemoteApproval(autoId) {
		alert("暂不支持【现场且远程审批】模式！");
	}

	// 现场或远程审批
	function localOrRemoteApproval(autoId) {
		alert("暂不支持【现场或远程审批】模式！");
	}
};

/**
 * 将用户的选择的印章的相关信息放入页面隐藏域
 */
function sealSelect(){
	var multiStr = $("#sealUse option:selected").val();
	var array = multiStr.split("_");
	var t_mechsealinfoid = array[0];
	var t_tradecode = array[1];
	var t_sealOrgNo = array[2];
	
	var multiNumStr = $("#sealUse option:selected").text();
	var tmpInfo = multiNumStr.split("--");
	var now_tradeCodeName = tmpInfo[0];
	$("#tradeCodeName").val(now_tradeCodeName);
	multiNumStr = tmpInfo[1];
	var arrayinfo = multiNumStr.split("/");
	now_usedNum = parseInt(arrayinfo[0]);
	now_applyNum = parseInt(arrayinfo[1]);
	if(now_applyNum <= now_usedNum){
		if(!autoSelect){
			alert("当前印章所申请的用印数目已用尽！请使用其他印章...");
		}
		autoSelect = false;
		$.each($("#sealUse option:not(:selected)"), function(i, t){
			var text = $(t).text();
			var arrayNum = text.split("--")[1].split("/");
			if(parseInt(arrayNum[1]) > parseInt(arrayNum[0])){
				$(t).attr("selected", true);
				return false;
			}
		});
		$("#sealUse").change();
		return;
	}
	
//	ocxbase_utils.sealImageHandler.sealImageAngle = 0;//角度
//	ocxbase_utils.sealImageHandler.initBak("body", "voucherImg",t_point, t_point, ocxbase_utils.sealImageHandler.external.imageClickCallback);
	// 重置用印位置信息
	$("#xPosition").val("");
	$("#yPosition").val("");
	ocxbase_utils.sealImageHandler.clearSealImage();
	$("#rotateSealImage").css('display', 'none');
	if(multiStr == '-1' || t_tradecode == '' || t_tradecode == '-1'){
		$("#sealUse").val("-1");
		alert("请选择印章！");
		clearSelect();
		return;
	}else{
		$("#mechSealInfoId").val(t_mechsealinfoid);
		$("#tradeCode").val(t_tradecode);
		$("#sealOrgNo").val(t_sealOrgNo);
	}
}

/**
 * 查询用印详情
 */
function queryUseSealDetail(autoId) {
	OCX_Logger.info("开始查询用印业务信息,用印流水号为：" + autoId,"gsshd");
	var result = null;
	var success = false;
	$.ajax({
		type : "post",
		url : ctx + "/mechseal/sealuse/autoSealAction_gainTask.action",
		data : {
			"bizInfo.autoId" : autoId
		},
		dataType : "json",
		async : false,
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0" || XMLHttpRequest.status != "200") {
				result = '服务器响应失败';
			}
		},
		success : function(response) {
			result = response;
			if (response.responseMessage.success == true) {
				success = true;
			}
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
			if (textStatus != null) {
				result = textStatus;
			} else {
				result = errorThrown;
			}
		}
	});
	if (success) {
		OCX_Logger.info("查询用印业务信息成功。", "gsshd");
		if(isShowDetailPage){
			showUseSealPage(result);
		}
	} else {
		OCX_Logger.info("查询用印业务信息失败。" + autoId, "gsshd");
		alert(result.responseMessage.message);
	}
};

/**
 * 初始化用印页面
 */
function initUseSealPage() {
	$("#useSealApplyInfo").dialog({
		autoOpen : false,
		resizable : false,
		height : $("#body").height(), //不起作用
		width : multiply($("#body").width(), 59) / 60,
		modal : true,
		position : {
			at : "left top"
		},
		close : function() {
			clearSelect();
			closeDetail();
			initTaskList();
		}
	});
};

/**
 * 显示用印页面
 * 
 * @param response
 */
function showUseSealPage(response) {
	OCX_Logger.info("开始处理用印业务信息。", "gsshd");
	try {
		if (response.responseMessage.message == "normal") {
//			var paramTradeCode = response.paramTradeCode;
			var bizInfo = response.bizInfo;
			if (!tool.isNull(bizInfo)) {
				$("#useSealApplyInfo").dialog("open");
				$("#useSealApplyInfo").css("height", $("#body").height()-8);
				var batchUseSealNumVal = "";
//				$.each(bizInfo.sealUseList, function(i, sealUseInfo){
//					batchUseSealNumVal += sealUseInfo.usedNum + "/" + sealUseInfo.applyNum + "|";
//				});
				if(batchUseSealNumVal.length > 0){
					batchUseSealNumVal = batchUseSealNumVal.substring(0, batchUseSealNumVal.length -1);
				}
				$("#batchUseSealNum").val(batchUseSealNumVal);
//				$("#usedNum").val(bizInfo.usedNum);
//				$("#applyNum").val(bizInfo.sealUseList.applyNum);
//				$("#applyNum").val(bizInfo.applyNum);
				$("#detailAutoId").val(bizInfo.autoId);
//				alert($("#detailAutoId").val(bizInfo.id));
				$("#requestId").val(bizInfo.requestId);
//				$("#batchNo").val(bizInfo.batchNo);
//				$("#fileOwnerName").val(bizInfo.fileOwnerName);
				
//				OCX_Logger.info("业务信息为:" + sealBizTypeName, "gsshd");
				$("#sealUse").empty();
//				$("#sealUse").append("<option value='-1'>" + "--- 请选择 ---" + "</option>");

				usedNum = 0;
				applyNum = 0;
				$.each(bizInfo.mechSealInfos,function(i, mechSealInfo){
					$("#sealUse").append(
							"<option value='" + mechSealInfo.id + "_" + mechSealInfo.tradeCode + "_" + mechSealInfo.sealOrgNo + "'>" + mechSealInfo.tradeCodeName + " -- " + mechSealInfo.usedNum + "/"
							+ mechSealInfo.applyNum + "</option>");
					usedNum += mechSealInfo.usedNum;
					applyNum += mechSealInfo.applyNum;
				});
				/**
				 *  $("#tradeCode").val(bizInfo.tradeCode);
					$("#sealOrg").val(bizInfo.sealOrgName);
					$("#sealOrgNo").val(bizInfo.sealOrgNo);
				*/
				if (usedNum == applyNum || bizInfo.status == sealUseConstants.USE_SEAL_SUCCESS) {
					biz_finish = true; // batchUseSeal.js
					OCX_Logger.info("本用印申请单已全部盖章完毕，申请次数为：" + applyNum
							+ ",用印次数为：" + usedNum, "gsshd");
					ocxbase_messageHandler.showTipMessage("本用印申请单已全部盖章完毕！"); // batchUseSeal.js
					// 冗余代码 comment by chenhuang 2016-5-12
					$("#completeUseSealBtnId").css('display', ""); // batchUseSeal.js
				} else {
					OCX_Logger.info("用印业务信息处理完毕，准备打开纸板。", "gsshd");
					// 打开纸板
					openPaperDoor(); // batchUseSeal.js
				}

				left_over_use_num = applyNum - usedNum; // batchUseSeal.js
				OCX_Logger.info("剩余用印次数为：" + left_over_use_num, "gsshd");
				autoSelect = true;
				$("#sealUse").change();
			} else {
				alert("印章类型[" + $("#tradeCode").val() + "]未配置！");
			}
		} else {
			alert(response.responseMessage.data);
		}
	} catch (e) {
		alert(e.message);
	}
};

function startViewImage(storeId) {
	wfStoreFancyBox.showAllImageByStoreId(storeId, "buttons");
};

/**
 * 关闭详情页面
 */
function closeDetail() {
	try {
		var autoId = $("#detailAutoId").val();
		if (!tool.isNull(autoId)) {
			var url = ctx + "/mechseal/sealuse/batchUseSealTaskAction_unlockTask.action";
			var data = {
				"bizInfo.autoId" : autoId
			};
			tool.ajaxRequest(url, data);
		}
	} catch (e) {
		alert(e.message);
	} finally {
		resetDetail();
	}
};

/**
 * 重置详情页面属性
 */
function resetDetail() {
	$("#detailAutoId").val("");
	$("#fileOwnerName").val("");
	$("#storeId").val("");
	$("#sealNum").val("");
	biz_finish = false; // batchUseSeal.js
	left_over_use_num = null; // batchUseSeal.js
};

function isBatchUseSeal() {
	return (use_seal_mode == "batch") ? true : false;
}

function finishSealUse(autoId){
	if(confirm("确定结束本笔业务？一旦结束，将不可恢复")){		
		
		isShowDetailPage=true;
		biz_finish=true;
		$("#detailAutoId").val(autoId);
		var memo="手动结束本笔业务";
		var updateRet = finishUseSealApplyInfo(memo);
		if (!updateRet.success) {
			OCX_Logger.info("结束本笔业务失败，异常信息为：" + updateRet.data, "gsshd");;
			ocxbase_messageHandler.dealErrorMssage(updateRet.data);
			return;
		}else{
			$.success("结束业务成功");
			fileFtpUploadFlag = false;
			completeUseSeal();
			fileFtpUploadFlag = true;//手动结束任务完成后，将判断标志恢复原值
		}

	}
};



