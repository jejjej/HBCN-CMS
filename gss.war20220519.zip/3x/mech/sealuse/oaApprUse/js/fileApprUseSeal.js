/**
 * 创建于:2015-10-29<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 机控文件审批用印JS（可以单独用印或者多张凭证盖在同一个位置上多票据用印）<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */


function myApplyInit() {
    $("#delegationDLG").dialog({
	autoOpen : false,
	resizable : false,
	height : 240,
	width : 450,
	modal : true,
	buttons : {},
	close : function() {
	    $("#form")[0].reset();
	}
    });
    $(".ui-dialog").css("padding-left", 0);
    $(".ui-dialog").css("padding-top", 0);
};
var machine_num;

// 图片尺寸误差
var size_deviation = 0.05;

// 使用的摄像头分辨率常数
var CAMERA_RES_WIDTH = 2048;
var CAMERA_RES_HEIGHT = 1536;

var xPositionNotChange = "";
var yPositionNotChange = "";

// 凭证图像
var use_cut_img = true;
var src_img_path, cut_img_path;
var big_pic_width = 0, big_pic_height = 0;
var small_pic_width = 0, small_pic_height = 0;
var display_pic_width = 0, display_pic_height = 0;

//标记是否下一笔用印 1是下一笔 
var nextSeal_left_over_use_num = 0;
var usedNum = "";
var applyNum = "";

// 用印数据
var use_model = {
	"isFirst" : true,
	"firstImgWidth" : 0,
	"firstImgHeight" : 0
};

var biz_finish = false; // 一笔业务盖章完毕
var left_over_use_num = null; // 剩余的用印数量
var batch_used_num = 0; // 一次批量用印，已用印的次数
var FinishBy ;

$().ready(
		function() {
			// 初始化控件
			var ret = ocxbase_messageHandler.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			ret = ocxbase_fileStore.initOcx(basePath);
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			ret = ocxbase_xusbVideo.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			ret = ocxbase_sealMachine.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			//版面识别控件
			ret = ocxbase_imageProcessing.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};

			// 盖章位置印章图片处理
			ocxbase_utils.sealImageHandler.init("body", "voucherImg",
					ocxbase_utils.sealImageHandler.external.imageClickCallback);

			// 绑定onclick事件
			$("#applyBtn").bind("click", openPaperDoor);
			
			$("#applyBtn1").bind("click", openPaperDoor);
//			修改为判断是否需要授权操作 
			$("#commitBtn").bind("click", isNeedAuth);
//			$("#commitBtn").bind("click", useSeal); 
			$("#switchVoucherImage").bind("click", switchVoucherImage);
			$("#rotateSealImage").bind("click", ocxbase_utils.sealImageHandler.rotateSealImage);
			$("#sealUse").live("change", sealSelect);
			
			ocxbase_messageHandler.bindNextUseSealClickEvent(startNextUseSeal);
			ocxbase_messageHandler.bindCompleteClickEvent(completeUseSeal);
			
			// 初始化设备
			ocxbase_messageHandler.showTipMessage("设备初始化中，请稍候...");
			window.setTimeout(function() {
				var connResult = ocxbase_machineAndCameraConnProxy.connect(machineReady);
				if (!connResult.success) {
					ocxbase_messageHandler.dealErrorMssage(connResult.data);
				}
			}, 1500);
		});

/*预览文件列表*/
function previewDoc() {
    
    var param = {
		"requestId" : $("#requestId").val(),
		"batchNo" : $("#batchNo").val()
	};
    if(null == $("#batchNo").val() || "" == $("#batchNo").val() || "nocheckcode" == $("#batchNo").val()){
    	alert("此任务无附件！");
    	return;
    }
    var url = ctx + "/mechseal/sealuse/batchUseSealTaskAction_fetchFileList.action";
    var data = tool.ajaxRequest(url, param);
//    var html = "";
    if (data.success) {
//    	alert(data.response.webResponseJson.data);
    	var array = [];
    	var json = data.response.webResponseJson.data;
    	$.each(json, function(i,val){
    		var arrayTemp = [];    
    		arrayTemp .push(json[i]);
    		array.push(arrayTemp);
    	});
    	$("#previewId").empty();
    	$("#previewId").append("<option value='-1'>"+"---请选择---"+"</option>");
    	$.each(array, function(i,val){
//    		alert(i); 
//    		alert(val);
//    		html="<option value='i'>"+val+"</option>";
    		$("#previewId").append("<option value='"+val+"'>"+val+"</option>");
    	}); 
    }else{
    	alert("预览附件失败！");
    	return;
    }
    $("#delegationDLG").dialog("open");
};

function submitForm() {
	var fileName = $("#previewId").val();
	if(fileName == '-1'){
		alert("请选择待预览的文件！");
		return;
	}
	var batchNo = $("#batchNo").val();
//    var param = {
//    "batchNo" : $("#batchNo").val(),
//	"previewId" : $("#previewId").val()
//    };
//    var url = ctx + "/mechseal/sealuse/batchUseSealTaskAction_downLoadOneFile.action";
//    var data = tool.ajaxRequest(url, param);
//    if (data.success) {
	window.open("/"+fileName);
//	window.open("/1副本1.xls");
	$("#delegationDLG").dialog("close");
//    }
//    window.open(ctx+ "/11111.docx");
};

/**
 * 手动关闭附件预览页面
 */
function exitAttachmentPreview(){
	$("#delegationDLG").dialog("close");
}

/*function download(){
	window.open("/1.jpg");
	 
};*/

/*function queryForm(){
	var url = ctx + "/mechseal/sealuse/batchUseSealTaskAction_test.action";
	$('#form').attr("action", url).submit();; 
};*/

// 设备连接结果回调事件
function machineReady(ret) {
	if (ret.success) {
		machine_num = ocxbase_sealMachine.getMachineNum();

		// 初始化用印范围红框顶点数据 sealBoundaryUtil.js
		var boundaryRet = setMaxMinDistance(machine_num, ocxbase_xusbVideo.defaultProp);
		if (!boundaryRet) {
			return;
		}

		ocxbase_messageHandler.hideWaittingDialog();
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}
};

// 用印前打开纸板
function openPaperDoor() {
	$('#applyBtn').attr("disabled", true);

	ocxbase_utils.sealImageHandler.clearSealImage();
	$("#rotateSealImage").css('display', 'none');
	var ret = ocxbase_sealMachine.openPaperDoor(doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	} else {
		ocxbase_messageHandler.showTipMessage("请放入凭证...");
	}

	// 纸板关闭回调函数
	function doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		var captureInterval = ocxbase_iniHelper.readGssIni("captureInterval", 1500);
		OCX_Logger.info("执行用印前纸板关闭回调，准备开始处理用印流程，延时[" + captureInterval + "ms]",
				"gsshd");
		setTimeout(function() {
			dealUseSealProcess("start", null, null);
		}, captureInterval);
	}
};

/**
 * 用印过程处理<br>
 * 
 * @param state：'start'、'end'
 * @param useSealSuccess：true/false(非用印结束时可传入null)
 * @param useSealErrorMsg：用印异常信息(非用印结束时可传入null)
 */
function dealUseSealProcess(state, useSealSuccess, useSealErrorMsg, endCallback) {
	OCX_Logger.info("~~~~~~~~~~~用印流程处理开始，当前流程为:[" + state + "]~~~~~~~~~~~", "gsshd");
	var srcImgPath, cutImgPath;
	OCX_Logger.info("用印流程处理，拍照开始", "gsshd");
	var ret = ocxbase_xusbVideo.captureImage(false);
	if (ret.success) {
		OCX_Logger.info("用印流程处理，拍照成功", "gsshd");
		srcImgPath = ret.data.srcImagePath;
		cutImgPath = ret.data.cutImagePath;
		src_img_path = srcImgPath;
		cut_img_path = cutImgPath;
		OCX_Logger.info("用印流程处理，原图路径为：" + src_img_path, "gsshd");
		OCX_Logger.info("用印流程处理，裁剪图路径为：" + cut_img_path, "gsshd");
		// 显示凭证图像
		if (use_cut_img) {
			document.getElementById("voucherImg").src = cutImgPath;
			OCX_Logger.info("用印流程处理，裁剪图凭证图像显示完成...", "gsshd");
		} else {
			document.getElementById("voucherImg").src = srcImgPath;
			OCX_Logger.info("用印流程处理，原图凭证图像显示完成...", "gsshd");
		}
	} else {
		OCX_Logger.info("用印流程处理，拍照失败", "gsshd");
		ocxbase_messageHandler.dealErrorMssage(ret.data);
		if(endCallback != null && endCallback != undefined){
			endCallback();
		}
		return;
	}

	if ("start" == state) {
		OCX_Logger.info("用印流程处理，盖章前流程处理开始...", "gsshd");
		// 计算图像裁剪前后的大小
		var cutSize = ocxbase_xusbVideo.getLastCutImageSize();
		if (cutSize.success) {
			small_pic_width = cutSize.data.width;
			small_pic_height = cutSize.data.height;
			big_pic_width = CAMERA_RES_WIDTH;
			big_pic_height = CAMERA_RES_HEIGHT;
			OCX_Logger.info("用印流程处理，获取图片size成功...", "gsshd");
			OCX_Logger.info("用印流程处理，小图宽为：" + small_pic_width, "gsshd");
			OCX_Logger.info("用印流程处理，小图高为：" + small_pic_height, "gsshd");
			OCX_Logger.info("用印流程处理，大图宽为：" + big_pic_width, "gsshd");
			OCX_Logger.info("用印流程处理，大图高为：" + big_pic_height, "gsshd");
		} else {
			OCX_Logger.info("用印流程处理，获取图片size失败...", "gsshd");
			ocxbase_messageHandler.dealErrorMssage(cutSize.data);
			if(endCallback != null && endCallback != undefined){
				endCallback();
			}
			return;
		}

		// 显示用印边界线
		queryCornerPoints(small_pic_width, small_pic_height, big_pic_width, big_pic_height);
		OCX_Logger.info("用印流程处理，显示用印边界线完成...", "gsshd");
		document.getElementById("voucherImg").onload = function() {
			var img = document.getElementById("voucherImg");
			display_pic_width = img.width;
			display_pic_height = img.height;
			if (use_cut_img) {
				showBoundaryCanvas("sealCanvasDiv", "voucherImg", use_cut_img, small_pic_width, small_pic_height);
			} else {
				showBoundaryCanvas("sealCanvasDiv", "voucherImg", use_cut_img, small_pic_width, small_pic_height);
			}
		};

		// 释放相应按钮
		$("#commitBtn").css('display', "");
		showSwitchVoucherImageBtn();
		ocxbase_messageHandler.hideWaittingDialog();
		OCX_Logger.info("用印流程处理，盖章前流程处理结束...", "gsshd");
	} else if ("end" == state) {
		OCX_Logger.info("用印流程处理，盖章后流程处理——>开始...", "gsshd");
		OCX_Logger.info("用印流程处理，盖章后流程处理——>上传用印后图像开始", "gsshd");
		var uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cutImgPath, "append");
		if (!uploadRet.success) {
			OCX_Logger.error("用印流程处理，盖章后流程处理——>上传用印后图像失败", "gsshd");
			ocxbase_messageHandler.dealErrorMssage(uploadRet.data);

			if(endCallback != null && endCallback != undefined){
				endCallback();
			}
			return;
		}
		if (useSealSuccess) {
			OCX_Logger.info("用印流程处理，盖章后流程处理——>上传用印后图像成功", "gsshd");
			ocxbase_messageHandler.showTipMessage("盖章完毕，请取凭证！</br>如果要继续下一笔业务，请先放入凭证，再关纸盒！");
			OCX_Logger.info("用印流程处理，盖章后流程处理——>打开纸板", "gsshd");
			useSealCompletedOpenPaperDoor();
		} else {
			OCX_Logger.info("用印流程处理，盖章后流程处理——>上传用印后图像失败，失败信息为：" + useSealErrorMsg, "gsshd");
			ocxbase_messageHandler.dealErrorMssage(useSealErrorMsg);

			if(endCallback != null && endCallback != undefined){
				endCallback();
			}
			return;
		}
		OCX_Logger.info("用印流程处理，盖章后流程处理结束", "gsshd");
	}

	if(endCallback != null && endCallback != undefined){
		endCallback();
	}
	$('#applyBtn').attr("disabled", false);
	OCX_Logger.info("~~~~~~~~~~~用印流程处理结束，当前流程为:[" + state + "]~~~~~~~~~~~", "gsshd");
	
};

function showMessage(message) {
	$("#showMessage").html(message);
};

//用印前打开纸板
function openDoor() {
	$('#applyBtn').attr("disabled", true);
	showMessage("");
	
	var ret = ocxbase_sealMachine.openPaperDoor(doorCloseBack);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	} else {
		ocxbase_messageHandler.showTipMessage("请放入凭证...");
	}

	// 纸板关闭回调函数
	function doorCloseBack(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		setTimeout(function() {
			dealUseSeal("start", null, null);
		}, ocxbase_iniHelper.configParam.closecapture_maincamera_dealy);
	}
};

/**
 * 版式识别过程处理<br>
 * 
 * @param state：'start'、'end'
 * @param useSealSuccess：true/false(非用印结束时可传入null)
 * @param useSealErrorMsg：用印异常信息(非用印结束时可传入null)
 */
function dealUseSeal(state, useSealSuccess, useSealErrorMsg) {
	var srcImgPath, cutImgPath, transImagePath;
	var ret = ocxbase_xusbVideo.captureImage(true, state);
	if (ret.success) {
		srcImgPath = ret.data.srcImagePath;
		cutImgPath = ret.data.cutImagePath;
		transImagePath = ret.data.transImagePath;
		src_img_path = srcImgPath;
		cut_img_path = cutImgPath;
		
		// 显示凭证图像
//		document.getElementById("voucherImg").src = transImagePath;
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
		return;
	}

	if ("start" == state) {
		// 识别凭证号
		var regRet = ocxbase_imageProcessing.recognizeVoucher(machine_num, cutImgPath);
		if (regRet.success) {
			document.getElementById("voucherImg").src = regRet.data.voucherInfo.revolvedImg;
			//不需要验证码
//			$("#verificationCode").val(regRet.data.verificationCodeInfo.code);
//			$("#billNo").val(regRet.data.billCodeInfo.code);
//			$("#billNo").attr("disabled",true);
			/*var res_ = checkUseSealInfo();
			if(res_.success){
				useSeal();
			}*/
			useSeal();
		} else {
			if (regRet.data.voucherInfo != null && regRet.data.voucherInfo.revolvedImg != null) {
				document.getElementById("voucherImg").src = regRet.data.voucherInfo.revolvedImg;
			}
			alert(regRet.data.errorMsg);
			localAuth();
		}
		
	} else if ("end" == state) {
		var uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cutImgPath, "append");
		if (!uploadRet.success) {
			ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
			return;
		}
		if (useSealSuccess) {
			ocxbase_messageHandler.showTipMessage("盖章完毕，请取凭证！</br>如果要继续下一笔业务，请先放入凭证，再关纸板！");
			useSealCompletedOpenPaperDoor();
		} else {
			ocxbase_messageHandler.dealErrorMssage(useSealErrorMsg);
			return;
		}
	}

	$('#applyBtn').attr("disabled", false);
};

/*
 * 判断是否需要授权操作
 */
function isNeedAuth(){
	var xPosition = $("#xPosition").val();
	var yPosition = $("#yPosition").val();
	var tradeCode = $("#tradeCode").val();
	var sealOrgNo = $("#sealOrgNo").val();
	var sealSn = $("#sealSn").val();
	var batchUseSealNum = $("#batchUseSealNum").val();
	if (!xPosition || !yPosition) {
		alert("请选择盖章坐标!");
		ocxbase_messageHandler.hideWaittingDialog();
		return;
	}
	if (!tradeCode) {
		alert("请选择印章类型!");
		ocxbase_messageHandler.hideWaittingDialog();
		return;
	}
	
	machine_num = ocxbase_sealMachine.getMachineNum();
	//判断此设备的印控机是否处于启用状态
	var result = isEnable(machine_num);
	if (!result){
		ocxbase_messageHandler.showTipMessage("当前设备未启用，请先启用设备！");
		return;
	}
	if(null != specialSing && "" != specialSing && "null" != specialSing && "1" == specialSing){
		localAuth();
	}else{
		//不需要授权则进行版式识别(版式识别通过则盖章，不通过则跳转到授权操作)
		//按照现有的需求，目前只识别门柜的版式
		/*if(sealUseConstants.USE_SEAL_FROM_MENGUI == applyModeSing){
			dealUseSeal("start", null, null);
		}else{
			useSeal();
		}*/
		useSeal();
//		openDoor();
	}
}

/*本地授权*/
function localAuth() {
	var operAuth = new top.OperAuth();
	operAuth.operType = "fileApprUseSeal_check"; // 权限 (action-auth.xml)
	operAuth.orgLevel = "self";//同机构用户才能审核
	operAuth.authSuccess = function(peopleCode) {
		if (!tool.isNull(peopleCode)) {
			check_people = peopleCode;
			$("#checkPeopleCode").val(check_people);
			//用印完一笔之后将数据设置为不需要审核(重新进任务再需要审核)
			specialSing = 0;
			useSeal();
		} else {
			alert("印章装卸授权方式配置错误，请联系技术人员!");
		}
	};
	operAuth.authCancel = function() {
//		alert("必须同机构授权人授权");
	};
	operAuth.auth();
}

//判断设备是否启用
function isEnable(machine_num){
	var result = "";
	$.ajax({
		type : "POST",
		url : top.ctx + "/mms/managerSealDeviceAction!findEnabledMachine.action",
		data : {"sealDevice.deviceNum" : machine_num},
		dataType : "json",
		async : false,
		success : function(data) {
			if(data.responseMessage.success){
				result = data.responseMessage.data;
			}
		}
	
	});
	return result;
}

// 用印
function useSeal() {
	$("#" + ocxbase_utils.sealImageHandler.sealImageDivId).css('display', 'none');
	OCX_Logger.info("***********用印函数处理开始***********", "gsshd");
	var xPosition = $("#xPosition").val();
	var yPosition = $("#yPosition").val();
	var tradeCode = $("#tradeCode").val();
	var sealOrgNo = $("#sealOrgNo").val();
	var sealSn = $("#sealSn").val();
	var batchUseSealNum = $("#batchUseSealNum").val();
	if (!xPosition || !yPosition) {
		alert("请选择盖章坐标!");
		ocxbase_messageHandler.hideWaittingDialog();
		return;
	}
	if (!tradeCode) {
		alert("请选择印章类型!");
		ocxbase_messageHandler.hideWaittingDialog();
		return;
	}
	
	machine_num = ocxbase_sealMachine.getMachineNum();
	//判断此设备的印控机是否处于启用状态
	var result = isEnable(machine_num);
	if (!result){
		ocxbase_messageHandler.showTipMessage("当前设备未启用，请先启用设备！");
		return;
	}
	
	if (isBatchUseSeal()) { // -> batchUseSealTaskList.js
		var format = /^\+?[1-9][0-9]*$/;
		if (!format.test(batchUseSealNum) || batchUseSealNum <= 0 || batchUseSealNum > left_over_use_num) {
			alert("请输入有效的用印次数");
			ocxbase_messageHandler.hideWaittingDialog();
			$("#batchUseSealNum").focus();
			return;
		}
	}
	
	OCX_Logger.info("用印坐标选择完成，xPosition：" + xPosition + "，yPosition + " + yPosition + "， tradeCode：" + tradeCode + "， sealOrgNo：" + sealOrgNo + "，batchUseSealNum：" + batchUseSealNum , "gsshd");

	ocxbase_messageHandler.showTipMessage("准备开始用印...");

	// 隐藏切换图片按钮
	$("#switchVoucherImageId").css('display', 'none');

	// 上传用印前凭证图像
	var uploadRet;
	OCX_Logger.info("用印开始，上传用印前图像开始", "gsshd");
	if (use_cut_img) {
		OCX_Logger.info("用印开始，上传用印前图像路径为：" + cut_img_path, "gsshd");
		uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cut_img_path, "add");
	} else {
		OCX_Logger.info("用印开始，上传用印前图像路径为：" + src_img_path, "gsshd");
		uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(src_img_path, "add");
	}
	if (!uploadRet.success) {
		OCX_Logger.info("用印开始，上传用印前图像失败，失败信息为：" + uploadRet.data, "gsshd");
		ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
		return;
	}
	OCX_Logger.info("用印开始，上传用印前图像成功，图像存储ID为：" + $("#storeId").val(), "gsshd");

	// 是否盖骑缝章
	var isAcrossPageSeal = false;
	var useSealPattern = $("#useSealPattern").val();
	if (useSealPattern == "2") {
		isAcrossPageSeal = true;
	}

	// 计算盖章角度
	var angle;
	var cutAngle = ocxbase_xusbVideo.getLastCutImageAngle();
	if (cutAngle.success) {
		angle = cutAngle.data + ocxbase_utils.sealImageHandler.getSealAngle();
		angle = (angle + 360) % 360;
	} else {
		ocxbase_messageHandler.dealErrorMssage(cutAngle.data);
		return;
	}

	// 计算盖章坐标
	// 用原图还是裁剪图片
	var imgWidth = big_pic_width;
	var imgHeight = big_pic_height;
	if (use_cut_img) {
		imgWidth = small_pic_width;
		imgHeight = small_pic_height;
	}
	// 用印裁剪图片并裁剪成功时需计算在原图中的坐标
	var useSealXpos = multiply(xPosition / 100, imgWidth);
	var useSealYpos = multiply(yPosition / 100, imgHeight);
	if (!ocxbase_xusbVideo.imageIs2048_1536(imgWidth, imgHeight)) {
		var ret = ocxbase_xusbVideo.getLastCutInSrcPosition(useSealXpos, useSealYpos);
		if (ret.success) {
			useSealXpos = ret.data.x;
			useSealYpos = ret.data.y;
		} else {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
	}

	if (isBatchUseSeal()) { // -> batchUseSealTaskList.js
		OCX_Logger.info("用印开始，本次用印为批量用印模式...", "gsshd");
		
		// 记录第一次用印信息
		if (use_model["isFirst"]) {
			use_model["isFirst"] = false;
			use_model["firstImgWidth"] = imgWidth;
			use_model["firstImgHeight"] = imgHeight;
			OCX_Logger.info("用印开始，设置批量用印数据成功，imgWidth = " + imgWidth
					+ "，imgHeight = " + imgHeight, "gsshd");
		} else {
			// 判断是否与原纸大小一致
			if (!checkPaper(use_model["firstImgWidth"], use_model["firstImgHeight"], imgWidth, imgHeight)) {
				OCX_Logger.info("用印开始，批量用印模式，检测到更换了纸张，需重新选章并设置盖章位置后进行用印...", "gsshd");
				alert("检测到更换了纸张，请重新选章并设置盖章位置后进行用印!");
				ocxbase_messageHandler.hideWaittingDialog();
				return;
			}
			OCX_Logger.info("用印开始，批量用印模式影像大小检测成功...", "gsshd");
		}
	}

	// 新增用印业务信息
	$("#machineNo").val(machine_num);
	OCX_Logger.info("用印开始，创建用印日志...", "gsshd");
	var creatRet = updateBatchUseSealApplyInfo(sealUseConstants.LOG_STATUS_START_USE, "开始用印");
	if (!creatRet.success) {
		OCX_Logger.info("用印开始，用印日记创建失败，用印终止，失败信息为：" + creatRet.data, "gsshd");
		ocxbase_messageHandler.dealErrorMssage(creatRet.data);
		return;
	}
	
	OCX_Logger.info("用印开始，创建用印日志成功，机器正在用印...", "gsshd");
	
	ocxbase_messageHandler.showTipMessage("正在用印...");

	// 开始用印
	/*var useRet = ocxbase_sealMachine.useSeal(sealOrgNo, tradeCode, isAcrossPageSeal, angle, useSealXpos, useSealYpos,
			useSealCallback);*/
	var useRet = ocxbase_sealMachine.startUseSeal(tradeCode, isAcrossPageSeal, angle, useSealXpos, useSealYpos,
			useSealCallback);
	if (!useRet.success) {
		ocxbase_messageHandler.dealErrorMssage(useRet.data);
		/*if("此登录人员无使用该印章权限" == useRet.data){
			var status = sealUseConstants.USE_SEAL_REFUSE;
			var logStatus = sealUseConstants.LOG_STATUS_REFUSE;
			var memo = useRet.data;
			
			//调用无权用印时的日志处理方法
			oaSealUseRefusedProcess(memo,status,logStatus);
			ocxbase_messageHandler.hideWaittingDialog();
			alert(useRet.data);
		}else{
			ocxbase_messageHandler.dealErrorMssage(useRet.data);
		}*/
		return;
	}
	
	// 用印结束回调函数
	function useSealCallback(ret) {
		OCX_Logger.info("用印结束，用印结束回调函数执行开始...", "gsshd");
		// 保存用印信息
		var memo, status, logStatus;
		if (ret.success) {
			OCX_Logger.info("用印结束，本次用印成功...", "gsshd");
			if (isBatchUseSeal()) { // -> batchUseSealTaskList.js
				batch_used_num++;
				OCX_Logger.info("用印结束，批量用印模式，已用印次数为：" + batch_used_num, "gsshd");
			}
			status = sealUseConstants.USE_SEAL_SUCCESS;
			logStatus = sealUseConstants.LOG_STATUS_SUCCESS;
			memo = ret.data.message;
			$("#sealPosition").val(ret.data.sealPos);
			OCX_Logger.info("用印结束，本次用印印章位置为：" + ret.data.sealPos, "gsshd");
		} else {
			memo = ret.data.errMsg;
			if (ret.data.errCode == "USE_SEAL_DISCONNECT") {
				status = sealUseConstants.USE_SEAL_DISCONNECT;
				logStatus = sealUseConstants.LOG_STATUS_DISCONNECT;
			} else if (ret.data.errCode == "USE_SEAL_ERROR") {
				logStatus = sealUseConstants.LOG_STATUS_FAIL;
			}
			OCX_Logger.info("用印结束，本次用印异常，异常代码为：" + ret.data.errCode + "，异常信息为：" + memo + "，日志状态为：" + logStatus, "gsshd");
		}
		$("#status").val(status);
		$("#bizMemo").val(memo);
		$("#logMemo").val(memo);
		
		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		var captureInterval = ocxbase_iniHelper.readGssIni("captureInterval", 1500);
		OCX_Logger.info("用印结束，用印结束回调函数执行——>准备用印后拍照，延时[" + captureInterval + "]", "gsshd");;
		setTimeout(function() {
			dealUseSealProcess("end", ret.success, memo, function(){
				var updateRet = updateBatchUseSealApplyInfo(logStatus, memo);
				OCX_Logger.info("用印结束，用印结束回调函数执行——>更新用印状态", "gsshd");;
				if (!updateRet.success) {
					OCX_Logger.info("用印结束，用印结束回调函数执行——>更新用印状态失败，异常信息为：" + updateRet.data, "gsshd");;
					ocxbase_messageHandler.dealErrorMssage(updateRet.data);
					return;
				}
				
			});
		}, captureInterval);
	}
	OCX_Logger.info("***********用印函数处理结束***********", "gsshd");
};

/**
 * 无权用印时的日志处理函数
 */
function oaSealUseRefusedProcess(memo,status,logStatus){
	
	$("#status").val(status);
	$("#bizMemo").val(memo);
	$("#logMemo").val(memo);
	
	//更新用印申请状态以及用印日志信息
	var updateRet = updateBatchUseSealApplyInfo(logStatus, memo);
	OCX_Logger.info("无权用印，日志中更新用印状态", "gsshd");
	if (!updateRet.success) {
		OCX_Logger.info("无权用印状态下，更新用印状态失败，异常信息为：" + updateRet.data, "gsshd");;
		ocxbase_messageHandler.dealErrorMssage(updateRet.data);
		return;
	}
}

// 用印结束弹出纸板
function useSealCompletedOpenPaperDoor() {
	var ret = ocxbase_sealMachine.openPaperDoor(_doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}

	// 纸板关闭回调函数
	function _doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}

		if (biz_finish) {
			/*if(sealUseConstants.USE_SEAL_FROM_XINDAI == applyModeSing){
//				alert(autoIdSing);
				sendXinDaiMessage();
			}*/
			/*if(sealUseConstants.USE_SEAL_FROM_OA == applyModeSing){
//				alert(autoIdSing);
//				alert(applyModeSing);
				sendOAMessage();
			}*/
			ocxbase_messageHandler.showTipMessage("本次用印申请单已全部盖章完毕！");
			ocxbase_messageHandler.showCompleteButton();
		} else {
			if (isBatchUseSeal()) { // -> batchUseSealTaskList.js
				// 批量用印不用再选印章和位置，直接继续用印
				if (batch_used_num >= $("#batchUseSealNum").val()) {
					ocxbase_messageHandler.showTipMessage("是否继续下一笔业务？");
					ocxbase_messageHandler.showAllButton();
				} else {
					ocxbase_messageHandler.showTipMessage("正在拍照处理中...");
					dealUseSealProcess("start", null, null);
					useSeal();
				}
			} else {
				ocxbase_messageHandler.showTipMessage("是否继续下一笔业务？");
				ocxbase_messageHandler.showAllButton();
			}
		}
	}
};


/**
 * 返回用印信息状态给信贷系统
 */
function sendXinDaiMessage() {
		var autoId = $("#detailAutoId").val();
		if (!tool.isNull(autoId)) {
			var url = ctx + "/mechseal/sealuse/mechSealUseApplyAction_sendXinDaiMessage.action";
			var param = {
				"id" : autoId
			};
			var data = tool.ajaxRequest(url, param);
			if (data.success) {
				OCX_Logger.info("返回门柜用印信息状态上传成功");
			}else{
				OCX_Logger.info("返回门柜用印信息状态上传失败");
			}
	}
};

/**
 * 返回用印信息状态给OA系统
 */
function sendOAMessage() {
		var autoId = $("#detailAutoId").val();
		if (!tool.isNull(autoId)) {
			var url = ctx + "/mechseal/sealuse/mechSealUseApplyAction_sendOAMessage.action";
			var param = {
				"id" : autoId
			};
			var data = tool.ajaxRequest(url, param);
			if (data.success) {
//				alert("返回OA用印信息状态上传成功");
				OCX_Logger.info("返回OA用印信息状态上传成功");
			}else{
				OCX_Logger.info("返回OA用印信息状态上传失败");
			}
	}
};
// 开始下一笔用印
function startNextUseSeal() {
	left_over_use_num = nextSeal_left_over_use_num;
	resetPropsCache();
	autoSelect = true;
	$("#sealUse").change();
	ocxbase_messageHandler.showTipMessage("正在拍照处理中...");
	dealUseSealProcess("start", null, null);
};

// 结束用印
function completeUseSeal() {
	resetPropsCache();

	// 用印完成
	if (biz_finish) {
		$("#useSealApplyInfo").dialog("close");
		/*var param = {
				"requestId" : $("#requestId").val()
		};
		if(fileFtpUploadFlag){//用印任务正常结束
			var url = ctx + "/mechseal/sealuse/batchUseSealTaskAction_sealUsefileUpload.action";
			var data = tool.ajaxRequest(url, param);
			if (data.success) {
				alert("文件上传完成");
			}else{
				alert("文件上传失败");
			}
		}*/
		resetDetail(); // batchUseSealTaskList.js
		initTaskList(); // batchUseSealTaskList.js
	}else{
		autoSelect = true;
		$("#sealUse").change();
	}
};

/**
 * 返回页面
 */
function rebackTask(){

	$("#status").val("");
	$("#tradeCode").val("");
	$("#tradeCodeName").val("");
	$("#sealSn").val("");
	$("#sealOrgNo").val("");
	// 重置用印位置信息
	$("#xPosition").val("");
	$("#yPosition").val("");
	ocxbase_utils.sealImageHandler.clearSealImage();
	$("#rotateSealImage").css('display', 'none');
	$("#useSealApplyInfo").dialog("close");
	resetDetail(); // batchUseSealTaskList.js
	initTaskList(); // batchUseSealTaskList.js
};
/**
 * 返回页面
 */
function clearSelect(){

	$("#status").val("");
	$("#tradeCode").val("");
	$("#tradeCodeName").val("");
	$("#sealSn").val("");
	$("#sealOrgNo").val("");
	// 重置用印位置信息
	$("#xPosition").val("");
	$("#yPosition").val("");
	ocxbase_utils.sealImageHandler.clearSealImage();
	$("#rotateSealImage").css('display', 'none');
};


// 切换凭证裁剪前后图像
function switchVoucherImage() {
	// 切换凭证图像
	if (use_cut_img) {
		use_cut_img = false;
		document.getElementById("voucherImg").src = src_img_path;
	} else {
		use_cut_img = true;
		document.getElementById("voucherImg").src = img_path;
	}

	// 重置用印位置信息
	$("#xPosition").val("");
	$("#yPosition").val("");
	ocxbase_utils.sealImageHandler.clearSealImage();
	$("#rotateSealImage").css('display', 'none');
};

function showSwitchVoucherImageBtn() {
	if (fast_switch_voucher_image) {
		$("#switchVoucherImageId").css('display', '');
	}
};

// 重置属性缓存
function resetPropsCache() {
	document.getElementById("voucherImg").onload = null;
	clearSealCanvas("sealCanvasDiv");
	document.getElementById("voucherImg").src = ctx + "/3x/ocxbase/useSealFramework/ocxbase_voucherImg.png";
	ocxbase_messageHandler.hideWaittingDialog();
	use_cut_img = true;
	src_img_path = null;
	cut_img_path = null;
	$("#applyBtn").css('display', '');
	$('#applyBtn').attr("disabled", false);
	$("#commitBtn").css('display', 'none');
	ocxbase_messageHandler.hideAllButton();
	ocxbase_utils.sealImageHandler.clearSealImage();
	$("#rotateSealImage").css('display', 'none');
//	$("#status").val("");
//	$("#tradeCode").val("");
//	$("#tradeCodeName").val("");
//	$("#sealSn").val("");
//	$("#sealOrgNo").val("");
	use_model["isFirst"] = true;
	use_model["firstImgWidth"] = 0;
	use_model["firstImgHeight"] = 0;

	$("#xPosition").val("");
	$("#yPosition").val("");

	batch_used_num = 0;
	$("#batchUseSealNum").val("");
};

// 页面关闭响应事件
function closePage() {
	ocxbase_machineAndCameraConnProxy.disconnect();

//	closeDetail();// -> batchUseSealTaskList.js
};

/**
 * 保存用印信息
 * 
 * @param sealUseStatus
 *            {@see sealUseConstants.sealUseLogStatus}
 */
var log_autoid = "";
function updateBatchUseSealApplyInfo(sealUseLogStatus, memo) {
	var param = {
		"bizInfo.autoId" : $("#detailAutoId").val(),
		"mechSealUseLog.autoId" : log_autoid,
		"mechSealUseLog.sealPos" : $("#sealPosition").val(),
		"mechSealUseLog.status" : sealUseLogStatus,
		"mechSealUseLog.machineNum" : $("#machineNo").val(),
		"mechSealUseLog.storeId" : $("#storeId").val(),
		"mechSealUseLog.checkPeopleCode" : $("#checkPeopleCode").val(),
		"mechSealUseLog.memo" : memo,
		"mechSealUseLog.firstApprPeopleCode" : first_appr_code,
		"mechSealInfo.id" : $("#mechSealInfoId").val(),
		"mechSealInfo.sealType" : $("#tradeCode").val(),
		"mechSealInfo.sealTypeName" : $("#tradeCodeName").val()
	};
	OCX_Logger.info("更新用印信息，请求参数为：[bizInfo.autoId=" + $("#detailAutoId").val()
			+ ",mechSealUseLog.autoId=" + log_autoid
			+ ",mechSealUseLog.storeId=" + $("#storeId").val()
			+ ",mechSealUseLog.memo=" + memo + "]", "gsshd");
	log_autoid = null;
	var url = ctx + "/mechseal/sealuse/batchUseSealTaskAction_updateUseSealInfo.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		if (data.response.webResponseJson.state == "normal") {
			log_autoid = data.response.mechSealUseLog.autoId;
			var bizInfo = data.response.bizInfo;
			OCX_Logger.info("更新用印信息成功，日志ID为：" + log_autoid, "gsshd");
			OCX_Logger.info("更新用印信息成功，业务状态为：" + bizInfo.status, "gsshd");
			OCX_Logger.info("更新用印信息成功，已用印次数为：" + bizInfo.usedNum, "gsshd");
			OCX_Logger.info("更新用印信息成功，申请用印次数为：" + bizInfo.applyNum, "gsshd");
//			var paramTradeCode = data.response.paramTradeCode;
//			var sealBizTypeName = bizInfo.tradeCodeName + " -- " + bizInfo.usedNum + "\\" + bizInfo.applyNum;
			$("#sealUse").empty();
//			$("#sealUse").append(
//					"<option value='" + bizInfo.tradeCode + "'>" + sealBizTypeName + "</option>");
			usedNum = 0;
			applyNum = 0;
//			$("#sealUse").append("<option value='-1'>" + "--- 请选择 ---" + "</option>");
			$.each(bizInfo.mechSealInfos,function(i, mechSealInfo){
				/*$("#sealUse").find("option[value='"+mechSealInfo.id + "_" + mechSealInfo.sealType + "_" + mechSealInfo.OrgNo+"'").html(mechSealInfo.sealTypeName + " -- " + mechSealInfo.usedNum + "\\"
						+ mechSealInfo.applyNum);*/
				
				$("#sealUse").append(
						"<option value='" + mechSealInfo.id + "_" + mechSealInfo.tradeCode + "_" + mechSealInfo.sealOrgNo + "'>" + mechSealInfo.tradeCodeName + " -- " + mechSealInfo.usedNum + "/"
						+ mechSealInfo.applyNum + "</option>");
				usedNum += mechSealInfo.usedNum;
				applyNum += mechSealInfo.applyNum;
			});
			if(usedNum == applyNum ||bizInfo.status == sealUseConstants.USE_SEAL_SUCCESS){
//				$("#sealUse").append("<option value='-1'>" + "--- 请选择 ---" + "</option>");
				biz_finish = true;
			}
//			if (bizInfo.usedNum == bizInfo.applyNum || bizInfo.status == sealUseConstants.USE_SEAL_SUCCESS) {
//				/*OCX_Logger.info("更新用印信息成功，判断该笔业务用印已经完成，准备提交工作流任务...", "gsshd");
//				var activeRet = activeFinishUseSealWorkFlow();
//				if (!activeRet.success) {
//					OCX_Logger.info("更新用印信息成功，判断该笔业务用印已经完成，任务提交失败,异常信息为：" + activeRet.data, "gsshd");
//					return activeRet;
//				}*/
//				biz_finish = true;
//			}
			
//			nextSeal_left_over_use_num = bizInfo.applyNum - bizInfo.usedNum;
			nextSeal_left_over_use_num = applyNum - usedNum;
			OCX_Logger.info("更新用印信息成功，剩余用印次数为：" + nextSeal_left_over_use_num, "gsshd");
			return ocxbase_utils.genOptResult(true, null);
		} else {
			return ocxbase_utils.genOptResult(false, data.response.webResponseJson.data);
		}
	} else {
		return ocxbase_utils.genOptResult(false, "更新用印结果服务器响应失败：" + data.response);
	}	
};

/**
 * 判断纸张大小是否发生改变
 * 
 * @param modlex
 * @param modley
 * @param picx
 * @param picy
 * @returns {Boolean}
 */
function checkPaper(modlex, modley, picx, picy) {
	var xVerify = Math.abs(modlex - picx) / modlex;
	var yVerify = Math.abs(modley - picy) / modley;
	if (xVerify > size_deviation || yVerify > size_deviation)
		return false;
	return true;
};

function finishUseSealApplyInfo(memo) {
	var param = {
		"bizInfo.autoId" : $("#detailAutoId").val(),
		"bizInfo.status": sealUseConstants.USE_SEAL_HANDPASS,
		"bizInfo.memo" : memo,
		"taskResult" : sealUseConstants.RESULT_USE_SEAL_FINISH
	};
//	业务任务信息提交任务
	var url = ctx + "/mechseal/sealuse/batchUseSealTaskAction_finishBizInfoDirectly.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
 		return ocxbase_utils.genOptResult(true, null);
	}
/*		if (data.response.webResponseJson.state == "normal") {
			//工作流提交任务
			var url = ctx + "/mechseal/sealuse/batchUseSealTaskAction_commitTask.action";
			var data = tool.ajaxRequest(url, param);
			if (data.success) {
				if (data.response.responseMessage.success == true) {
					return ocxbase_utils.genOptResult(true, null);
				}else{
					return ocxbase_utils.genOptResult(false, "结束行政章文件审批用印工作流服务器响应失败：" + data.response.responseMessage.message);
				}
			}else{
				return ocxbase_utils.genOptResult(false, "结束行政章文件审批用印工作流服务器响应失败：" + data.response);
			}
		}
		else{
			return ocxbase_utils.genOptResult(false, "更新用印结果服务器响应失败：" + data.response);
		}
	}
*/
}

