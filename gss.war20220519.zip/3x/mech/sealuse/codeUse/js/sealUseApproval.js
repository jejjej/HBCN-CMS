/**
 * 创建于:2014-9-10<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 机控用印审批JS
 * 
 * @author 孙强
 * @author Rickychen
 * @version 1.0.0
 */

$().ready(function() {
	queryBizInfo();
});

/**
 * 获取业务信息
 */
function queryBizInfo() {
	var url = ctx + "/mechseal/sealuse/approvalUseMechSealAction_queryBizInfo.action";
	var data = tool.ajaxRequest(url, "");
	if (data.success) {
		var bizInfo = data.response.webResponseJson.data;
		if (data.response.webResponseJson.state == "normal") {
			if (bizInfo == null) {
				closeBtn();
				showMessage1("暂无用印申请");
				reset();
				return;
			}
			showMessage("");
			var money = bizInfo["extInfo"]["money"];
			if (money != null && money != undefined && money != "") {
				bizInfo["extInfo"]["money"] = money / 100;
			}
			tool.initForm(bizInfo);
			$("#sealName").val(data.response.sealName);
			document.getElementById("fileImg").src = data.response.url;
		} else {
			alert(bizInfo);
		}
	} else {
		alert("服务器响应失败：" + data.response);
	}
};

/**
 * 审核通过
 */
function approvalPass() {
	var bizInfo = $('#bizInfo').serialize();
	var url = ctx + "/mechseal/sealuse/approvalUseMechSealAction_approvalPass.action";
	var data = tool.ajaxRequest(url, bizInfo);
	if (data.success) {
		var result = data.response.data;
		if (data.response.state == "normal") {
			showMessage(result);
			queryBizInfo();
		} else {
			alert(result);
		}
	} else {
		alert("服务器响应失败：" + data.response);
	}
};

/**
 * 审核拒绝
 */
function approvalRefuse() {
	var bizInfo = $('#bizInfo').serialize();
	var url = ctx + "/mechseal/sealuse/approvalUseMechSealAction_approvalRefuse.action";
	var data = tool.ajaxRequest(url, bizInfo);
	if (data.success) {
		var result = data.response.data;
		if (data.response.state == "normal") {
			showMessage(result);
			queryBizInfo();
		} else {
			alert(result);
		}
	} else {
		alert("服务器响应失败：" + data.response);
	}
};

/**
 * 取消锁定
 */
function unlockApproval() {
	var url = ctx + "/mechseal/sealuse/approvalUseMechSealAction_unlockApproval.action";
	var data = tool.ajaxRequest(url, "");
	if (data.success) {
		var result = data.response.data;
		if (data.response.state == "normal") {
			// 解锁成功，前台不做任何操作
		} else {
			alert(result);
		}
	} else {
		if (!data.response == "") {
			alert("解锁时服务器响应失败：" + data.response);
		}
	}
};

/**
 * 显示提示信息
 * 
 * @param message
 *            信息
 */
function showMessage(message) {
	$("#showMessage").html(message);

};

function showMessage1(message) {
	$("#showMessage1").html(message);
};

/**
 * 隐藏按钮
 */
function closeBtn() {
	$("#btn").css('display', 'none');
};

/**
 * 重置页面
 */
function reset() {
	$("#bizInfo")[0].reset();
	document.getElementById("fileImg").src = ctx + "/3x/ocxbase/useSealFramework/ocxbase_voucherImg.png";
};