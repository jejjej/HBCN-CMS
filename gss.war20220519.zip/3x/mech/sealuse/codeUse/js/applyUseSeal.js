/**
 * 创建于:2015-10-27<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 机控印章打码用印JS（通过识别验证码自动盖章）<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var machine_num;

// 使用的摄像头分辨率常数
var CAMERA_RES_WIDTH = 2048;
var CAMERA_RES_HEIGHT = 1536;

// 凭证图像
var src_img_path, cut_img_path;

$().ready(function() {
	// 初始化控件
	var ret = ocxbase_messageHandler.initOcx();
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	ret = ocxbase_fileStore.initOcx(basePath);
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	ret = ocxbase_xusbVideo.initOcx();
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	ret = ocxbase_sealMachine.initOcx();
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	ret = ocxbase_imageProcessing.initOcx();
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};

	// 绑定onchange事件
	$('#verificationCode').change(function() {
		initMechSealUseApplyInfoForm();
	});

	// 绑定onclick事件
	$("#applyBtn").bind("click", openPaperDoor);
	$("#commitBtn").bind("click", applyUseSeal);

	ocxbase_messageHandler.bindNextUseSealClickEvent(startNextUseSeal);
	ocxbase_messageHandler.bindCompleteClickEvent(completeUseSeal);

	// 初始化设备
	ocxbase_messageHandler.showTipMessage("设备初始化中，请稍候...");
	window.setTimeout(function() {
		var connResult = ocxbase_machineAndCameraConnProxy.connect(machineReady);
		if (!connResult.success) {
			ocxbase_messageHandler.dealErrorMssage(connResult.data);
		}
	}, 500);
});

// 设备连接结果回调事件
function machineReady(ret) {
	if (ret.success) {
		machine_num = ocxbase_sealMachine.getMachineNum();

		openPaperDoor();
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}
};

// 用印前打开纸板
function openPaperDoor() {
	$('#applyBtn').attr("disabled", true);

	var ret = ocxbase_sealMachine.openPaperDoor(doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	} else {
		ocxbase_messageHandler.showTipMessage("请放入凭证...");
	}

	// 纸板关闭回调函数
	function doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		setTimeout(function() {
			dealUseSealProcess("start", null, null);
		}, 500);
	}
};

/**
 * 用印过程处理<br>
 * 
 * @param state：'start'、'end'
 * @param useSealSuccess：true/false(非用印结束时可传入null)
 * @param useSealErrorMsg：用印异常信息(非用印结束时可传入null)
 */
function dealUseSealProcess(state, useSealSuccess, useSealErrorMsg) {
	var srcImgPath, cutImgPath, transImagePath;
	var ret = ocxbase_xusbVideo.captureImage(true, state);
	if (ret.success) {
		srcImgPath = ret.data.srcImagePath;
		cutImgPath = ret.data.cutImagePath;
		transImagePath = ret.data.transImagePath;
		src_img_path = srcImgPath;
		cut_img_path = cutImgPath;

		// 显示凭证图像
		document.getElementById("voucherImg").src = transImagePath;
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
		return;
	}

	if ("start" == state) {
		// 识别业务验证码
		var regRet = ocxbase_imageProcessing.recognizeVoucher(machine_num, cutImgPath);
		if (regRet.success) {
			document.getElementById("voucherImg").src = regRet.data.voucherInfo.revolvedImg;
			$("#verificationCode").val(regRet.data.verificationCodeInfo.code);
			initMechSealUseApplyInfoForm();
		} else {
			if (regRet.data.voucherInfo != null && regRet.data.voucherInfo.revolvedImg != null) {
				document.getElementById("voucherImg").src = regRet.data.voucherInfo.revolvedImg;
			}

			dealRegCodeFail(regRet.data.errorMsg);
		}
	} else if ("end" == state) {
		var uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cutImgPath, "append");
		if (!uploadRet.success) {
			ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
			return;
		}
		if (useSealSuccess) {
			ocxbase_messageHandler.showTipMessage("盖章完毕，请取凭证！</br>如果要继续下一笔业务，请先放入凭证，再关纸盒！");
			useSealCompletedOpenPaperDoor();
		} else {
			ocxbase_messageHandler.dealErrorMssage(useSealErrorMsg);
			return;
		}
	}

	$('#applyBtn').attr("disabled", false);
};

// 向服务器提交用印申请
function applyUseSeal() {
	$("#verificationCode").attr("disabled", false);

	// 上传用印前凭证图像
	var uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cut_img_path, "add");
	if (!uploadRet.success) {
		ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
		return;
	}

	// 提交用印申请信息
	var bizInfo = $('#mechSealUseApplyInfo').serializeArray();
	$.each(bizInfo, function(i, field) {
		if (field.name == "applyExtInfo.money_long") {
			bizInfo[i].value = multiply(field.value, 100);
		}
	});
	$("#verificationCode").attr("disabled", true);
	var url = ctx + "/mechseal/sealuse/applyUseMechSealAction_applyUseMechSeal.action";
	var data = tool.ajaxRequest(url, bizInfo);
	if (data.success) {
		var result = data.response.webResponseJson.data;
		if (data.response.webResponseJson.state == "normal") {
			ocxbase_messageHandler.showTipMessage("正在等待审核，请稍候....");

			var param = {
				'verificationCode' : $("#verificationCode").val()
			};
			var url = ctx + "/mechseal/sealuse/applyUseMechSealAction_findApprovalResult.action";
			ocxbase_bizInfoAjax.approvalHandler.startWaitApproalResultThread(url, param, endApprovalCallback)
		} else {
			showMessage(result);
		}
	} else {
		ocxbase_messageHandler.dealErrorMssage("服务器响应失败：" + data.response);
	}

	// 审批结束
	function endApprovalCallback(ret) {
		if (ret.success) {
			useSeal();
		} else {
			ocxbase_messageHandler.showTipMessage(ret.data + "</br>如果要继续下一笔业务，请先放入凭证，再关纸盒！");

			// 审核不通过时，先提示“不通过”再延迟弹出纸板，可以调整timeout的时间亦可去掉timeout
			setTimeout(function() {
				useSealCompletedOpenPaperDoor();
			}, 3000);
		}
	}
};

// 用印
function useSeal() {
	ocxbase_messageHandler.showTipMessage("准备开始用印...");

	// 获取盖章信息
	$("#machineNum").val(machine_num);
	var paperDirection, voucherUseSealXpos, voucherUseSealYpos;
	var useSealInfoRet = queryBizSealInfo();
	if (!useSealInfoRet.success) {
		ocxbase_messageHandler.dealErrorMssage(useSealInfoRet.data);
		return;
	} else {
		paperDirection = ocxbase_imageProcessing.getRecognitionResult().voucherInfo.direction;
		if (paperDirection == 0) {
			voucherUseSealXpos = useSealInfoRet.data.useSealXposition0;
			voucherUseSealYpos = useSealInfoRet.data.useSealYposition0;
		} else if (paperDirection == 90) {
			voucherUseSealXpos = useSealInfoRet.data.useSealXposition90;
			voucherUseSealYpos = useSealInfoRet.data.useSealYposition90;
		} else if (paperDirection == 180) {
			voucherUseSealXpos = useSealInfoRet.data.useSealXposition180;
			voucherUseSealYpos = useSealInfoRet.data.useSealYposition180;
		} else if (paperDirection == 270) {
			voucherUseSealXpos = useSealInfoRet.data.useSealXposition270;
			voucherUseSealYpos = useSealInfoRet.data.useSealYposition270;
		} else {
			ocxbase_messageHandler.dealErrorMssage("凭证旋转角度未定义");
			return;
		}
	}

	// 用印裁剪图片并裁剪成功时需计算在原图中的坐标
	var xPosInPictrue, yPosInPictrue;
	var ret = ocxbase_xusbVideo.getLastCutInSrcPosition(voucherUseSealXpos, voucherUseSealYpos);
	if (ret.success) {
		xPosInPictrue = ret.data.x;
		yPosInPictrue = ret.data.y;
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
		return;
	}

	// 计算盖章角度
	var angle = 0;
	if (normal_use_seal_rotate) {
		var cutAngle = ocxbase_xusbVideo.getLastCutImageAngle();
		if (cutAngle.success) {
			angle = cutAngle.data + paperDirection;
			angle = (angle + 360) % 360;
		} else {
			ocxbase_messageHandler.dealErrorMssage(cutAngle.data);
			return;
		}
	}

	var creatRet = ocxbase_bizInfoAjax.bizInfo.createStartUseMechSeal(ctx
			+ "/mechseal/sealuse/specialUseMechSealAction_creatStartUseMechSealLog.action");
	if (!creatRet.success) {
		ocxbase_messageHandler.dealErrorMssage(creatRet.data);
		return;
	}

	ocxbase_messageHandler.showTipMessage("正在用印...");

	// 开始用印
	var useRet = ocxbase_sealMachine.useSeal(useSealInfoRet.data.tradeCode, false, angle, xPosInPictrue, yPosInPictrue,
			useSealCallback);
	if (!useRet.success) {
		ocxbase_messageHandler.dealErrorMssage(useRet.data);
		return;
	}

	// -------内部函数--------
	// 用印结束回调函数
	function useSealCallback(ret) {
		// 保存用印信息
		var memo, status;
		if (ret.success) {
			status = sealUseConstants.USE_SEAL_SUCCESS;
			memo = ret.data.message;
			$("#sealPosition").val(ret.data.sealPos);
		} else {
			memo = ret.data.errMsg;
			if (ret.data.errCode == "USE_SEAL_DISCONNECT") {
				status = sealUseConstants.USE_SEAL_DISCONNECT;
			} else if (ret.data.errCode == "USE_SEAL_ERROR") {
				status = sealUseConstants.USE_SEAL_EXCEPTION;
			}
		}
		$("#status").val(status);
		$("#bizMemo").val(memo);
		$("#logMemo").val(memo);
		var updateRet = ocxbase_bizInfoAjax.bizInfo.updateUseMechSealResult(ctx
				+ "/mechseal/sealuse/applyUseMechSealAction_updateUseMechSealResult.action");
		if (!updateRet.success) {
			ocxbase_messageHandler.dealErrorMssage(updateRet.data);
			return;
		}

		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		setTimeout(function() {
			dealUseSealProcess("end", ret.success, memo);
		}, 500);
	};

	// 获取业务的印章信息
	function queryBizSealInfo() {
		var tradeCode = $("#tradeCode").val();
		if (null == tradeCode || "" == tradeCode) {
			return ocxbase_utils.genOptResult(false, "交易码不存在");
		}

		var param = {
			'tradeCode' : tradeCode,
			'sealMachineCode' : machine_num
		};
		var url = ctx + "/mechseal/sealuse/applyUseMechSealAction_findBizSealInfo.action";
		var data = tool.ajaxRequest(url, param);
		if (data.success) {
			var bizSealInfo = data.response.webResponseJson.data;
			if (data.response.webResponseJson.state == "normal") {
				return ocxbase_utils.genOptResult(true, bizSealInfo);
			} else {
				return ocxbase_utils.genOptResult(false, bizSealInfo);
			}
		} else {
			return ocxbase_utils.genOptResult(false, "服务器响应失败：" + data.response);
		}
	};
};

// 用印结束弹出纸板
function useSealCompletedOpenPaperDoor() {
	var ret = ocxbase_sealMachine.openPaperDoor(_doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}

	// 纸板关闭回调函数
	function _doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}

		ocxbase_messageHandler.showTipMessage("是否继续下一笔业务？");
		ocxbase_messageHandler.showAllButton();
	}
};

// 开始下一笔用印
function startNextUseSeal() {
	resetPropsCache();
	ocxbase_messageHandler.showTipMessage("正在拍照处理中...");
	dealUseSealProcess("start", null, null);
};

// 结束用印
function completeUseSeal() {
	resetPropsCache();
};

// 重置属性缓存
function resetPropsCache() {
	document.getElementById("voucherImg").onload = null;
	document.getElementById("voucherImg").src = ctx + "/3x/ocxbase/useSealFramework/ocxbase_voucherImg.png";
	ocxbase_messageHandler.hideWaittingDialog();
	src_img_path = null;
	cut_img_path = null;
	$("#applyBtnTd").css('display', '');
	$('#applyBtn').attr("disabled", false);
	$("#mechSealUseApplyInfo")[0].reset();
	$("#commitBtnTd").css('display', 'none');
	ocxbase_messageHandler.hideAllButton();
	$("#status").val("");
};

/**
 * 页面关闭响应事件
 */
function closePage() {
	ocxbase_machineAndCameraConnProxy.disconnect();
};

function showMessage(message) {
	$("#showMessage").html(message);
};

// 识别验证码失败处理
function dealRegCodeFail(errorMsg) {
	if (ocxbase_xusbVideo.lastImageCutSuccess()) {
		ocxbase_messageHandler.hideWaittingDialog();
		$("#verificationCode").attr("disabled", false);
		$("#verificationCode").focus();
		showMessage(errorMsg);
	} else {
		ocxbase_messageHandler.showTipMessage("凭证识别失败！</br>如果要继续下一笔业务，请先放入凭证，再关纸盒！");
		useSealCompletedOpenPaperDoor();
	}
};

// 用业务验证码识别业务信息
function initMechSealUseApplyInfoForm() {
	var code = $("#verificationCode").val();
	if (null == code || undefined == code || "" == code) {
		return;
	}
	var param = {
		'verificationCode' : code
	};
	var url = ctx + "/mechseal/sealuse/applyUseMechSealAction_queryMechSealUseApplyInfo.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		var bizInfo = data.response.webResponseJson.data;
		if (data.response.webResponseJson.state == "normal") {
			if (bizInfo != null && bizInfo) {
				var money = bizInfo["extInfo"]["money"];
				if (money != null && money != undefined && money != "") {
					bizInfo["extInfo"]["money"] = money / 100;
				}
				tool.initForm(bizInfo);

				// 释放相应按钮
				showMessage("");
				$("#commitBtnTd").css('display', "");
				ocxbase_messageHandler.hideWaittingDialog();
			} else {
				dealRegCodeFail("验证码不存在");
			}
		} else {
			ocxbase_messageHandler.hideWaittingDialog();
			showMessage(bizInfo);
		}
	} else {
		showMessage("服务器响应失败：" + data.response);
	}
};