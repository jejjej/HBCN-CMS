/**
 * 创建于:2016-11-14<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 授权中心配置
 * 
 * @author listen
 * @version 1.0.0
 */

var sealType;
var tdNum = 0;

var id;


var flagTradeCode = false;
// new
// 业务要素列表
var bizElementInfo;

var codePath = "C:\\yzjgss\\resources\\3x\\img\\verficationCode.jpg";



/**
 * 初始化
 */
$(document).ready(
		function() {
			var path = ctx + "/activex/api/";

			if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body,
					path, "run")) {
				alert("通用控件初始化失败");
			}
			// if (!ocxObject.initOcx(ocxObject.OCX_SealGenerator,
			// document.body, path, "run")){
			// alert("印章生成控件初始化失败");
			// }
			if (!ocxObject.initOcx(ocxObject.OCX_ElecSealPrint, document.body,
					path, "run"))
				alert("验证码识别控件初始化失败");
			if (!ocxObject.initOcx(ocxObject.OCX_Print, document.body, path,
					"run")) {
				alert("模板打印控件初始化失败");
			}
			if (!ocxObject.initOcx(ocxObject.OCX_Base64, document.body, path,
					"run")) {
				alert("解码控件初始化失败");
			}
			// 新建表单提交数据验证
			$("#form").validationEngine({
				showOnMouseOver : true,
				validationEventTrigger : "keyup blur",
				promptPosition : "centerRight",
				autoPositionUpdate : true,
				onValidationComplete : function() {
				}
			});

			$("#printBtn").click(
				function(event) {
					event.preventDefault();
					if ($("#accNo").val() == ""
							&& $("#cardNo").val() == "") {
						show("账号与卡号不能都为空");
						$("#printBtn").val("");
						return;
					}
					if (!$("#form").validationEngine("validate")
							|| !flagTradeCode) {
						$("#printBtn").val("");
						return;
					}
					if (!flagTradeCode) {
						$("#printBtn").val("");
						return;
					}
					$("#printBtn").attr("disable", true);
					printCode();
				});

			$("#resetBtn").click(function(event) {
				event.preventDefault();
				reset();
			});

			$("#tradeCode").blur(function() {
				var tradeCode = $("#tradeCode").val();
				var reg = /^[0-9](\d{3})$/;
				if (reg.test(tradeCode)) {
					$(this).unbind('blur');
					$(this).focus(function() {
						$(this).blur();
					});
					queryTradeCode();
				}

			});

			// 初始化表单
			initPrintElecSealForm();
			initFileType();
		});

/**
 * 初始化表单
 */
function initPrintElecSealForm() {
	var url = ctx + "/mechseal/sealuse/integratedPrintAction_initForm.action";
	var data = tool.ajaxRequest(url, '');
	if (data.success) {
		if (data.response.webResponseJson.state == "normal") {
			$("#districtCode").val("000");
			$("#orgNo").val(data.response.webResponseJson.data.orgNo);
			$("#peopleCode").val(data.response.webResponseJson.data.peopleCode);
		} else {
			show("服务器响应失败");
		}
	} else {
		show("服务器响应失败：" + data.response);
	}
};

/**
 * 交易代码查询业务信息
 */
function queryTradeCode() {
	var url = ctx + "/mechseal/sealuse/integratedPrintAction_queryByTradeCode.action";
	var formData = {
		"tradeCode" : $("#tradeCode").val(),
		"sealMode" : "1"// 机控用印 打印验证码
	};
	var data = tool.ajaxRequest(url, formData);
	if (data.success) {
		if (data.response.webResponseJson.state == "normal") {
			// 临时代码，后续会合并，不存在单独判断
			if (data.response.webResponseJson.data.useType != "0") {
				showMessage("此功能不支持电子印章");
				return;
			}
			flagTradeCode = true;
			$("#bizType").val( data.response.webResponseJson.data.bizTypeInfo.bizName);
			//$("#sealType").val( sealTypeList[data.response.webResponseJson.data.sealMode]);
			var sealTypeName=GPCache.get(GPCache.SMS,GPType.SMS_SEAL_TYPE,data.response.webResponseJson.data.sealTypeId);
			$("#sealName").val(sealTypeName);
			$("#sealCount").val(data.response.webResponseJson.data.useType);
//			$("#position").val(data.response.webResponseJson.data.position);
//			$("#sealMode").val(data.response.webResponseJson.data.sealMode);
			sealType = data.response.webResponseJson.data.sealMode;
			bizElementInfo = $
					.parseJSON(data.response.webResponseJson.data.bizTypeInfo.bizElemts);
			if (bizElementInfo != null) {
				showBizInfoElementData();
			} else {
				show("没有获取到业务要素");
			}

		} else {
			$("#bizType").val("");
			$("#sealType").val("");
			$("#sealCount").val("");
			show(data.response.webResponseJson.data);
			flagTradeCode = false;
			reset();
		}
	} else {
		show("服务器响应失败：" + data.response);
	}
};

// 申请用印
function printCode() {
	var bizElementInfos = genElementValue();
	var formData = {
		"tradeCode" : $("#tradeCode").val(),
		"bizElementInfo" : $.toJSON(bizElementInfos),
		"position_x":$("#position_x").val(),
		"position_y":$("#position_y").val()
	};
	//var url = ctx + "/mechseal/sealuse/integratedPrintAction_printCode.action";
	var url = ctx + "/mechseal/sealuse/integratedPrintAction_printCodeByPosition.action";
	var data = tool.ajaxRequest(url, formData);

	// 机控印章用印, 只打印验证码
	if (data.success) {
		if (data.response.webResponseJson.state == "normal") {
			// 打印
//			var varficationCode = data.response.webResponseJson.data;
//			var result = OCX_ElecSealPrint.startPrintStr(varficationCode, 50, 50, 40, 40);
			var printObject = data.response.webResponseJson.data;
			genCodePic(printObject.codeData);
			var result=OCX_Print._startPrint(printObject.printCodeTemplate,printObject.printCodeData, printFail, printSuccess);
		} else {
			show(data.response.webResponseJson.data);
		}
	} else {
		show("服务器响应失败：" + data.response);
	}
};
/**
 * 用印成功
 */
function printSuccess() {

	var url = ctx + "/mechseal/sealuse/integratedPrintAction_initForm.action?id="+ id;
	var data = tool.ajaxRequest(url, '');
	if (data.success) {
		if (data.response.webResponseJson.state == "normal") {
			show("打印成功");
			$("#printBtn").attr("disable", false);
			reset();
		} else {
			show(response.webResponseJson.data);
		}
	} else {
		show("更新用印状态服务器响应失败：" + data.response);
	}
};

/**
 * 用印失败
 */
function printFail() {
	show("打印失败");
};

/**
 * 生成印章图片
 */
function genCodePic(CodeData) {
	OCX_Base64.decodeBase64(CodeData, codePath);
};
// 根据业务要素，显示界面
function showBizInfoElementData() {
	var trNode;
	// 排序
	bizElementInfo.sort(function(a, b) {
		return a.order - b.order;
	});
	// 循环显示
	$.each(bizElementInfo, function(index, element) {
		// 创建两个td
		if (tdNum % 3 == 0) {
			trNode = $('<tr id="tr' + parseInt(tdNum / 3)
					+ '" class="form_row_height_40"></tr>');
			$("#table").append(trNode);
		}
		tdNum++;
		// label
		var tdNod = $('<td class="form_label_100">' + element.elementName
				+ "</td>");
		$(trNode).append(tdNod);
		tdNode = $('<td></td>');
		divNode = $('<div class="form_textfiled_160"></div>');

		$(tdNode).append(divNode);
		$(trNode).append(tdNode);
		var node = $('<input id="' + element.elementValue + '" name="'
				+ element.elementValue + '"></input>');
		// var node = $('<input id="' + element.elementValue + '" name="'
		// + element.elementValue + '" value="'+element.elementValue+'"
		// ></input>');
		divNode.prepend(node);

	});
};
// 数据录入
function saveElementValue() {
	var bizElementInfos = genElementValue();
	var url = ctx
			+ "/ess/print/integratedPrintAction_saveBizElementInfo.action";
	var formData = {
		"bizElementInfos" : $.toJSON(bizElementInfos),
		"sealMode" : $("#sealMode").val()
	};
	var data = tool.ajaxRequest(url, formData);
	if (data.success) {
		if (data.response.webResponseJson.state == "normal") {
			show(data.response.webResponseJson.data);
		} else {
			show(data.response.webResponseJson.data);
		}
	}
}

// 匹配界面数据的要素
function searchElement(data, key) {
	var rd = null;
	$.each(data, function(index) {
		if (data[index].name == key) {
			rd = data[index];
		}
	});
	return rd;
}

// 生成要素数据
function genElementValue() {
	var data = $('#form').serializeArray();
	var bizElementInfos = new Array();
	$.each(bizElementInfo, function(index, element) {
		var find = searchElement(data, element.elementValue);
		if (find != null) {
			bizElementInfos.push({
				tradeCode : $("#tradeCode").val(),
				elementKey : element.elementValue,
				elementName : element.elementName,
				elementValue : find.value,
				orderid : element.order,
				isShow : element.isShow
			});
		}
		;
	});
	return bizElementInfos;
}

/**
 * 删除生成的tr
 */
function destroyTr() {
	if (tdNum == 0) {
		return;
	}

//	for (var i = 0; i < inputParamList.length; i++) {
//		if ((inputParam & Math.pow(2, i)) != 0) {
//			$("#" + inputParamList[i]).remove();
//		}
//	}

	for (var i = 0; i <= parseInt((tdNum - 1) / 3); i++) {

		$("#tr" + i).remove();
	}
};

/**
 * 重置
 */
function reset() {
	$("#form")[0].reset();
	destroyTr();
	tdNum = 0;
	flagTradeCode = false;
	$("#tradeCode").unbind('focus');
	$("#tradeCode").blur(function() {
		var tradeCode = $("#tradeCode").val();
		var reg = /^[0-9](\d{3})$/;
		if (reg.test(tradeCode)) {
			$(this).unbind('blur');
			$(this).focus(function() {
				$(this).blur();
			});
			queryTradeCode();
		}

	});
	$("#fileType").val("0");
	showPositionByType("0");
};

function initFileType(){
	$("#fileType").empty();
	for ( var key in constants.printCodeFileType) {
		$("#fileType").append("<option value='" + key + "'>"+ constants.printCodeFileType[key] + "</option>");
	}
	$("#fileType").append("<option value='0'>其他</option>");
	$("#fileType").val("0");
}


/**
 * 
 */
function fileTypeOnChange(){
	var fileType=$('#fileType').val();
	showPositionByType(fileType);
};
/**
 * 显示文件类型的固定位置
 * @param fileType
 */
function showPositionByType(fileType){
	if(fileType=="0"){//其他的开放输入
		$('#position_x').val("");
		$('#position_y').val("");
//		$('#position_x').attr("disabled",false);
//		$('#position_y').attr("disabled",false);
	}else{
//		$('#position_x').attr("disabled", true);
//		$('#position_y').attr("disabled", true);
		$('#position_x').val(constants.printCodePositionMap[fileType + "x"]);
		$('#position_y').val(constants.printCodePositionMap[fileType + "y"]);
	}
	
}


