//判断是否是egde浏览器，其他浏览器正常访问
if(window.showModalDialog==undefined){
	var loginPeople = {
			orgName : "",
			orgNo : ""
	};
}else{
	var loginPeople = null;
}
/**
 * 页面初始化加载
 */
$(document).ready(function() {
	initOrgNo();
	initTaskList();
	initUseSealPage();
});
var sealUseConstant = new Object();
sealUseConstants.SealUseApplyStatus = {
	"0" : "启用", 
	"1" : "停用",
	"2" : "销毁" 
};
/**
 * 初始化任务列表
 */
function initTaskList() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight
			+ 6 - 50 * 2;
	var url = ctx+ "/mechseal/task/sealUseInstallAction_gainSealInstallList.action";
	// 用印信息列表
	$("#useSealList").jqGrid(
			{
				width : pageContentWidth,
				height : tableHeight + "px",
				url : url,
				multiselect : false,
				rowNum : 20,
				rownumbers : true,
				sortable : true,// 是否排序
				sortname : "applyDate",
				sortorder : "desc",
				ondblClickRow : function(row) {
					var rowData = $("#useSealList").getRowData(row);
					//判断是否是egde浏览器，其他浏览器照常
					if(window.showModalDialog==undefined){
						//这个赋值方法仅适用于通过window.open()方法打开的父子页面。切勿使用于其他框架。
						window.opener.document.getElementById("sealType").value = rowData.sealType;
						window.opener.document.getElementById("sealTypeName").value = rowData.sealTypeName;
						window.opener.document.getElementById("sealName").value = rowData.sealName;
						window.opener.document.getElementById("sealOrgNo1").value = rowData.sealOrgNo;
						window.opener.document.getElementById("sealOrgName").value = rowData.sealOrgName;
						window.opener.document.getElementById("deviceNum").value = rowData.deviceNum;
						window.opener.document.getElementById("fontFace").value = rowData.faceFont;
						window.opener.document.getElementById("sealNum").value = rowData.sealNum;
						window.opener.document.getElementById("sealautoId").value = rowData.sealApprovalPeople;
						window.opener.document.getElementById("sealId").value = rowData.autoId;
					}else{
						window.returnValue = rowData;
					}
					window.close();
				},
				rowList : [ 20, 50, 100 ],
				colNames : [ "ID","所属机构(Chop Custodian Party)", "所属机构名称Chop: Affiliated Institution Name", "印章种类(Chop Group)", "印章类型(Chop Type)", "印章类型(Chop Type)",
						"印章名称(Chop Name)", "维护时间(Maintenance Date)", "章面字样(Text on the chop) ", "审批人(Authorizer)","审批人名称(Authorizer Name)", "印章保管人(Chop Custodian)","印章保管人(Chop Custodian)","设备编号(Device ID)","槽位(Slot No)", "印章状态(Chop Status)" ],
				colModel : [
				            {
					name : "autoId",
					index : "autoId",
					align : "center",
					hidden:true,
					sortable : false
				},{
					name : "sealOrgNo",
					index : "sealOrgNo",
					align : "center",
					sortable : false
				}, {
					name : "sealOrgName",
					index : "sealOrgName",
					align : "center",
					sortable : false
				}, {
					name : "sealGroup",
					index : "sealGroup",
					align : "center",
					sortable : false
				}, {
					name : "sealType",
					index : "sealType",
					hidden:true,
					align : "center",
					sortable : false
				}, {
					name : "sealTypeName",
					index : "sealTypeName",
					align : "center",
					sortable : false
				}, {
					name : "sealName",
					index : "sealName",
					align : "center",
					sortable : false
				}, {
					name : "maintainTime",
					index : "maintainTime",
					align : "center",
					sortable : false
				}, {
					name : "faceFont",
					index : "faceFont",
					align : "center",
					sortable : false
				}, {
					name : "sealApprovalPeople",
					index : "sealApprovalPeople",
					align : "center",
					width : 80,
					hidden:true,
					sortable : false
				}, {
					name : "sealApprovalPeopleName",
					index : "sealApprovalPeopleName",
					align : "center",
					width : 80,
					sortable : false
				}, {
					name : "sealStoragePeople",
					index : "sealStoragePeople",
					hidden:true,
					align : "center",
					sortable : false
				},
				 {
					name : "sealStoragePeopleName",
					index : "sealStoragePeopleName",
					align : "center",
					sortable : false
				},{
					name : "deviceNum",
					index : "deviceNum",
					align : "center",
					hidden:true,
					sortable : false
				},{
					name : "sealNum",
					index : "sealNum",
					align : "center",
					hidden:true,
					sortable : false
				}, {
					name : "sealStutas",
					index : "sealStutas",
					align : "center",
					sortable : false,
					formatter : function(value, options, rData) {
						return sealUseConstants.SealUseApplyStatus[value];
					}
				}],
				pager : "#useSealPager",
				caption : "印章选择列表(Chop Selection List)"
			}).trigger("reloadGrid");
	$("#useSealList").navGrid("#useSealPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

function initUseSealPage() {
	$("#submitForm").click(function() {
		queryApplyInfoForTerm();
	});
};
function queryApplyInfoForTerm() {
	$("#useSealList").jqGrid("search", "#queryForm");
};
function initOrgNo() {
	//判断是否是egde浏览器，其他浏览器照常
	if(window.showModalDialog==undefined){
		var variables = window.location.search;//获取url中携带的参数
		if(variables !=null && variables != ""){//判断数据是否有效
	        var variablesDe = decodeURI(variables);//重新编码,防止中文参数乱码
	        var variableArray  = variablesDe.substr(1).split("&");//将参数进行分割到数组中
	        for (var i= 0;i<variableArray.length;i++) {//遍历数组
	            var variable =  variableArray[i].split("="); //参数名key与参数值按=号进行分割成数组
	            switch(variable[0]) {   //将参数分解开来
	                case "orgNo": //参数 orgNo
	                	loginPeople.orgNo = variable[1]; //variable[1]  参数 orgNo 的值
	                    break;
	                case "orgName": //参数 orgName
	                	loginPeople.orgName = variable[1]; //variable[1]  参数 orgName 的值
	                	break;
	                   default:
	            }
	        }
		}
	}else{
		loginPeople = window.dialogArguments;
	}
	$("#organizationSid_Item").val(
			loginPeople.orgName + "(" + loginPeople.orgNo + ")");
	$("#sealOrgNo").val(loginPeople.orgNo);
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo) {
	var organizationSid = "00000000000000000000000000000000";
	$("#organizationSid_Item").radioOrgTree(
			true,
			organizationSid,
			0,
			false,
			function(event, treeId, treeNode) {
				if (treeNode) {
					$("#organizationSid_Item").val(
							treeNode.organizationName + "("
									+ treeNode.organizationNo + ")");
					$("#sealOrgNo").val(treeNode.organizationNo);
				}
			});
}
