//验证某个值为正整数的正则表达式
var regu = /^[1-9]\d*$/;
/**
 * 页面初始化加载
 */
$(document).ready(function(){
	initOrgSelect();
	$("#sealOrg").bind("change",showSeals);
//	$("#upload").bind("click",uploadFile);
});

/**
 * 初始化机构数据
 */
function initOrgSelect(){
	var url = ctx + "/sealusetask/create/sealUseTask_initSealOrg.action";
	var result = tool.ajaxRequest(url, null);
	if(result.response.webResponseJson.state == "normal"){
		var orgArray = result.response.webResponseJson.data;
		$.each(orgArray, function(index, organize) {
			$("#sealOrg").append("<option value='"+ organize.orgNo +"'>"+ organize.orgName +"</option>");
		});
	}else{
		var message = reslut.response.webResponseJson.message;
		alert(message);
	}
}

/**
 * 展示印章列表
 */
function showSeals(){
	var orgNo = $("#sealOrg").val();
	//清空下拉列表
	$("#seals").empty();
	if(orgNo == "0"){
		alert("请选择印章使用机构！");
	}else{
		var url = ctx + "/sealusetask/create/sealUseTask_initAvailableSeal.action";
		var param = {
				"orgNo" : orgNo
		};
		var result = tool.ajaxRequest(url, param);
		if(result.response.webResponseJson.state == "normal"){
			var sealArray = result.response.webResponseJson.data;
			$.each(sealArray,function(index,seal){
				if(index == 0){
					$("#seals").append("<div class='form-control' style='width:240px'><input type='checkbox' value='"+ seal.id +"'>"+ seal.sealUseName +"</input>&nbsp;<lable>使用次数:</lable>&nbsp;<input id='"+ seal.id+"' type='text' style='width:40px'><lable>&nbsp;&nbsp;&nbsp;</lable></div>");
				}else{
					$("#seals").append("<div class='form-control' style='width:240px;margin-top:5px'><input type='checkbox' value='"+ seal.id +"'>"+ seal.sealUseName +"</input>&nbsp;<lable>使用次数:</lable>&nbsp;<input id='"+ seal.id+"' type='text' style='width:40px'><lable>&nbsp;&nbsp;&nbsp;</lable></div>");
				}
			});
		}else{
			var message = result.response.webResponseJson.message;
			$("#seals").append("<div class='form-control' style='width:240px'><p style='color:red'>"+ message +"</p></div>");
		}
	}
}

/**
 * 提交申请
 */
function submitApply(){
	$("#submitBtn").attr("disabled") == "disabled";
	var fileName = $.trim($("#tableTile").val());
	if("" == fileName){
		alert("文件名称不能为空！");
		return;
	}
	var applyReason = $.trim($("#tableReason").val());
	if("" == applyReason){
		alert("申请原因不能为空！");
		return;
	}
	var hasFile = $("#fileinput").val();
	if("" == hasFile){
		alert("请选择待上传文件");
		return;
	}
	var fileNum = $.trim($("#fileNum").val());
	if("" == fileNum){
		alert("请输入文件份数！");
		return;
	}else if(!regu.test(fileNum)){
		alert("输入的文件份数不合法！");
		return;
	}
	var elements = $("#seals > div > input:checked");
	if(elements.length == 0){
		alert("请选择当前申请所需要的印章");
		return;
	}else{
		var ids = "";
		var isPass = true;
		$.each(elements,function(index,element){
			var tempNum = $("#"+ element.value).val();
			if(!regu.test(tempNum)){
				isPass = false;
			}
			if(index == 0){
				ids += element.value + "*" + $("#"+ element.value).val();
			}else{
				ids = ids + "|" + element.value + "*" + $("#"+ element.value).val();
			}
		});
		if(!isPass){
			alert("印章使用次数必须为正整数！");
			return;
		}
		$("#sealId").val(ids);
	}
	$("#sealUseApplyForm").submit();
}


/**
 * 授权码
 */
function creatFastUseSealCode(){
	var url = ctx + "/sealusetask/create/sealUseTask_creatFastUseSealCode.action";
	var param = {};
	var result = tool.ajaxRequest(url, param);
	if(result.response.webResponseJson.state == "normal"){
		var verifyCode = result.response.webResponseJson.data;
		alert("快速用印授权码：\r\n"+verifyCode+"\r\n有效时间"+result.response.webResponseJson.message+"秒");
	}else{
		var message = result.response.webResponseJson.message;
		alert(message);
	}
}