var count_upload = 0; //计数上传循环伦次
/**
 * 页面初始化加载
 */
$(document).ready(function(){
	hideDiv();
	//加载二维码
	var imgBase64 = decodeURI(qrcode);
	$("#scan").attr("src", "data:image/png;base64," + imgBase64);
});

function processDoc(){
	if(count_upload > 2) {
		alert("文档上传异常");
		return;
	}
	count_upload++;
	$("a[name='doc'][upload='0']").each(function(index){
		//循环上传处理后的文档
		setQRCode($("input[name='docBase64']")[index].qrcode);
		ret = YZJWordProcess.generateDocFileBase64($("input[name='docBase64']")[index].value);
		if (ret.code == "0000") {
			$(this).attr("upload", "1");
		}		
		ret = YZJWordProcess.getDocPageCount();
		if (ret.code != "0000") {
			alert(ret.msg+":"+ret.data);
			return;
		}
		var filename = $(this).html();
		var pageNum = ret.data;
		uploadDoc(scanNums, filename, pageNum);
	});
	if($("a[name='doc'][upload='0']").length > 0) {
		processDoc();
	}
}

//预览文本
function previewDoc(index){
	if(taskType == "1") {
		setQRCode(decodeURI(qrcode));
	} else if(taskType == "2") {
		setQRCode($("input[name='docBase64']")[index].qrcode);
	}
	var ret = YZJWordProcess.generateDocFileBase64($("input[name='docBase64']")[index].value);
	if (ret.code != "0000") {
		alert(ret.msg+":"+ret.data);
		return;
	}
	ret = YZJWordProcess.previewDocFile();
	if (ret.code != "0000") {
   	 	alert(ret.msg+":"+ret.data);
    }
}

function uploadDoc(scanNum, fileName, pageNum){
	var url = basePath + "/sealusetask/create/sealUseTask_uploadDoc.action";
	url += "?scanNum="+scanNum+"&fileName="+encodeURIComponent(encodeURIComponent(fileName))+"&pageNum=" + pageNum;
	var ret = YZJWordProcess.uploadFile(url);
	if (ret.code != "0000") {
   	 	alert(ret.msg+":"+ret.data);
    }
}

function encodeBase64(filePath){
	if (filePath) {
		var ret = OCX_Base64.encodeBase64(filePath);
		if (ret.code == "1001") {
			return ret.data;
	    } else {
	    	alert("base64编码异常：" + ret.msg);
	    	return null;
	    }
	}
}

function setCookie(cname,cvalue,exdays){
	var d = new Date();
	d.setTime(d.getTime()+(exdays*60*1000));
	var expires = "expires="+d.toGMTString();
	document.cookie = cname+"="+cvalue+"; "+expires;
}

//设置文档二维码
function setQRCode(qrcode){
	var ret = YZJWordProcess.setQRCodeImageData(qrcode);
	if (ret.code != "0000") {
    	alert(ret.msg+":"+ret.data);
    	return;
    }
}

function showDiv() { 
	$(".bg").css("display", "block");
	$("#preloading").css("display", "block");
}
 
function hideDiv(){
	$(".bg").css("display", "none");
	$("#preloading").css("display", "none");	
}