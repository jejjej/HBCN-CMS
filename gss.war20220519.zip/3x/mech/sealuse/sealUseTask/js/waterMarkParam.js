//验证某个值为正整数的正则表达式
var regu = /^[1-9]\d*$/;
var login_people = null; // 人员信息
/**
 * 页面初始化加载
 */
$(document).ready(function(){
	initUseSealPage();
	initLoginPeople();
	initTaskList();
});

/**
 * 初始化机构人员信息
 */
function initLoginPeople() {
	login_people = top.loginPeopleInfo;
};

/**
 * 初始化任务列表
 */
function initTaskList() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	// 
	$("#paramList")
			.jqGrid(
					{
						width : pageContentWidth,
						height : tableHeight + "px",
						url : ctx + "/base/gssGlobalParamAction_list.action?moduleId=" + moduleId,
						multiselect : false,
						rowNum : 20,
						rownumbers : true,
						sortable : true,// 是否排序
						sortname : "orderId",
						sortorder : "desc",
						rowList : [20, 50, 100],
						colNames : ["配置文件类型",  "文件名称", "预览",  "操作"],
						colModel : [
								{
									name : "paramType",
									index : "paramType",
									align : "center",
									width : 60,
									sortable : false,
									formatter : function(value){
										return value == "GSS_USESEAL_WATERMARK" ? "水印":"骑缝章";
									}
								},								
								{
									name : "paramValue",
									index : "paramValue",
									align : "center",
									width : 100,
									sortable : false
								},
								{
									name : "paramKey",
									index : "paramKey",
									align : "center",
									width : 90,
									sortable : false,
									formatter : function(value) {
									    return "<a onclick=\"startViewImage('"
										    + value
										    + "')\" style='text-decoration:underline;color:blue;cursor: hand;'>图像</a>";
									}
								},
								{
									name : "autoId",
									index : "autoId",
									align : "center",
									width : 60,
									sortable : false,
									formatter : function(value, index, rData) { 
										return "<input type='button' style=\" width:65px; \"  onclick=\"editForm('"+value+"','"+rData.paramType+"');\" value='修改' />" +
										"&nbsp;&nbsp;<input type='button' style=\" width:65px; \"  onclick=\"del('"+value+"');\" value='删除' />";
									}
								}],
						pager : "#paramPager",
						caption : "一体机配置列表"
					}).trigger("reloadGrid");
	$("#paramList").navGrid("#paramPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

function initUseSealPage() {
	$("#submitForm").click(function() {
		queryApplyInfoForTerm();
	});
	$("#clearForm").click(function() {
		$("#queryForm")[0].reset();
	});
	$("#paramInfo").dialog({
		autoOpen : false,
		resizable : false,
		width : 400,
		modal : true,
		position : {
			at : "center"
		},
		close : function() {
			initTaskList();
			$("#paramForm")[0].reset();
			$("#paramType").attr("disabled", false);
		}
	});
};

function applyInfo(){
	$("#paramInfo").dialog("open");
}

function queryApplyInfoForTerm() {
	 $("#paramList").jqGrid("search", "#queryForm");
};

/**
 * 提交申请
 */
function submitApply(){
	$("#submitBtn").attr("disabled") == "disabled";
	var fileinput = $.trim($("#fileinput").val());
	if("" == fileinput){
		alert("请先选择文件！");
		return;
	}
	var file_suffix = fileinput.substring(fileinput.lastIndexOf(".")+1,fileinput.length);
	if(file_suffix != "png") {
		alert("请选择png格式文件");
		return;
	}
	
	if($("#autoId").val() == "") {
		//校验数据
		var success = false;
		var msg = null;
		$.ajax({
			url:ctx + "/base/gssGlobalParamAction_checkParamInfo.action",
			type:"POST",
			async:false,
			dataType : "json",
			data:$("#paramForm").serialize(),
			complete : function(XMLHttpRequest, textStatus) {
				if (XMLHttpRequest.readyState == "0" || XMLHttpRequest.status != "200") {
					msg = '服务器响应失败';
				}
			},
			success : function(response) {
				if (response.responseMessage.success == true) {
					success = true;
				} else {
					msg = response.responseMessage.message
				}
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
				if (textStatus != null) {
					msg = textStatus;
				} else {
					msg = errorThrown;
				}
			}
		});
		if(!success) {
			alert(msg);
			return;
		}
		paramForm.action = ctx + "/base/gssGlobalParamAction_addParamInfo.action";
	} else {
		paramForm.action = ctx + "/base/gssGlobalParamAction_updateParamInfo.action";
	}
	$("#paramForm").submit();
}

function editForm(key, type){
	$("#autoId").val(key);
	$("#paramType").val(type);
	$("#paramType").attr("disabled", true);
	$("#paramInfo").dialog("open");
}

function del(key){
	if(confirm("确定删除？")) {
		var url = ctx + "/base/gssGlobalParamAction_deleteParamInfo.action";
		var param = {"gssGlobalParam.autoId":key};
		var data = tool.ajaxRequest(url, param);
		if(data.success && data.response.responseMessage.success){
			initTaskList();
		}else{
			if(data.response && data.response.responseMessage) {
				alert(data.response.responseMessage.message);
			} else {
				alert(arg);
			}
		}
	}
}

function startViewImage(storeId) {
    wfStoreFancyBox.showAllImageByStoreId(storeId, "buttons");
};