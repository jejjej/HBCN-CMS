var sealautoId = null;
var boolenPage;  //判断是哪个页面访问的
/**
 * 页面初始化加载
 */
$(document).ready(function() {
	initOrgNo();
	initTaskList();
	initUseSealPage();
});

/**
 * 初始化任务列表
 */
function initTaskList() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight
			+ 6 - 50 * 2;
	var url = ctx+ "/mechseal/task/sealUseInstallAction_queryPeopleByseal.action";
	// 用印信息列表
	$("#usePeopleList").jqGrid(
			{
				width : pageContentWidth,
				height : tableHeight + "px",
				url : url,
				multiselect : false,
				postData:{
					"sealautoId":sealautoId
				},
				rowNum : 1000,
				rownumbers : true,
				sortable : false,// 是否排序
				ondblClickRow : function(row) {
					var rowData = $("#usePeopleList").getRowData(row);
					//判断是否是egde浏览器，其他浏览器照常
					if(window.showModalDialog==undefined){
						//共用一个页面，用于区分
						if(boolenPage == 1){
							//这个赋值方法仅适用于通过window.open()方法打开的父子页面。切勿使用于其他框架。
							window.opener.document.getElementById("apprPeopleName").value = rowData.peopleName;
							window.opener.document.getElementById("apprPeopleSid").value = rowData.sid;
						}else if(boolenPage == 2){
							//这个赋值方法仅适用于通过window.open()方法打开的父子页面。切勿使用于其他框架。
							window.opener.document.getElementById("addApprPeople").value = rowData.peopleCode;
						}else if(boolenPage == 3){
							//这个赋值方法仅适用于通过window.open()方法打开的父子页面。切勿使用于其他框架。
							window.opener.document.getElementById("updateApprPeople").value = rowData.peopleCode;
						}
					}else{
						window.returnValue = rowData;
					}
					window.close();
				},
				rowList : [ 20, 50, 100 ],
				colNames : [ "ID","用户姓名(User Name)", "用户代码(User Code)", "所属机构(Affiliated Institution)"],
				colModel : [
				            {
					name : "sid",
					index : "sid",
					align : "center",
					hidden:true,
					sortable : false
				},{
					name : "peopleName",
					index : "peopleName",
					align : "center",
					sortable : false
				}, {
					name : "peopleCode",
					index : "peopleCode",
					align : "center",
					sortable : false
				}, {
					name : "orgName",
					index : "orgName",
					align : "center",
					sortable : false
				}
				],
				pager : "#useSealPager",
				caption : "人员选择列表(User Selection List)"
			}).trigger("reloadGrid");
	$("#usePeopleList").navGrid("#useSealPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

function initUseSealPage() {
	$("#submitForm").click(function() {
		queryApplyInfoForTerm();
	});
};
function queryApplyInfoForTerm() {
	$("#usePeopleList").jqGrid("search", "#queryForm");
};
function initOrgNo() {
	//判断是否是egde浏览器，其他浏览器照常
	if(window.showModalDialog==undefined){
		var variables = window.location.search;//获取url中携带的参数
		if(variables !=null && variables != ""){//判断数据是否有效
	        var variablesDe = decodeURI(variables);//重新编码,防止中文参数乱码
	        var variableArray  = variablesDe.substr(1).split("&");//将参数进行分割到数组中
	        for (var i= 0;i<variableArray.length;i++) {//遍历数组
	            var variable =  variableArray[i].split("="); //参数名key与参数值按=号进行分割成数组
	            switch(variable[0]) {   //将参数分解开来
	                case "sealautoId": //参数 sealautoId
	                	sealautoId = variable[1]; //variable[1]  参数 sealautoId 的值
	                    break;
	                case "boolenPage": //参数 boolenPage
	                	boolenPage = variable[1]; //variable[1]  参数 boolenPage 的值
	                	break;
	                   default:
	            }
	        }
		}
	}else{
		sealautoId = window.dialogArguments;
	}
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo) {
	var organizationSid = "00000000000000000000000000000000";
	$("#organizationSid_Item").radioOrgTree(
			true,
			organizationSid,
			0,
			false,
			function(event, treeId, treeNode) {
				if (treeNode) {
					$("#organizationSid_Item").val(
							treeNode.organizationName + "("
									+ treeNode.organizationNo + ")");
					$("#sealOrgNo").val(treeNode.organizationNo);
				}
			});
}
