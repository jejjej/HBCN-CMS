/**
 * 
 * 创建于:2014-9-11<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 人员登录日志查询
 * 
 * @author guoshixuan
 * @version 1.0
 */

/**
 * 初始化Grid数据
 */
$(function() {
	initOrgNo();
	initPage();
});

function initOrgNo() {
	var loginPeople = top.loginPeopleInfo;
	$("#organizationSid_Item").val(loginPeople.orgName+"("+loginPeople.orgNo+")");
	$("#operatorOrgNo").val(loginPeople.orgNo);
}

function initPage(){
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() -2;
		pageHeaderHeight = pageHeaderHeight.substr(0,pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight -pageHeaderHeight + 6 - 50*2 ;
	$("#logPeopleManageList").jqGrid(
		{
			width : pageContentWidth,
			height : tableHeight,
			url : ctx + "/appUnlockLogAction_queryList.action",
			multiselect : false,
			rowNum : 20,
			rownumbers : true,
			sortname : "logId",
			sortorder : "desc",
			rowList : [ 20, 50, 100 ],
			colNames : ["机构", "设备编号", "操作人","监印人", "操作时间", "备注" ],
			colModel : [
					{
						name : "operatorOrgNo",
						index : "operatorOrgNo",
						align : "center",
						width : 60,
						sortable : true,
						formatter : function(value, options, rData) {
							var operatorOrgName = "";
							if(rData.operatorOrgName!=null){
								operatorOrgName += rData.operatorOrgName;
							}
							if(rData.operatorCode!=null){
								operatorOrgName += "("+rData.operatorOrgNo+")";
							}
							return operatorOrgName;
						}
					},
					{
						name : "deviceNum",
						index : "deviceNum",
						align : "center",
						width : 60,
						sortable : true
					},
					{
						name : "operatorNo",
						index : "operatorNo",
						align : "center",
						width : 60,
						sortable : true,
						formatter : function(value, options, rData) {
							var operatorName = "";
							if(rData.operatorName!=null){
								operatorName += rData.operatorName;
							}
							if(rData.operatorNo!=null){
								operatorName += "("+rData.operatorNo+")";
							}
							return operatorName;
						}
					},
					{
						name : "authNo",
						index : "authNo",
						align : "center",
						width : 60,
						sortable : true,
						formatter : function(value, options, rData) {
							var authName = "";
							if(rData.authName!=null){
								authName += rData.authName;
							}
							if(rData.authNo!=null){
								authName += "("+rData.authNo+")";
							}
							return authName;
						}
					},
					{
						name : "operateTime",
						index : "operateTime",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							var operateTime = "";
							if(rData.operateDate!=null){
								operateTime += rData.operateDate;
							}
							if(rData.operateTime!=null){
								operateTime += " "+rData.operateTime;
							}
							return operateTime;
						}
					},
					{
						name : "memo",
						index : "memo",
						align : "center",
						width : 160,
						sortable : false
					} ],
			pager : "#logPeopleManagePager",
			caption : "开锁日志信息列表"
		}).trigger("reloadGrid");
	
	$("#logPeopleManageList").navGrid("#logPeopleManagePager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
}

/**
 * 查询数据，执行查询
 */
function queryData() {
	$("#logPeopleManageList").jqGrid("search", "#queryForm");
}

/**
 * 重置查询条件
 */
function resetMethod() {
	$("#queryForm")[0].reset();
	initOrgNo();
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo){
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#organizationSid_Item").radioOrgTree(true,organizationSid,0,false,function(event, treeId, treeNode){
		if(treeNode){
			$("#organizationSid_Item").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
			$("#"+organizationNo).val(treeNode.organizationNo);
		}
	});
}