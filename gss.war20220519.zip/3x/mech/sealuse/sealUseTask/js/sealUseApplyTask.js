//验证某个值为正整数的正则表达式
var regu = /^[1-9]\d*$/;
var login_people = null; // 人员信息
var roleGroupMap = new Map();
var scanNum = null;
var hasFile = false;
/**
 * 页面初始化加载
 */
$(document).ready(function(){
//	initOrgSelect();
	initUseSealPage();
	initLoginPeople();
	initTaskList();
	selectUtils.initTradeInfoConfig1();
	selectUtils.initSealBizType("sealType","1");
	initSeals();
	initAllRoleGroups();
	showFiles();
});

/**
 * 初始化机构人员信息
 */
function initLoginPeople() {
	login_people = top.loginPeopleInfo;
};

function initTradeInfo() {
	try {
		var url = ctx + "/gss/paramflow/gssParamFlow_list.action";
		var param = {orgType:""};
		var data = tool.ajaxRequest(url,param);
		var options = "<option value=''>--请选择--</option>";
		if (data.success) {
			if(data.response.responseMessage.success){
				var paramFlow = data.response.responseMessage.data;
				$(paramFlow).each(
						function(i, value) {
							options += "<option name='tableApply.tradeCode' value='" + value.tradeCode + "'>" + selectUtils.tradeInfo[value.tradeCode] + "</option>";
						});
					$("#tradeCode").html(options);
			}
		} else {
			alert(data.response);
		}
	} catch (e) {
		return e.message;
	}
}

/**
 * 初始化任务列表
 */
function initTaskList() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	var url = ctx + "/mechseal/task/sealUseApprTaskZHAction_findSealUseApply.action";
	if(_t == "0001") {
		url = ctx + "/mechseal/task/sealUseApprTaskZHAction_gainTaskList.action";
		document.getElementById("deleteBtn").style.display = "";
		document.getElementById("addBtn").style.display = "";
		document.getElementById("submitBtn").style.display = "";
		document.getElementById("fileTr").style.display = "";
	} else {
		document.getElementById("addBtn").style.display = "none";
	}
	// 用印信息列表
	$("#useSealList")
			.jqGrid(
					{
						width : pageContentWidth,
						height : tableHeight + "px",
						url : url,
						multiselect : false,
						rowNum : 20,
						rownumbers : true,
						sortable : true,// 是否排序
						sortname : "applyDate",
						sortorder : "desc",
						rowList : [20, 50, 100],
						colNames : ["任务码","用印申请标题","申请原因", "申请人", "机构名称","状态","申请日期", "影像","操作"],
						colModel : [
								{
									name : "scanNum",
									index : "scanNum",
									align : "center",
									width : 80,
									sortable : false,
									formatter : function(value) {
										return "<a href=\"javascript:void(0)\" onMouseOut=\"showImg('hide','"+value+"',this);\"  onmouseover=\"showImg('show','"+value+"',this);\">" + value + "</a>";
									}
								},
								{
									name : "title",
									index : "title",
									align : "center",
									sortable : false
								},
								{
									name : "materialName",
									index : "materialName",
									align : "center",
									sortable : false
								},								
								{
									name : "peopleName",
									index : "peopleName",
									align : "center",
									width : 100,
									sortable : false
								},
								{
									name : "applyPeopleOrgName",
									index : "applyPeopleOrgName",
									align : "center",
									sortable : false
								},
								{
									name : "status",
									index : "status",
									align : "center",
									sortable : false,
									formatter : function(value, options, rData) {
										return sealUseConstants.SealUseApplyStatus[value];
								    }
								},
								{
									name : "applyDate",
									index : "applyDate",
									align : "center",
									width : 90,
									sortable : false,
									formatter : function(value, options, rData) {
										return value.substring(0,4)+"-"+value.substring(4,6)+"-"+value.substring(6,8)+" "+
												rData.applyTime.substring(0,2)+":"+rData.applyTime.substring(2,4)+":"+rData.applyTime.substring(4,6);
									}
								},
								{
									name : "storeId",
									index : "storeId",
									width : 90,
								    formatter : function(value, options, rData) {
										if (null == value || value == "") {
										    return "无图像";
										} else {
										    return "<a onclick=\"startViewImage('"
											    + value
											    + "')\" style='text-decoration:underline;color:blue;cursor: hand;'>图像</a>";
										}
									}
									
								},
								{
									name : "id",
									index : "id",
									align : "center",
									width : 60,
									sortable : false,
									formatter : function(value, options, rData) { 
										if(rData.status == "0011"){
											if(rData.peopleName == login_people.peopleName) {
												return "<input type='button' style=\" width:65px; \"  onclick=\"saveData('"+value+"','"+rData.status+"');\" value='仅保存' />";								
											} else {
												return "<input type='button' style=\" width:65px; background:red; \"  onclick=\"showDetail('"+value+"');\" value='详情' />";
											}
										}else{
											return "<input type='button' style=\" width:65px; background:red; \"  onclick=\"showDetail('"+value+"');\" value='详情' />";
										}
									}
								}],
						pager : "#useSealPager",
						caption : "我的申请列表"
					}).trigger("reloadGrid");
	$("#useSealList").navGrid("#useSealPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

function saveData(id,status){
	initTradeInfo();
	var url = ctx + "/mechseal/task/sealUseApprTaskZHAction_gainSaveTask.action?_t="+status;
	var param = {"bizInfo.id":id};
	var data = tool.ajaxRequest(url, param);
	if(data.success){
    	var bizInfo = data.response.bizInfo;
    	var mechSealInfos = data.response.mechSealInfos;
    	var mechSealFiles = data.response.mechSealFiles;

    	$("#tradeCode").find("option[value='"+bizInfo.tradeCode+"']").attr("selected",true); 
		$("#applyTitle").val(bizInfo.title);
		$("#applyReason").val(bizInfo.materialName);
		/*$("#sealType0").find("option[value='"+mechSealInfo.tradeCode+"']").attr("selected",true); ;*/
		
		if(mechSealInfos != null){
			$.each(mechSealInfos,function(i,item){
				if(i == 0) {
					$("#sealType1").val(item.sealId);
					$("#sealNum1").val(item.applyNum);
				} else {
					addSealSelect();
					$("#sealType" + num).val(item.sealId);
					$("#sealNum" + num).val(item.applyNum);
				}
			});
		}
		
		$("#targetOrgMemo").val(bizInfo.extInfo.targetOrgMemo);
		$("#useSealReason").val(bizInfo.extInfo.useSealReason);
		$("#fileTypeName").val(bizInfo.extInfo.fileType);
		$("#runSealFunc_select").val(bizInfo.runSealfunc);
		$("#id").val(bizInfo.id);
		document.getElementById("docwordTr").style.display = "";
		showDocDetail(bizInfo.scanNum);
		$("#sealUseTaskInfo").dialog("open");
	}
    		
}

function showDetail(id) {
	if (_t != "0001") {
		_t = "0005";
	}
	var url = ctx + "/mechseal/task/sealUseApprTaskZHAction_gainTask.action?_t="+_t;
	var param = {"bizInfo.id":id};
	var data = tool.ajaxRequest(url, param);
	if(data.success){
		initTradeInfo();
    	var bizInfo = data.response.bizInfo;
    	var mechSealInfos = data.response.mechSealInfos;
    	var mechSealFiles = data.response.mechSealFiles;
    	scanNum = bizInfo.scanNum;
    	$("#id").val(bizInfo.id);
    	if(_t == "0001") {
    		$("#tradeCode").find("option[value='"+bizInfo.tradeCode+"']").attr("selected",true); 
    		$("#applyTitle").val(bizInfo.title);
    		$("#applyReason").val(bizInfo.materialName);
    		/*$("#sealType0").find("option[value='"+mechSealInfo.tradeCode+"']").attr("selected",true); ;*/
    		if(mechSealInfos != null){
    			$.each(mechSealInfos,function(i,item){
    				if(i == 0) {
    					$("#sealType1").val(item.sealId);
    					$("#sealNum1").val(item.applyNum);
    				} else {
    					addSealSelect();
    					$("#sealType" + num).val(item.sealId);
    					$("#sealNum" + num).val(item.applyNum);
    				}
    			});
    		}
    		$("#targetOrgMemo").val(bizInfo.extInfo.targetOrgMemo);
    		$("#sealNum").val(bizInfo.applyNum);
    		$("#useSealReason").val(bizInfo.extInfo.useSealReason);
    		$("#fileTypeName").find("option[value='"+bizInfo.extInfo.fileType+"']").attr("selected",true);
    		$("#sealUseTaskInfo").dialog("open");
    		$("#memo1").val("重新提交");
    		document.getElementById("docwordTr").style.display = "";
    		showDocDetail(bizInfo.scanNum);
    	} else {
    		$("#tradeCode1").val(selectUtils.tradeInfo[bizInfo.tradeCode]);; 
    		$("#applyTitle1").val(bizInfo.title);
    		$("#applyReason1").val(bizInfo.materialName);
    		$("#memo").val(bizInfo.memo);
    		
    		$("#seals1").empty();
    		if(mechSealInfos != null){
    			$.each(mechSealInfos,function(i,item){
    				showSealsDetail(item.sealId,item.applyNum);
    			});
    		}
    		
    		$("#targetOrgMemo1").val(bizInfo.extInfo.targetOrgMemo);
    		$("#useSealReason1").val(bizInfo.extInfo.useSealReason);
    		$("#runSealfuncs").val(bizInfo.runSealfunc);
    		$("#fileType1").val(bizInfo.extInfo.fileType);
    		if(bizInfo.status == "000" && bizInfo.peopleName == login_people.peopleName) {
    			document.getElementById("cancelBtn").style.display = "";
    		} else {
    			document.getElementById("cancelBtn").style.display = "none";
    		}
    		$("#sealUseTaskInfo1").dialog("open");
    		showDocDetail(bizInfo.scanNum);
    	}
    }else{
		var message = reslut.response.webResponseJson.message;
		alert(message);
	}
}

function showDocDetail(scanNum){
	var url = ctx + "/sealusetask/create/sealUseTask_queryDocDetail.action";
	var param = {"scanNum":scanNum};
	var result = tool.ajaxRequest(url, param);
	if(result.response.webResponseJson.state == "normal"){
		var files = result.response.webResponseJson.data;
		if(files.length != 0){
			hasFile = true;
			var html = "";
			for(var i = 0; i < files.length; i ++) {
				html += "<a href='"+files[i].filePath+"' title='"+files[i].fileDesc+"'>"+files[i].fileDesc+"</a><br/>";
			}
			$('#docword').html(html);
			$('#docword1').html(html);
			$("#hasFile").val("1");
		} else {
			hasFile = false;
		}
	}else{
		var message = result.response.webResponseJson.message;
		alert(message);
	}
}

function initUseSealPage() {
	$("#submitForm").click(function() {
		queryApplyInfoForTerm();
	});
	$("#clearForm").click(function() {
		$("#queryForm")[0].reset();
	});
	$("#sealUseTaskInfo").dialog({
		autoOpen : false,
		resizable : false,
		width : 650,
		height : 'auto',
		modal : true,
		position : {
			at : "center"
		},
		close : function() {
			initTaskList();
			num = 1;
			initSeals();
			showFiles();
			document.getElementById("docwordTr").style.display = "none";
			$("#sealUseApplyForm")[0].reset();
		}
	});
	$("#sealUseTaskInfo1").dialog({
		autoOpen : false,
		resizable : false,
		width : 650,
		height : 'auto',
		modal : true,
		position : {
			at : "center"
		},
		close : function() {
			initTaskList();
			$("#sealUseApplyForm1")[0].reset();
		}
	});
	$("#docPreview").dialog({
		autoOpen : false,
		resizable : false,
		width : $(window).width() / 2,
		modal : true,
		position : {
			at : "center"
		},
		close : function() {
			initTaskList();
			$("#docPreview").html("");
		}
	});
	$("#nextHandleDiv").dialog({
		autoOpen : false,
		resizable : false,
		width : $(window).width() / 2,
		modal : true,
		position : {
			at : "center"
		},
		buttons:{
			"确定": function() {
				var nextHandlerSid = $("#nextHandlerSid").val();
				if("" == $("#nextHandlerSid").val()) {
					alert("请选择复核人");
					return;
				}
				$("#apprPeopleSid").val(nextHandlerSid);
				sealUseApplyForm.action = ctx + "/sealusetask/create/sealUseTask_createUseSealTask.action";
				$("#sealUseApplyForm").submit();
			}
		},
		close : function() {
			initTaskList();
			$("#docPreview").html("");
		}
	});
};

function applyUseSeakTask(){
	initTradeInfo();
	hasFile = false;
	$("#hasFile").val("0");
	$("#sealUseTaskInfo").dialog("open");
}

function queryApplyInfoForTerm() {
	 $("#useSealList").jqGrid("search", "#queryForm");
};

/**
 * 初始化机构数据
 */
function initOrgSelect(){
	var url = ctx + "/sealusetask/create/sealUseTask_initSealOrg.action";
	var result = tool.ajaxRequest(url, null);
	if(result.response.webResponseJson.state == "normal"){
		var orgArray = result.response.webResponseJson.data;
		$.each(orgArray, function(index, organize) {
			$("#sealOrg").append("<option value='"+ organize.orgNo +"'>"+ organize.orgName +"</option>");
		});
	}else{
		var message = reslut.response.webResponseJson.message;
		alert(message);
	}
}

/**
 * 提交申请
 */
function submitApply(saveOrCreate){
	$("#submitBtn").attr("disabled") == "disabled";
	var fileName = $.trim($("#applyTitle").val());
	if("" == fileName){
		alert("标题不能为空！");
		return;
	}
	var applyReason = $.trim($("#applyReason").val());
	if("" == applyReason){
		alert("申请原因不能为空！");
		return;
	}else{
        $("#applyReason").val(applyReason);
    }
	
	var targetOrgMemo = $.trim($("#targetOrgMemo").val());
	if("" == targetOrgMemo) {
		alert("发送单位不能为空");
		return;
	}
	var useSealReason = $.trim($("#useSealReason").val());
	if("" == useSealReason) {
		alert("用印情况说明不能为空");
		return;
	}
	var runSealfunc = $("#runSealFunc_select option:selected").val();
	if("" == runSealfunc) {
		alert("请选择盖章方式");
		return;
	}
	$("#runSealfunc").val(runSealfunc);
	
	if(runSealfunc == "1" && num > 1) {
		alert("开门盖章只能申请一种印章！");
		return;
	}
	//多文件上传
	var fileValue = $("#fileinput").val();
	if(!hasFile) {
		if(!checkFile(fileValue)){
			return;
		};
	} else {
		if(fileValue != "") {
			$("#hasFile").val("0");
			if(!checkFile(fileValue)){
				return;
			};
		}
	}
	
	var sealType = "";
	var sealNums = "";
	for (var i = 0; i < num; i ++) {
		var bico = (i+1);
		if(!regu.test($("#sealNum"+bico).val())){
			alert("用印次数必须为正整数");
			return;
		}
		
		if("" == $("#sealType"+bico).val()) {
			alert("请选择印章类型");
			return;
		}
		
		if (i == num) {
			sealType += $("#sealType"+bico).val();
			sealNums += $("#sealNum"+bico).val();
			
		} else {
			sealType += $("#sealType"+bico).val()+"|";
			sealNums += $("#sealNum"+bico).val()+"|";
		}
	}
	
	
	var typeArrys = sealType.split("|");
	for(var i=0; i<typeArrys.length; i++){
		for(var l=i+1;l<typeArrys.length;l++){
			if(typeArrys[i] == typeArrys[l]){
				alert("不能提交相同类型印章");
				return;
			}
		}
	}
	
	
	$("#sealId").val(sealType);
	if("" == sealType) {
		alert("请选择印章类型");
		return;
	}
	
	$("#sealNums").val(sealNums);
	
	var tradeCode = $("#tradeCode").val();
	if("" == tradeCode) {
		alert("请选择交易代码");
		return;
	}
	$("#tradeCodeName").val(selectUtils.tradeInfo[tradeCode]);
	if(saveOrCreate) {
		$("#status").val("000");
		$("#memo1").val("申请任务");
		initFlowParamInfo();
	} else {
		$("#status").val("0011")
		$("#memo1").val("保存任务");
		sealUseApplyForm.action = ctx + "/sealusetask/create/sealUseTask_createUseSealTask.action";
		$("#sealUseApplyForm").submit();
	}
}

function checkFile(fileValue) {
	var flag = true;
	if("" == fileValue){
		alert("请选择待上传文件");
		return false;
	}
//	var fileType = $("#fileTypeName").val();
//	if("" == fileType) {
//		alert("请选择文件类型");
//		return false;
//	}
//	$("#fileType").val(fileType);
	var runSealfunc = $("#runSealFunc_select option:selected").val();
	$("input[name='uploadFile']").each(function(index){
		var filename=$(this).val();
		if(filename == ""){
			alert("未上传附件");
			flag = false;
			return false;
		}
		var file_suffix = filename.substring(filename.lastIndexOf(".")+1,filename.length);
		if(runSealfunc == "0") {
			if(file_suffix != "docx" && file_suffix != "doc") {
				alert("请选择word文档");
				flag = false;
				return false;
			}
		} else {
			if(file_suffix != "pdf" && file_suffix != "tif") {
				alert("请选择pdf或者tif文档");
				flag = false;
				return false;
			}
		}
		$("input[name='uploadFile']").each(function(tl){
			if(index != tl && filename == $(this).val()) {
				alert("请选择不同文档");
				flag = false;
				return false;
			}
			
		});
		
		if(!flag) {
			return false;
		}
	});
	if(!flag) {
		return false;
	}
	
	if($("#fileTd").find("input[value='']").length > 0) {
		alert("请填写空白栏");
		return false;
	}
	for(var i=0;i<$("#fileTd").find("input").length;i++) {
		$("#fileTd").after("<input name=\"tableApply.filepaths\" type=\"hidden\" value=\""+$("#fileTd").find("input")[i].value+"\" />");
	}
	return true;
}

function showFiles(){
	$("#fileTd").html("");
	$("#fileTd").prev().html("待上传文件/份数：");
	$("#fileNum").parent().parent().css("display", "none");
	var str = "<input class=\"form_label_200\" id=\"fileinput\" name=\"uploadFile\" type=\"file\" index=1 />&nbsp;&nbsp;" +
			"<input type=\"text\"  name=\"tableApply.allPrintNum\" onkeypress=\"return event.keyCode>=48&&event.keyCode<=57\" maxlength=2 style=\"width:20px;\" value=\"1\" index=1 />" +
			"<img src='"+ctx+"\\windforce\\common\\images\\ioco_03.png' href='#' onclick='addFile();' index=1 style='width:20px;height:20px;' />" +
			"<img src='"+ctx+"\\windforce\\common\\images\\ioco_04.png' href='#' name='delIcon' onclick='delFile(1);' index=1 style='width:20px;height:20px;' />";
	$("#fileTd").append(str);
}

function addFile(){
	var index = Number($("img[name='delIcon']:last").attr("index")) + 1;
	var str = "<br index="+index+" /><input class=\"form_label_200\"  name=\"uploadFile\" type=\"file\" index="+index+" />&nbsp;&nbsp;" +
			"<input type=\"text\" name=\"tableApply.allPrintNum\" onkeypress=\"return event.keyCode>=48&&event.keyCode<=57\" maxlength=2 style=\"width:20px;\" value=\"1\" index="+index+" />" +
			"<img src='"+ctx+"\\windforce\\common\\images\\ioco_03.png' href='#' onclick='addFile();' index="+index+" style='width:20px;height:20px;' />" +
			"<img src='"+ctx+"\\windforce\\common\\images\\ioco_04.png' href='#' name='delIcon' onclick='delFile("+index+");' index="+index+" style='width:20px;height:20px;' />";
	$("#fileTd").append(str);
}

function delFile(index){
	if($("img[name='delIcon']").length == 1) {
		return;
	}
	$("#fileTd [index="+index+"]").remove();
}

function showSealsDetail(sealId,sealApplyNum) {
	var sealName = sealMap.get(sealId);
	if(sealName == undefined || sealName == "" || sealName == "undefined") {
		sealName = "印章不存在";
	}
	var str = "<div id='divSealNum'><input disabled='disabled' value='"+sealName+"' style='width:300px;'/><input maxlength='10' style='width:50px;' disabled='disabled' value='"+sealApplyNum+"' /></div>";
	$("#seals1").append(str);
}

function checkSealNum(object){
    var num = $(object).val();
    if(num != "" && num !=undefined && !regu.test(num)){
        $(object).val("");
    }
}

/**
 * 展示印章列表
 */
var num = 1;
var sealOption = "";
var sealMap = new Map();
function initSeals(){
	//清空下拉列表
	sealMap = new Map();
	sealOption = "";
	$("#seals").empty();
	var url = ctx + "/sealusetask/create/sealUseTask_initAvailableSeal.action";
	var param = {"orgNo":login_people.orgNo};
	var result = tool.ajaxRequest(url, param);
	if(result.response.webResponseJson.state == "normal"){
		var sealArray = result.response.webResponseJson.data;
		var str = "<div id='divSealNum' index='"+num+"'><select id='sealType"+num+"' index='"+num+"'><option value=''>--请选择--</option></select>" +
		"<img src='"+ctx+"\\windforce\\common\\images\\ioco_03.png' href='#' onclick='addSealSelect();' index='"+num+"' style='width:20px;height:20px;' />" +
		"<img src='"+ctx+"\\windforce\\common\\images\\ioco_04.png' href='#' name='delIcon' onclick='delSealSelect("+num+");' index='"+num+"' style='width:20px;height:20px;' />" +
		"&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp用印次数:&nbsp&nbsp<input type='test' maxlength='10' style='width:50px;' id='sealNum"+num+"' onkeyup='checkSealNum(this);'/></div>"+
				"<br index='"+num+"'/>";
		$.each(sealArray,function(index,seal){
			sealOption += "<option value='"+seal.autoId+"' name=''>"+seal.sealTypeName+"("+seal.deviceNum+")</option>";
			sealMap.put(seal.autoId,seal.sealTypeName+"("+seal.deviceNum+")");
		});
		$("#seals").append(str);
		$("#sealType"+num).append(sealOption);
	}else{
		var message = result.response.webResponseJson.message;
		$("#seals").append("<div class='form-control' style='width:240px'><p style='color:red'>"+ message +"</p></div>");
	}
}

function addSealSelect() {
	if(num < 6) {
		num++;
		var str = "<div id='divSealNum' index='"+num+"'><select id='sealType"+num+"' index='"+num+"'><option value=''>--请选择--</option></select>" +
		"<img src='"+ctx+"\\windforce\\common\\images\\ioco_03.png' href='#' onclick='addSealSelect();' index='"+num+"' style='width:20px;height:20px;' />" +
		"<img src='"+ctx+"\\windforce\\common\\images\\ioco_04.png' href='#' name='delIcon' onclick='delSealSelect("+num+");' index='"+num+"' style='width:20px;height:20px;' />" +
		"&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp用印次数:&nbsp<input type='test' style='width:50px;' maxlength='10'  id='sealNum"+num+"' /></div>"+
		"<br index='"+num+"'/>";
		$("#seals").append(str);
		$("#sealType" + num).append(sealOption);
	} else {
		alert("印章种类最多设置6种");
		return;
	}
}

function delSealSelect(index) {
	if($("img[name='delIcon']").length == 1) {
		return;
	}
	if(index != num) {
		alert("请先删除下排印章信息！");
		return;
	}
	num--;
	$("#seals [index="+index+"]").remove();
	$("#sealNum [index="+index+"]").remove();
}

function showImg(type, value, obj){
	if(type == "show") {
		var e = event || window.event;
		var pos = obj.getBoundingClientRect();
		$("#qrcodeImg").css("left", 360);
		$("#qrcodeImg").css("top",100);
		$("#qrcodeImg").qrcode({render: "table",width:300,height:300,text:value});
		$("#qrcodeImg").css("display", "block");
	} else if (type == "hide") {
		$("#qrcodeImg").css("display", "none");
		$("#qrcodeImg").html("");
	}
}

/*function showDocDetail(){
	var url = ctx + "/sealusetask/create/sealUseTask_queryDocDetail.action";
	var param = {"scanNum":scanNum};
	var result = tool.ajaxRequest(url, param);
	if(result.response.webResponseJson.state == "normal"){
		var files = result.response.webResponseJson.data;
		$.each(files, function(i, row){
			$('#docPreview').append("<a href='"+row.filePath+"' title='"+row.fileDesc+"'>"+row.fileDesc+"</a><br/>");
		});
		$('#docPreview').dialog('open');
	}else{
		var message = result.response.webResponseJson.message;
		alert(message);
	}
}*/

/**
 * 查询流程配置参数
 */
function initFlowParamInfo () {
	try {
		var url = ctx + "/gss/paramflow/gssParamFlow_findParamFlowByFileId.action";
		var param = {"paramFlow.tradeCode":$("#tradeCode").val()};
		var data = tool.ajaxRequest(url,param);
		if (data.success && data.response.responseMessage.success) {
			var paramFlowInfo = data.response.paramFlow
			if (paramFlowInfo != null && paramFlowInfo != "") {
				if (paramFlowInfo.flowParam != null && paramFlowInfo.flowParam != "") {
					var paramFlow = eval('(' + paramFlowInfo.flowParam + ')');
					var roleGroupSid = paramFlow.node1.split("-")[1];
					var orgType = paramFlow.node1.split("-")[0];
					$("#nextOrgType").val(orgType)
					$("#roleGroupSid").val(roleGroupSid);
					$("#roleGroupName").val(roleGroupMap.get(roleGroupSid));
					$("#nodeId").val("node1");
					findPeopleInfo(orgType,roleGroupSid);
				} else {
					$("#paperType option:first").prop("selected", 'selected');
					alert("请先配置业务流程参数");
				}
			} else {
				$("#paperType option:first").prop("selected", 'selected');
				alert("请先配置业务流程参数");
			}
		} else {
			alert(data.response.responseMessage.message);
		}
	} catch (e) {
		return e.message;
	}
	
}

/**
 * 查询角色信息
 */
function initAllRoleGroups () {
	try {
		var url = ctx + "/gss/paramflow/gssParamFlow_queryAllRoleGroupInfo.action";
		var param = {};
		var data = tool.ajaxRequest(url,param);
		var roleGroupData = null;
		if (data.success) {
			if(data.response.responseMessage.success && data.response.responseMessage.data && data.response.responseMessage.data != null){
				roleGroupData = data.response.responseMessage.data;
				if (roleGroupData && roleGroupData != null && roleGroupData.length > 0) {
					$(roleGroupData).each(
							function(i, value) {
								var roleGroup = value.split(",");
								var roleGroupSid = roleGroup[0];
								var roleGroupName = roleGroup[1];
								roleGroupMap.put(roleGroupSid,roleGroupName);
							});
				}
			}
		} else {
			alert(data.response);
		}
	} catch (e) {
		return e.message;
	}
}

/**
 * 查询相应机构类型角色下的人员
 */
function findPeopleInfo (orgType,roleGroupSid) {
	try {
		var url = ctx + "/ext/po/extPersonnelAction_findPersonnelByOrgAndRoleGroup.action";
		var param = {"orgType":orgType,"roleGroupSid":roleGroupSid};
		var data = tool.ajaxRequest(url,param);
		var option = "<option value='' name='tableApply.nextHandlerSid'>--请选择--</option>";
		if (data.success) {
			if (data.response.personnels != null && data.response.personnels.length > 0) {
				var personnels = data.response.personnels;
				$(personnels).each(
					function(i,value) {
						option += "<option value='"+value.sid+"'>"+value.personnelName+"</option>";
					}
				);
				$("#nextHandlerSid").html(option);
				$("#nextHandleDiv").dialog("open");
			} else {
				$("#paperType option:first").prop("selected", 'selected');
				alert("未配置相关角色人员");
			}
		} else {
			alert(data.response.responseMessage.message);
		}
	} catch (e) {
		return e.message;
	}
}

function deleteApply() {
	var url = ctx + "/sealusetask/create/sealUseTask_deleteTask.action";
	var param = {"tableApply.id":$("#id").val()};
	var data = tool.ajaxRequest(url,param);
	if(data.success) {
		queryApplyInfoForTerm();
		$("#sealUseTaskInfo").dialog("close");
	}
}

function checkLength(id,maxlength) {
	var value = $(id).val();
	if(value.length > maxlength) {
		alert("输入字数不能超过:" + maxlength);
		$(id).focus();
	}
}

function cancel() {
	var url = ctx + "/sealusetask/create/sealUseTask_cancelTask.action";
	var param = {"tableApply.id":$("#id").val()};
	var data = tool.ajaxRequest(url, param);
	if(data.success){
		if(data.response.webResponseJson.data) {
			queryApplyInfoForTerm();
			$("#sealUseTaskInfo1").dialog("close");
		} else {
			alert("正在复核中，无法撤回!");
		}
    }else{
		var message = reslut.response.webResponseJson.message;
		alert(message);
	}
}
/**
 * 图片展示
 * 
 * @param storeId
 */
function startViewImage(storeId) {
    wfStoreFancyBox.showAllImageByStoreId(storeId, "buttons");
};