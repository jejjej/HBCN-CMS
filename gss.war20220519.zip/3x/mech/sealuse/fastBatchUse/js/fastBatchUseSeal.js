/**
 * 创建于:2015-10-21<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 机控多票据用印JS（多张凭证在同一个位置用印）<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var machine_num;

// 图片尺寸误差
var size_deviation = 0.05;

// 凭证图像
var use_cut_img = true;
var src_img_path, cut_img_path;
var big_pic_width = 0, big_pic_height = 0;
var small_pic_width = 0, small_pic_height = 0;
var display_pic_width = 0, display_pic_height = 0;

// 用印数据
var use_model = {
	"isFirst" : true,
	"firstImgWidth" : 0,
	"firstImgHeight" : 0
};

$().ready(
		function() {
			// 初始化控件
			var ret = ocxbase_messageHandler.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			ret = ocxbase_fileStore.initOcx(basePath);
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			ret = ocxbase_xusbVideo.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			ret = ocxbase_sealMachine.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};

			// 初始化交易代码下拉框
			selectUtils.initTradeCodeConfig("tradeCode", 1);
			$("#tradeCode").change(function(){
				if($(this).val() == ""){
					var option = "<option value=\"\">--请选择--</option>";
					$("#sealTypeCode").html(option);
				}else{
					selectUtils.initSealTypeConfigByTradeCode($(this).val(),"sealTypeCode",1);
				}
			});
			$("#sealTypeCode").change(function(){
			});

			// 盖章位置印章图片处理
			ocxbase_utils.sealImageHandler.init("body", "voucherImg",
					ocxbase_utils.sealImageHandler.external.imageClickCallback);

			// 绑定onclick事件
			$("#applyBtn").bind("click", openPaperDoor);
			$("#commitBtn").bind("click", useSeal);
			$("#switchVoucherImage").bind("click", switchVoucherImage);
			$("#rotateSealImage").bind("click", ocxbase_utils.sealImageHandler.rotateSealImage);

			ocxbase_messageHandler.bindNextUseSealClickEvent(startNextUseSeal);
			ocxbase_messageHandler.bindCompleteClickEvent(completeUseSeal);
			
			var queryurl = ocxbase_exceptionLogHandler.ctx + "/3xbase/useSealExceptionAction_findErrorRecord.action";
			var dealurl = ocxbase_exceptionLogHandler.ctx + "/3xbase/useSealExceptionAction_updateErrorRecord.action";
			ocxbase_exceptionLogHandler.setExceptionData(queryurl, null, dealurl, null);
			
			// 初始化设备
			ocxbase_messageHandler.showTipMessage("设备初始化中，请稍候...");
			window.setTimeout(function() {
				var connResult = ocxbase_machineAndCameraConnProxy.connect(machineReady);
				if (!connResult.success) {
					ocxbase_messageHandler.dealErrorMssage(connResult.data);
				}
			}, 500);
		});

// 设备连接结果回调事件
function machineReady(ret) {
	if (ret.success) {
		machine_num = ocxbase_sealMachine.getMachineNum();

		// 初始化用印范围红框顶点数据 sealBoundaryUtil.js
		var boundaryRet = setMaxMinDistance(machine_num);
		if (!boundaryRet) {
			return;
		}

		openPaperDoor();
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}
};

// 用印前打开纸板
function openPaperDoor() {
	$('#applyBtn').attr("disabled", true);

	ocxbase_utils.sealImageHandler.clearSealImage();
	var ret = ocxbase_sealMachine.openPaperDoor(doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	} else {
		ocxbase_messageHandler.showTipMessage("请放入凭证...");
	}

	// 纸板关闭回调函数
	function doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		setTimeout(function() {
			dealUseSealProcess("start", null, null);
		}, ocxbase_iniHelper.configParam.closecapture_maincamera_dealy);
	}
};

/**
 * 用印过程处理<br>
 * 
 * @param state：'start'、'end'
 * @param useSealSuccess：true/false(非用印结束时可传入null)
 * @param useSealErrorMsg：用印异常信息(非用印结束时可传入null)
 */
function dealUseSealProcess(state, useSealSuccess, useSealErrorMsg) {
	var srcImgPath, cutImgPath, transImagePath;
	var ret = ocxbase_xusbVideo.captureImage(false, state);
	if (ret.success) {
		srcImgPath = ret.data.srcImagePath;
		cutImgPath = ret.data.cutImagePath;
		transImagePath = ret.data.transImagePath;
		src_img_path = srcImgPath;
		cut_img_path = cutImgPath;

		// 显示凭证图像
		document.getElementById("voucherImg").src = transImagePath;
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
		return;
	}

	if ("start" == state) {
		// 计算图像裁剪前后的大小
		var cutSize = ocxbase_xusbVideo.getLastCutImageSize();
		if (cutSize.success) {
			small_pic_width = cutSize.data.width;
			small_pic_height = cutSize.data.height;
			big_pic_width = ocxbase_xusbVideo.cameraInfo.width;
			big_pic_height = ocxbase_xusbVideo.cameraInfo.height;
		} else {
			ocxbase_messageHandler.dealErrorMssage(cutSize.data);
			return;
		}

		// 显示用印边界线
		queryCornerPoints(small_pic_width, small_pic_height, big_pic_width, big_pic_height);
		document.getElementById("voucherImg").onload = function() {
			var img = document.getElementById("voucherImg");
			display_pic_width = img.width;
			display_pic_height = img.height;
			if (use_cut_img) {
				showBoundaryCanvas("sealCanvasDiv", "voucherImg", use_cut_img, small_pic_width, small_pic_height);
			} else {
				showBoundaryCanvas("sealCanvasDiv", "voucherImg", use_cut_img, small_pic_width, small_pic_height);
			}
		};

		// 释放相应按钮
		$("#commitBtnTd").css('display', "");
		showSwitchVoucherImageBtn();
		ocxbase_messageHandler.hideWaittingDialog();
	} else if ("end" == state) {
		var uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cutImgPath, "append");
		if (!uploadRet.success) {
			ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
			return;
		}
		if (useSealSuccess) {
			ocxbase_messageHandler.showTipMessage("盖章完毕，请取凭证！</br>如果要继续下一笔业务，请先放入凭证，再关纸盒！");
			useSealCompletedOpenPaperDoor();
		} else {
			ocxbase_messageHandler.dealErrorMssage(useSealErrorMsg);
			return;
		}
	}

	$('#applyBtn').attr("disabled", false);
};

// 用印
function useSeal() {
	var xPosition = $("#xPosition").val();
	var yPosition = $("#yPosition").val();
	var tradeCode = $("#tradeCode").val();
	if (!xPosition || !yPosition) {
		alert("请选择盖章坐标!");
		ocxbase_messageHandler.hideWaittingDialog();
		return;
	}
	if (!tradeCode) {
		alert("请选择交易名称!");
		ocxbase_messageHandler.hideWaittingDialog();
		return;
	}
	var sealTypeCode = $("#sealTypeCode").val();
	if(!sealTypeCode){
		alert("请选择印章类型");
		ocxbase_messageHandler.hideWaittingDialog();
		return;
	}

	ocxbase_messageHandler.showTipMessage("准备开始用印...");

	// 上传用印前凭证图像
	var uploadRet;
	if (use_cut_img) {
		uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cut_img_path, "add");
	} else {
		uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(src_img_path, "add");
	}
	if (!uploadRet.success) {
		ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
		return;
	}

	// 是否盖骑缝章
	var isAcrossPageSeal = false;
	var useSealPattern = $("#useSealPattern").val();
	if (useSealPattern == "2") {
		isAcrossPageSeal = true;
	}

	// 计算盖章角度
	var angle;
	var cutAngle = ocxbase_xusbVideo.getLastCutImageAngle();
	if (cutAngle.success) {
		angle = cutAngle.data + ocxbase_utils.sealImageHandler.getSealAngle();
		angle = (angle + 360) % 360;
	} else {
		ocxbase_messageHandler.dealErrorMssage(cutAngle.data);
		return;
	}

	// 计算盖章坐标
	// 用原图还是裁剪图片
	var imgWidth = big_pic_width;
	var imgHeight = big_pic_height;
	if (use_cut_img) {
		imgWidth = small_pic_width;
		imgHeight = small_pic_height;
	}
	// 用印裁剪图片并裁剪成功时需计算在原图中的坐标
	var useSealXpos = multiply(xPosition / 100, imgWidth);
	var useSealYpos = multiply(yPosition / 100, imgHeight);
	if (!ocxbase_xusbVideo.imageMateWidthHeight(imgWidth, imgHeight)) {
		var ret = ocxbase_xusbVideo.getLastCutInSrcPosition(useSealXpos, useSealXpos);
		if (ret.success) {
			useSealXpos = ret.data.x;
			useSealYpos = ret.data.y;
		} else {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
	}

	// 记录用印信息
	if (use_model["isFirst"]) {
		use_model["isFirst"] = false;
		use_model["firstImgWidth"] = imgWidth;
		use_model["firstImgHeight"] = imgHeight;
	} else {
		// 判断是否与原纸大小一致
		if (!checkPaper(use_model["firstImgWidth"], use_model["firstImgHeight"], imgWidth, imgHeight)) {
			alert("检测到更换了纸张，请重新选章并设置盖章位置后进行用印!");
			ocxbase_messageHandler.hideWaittingDialog();
			return;
		}
	}

	// 新增用印业务信息
	$("#machineNum").val(machine_num);
	var creatRet = ocxbase_bizInfoAjax.bizInfo.createStartUseMechSeal(ctx
			+ "/mechseal/sealuse/fastBatchUseMechSealAction_createFastUseMechSeal.action","mechSealUseApplyInfo");
	if (!creatRet.success) {
		ocxbase_messageHandler.dealErrorMssage(creatRet.data);
		return;
	}

	ocxbase_messageHandler.showTipMessage("正在用印...");

	// 开始用印
	var useRet = ocxbase_sealMachine.startUseSeal(sealTypeCode, isAcrossPageSeal, angle, useSealXpos, useSealYpos,
			useSealCallback);
	if (!useRet.success) {
		ocxbase_messageHandler.dealErrorMssage(useRet.data);
		return;
	}

	// 用印结束回调函数
	function useSealCallback(ret) {
		// 保存用印信息
		var memo, status;
		if (ret.success) {
			status = sealUseConstants.USE_SEAL_SUCCESS;
			memo = ret.data.message;
			$("#sealPosition").val(ret.data.sealPos);
		} else {
			memo = ret.data.errMsg;
			if (ret.data.errCode == "USE_SEAL_DISCONNECT") {
				status = sealUseConstants.USE_SEAL_DISCONNECT;
			} else if (ret.data.errCode == "USE_SEAL_ERROR") {
				status = sealUseConstants.USE_SEAL_EXCEPTION;
			}
		}
		$("#status").val(status);
		$("#bizMemo").val(memo);
		$("#logMemo").val(memo);
		var updateRet = ocxbase_bizInfoAjax.bizInfo.updateUseMechSealResult(ctx
				+ "/mechseal/sealuse/fastBatchUseMechSealAction_updateFastUseMechSeal.action","mechSealUseApplyInfo");
		if (!updateRet.success) {
			ocxbase_messageHandler.dealErrorMssage(updateRet.data);
			return;
		}

		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		setTimeout(function() {
			dealUseSealProcess("end", ret.success, memo);
		}, ocxbase_iniHelper.configParam.overcapture_maincamera_delay);
	}
};

// 用印结束弹出纸板
function useSealCompletedOpenPaperDoor() {
	var ret = ocxbase_sealMachine.openPaperDoor(_doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}

	// 纸板关闭回调函数
	function _doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}

		ocxbase_messageHandler.showTipMessage("是否继续下一笔业务？");
		ocxbase_messageHandler.showAllButton();
	}
};

// 开始下一笔用印
function startNextUseSeal() {
	ocxbase_messageHandler.hideAllButton();
	ocxbase_messageHandler.showTipMessage("正在拍照处理中...");
	dealUseSealProcess("start", null, null);
	useSeal();
};

// 结束用印
function completeUseSeal() {
	resetPropsCache();
};

// 切换凭证裁剪前后图像
function switchVoucherImage() {
	// 切换凭证图像
	if (use_cut_img) {
		use_cut_img = false;
		document.getElementById("voucherImg").src = src_img_path;
	} else {
		use_cut_img = true;
		document.getElementById("voucherImg").src = img_path;
	}

	// 重置用印位置信息
	$("#xPosition").val("");
	$("#yPosition").val("");
	ocxbase_utils.sealImageHandler.clearSealImage();
	$("#rotateSealImageId").css('display', 'none');
};

function showSwitchVoucherImageBtn() {
	if (fast_switch_voucher_image) {
		$("#switchVoucherImageId").css('display', '');
	}
};

// 重置属性缓存
function resetPropsCache() {
	document.getElementById("voucherImg").onload = null;
	clearSealCanvas("sealCanvasDiv");
	document.getElementById("voucherImg").src = ctx + "/3x/ocxbase/useSealFramework/ocxbase_voucherImg.png";
	ocxbase_messageHandler.hideWaittingDialog();
	use_cut_img = true;
	src_img_path = null;
	cut_img_path = null;
	$("#applyBtnTd").css('display', '');
	$('#applyBtn').attr("disabled", false);
	$("#mechSealUseApplyInfo")[0].reset();
	$("#commitBtnTd").css('display', 'none');
	ocxbase_messageHandler.hideAllButton();
	ocxbase_utils.sealImageHandler.clearSealImage();
	$("#rotateSealImageId").css('display', 'none');
	$("#switchVoucherImageId").css('display', 'none');
	$("#status").val("");
	use_model["isFirst"] = true;
	use_model["firstImgWidth"] = 0;
	use_model["firstImgHeight"] = 0;
};

/**
 * 页面关闭响应事件
 */
function closePage() {
	ocxbase_machineAndCameraConnProxy.disconnect();
};

/**
 * 判断纸张大小是否发生改变
 * 
 * @param modlex
 * @param modley
 * @param picx
 * @param picy
 * @returns {Boolean}
 */
function checkPaper(modlex, modley, picx, picy) {
	var xVerify = Math.abs(modlex - picx) / modlex;
	var yVerify = Math.abs(modley - picy) / modley;
	if (xVerify > size_deviation || yVerify > size_deviation)
		return false;
	return true;
};