/**
 * 创建于:2015-10-20<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 机控印章快速用印JS（点哪盖哪快速用印，一次只能盖一个章）<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var machine_num;

// 凭证图像
var use_cut_img = true;
var src_img_path, cut_img_path;
var big_pic_width = 0, big_pic_height = 0;
var small_pic_width = 0, small_pic_height = 0;
var display_pic_width = 0, display_pic_height = 0;
var biz_finish = false;
var autoId = null;

$().ready(
		function() {
			var basePathUrl = decodeURIComponent(getURLParam("basePath"));
			if(basePathUrl != "") {
				basePath = basePathUrl;
			}
			// 初始化控件
			var ret = ocxbase_messageHandler.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			ret = ocxbase_fileStore.initOcx(basePath);
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			ret = ocxbase_xusbVideo.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			ret = ocxbase_sealMachine.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};

			// 初始化交易代码下拉框
			/*selectUtils.initTradeCodeConfig("tradeCode", 1);
			$("#tradeCode").change(function(){
				if($(this).val() == ""){
					var option = "<option value=\"\">--请选择--</option>";
					$("#sealTypeCode").html(option);
				}else{
					selectUtils.initSealTypeConfigByTradeCode($(this).val(),"sealTypeCode",1);
				}
			});*/
			selectUtils.initSealBizType("sealTypeCode",1);
			// 盖章位置印章图片处理
//			ocxbase_utils.sealImageHandler.init("body", "voucherImg",
//					ocxbase_utils.sealImageHandler.external.imageClickCallback);
			
			// 交易名称下拉列表热键
//			ocxbase_utils.selectHotKey.init("tradeCode");
			$("#sealTypeCode").change(function(){
				sealSelect();
			});
			// 绑定onclick事件
			$("#applyBtn").bind("click", openPaperDoor);
			$("#commitBtn").bind("click", useSeal);
			$("#switchVoucherImage").bind("click", switchVoucherImage);
			$("#rotateSealImage").bind("click", ocxbase_utils.sealImageHandler.rotateSealImage);
			document.oncontextmenu = function (e) {
				return false;
			}
			ocxbase_messageHandler.bindNextUseSealClickEvent(startNextUseSeal);
			ocxbase_messageHandler.bindCompleteClickEvent(completeUseSeal);
			ocxbase_messageHandler.bindCancelClickEvent(cancelUseSeal);
			
			var queryurl = ocxbase_exceptionLogHandler.ctx + "/3xbase/useSealExceptionAction_findErrorRecord.action";
			var dealurl = ocxbase_exceptionLogHandler.ctx + "/3xbase/useSealExceptionAction_updateErrorRecord.action";
			ocxbase_exceptionLogHandler.setExceptionData(queryurl, null, dealurl, null);
			
			// 初始化设备
			ocxbase_messageHandler.showTipMessage("设备初始化中，请稍候...");
			window.setTimeout(function() {
				var connResult = ocxbase_machineAndCameraConnProxy.connect(machineReady);
				if (!connResult.success) {
					ocxbase_messageHandler.dealErrorMssage(connResult.data);
					ocxbase_messageHandler.showCancelButton();
				}
			}, 500);
		});

// 设备连接结果回调事件
function machineReady(ret) {
	if (ret.success) {
		machine_num = ocxbase_sealMachine.getMachineNum();

		// 初始化用印范围红框顶点数据 sealBoundaryUtil.js
		var boundaryRet = setMaxMinDistance(machine_num, ocxbase_xusbVideo.defaultProp);
		if (!boundaryRet) {
			return;
		}
		autoId = getURLParam("id");
		if(autoId == null || autoId == "") {
			ocxbase_messageHandler.dealErrorMssage("用印申请单数据异常");
			ocxbase_messageHandler.showCancelButton();
		} else {
			queryUseSeal();		
		}
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
		ocxbase_messageHandler.showCancelButton();
	}
};

// 用印前打开纸板
function openPaperDoor() {
	$('#applyBtn').attr("disabled", true);
	
	ocxbase_utils.sealImageHandler.clearSealImage();
	$("#xPosition").val("");
	$("#yPosition").val("");
	var ret = ocxbase_sealMachine.openPaperDoor(doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
		ocxbase_messageHandler.showCancelButton();
	} else {
		ocxbase_messageHandler.showTipMessage("请放入凭证...");
	}

	// 纸板关闭回调函数
	function doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			ocxbase_messageHandler.showCancelButton();
			return;
		}
		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		setTimeout(function() {
			dealUseSealProcess("start", null, null);
		}, ocxbase_iniHelper.configParam.closecapture_maincamera_dealy);
	}
};

/**
 * 用印过程处理<br>
 * 
 * @param state：'start'、'end'
 * @param useSealSuccess：true/false(非用印结束时可传入null)
 * @param useSealErrorMsg：用印异常信息(非用印结束时可传入null)
 */
function dealUseSealProcess(state, useSealSuccess, useSealErrorMsg) {
	var srcImgPath, cutImgPath, transImagePath;
	var ret = ocxbase_xusbVideo.captureImage(false, state);
	if (ret.success) {
		srcImgPath = ret.data.srcImagePath;
		cutImgPath = ret.data.cutImagePath;
		transImagePath = ret.data.transImagePath;
		src_img_path = srcImgPath;
		cut_img_path = cutImgPath;

		// 显示凭证图像
		document.getElementById("voucherImg").src = transImagePath;
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
		ocxbase_messageHandler.showCancelButton();
		return;
	}

	if ("start" == state) {
		// 计算图像裁剪前后的大小
		var cutSize = ocxbase_xusbVideo.getLastCutImageSize();
		if (cutSize.success) {
			small_pic_width = cutSize.data.width;
			small_pic_height = cutSize.data.height;
			big_pic_width = ocxbase_xusbVideo.cameraInfo.width;
			big_pic_height = ocxbase_xusbVideo.cameraInfo.height;
		} else {
			ocxbase_messageHandler.dealErrorMssage(cutSize.data);
			ocxbase_messageHandler.showCancelButton();
			return;
		}
		
		// 显示用印边界线
		queryCornerPoints(small_pic_width, small_pic_height, big_pic_width, big_pic_height);
		document.getElementById("voucherImg").onload = function() {
			var img = document.getElementById("voucherImg");
			display_pic_width = img.width;
			display_pic_height = img.height;
			if (use_cut_img) {
				showBoundaryCanvas("sealCanvasDiv", "voucherImg", use_cut_img, small_pic_width, small_pic_height);
			} else {
				showBoundaryCanvas("sealCanvasDiv", "voucherImg", use_cut_img, small_pic_width, small_pic_height);
			}
		};

		// 释放相应按钮
		$("#commitBtnTd").css('display', "");
		ocxbase_messageHandler.hideWaittingDialog();
	} else if ("end" == state) {
		var uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cutImgPath, "append");
		if (!uploadRet.success) {
			ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
			ocxbase_messageHandler.showCancelButton();
			return;
		}
		if (useSealSuccess) {
			ocxbase_messageHandler.showTipMessage("盖章完毕，请取凭证！</br>如果要继续下一笔业务，请先放入凭证，再关纸盒！");
			useSealCompletedOpenPaperDoor();
		} else {
			ocxbase_messageHandler.dealErrorMssage(useSealErrorMsg);
			ocxbase_messageHandler.showCancelButton();
			return;
		}
	}

	$('#applyBtn').attr("disabled", false);
};

// 用印
function useSeal() {
	var xPosition = $("#xPosition").val();
	var yPosition = $("#yPosition").val();
//	var tradeCode = $("#tradeCode").val();
	var sealTypeCode = $("#sealTypeCode").val();
	if (!xPosition || !yPosition) {
		alert("请选择盖章坐标!");
		ocxbase_messageHandler.hideWaittingDialog();
		return;
	}
	/*if (!tradeCode) {
		alert("请选择交易名称!");
		ocxbase_messageHandler.hideWaittingDialog();
		return;
	}*/
	if(!sealTypeCode){
		alert("请选择印章类型");
		ocxbase_messageHandler.hideWaittingDialog();
		return;
	}
	ocxbase_utils.sealImageHandler.clearSealImage();
	ocxbase_messageHandler.showTipMessage("准备开始用印...");
	$("#" + ocxbase_utils.sealImageHandler.sealImageDivId).css('display', 'none');
	// 上传用印前凭证图像
	var uploadRet, uploadType;
	if($("#storeId").val()=="" || $("#storeId").val()==null) {
		uploadType = "add";
	} else {
		uploadType = "append";
	}
	if (use_cut_img) {
		uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cut_img_path, uploadType);
	} else {
		uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(src_img_path, uploadType);
	}
	if (!uploadRet.success) {
		ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
		ocxbase_messageHandler.showCancelButton();
		return;
	}

	// 是否盖骑缝章
	var isAcrossPageSeal = false;
	var useSealPattern = $("#useSealPattern").val();
	if (useSealPattern == "2") {
		isAcrossPageSeal = true;
	}

	// 计算盖章角度
	var angle;
	var cutAngle = ocxbase_xusbVideo.getLastCutImageAngle();
	if (cutAngle.success) {
		angle = cutAngle.data + ocxbase_utils.sealImageHandler.getSealAngle();
		angle = (angle + 360) % 360;
	} else {
		ocxbase_messageHandler.dealErrorMssage(cutAngle.data);
		ocxbase_messageHandler.showCancelButton();
		return;
	}

	// 计算盖章坐标
	// 用原图还是裁剪图片
	var imgWidth = big_pic_width;
	var imgHeight = big_pic_height;
	if (use_cut_img) {
		imgWidth = small_pic_width;
		imgHeight = small_pic_height;
	}
	// 用印裁剪图片并裁剪成功时需计算在原图中的坐标
	var useSealXpos = multiply(xPosition / 100, imgWidth);
	var useSealYpos = multiply(yPosition / 100, imgHeight);
	if (!ocxbase_xusbVideo.imageMateWidthHeight(imgWidth, imgHeight)) {
		var ret = ocxbase_xusbVideo.getLastCutInSrcPosition(useSealXpos, useSealXpos);
		if (ret.success) {
			useSealXpos = ret.data.x;
			useSealYpos = ret.data.y;
		} else {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			ocxbase_messageHandler.showCancelButton();
			return;
		}
	}
	var creatRet = updateMechSealUseApplyInfo(sealUseConstants.START_USE);
	if (!creatRet.success) {
		ocxbase_messageHandler.dealErrorMssage(creatRet.data);
		ocxbase_messageHandler.showCancelButton();
		return;
	}
	ocxbase_messageHandler.showTipMessage("正在用印...");

	// 开始用印
	var useRet = ocxbase_sealMachine.startUseSeal(sealTypeCode, isAcrossPageSeal, angle, useSealXpos, useSealYpos,
			useSealCallback);
	if (!useRet.success) {
		ocxbase_messageHandler.dealErrorMssage(useRet.data);
		ocxbase_messageHandler.showCancelButton();
		return;
	}
	
	// 用印结束回调函数
	function useSealCallback(ret) {
		// 保存用印信息
		var memo, status;
		if (ret.success) {
			status = sealUseConstants.USE_SEAL_SUCCESS;
			memo = ret.data.message;
			$("#sealPosition").val(ret.data.sealPos);
		} else {
			memo = ret.data.errMsg;
			if (ret.data.errCode == "USE_SEAL_DISCONNECT") {
				status = sealUseConstants.USE_SEAL_DISCONNECT;
			} else if (ret.data.errCode == "USE_SEAL_ERROR") {
				status = sealUseConstants.USE_SEAL_EXCEPTION;
			}
		}
		$("#status").val(status);
		$("#bizMemo").val(memo);
		$("#logMemo").val(memo);
		var updateRet = updateMechSealUseApplyInfo(status);
		if (!updateRet.success) {
			ocxbase_messageHandler.dealErrorMssage(updateRet.data);
			ocxbase_messageHandler.showCancelButton();
			return;
		}
		
		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		setTimeout(function() {
			dealUseSealProcess("end", ret.success, memo);
		}, ocxbase_iniHelper.configParam.overcapture_maincamera_delay);
	}
};

// 用印结束弹出纸板
function useSealCompletedOpenPaperDoor() {
	var ret = ocxbase_sealMachine.openPaperDoor(_doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
		ocxbase_messageHandler.showCancelButton();
	}

	// 纸板关闭回调函数
	function _doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			ocxbase_messageHandler.showCancelButton();
			return;
		}
		if (biz_finish) {
			ocxbase_messageHandler.showTipMessage("本次用印申请单已全部盖章完毕！");
			ocxbase_messageHandler.showCancelButton();
		} else {
			ocxbase_messageHandler.showTipMessage("是否继续下一笔业务？");
			ocxbase_messageHandler.showAllButton();
		}
	}
};

// 开始下一笔用印
function startNextUseSeal() {
	resetPropsCache();
	ocxbase_messageHandler.showTipMessage("正在拍照处理中...");
	dealUseSealProcess("start", null, null);
};

// 结束用印
function completeUseSeal() {
	resetPropsCache();
};

// 切换凭证裁剪前后图像
function switchVoucherImage() {
	// 切换凭证图像
	if (use_cut_img) {
		use_cut_img = false;
		document.getElementById("voucherImg").src = src_img_path;
	} else {
		use_cut_img = true;
		document.getElementById("voucherImg").src = img_path;
	}

	// 重置用印位置信息
	$("#xPosition").val("");
	$("#yPosition").val("");
	ocxbase_utils.sealImageHandler.clearSealImage();
	$("#rotateSealImageId").css('display', 'none');
};

// 重置属性缓存
function resetPropsCache() {
	document.getElementById("voucherImg").onload = null;
	clearSealCanvas("sealCanvasDiv");
	document.getElementById("voucherImg").src = ctx + "/3x/ocxbase/useSealFramework/ocxbase_voucherImg.png";
	ocxbase_messageHandler.hideWaittingDialog();
	use_cut_img = true;
	src_img_path = null;
	cut_img_path = null;
	$("#applyBtnTd").css('display', '');
	$('#applyBtn').attr("disabled", false);
//	$("#useSealBizInfo")[0].reset();
	$("#commitBtnTd").css('display', 'none');
	ocxbase_messageHandler.hideAllButton();
	ocxbase_utils.sealImageHandler.clearSealImage();
	$("#rotateSealImageId").css('display', 'none');
	$("#status").val("");
	$("#xPosition").val("");
	$("#yPosition").val("");
};

function queryUseSeal(){
	var result = null;
	var success = false;
	$.ajax({
		type : "post",
		url : ctx + "/mechseal/sealuse/mechSealUseApplyAction_gainTask.action",
		data : {
			"id" : autoId
		},
		dataType : "json",
		async : false,
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0" || XMLHttpRequest.status != "200") {
				result = '服务器响应失败';
			}
		},
		success : function(response) {
			result = response;
			if (response.responseMessage.success == true) {
				success = true;
			} else {
				result = response.responseMessage.message;
			}
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
			if (textStatus != null) {
				result = textStatus;
			} else {
				result = errorThrown;
			}
		}
	});
	if (success) {
		var bizInfo = result.sealUseApplyInfo;
		var sealCode = getURLParam("code");
		$("#sealTypeCode").val(sealCode);
		$("#sealTypeName").val($("#sealTypeCode option:selected").html() + " -- " + bizInfo.usedNum + "\\" + bizInfo.applyNum);
		if(bizInfo.storeId != "" && bizInfo.storeId != null) {
			$("#storeId").val(bizInfo.storeId);
		}
		if (bizInfo.usedNum == bizInfo.applyNum || bizInfo.status == sealUseConstants.USE_SEAL_SUCCESS) {
			biz_finish = true;
			ocxbase_messageHandler.showTipMessage("本用印申请单已全部盖章完毕！");
			ocxbase_messageHandler.showCancelButton();
		} else {
			// 打开纸板
			openPaperDoor();
		}
	} else {
		ocxbase_messageHandler.dealErrorMssage(result);
		ocxbase_messageHandler.showCancelButton();
	}
}

function updateMechSealUseApplyInfo(status) {
	var param = {
		"sealUseApplyInfo.id" : autoId,
		"sealUseApplyInfo.storeId" : $("#storeId").val(),
		"operResult" : status
	};
	var url = ctx + "/mechseal/sealuse/mechSealUseApplyAction_updateMechUseSeal.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		if (data.response.responseMessage.success == true) {
			var bizInfo = data.response.responseMessage.data;
			$("#sealTypeName").val($("#sealTypeCode option:selected").html() + " -- " + bizInfo.usedNum + "\\" + bizInfo.applyNum);
			if (bizInfo.usedNum == bizInfo.applyNum || bizInfo.status == sealUseConstants.USE_SEAL_SUCCESS) {
				biz_finish = true;
			}
			return ocxbase_utils.genOptResult(true, null);
		} else {
			return ocxbase_utils.genOptResult(false, data.response.responseMessage.message);
		}
	} else {
		return ocxbase_utils.genOptResult(false, "更新用印结果服务器响应失败：" + data.response);
	}
};

/**
 * 页面关闭响应事件
 */
function closePage() {
	ocxbase_machineAndCameraConnProxy.disconnect();
};

//返回
function cancelUseSeal() {
	window.parent.location.href = ctx+"/psio/tdk/ui/directPrint.jsp";
};

function getURLParam(key) {
	var reg = new RegExp('(^|&)' + key + '=([^&]*)(&|$)', 'i');
	var r = window.parent.location.search.substr(1).match(reg);
	if (r != null) {
		return unescape(r[2]);
	}
	return null;
}

function sealSelect(){
	var t_tradecode = $("#sealTypeCode").val();
	var diameter = null;
	var shape = null;
	if(t_tradecode == '' || t_tradecode == null){
		alert("请选择印章种类！");
		return;
	}
	var url = ctx + "/mechseal/sealhandle/sealHandleAndWhAction_querySealInfoBySealTypeAndOrgNo.action";
	var param = {
		"sealdeviceNum" : ocxbase_sealMachine.getMachineNum(),
		"sealSealType" : t_tradecode
	};
	var data = tool.ajaxRequest(url,param);
	if (data.success) {
		if(data.response.responseMessage.success){
			//表单填充数据
			diameter = data.response.diameter;
			relDiameter = data.response.relDiameter;
			relPx = data.response.relPx;
			shape = data.response.shape;
			// 盖章位置印章图片处理
			ocxbase_utils.sealImageHandler.initBak("body", "voucherImg",shape,relPx,relDiameter,diameter,
					ocxbase_utils.sealImageHandler.external.imageClickCallback);
		}else{
			alert(data.response.responseMessage.message);
			return;
		}
	} else {
		alert(data.response);
		return;
	}
}