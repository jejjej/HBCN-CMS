/**
 * 创建于:2015-10-27<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 机控印章远程审批用印JS（一客户端申请另一客户端实时审核用印）<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var machine_num;

// 凭证图像
var use_cut_img = true;
var src_img_path, cut_img_path;
var big_pic_width = 0, big_pic_height = 0;
var small_pic_width = 0, small_pic_height = 0;
var display_pic_width = 0, display_pic_height = 0;

// 实时审核
var wait_approving = "wait_approving"; // 用印审核默认值
var approval_result = wait_approving; // 用印审核结果，pass/refuse/approving
//<交易码，list[印章配置信息]>
var sealConfigs = new Map();

//<id，sealConfig>
var sealConfigMap = new Map();
var waitting_apprresult_timeout_clear = null;

//页面默认图片
var defaultSealImg = top.ctx + "/3x/ocxbase/useSealFramework/ocxbase_seal_0.png";
var defaultVoucherImg = top.ctx + "/3x/ocxbase/useSealFramework/ocxbase_voucherImg.png";

var mouse_pos_x = null; // 鼠标X坐标
var mouse_pos_y = null; // 鼠标Y坐标

$().ready(function() {
	
	$(".hideTR").hide();
	
	initSealConfigs();
	
	$("#checkCodeBtn").click(function(){
		var checkCode = $("#checkCode").val();
		var btnName = $(this).val();
		var xPosition = $("#xPosition").val();
		var yPosition = $("#yPosition").val();
		$("#bizInfo")[0].reset();
		$("#xPosition").val(xPosition);
		$("#yPosition").val(yPosition);
//		$("#sealImageDiv").css("display", "none");
		if (btnName == "验证" && checkCode) {
			var bizInfoRet = findByCheckCode(checkCode);
			if (bizInfoRet.success && bizInfoRet.data) {
				$(".hideTR").show();
				var bizInfo = bizInfoRet.data;
				if (bizInfo.status == sealUseConstants.START_USE) {
					$("#showMessage").html("该验证码正在用印!");
					openPaperDoor();
					return;
				}
				var _sealConfigs = sealConfigs.get(bizInfo.tradeCode);
				var flag = false;
				if (_sealConfigs && _sealConfigs.length > 0) {
					var options = "<option value=''>--请选择--</option>";
					var distinctSeal = {};
					for (var i = 0, len = _sealConfigs.length; i < len; i++) {
						var sealConfig = _sealConfigs[i];
						var sealType = sealConfig.reSealTypeId;
						if (sealType) {
							var sealTypeName = GPCache.get(GPCache.SMS, GPType.SMS_SEAL_TYPE, sealType);
							if (sealTypeName && distinctSeal.hasOwnProperty("sealType") == false) {
								flag = true;
								options += "<option value='"+ sealType +"' data='"+ sealConfig.autoId +"'>"+ sealTypeName +"</option>";
								distinctSeal[sealType] = sealTypeName;
							}
						}
					}
					if (!flag) {
						$("#showMessage").html("该交易码未进行印章类型配置!");
					}
					$("#sealTypeCodeId").html(options);
					$("#sealTypeCodeNameId").val("");
				} else {
					$("#showMessage").html("该交易码未进行印章类型配置!");
					return;
				}
				$("#bizInfo").fillForm({
					bizInfo : bizInfo
				});
				$("#checkCode").attr("disabled", "disabled");
				$("#checkCodeBtn").val("重置");
				$("#showMessage").html("验证码认证成功!");
			} else {
				$("#showMessage").html("验证码不正确!");
			}
			
		} else {
			$(".hideTR").hide();
			$("#checkCode").removeAttr("disabled");
			$("#checkCodeBtn").val("验证");
			$("#showMessage").html("请输入验证码!");
		}
	});
	
	$("#sealTypeCodeId").change(function(){
		$("#sealType").val($(this).val());
		var sealTypeName = GPCache.get(GPCache.SMS, GPType.SMS_SEAL_TYPE, $(this).val());
		if (sealTypeName) {
			var autoId = $("#sealTypeCodeId option:selected").attr("data");
			var sealConfig = sealConfigMap.get(autoId);
			if (sealConfig) {
				$("#billCodeId").val(sealConfig.billTplCode);
				$("#billNameId").val(sealConfig.billTplName);
			}
			
			$("#sealTypeCodeNameId").val(sealTypeName);
		} else {
			$("#sealTypeCodeNameId").val("");
			$("#billCodeId").val("");
			$("#billNameId").val("");
		}
	});
	
	$("#reCaptureImage").click(function(){
		setTimeout(function() {
			$("#xPosition, #yPosition").val("");
			$("#sealImageDiv").css('display', 'none');
			dealUseSealProcess("start", null, null);
		}, 100);
	});
	
	// 初始化控件
	var ret = ocxbase_messageHandler.initOcx();
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	ret = ocxbase_fileStore.initOcx(basePath);
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	ret = ocxbase_xusbVideo.initOcx();
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	ret = ocxbase_sealMachine.initOcx();
	if (!ret.success) {
		ocxbase_messageHandler.showTipMessage(ret.data);
		return;
	};
	// 盖章位置印章图片处理
	ocxbase_utils.sealImageHandler.init("body", "voucherImg",
			ocxbase_utils.sealImageHandler.external.imageClickCallback);

	// 绑定onclick事件
	$("#applyBtn").bind("click", openPaperDoor);
	$("#commitBtn").bind("click", startUseSeal);
	$("#switchVoucherImage").bind("click", switchVoucherImage);
	$("#rotateSealImage").bind("click", ocxbase_utils.sealImageHandler.rotateSealImage);

	ocxbase_messageHandler.bindNextUseSealClickEvent(startNextUseSeal);
	ocxbase_messageHandler.bindCompleteClickEvent(completeUseSeal);
	ocxbase_messageHandler.bindCancelClickEvent(cancelUseSeal);
	
	var queryurl = ocxbase_exceptionLogHandler.ctx + "/3xbase/useSealExceptionAction_findErrorRecord.action";
	var dealurl = ocxbase_exceptionLogHandler.ctx + "/3xbase/useSealExceptionAction_updateErrorRecord.action";
	ocxbase_exceptionLogHandler.setExceptionData(queryurl, null, dealurl, null);
	// 初始化设备
	ocxbase_messageHandler.showTipMessage("设备初始化中，请稍候...");
	OCX_Logger.info(LOGGER._3X,"访问电子印章补盖模块");
	window.setTimeout(function() {
		var connResult = ocxbase_machineAndCameraConnProxy.connect(machineReady);
		if (!connResult.success) {
			ocxbase_messageHandler.dealErrorMssage(connResult.data);
		}
	}, 500);
});

// 设备连接结果回调事件
function machineReady(ret) {
	if (ret.success) {
		machine_num = ocxbase_sealMachine.getMachineNum();
		var result = ocxbase_sealMachine.checkUseMachineAuthorization(machine_num);
		if (!result.success) {
			ocxbase_messageHandler.dealErrorMssage(result.data);
		} else {
			var boundaryRet = setMaxMinDistance(machine_num);
			if (!boundaryRet) {
				return;
			}
			openPaperDoor();
		}
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}
};

// 用印前打开纸板
function openPaperDoor() {
	$('#applyBtn').attr("disabled", true);

	var ret = ocxbase_sealMachine.openPaperDoor(doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	} else {
		ocxbase_messageHandler.showTipMessage("请放入凭证...");
	}

	// 纸板关闭回调函数
	function doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		setTimeout(function() {
			dealUseSealProcess("start", null, null);
		}, ocxbase_iniHelper.configParam.closecapture_maincamera_dealy);
	}
};

/**
 * 用印过程处理<br>
 * 
 * @param state：'start'、'end'
 * @param useSealSuccess：true/false(非用印结束时可传入null)
 * @param useSealErrorMsg：用印异常信息(非用印结束时可传入null)
 */
function dealUseSealProcess(state, useSealSuccess, useSealErrorMsg) {
	var srcImgPath, cutImgPath, transImagePath;
	var ret = ocxbase_xusbVideo.captureImage(false, state);
	if (ret.success) {
		srcImgPath = ret.data.srcImagePath;
		cutImgPath = ret.data.cutImagePath;
		transImagePath = ret.data.transImagePath;
		src_img_path = srcImgPath;
		cut_img_path = cutImgPath;

		// 显示凭证图像
		document.getElementById("voucherImg").src = transImagePath;
		$("#inputText").css('display', '');
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
		return;
	}

	if ("start" == state) {
		// 计算图像裁剪前后的大小
		var cutSize = ocxbase_xusbVideo.getLastCutImageSize();
		if (cutSize.success) {
			small_pic_width = cutSize.data.width;
			small_pic_height = cutSize.data.height;
			big_pic_width = ocxbase_xusbVideo.cameraInfo.width;
			big_pic_height = ocxbase_xusbVideo.cameraInfo.height;
		} else {
			ocxbase_messageHandler.dealErrorMssage(cutSize.data);
			return;
		}
		// 显示用印边界线
		queryCornerPoints(small_pic_width, small_pic_height, big_pic_width, big_pic_height);
		document.getElementById("voucherImg").onload = function() {
			var img = document.getElementById("voucherImg");
			display_pic_width = img.width;
			display_pic_height = img.height;
			if (use_cut_img) {
				showBoundaryCanvas("sealCanvasDiv", "voucherImg", use_cut_img, small_pic_width, small_pic_height);
			} else {
				showBoundaryCanvas("sealCanvasDiv", "voucherImg", use_cut_img, small_pic_width, small_pic_height);
			}
		};
		
		// 释放相应按钮
		//$("#commitBtnTd, #reCaptureImageId").css('display', "");
		showSwitchVoucherImageBtn();
		ocxbase_messageHandler.hideWaittingDialog();
	} else if ("end" == state) {
		
		var uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImage("#sealLogStoreId", cut_img_path, "append");
		if (!uploadRet.success) {
			ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
			return;
		}
		
		if (useSealSuccess) {
			ocxbase_messageHandler.showTipMessage("盖章完毕，请取凭证！</br>如果要继续下一笔业务，请先放入凭证，再关纸盒！");
			useSealCompletedOpenPaperDoor();
		} else {
			ocxbase_messageHandler.dealErrorMssage(useSealErrorMsg);
			return;
		}
	}

	$('#applyBtn').attr("disabled", false);
};

// 向服务器提交用印申请
function startUseSeal() {
	// 上传用印前凭证图像
	var voucherImg =$("#voucherImg").attr("src");
	if (voucherImg == defaultVoucherImg) {
		$("#showMessage").html("请先拍照!");
		return;
	}
	var uploadRet;
	if (use_cut_img) {
		uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cut_img_path, "add");
	} else {
		uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(src_img_path, "add");
	}
	if (!uploadRet.success) {
		ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
		return;
	}
	
	var sealType = $("#sealTypeCodeId").val();
	if (!sealType) {
		$("#showMessage").html("请选择印章类型!");
		return;
	}
	var sealInstallConfigRet = ocxbase_sealMachine.getSealInstallConfig(sealType);
	if (!sealInstallConfigRet.success || !sealInstallConfigRet.data) {
		$("#showMessage").html("该印章类型未找到印章安装信息!");
		return;
	}
	if (!$("#xPosition").val() || !$("#yPosition").val()) {
		$("#showMessage").html("请选择盖章位置!");
		return;
	}
	$("#showMessage").html("");
	localAuth();
};

/**
 * 本地授权
 */
function localAuth() {
	var operAuth = new top.OperAuth();
	operAuth.operType = "coveredUseSeal"; // 权限 (action-auth.xml)
	operAuth.orgLevel = "self";//同机构用户才能审核
	operAuth.authSuccess = function(peopleCode) {
		if (!tool.isNull(peopleCode)) {
			$("#checkPeopleCode").val(peopleCode);
			useSeal();
		} else {
			alert("用印授权方式配置错误，请联系技术人员!");
		}
	};
	operAuth.authCancel = function() {
		alert("必须经过授权人授权");
	};
	operAuth.auth();
}

// 用印
function useSeal() {
	ocxbase_messageHandler.showTipMessage("准备开始用印...");

	// 获取盖章信息
	$("#machineNum").val(machine_num);
	
	// 计算盖章角度
	var angle;
	var cutAngle = ocxbase_xusbVideo.getLastCutImageAngle();
	if (cutAngle.success) {
		angle = cutAngle.data + ocxbase_utils.sealImageHandler.getSealAngle();
		angle = (angle + 360) % 360;
	} else {
		ocxbase_messageHandler.dealErrorMssage(cutAngle.data);
		return;
	}

	// 用原图还是裁剪图片
	var imgWidth = big_pic_width;
	var imgHeight = big_pic_height;
	if (use_cut_img) {
		imgWidth = small_pic_width;
		imgHeight = small_pic_height;
	}
	// 用印裁剪图片并裁剪成功时需计算在原图中的坐标
	var useSealXpos = multiply($("#xPosition").val() / 100, imgWidth);
	var useSealYpos = multiply($("#yPosition").val() / 100, imgHeight);
	
	var uploadRet;
	if (use_cut_img) {
		uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImage("#sealLogStoreId", cut_img_path, "add");
	} else {
		uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImage("#sealLogStoreId", src_img_path, "add");
	}
	if (!uploadRet.success) {
		ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
		return;
	}

	// 新增用印业务信息
	var creatRet = ocxbase_bizInfoAjax.bizInfo.addUseSealLog(ctx
			+ "/mechseal/sealuse/auditUseSealTaskAction_addUseSealLog.action");
	if (!creatRet.success) {
		ocxbase_messageHandler.dealErrorMssage(creatRet.data);
		return;
	}

	ocxbase_messageHandler.showTipMessage("正在用印...");
	
	// 开始用印
	var sealType = $("#sealTypeCodeId").val();
	var useRet = ocxbase_sealMachine.startUseSeal(sealType, false, angle, useSealXpos, useSealYpos,
			useSealCallback);
	if (!useRet.success) {
		ocxbase_messageHandler.dealErrorMssage(useRet.data);
		return;
	}

	// 用印结束回调函数
	function useSealCallback(ret) {
		// 保存用印信息
		var memo, status;
		if (ret.success) {
			status = sealUseConstants.USE_SEAL_SUCCESS;
			memo = ret.data.message;
			$("#sealPosition").val(ret.data.sealPos);
		} else {
			memo = ret.data.errMsg;
			if (ret.data.errCode == "USE_SEAL_DISCONNECT") {
				status = sealUseConstants.USE_SEAL_DISCONNECT;
			} else if (ret.data.errCode == "USE_SEAL_ERROR") {
				status = sealUseConstants.USE_SEAL_EXCEPTION;
			}
		}
		$("#status").val(status);
		$("#bizMemo").val(memo);
		$("#logMemo").val(memo);
		var updateRet = ocxbase_bizInfoAjax.bizInfo.updateUseSealLog(ctx
				+ "/mechseal/sealuse/auditUseSealTaskAction_updateUseSealLog.action");
		if (!updateRet.success) {
			ocxbase_messageHandler.dealErrorMssage(updateRet.data);
			return;
		}
		
		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		setTimeout(function() {
			dealUseSealProcess("end", ret.success, memo);
			$("#checkCode").removeAttr("disabled");
		}, ocxbase_iniHelper.configParam.overcapture_maincamera_delay);
	}
};

// 用印结束弹出纸板
function useSealCompletedOpenPaperDoor() {
	var ret = ocxbase_sealMachine.openPaperDoor(_doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}

	// 纸板关闭回调函数
	function _doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}

		ocxbase_messageHandler.showTipMessage("是否继续下一笔业务？");
		ocxbase_messageHandler.showAllButton();
	}
};

// 开始下一笔用印
function startNextUseSeal() {
	resetPropsCache();
	ocxbase_messageHandler.showTipMessage("正在拍照处理中...");
	dealUseSealProcess("start", null, null);
};

function cancelUseSeal() {
	var autoId = $("#bizId").val();
	if (autoId) {
		$.post(top.ctx + "/mechseal/sealuse/auditUseSealTaskAction_cancelTask.action", {"bizInfo.autoId" : autoId}, function(data) {
			if (data.responseMessage.success) {
				if (data.responseMessage.data) {
					ocxbase_messageHandler.showTipMessage("用印审批取消成功.");
					ocxbase_messageHandler.hideButton(ocxbase_messageHandler.btnTdId().ceTdId);
				} else {
					ocxbase_messageHandler.showTipMessage("用印取消失败, 任务正在审批中...");
				}
			}
		});
	}
	
}

// 结束用印
function completeUseSeal() {
	resetPropsCache();
};

// 切换凭证裁剪前后图像
function switchVoucherImage() {
	// 切换凭证图像
	if (use_cut_img) {
		use_cut_img = false;
		document.getElementById("voucherImg").src = src_img_path;
	} else {
		use_cut_img = true;
		document.getElementById("voucherImg").src = img_path;
	}
};

function showSwitchVoucherImageBtn() {
	if (fast_switch_voucher_image) {
		$("#switchVoucherImageId").css('display', '');
	}
};

// 重置属性缓存
function resetPropsCache() {
	document.getElementById("voucherImg").onload = null;
	document.getElementById("voucherImg").src = defaultVoucherImg;
	ocxbase_messageHandler.hideWaittingDialog();
	clearSealCanvas("sealCanvasDiv");
	use_cut_img = true;
	src_img_path = null;
	cut_img_path = null;
	$("#applyBtnTd").css('display', '');
	$('#applyBtn').attr("disabled", false);
	$("#bizInfo")[0].reset();
	$("#commitBtnTd, #reCaptureImageId, #rotateSealImageId").css('display', 'none');
	ocxbase_messageHandler.hideAllButton();
	$("#status").val("");

	approval_result = wait_approving;
	
	resetForm();
	
	$(".hideTR").hide();
	$("#checkCode").removeAttr("disabled");
	$("#checkCodeBtn").val("验证");
};

/**
 * 页面关闭响应事件
 */
function closePage() {
	ocxbase_machineAndCameraConnProxy.disconnect();
};

//获取业务信息
function findByCheckCode(checkCode) {
	var param = {
		"bizInfo.checkCode" : checkCode,
		"bizInfo.operType" : 1
	};
	var url = ctx + "/mechseal/sealuse/auditUseSealTaskAction_findByCheckCodeAndOperType.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		var useSealInfo = data.response.webResponseJson.data;
		if (data.response.webResponseJson.state == "normal") {
			return ocxbase_utils.genOptResult(true, useSealInfo);
		} else {
			return ocxbase_utils.genOptResult(false, useSealInfo);
		}
	} else {
		return ocxbase_utils.genOptResult(false, "服务器响应失败：" + data.response);
	}
};

function initSealConfigs() {
	$.post($.getContextPath() + "/gss/sealconfig/sealConfigAction!listAll.action", {}, function(data) {
		if (data.responseMessage.success) {
			for ( var i = 0, len = data.sealConfigs.length; i < len; i++) {
				var sealConfig = data.sealConfigs[i];
				var _sealConfig = sealConfigs.get(sealConfig.tradeCode);
				if(!_sealConfig) {//不存在则新建
					_sealConfig = [];
				}
				_sealConfig.push(sealConfig);
				sealConfigs.put(sealConfig.tradeCode, _sealConfig);
				sealConfigMap.put(sealConfig.autoId, sealConfig);
			}
		}
	});
}


document.onmousemove = mouseMove;

/**
 * 点击凭证图片事件
 * 
 * @param el
 */
function voucherImgOnClick(el) {
	try {
		var voucherImg =$("#voucherImg").attr("src");
		if (voucherImg == defaultVoucherImg) {
			return;
		}
		// 显示在图片中的位置
		showPosition(el);
		// 显示印章图片
		showSealImage(mouse_pos_x, mouse_pos_y);
	} catch (e) {
	}
};

/**
 * 鼠标位置
 * 
 * @param ev
 * @returns
 */
function mousePosition(ev) {
	try {
		if (ev.pageX || ev.pageY) {
			return {
				x : ev.pageX,
				y : ev.pageY
			};
		}
		return {
			x : ev.clientX + document.body.scrollLeft - document.body.clientLeft,
			y : ev.clientY + document.documentElement.scrollTop
		};
	} catch (e) {
	}
};

/**
 * 鼠标移动
 * 
 * @param ev
 */
function mouseMove(ev) {
	try {
		ev = ev || window.event;
		var mousePos = mousePosition(ev);
		mouse_pos_x = mousePos.x;
		mouse_pos_y = mousePos.y;
	} catch (e) {
	}
};

/**
 * 显示鼠标在图片中的坐标
 * 
 * @param el
 */
function showPosition(el) {
	var x = mouse_pos_x - el.offsetParent.offsetLeft - el.offsetParent.offsetParent.offsetLeft;
	var y = mouse_pos_y - el.offsetParent.offsetTop - el.offsetParent.offsetParent.offsetTop;
	var xPos = Math.round(multiply(x / el.offsetWidth, 100));
	var yPos = Math.round(multiply(y / el.offsetHeight, 100));
	$("#xPosition").val(xPos);
	$("#yPosition").val(yPos);
};

/**
 * 显示印章图片
 * 
 * @param xPos
 * @param yPos
 */
function showSealImage(xPos, yPos) {
	$("#sealImageDiv").css('display', '');
	document.getElementById("sealImage").src = defaultSealImg;
	$("#sealImageDiv").css('top', yPos - 40);
	$("#sealImageDiv").css('left', xPos - 40);
};

/**
 * 重置页面
 */
function resetForm() {
	mouse_pos_x = null;
	mouse_pos_y = null;
	$("#showMessage").html("");
	$("#btn").css('display', 'none');
	$("#inputText").css('display', 'none');
	$("#bizInfo")[0].reset();
	document.getElementById("voucherImg").src = defaultVoucherImg;
	$("#sealImageDiv").css('display', 'none');
	//document.getElementById("sealImage").src = defaultSealImg;
	ocxbase_utils.sealImageHandler.clearSealImage();
};

