/**
 * 创建于:2016-10-27<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 印章装卸及维护<br>
 * 
 * @author dqq
 * @version 1.0.0
 */

var has_init_machine = false; // 印控机初始化标识
var has_open_camera_divice = false; // 摄像头打开标识
var has_open_side_camera = false; // 侧面摄像头打开标识
var is_side_door_open = false;//侧门打开标识
var is_stopvideo = false;//停止录制状态

var chipSoftVersionTag = 0;//主板备板标记 0主板 1备版
var sparePartsNo = "G3600200";
var open_camera_time = 0;//摄像头打开次数
var interval_down_clear;
var waitting_apprresult_timeout_clear;
//设备连接异常计数 连续超过5次以上，计为设备连接异常
var connect_exception_count = 0;
var dialogcount=0;
//每个槽位内印章预定盖印位置数组
var initPosition = {
		pos1:{x0:470,y0:590,x1:530,y1:590,x2:590,y2:590},
		pos2:{x0:1060,y0:590,x1:1120,y1:590,x2:1180,y2:590},
		pos3:{x0:1520,y0:590,x1:1580,y1:590,x2:1640,y2:590},
		pos4:{x0:470,y0:1100,x1:530,y1:1100,x2:590,y2:1100},
		pos5:{x0:1060,y0:1100,x1:1120,y1:1100,x2:1180,y2:1100},
		pos6:{x0:1520,y0:1100,x1:1580,y1:1100,x2:1640,y2:1100}
};//2048*1536下取的坐标点
var seal_index = 0;//印章集合数组索引{槽位号，印章号，是否蘸印油}
var useseal_count = 0;//每个章第几次盖章计数
var check_people;

//任务对象
var currentTask = new Object();
currentTask.taskid="";
//文件对象
var fileObj = new Object();
fileObj.folder = top.yzjgssRootPath + "\\yzjgss\\resources\\3x\\video\\";
fileObj.filepath = "";//文件绝对路径
fileObj.filename = "";//文件名称
fileObj.storeid = "";//storeid
var tasktype;//任务类型 1装卸任务  2维护任务
/**
 * 设备内印章信息
 */
var sealArr = new Array();

// --------------------------------------------------------------
// -------------初始化-----------
// --------------------------------------------------------------
$().ready(function() {
	initWaitingDialog();
	var ret = ocxbase_messageHandler.initOcx();
	if (!ret.success) {
		alert(ret.data);
		return;
	};

    ret = ocxbase_xusbVideo.initOcx();
	if (!ret.success) {
		alert(ret.data);
		return;
	};
	ret = ocxbase_sealMachine.initOcx();
	if (!ret.success) {
		alert(ret.data);
		return;
	};
    ret = ocxbase_fileStore.initOcx(basePath);
    if (!ret.success) {
    	alert(ret.data);
		return;
	};
	
	// 初始化视频控件
	if (!ocxObject.initOcx(ocxObject.OCX_VideoRecorder, document.body, ctx + '/activex/api/', 'run')) {
		alert("初始化视频控件失败");
		return;
	}
	
	var queryurl = ocxbase_exceptionLogHandler.ctx + "/3xbase/sealHandleExceptionAction_findErrorRecord.action";
	var dealurl = ocxbase_exceptionLogHandler.ctx + "/3xbase/sealHandleExceptionAction_updateErrorRecord.action";
	ocxbase_exceptionLogHandler.setExceptionData(queryurl, null, dealurl, null);
	
	// 延时设备初始化
	showWaitingDialog("加载中，请稍候...");
	$("#showimgDiv").hide();
	window.setTimeout(function() {
		initMachineAndOpenCamera();
	}, 500);
	$("#handleButton").click(function(){
		if(chipSoftVersionTag == 1){
			alert("设备接入紧急口，不能进行装卸章操作");
			return;
		}
		tasktype = 1;
		queryMachineStatus();
	});
	$("#maintainButton").click(function(){
		if(chipSoftVersionTag == 0){
			alert("设备未接入紧急口，不能进行维护操作");
			return;
		}
		tasktype = 2;
		queryMachineStatus();
	});
	$("#submitHandleButton").bind("click",submitSealHandle);
	$("#sealCheckButton").bind("click",submitSealCheck);
	$("#sealConfirmButton").bind("click",function(){
		check_people = null;
		$("#confirmDialog").dialog("open");
	});
	$("#sealCheckButton").hide();
	$("#sealConfirmButton").hide();
	
	initSealTypeSelect();
	$(".sealtype").each(function(){
		$(this).on("change",function(){
			var th = $(this).parent();
			//name="configs[x].sealSn" 元素
			var inputsn = $(th).find("input[name$='sealSn']").first();
			var sealTypeName = $(th).find("input[name$='sealTypeName']").first();
			if(null!=$(this).val() && ""!=$(this).val()){
				$(inputsn).val($(this).find("option:selected").attr("sealsn"));
				$(sealTypeName).val($(this).find("option:selected").html());
			}else{
				$(sealTypeName).val("");
				$(inputsn).val("");
			}
		});
	});
});

/**
 * 初始化dialog
 */
function initWaitingDialog() {
	$("#handleDialog").dialog({//印章装卸表单
		autoOpen : false,
		resizable : false,
		closeOnEscape : false,
		height : $(window).height() - 15, 
		width : $(window).width()-130,
		modal : true,
		open : function(event, ui) {
			$("#submitHandleButton").show();
			$("#sealCheckButton").hide();
			$("#sealConfirmButton").hide();
			currentTask = new Object();
			sealArr = new Array();
			querySealInstallConfig();
		},
		close : function(){
			$("#handleDialog")[0].reset();
			checkDialogNum();
			if(dialogcount == 0){
				$(".ui-widget-overlay").remove();
			}
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
	$("#maintainDialog").dialog({//印控机维护表单
		autoOpen : false,
		resizable : false,
		closeOnEscape : false,
		height : 200,
		width : 400,
		modal : true,
		buttons : {
			"提交":function() {
				submitSealMainTain();
			}
		},
		open : function(event, ui) {
			currentTask = new Object();
		},
		close : function(){
			checkDialogNum();
			if(dialogcount == 0){
				$(".ui-widget-overlay").remove();
			}
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
	$("#waitingApprDialog").dialog({//等待审批dialog
		autoOpen : false,
		resizable : false,
		draggable : false,
		closeOnEscape : false,
		height : 290,
		width : 390,
		modal : true,
		close : function() {
			checkDialogNum();
			if(dialogcount == 0){
				$(".ui-widget-overlay").remove();
			}
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").hide();
			$(".ui-dialog-titlebar-close").hide();
			$('.ui-dialog-buttonpane').find('button:contains("取消申请")').attr("disabled", false);
		},
		buttons : {
			"取消申请":function() {
				applyCancel();
			}
		}
	});
	$("#waitingDialog").dialog({//无头部底部的dialog
		autoOpen : false,
		resizable : false,
		draggable : false,
		closeOnEscape : false,
		height : 290,
		width : 390,
		modal : true,
		close : function() {
			checkDialogNum();
			if(dialogcount == 0){
				$(".ui-widget-overlay").remove();
			}
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").hide();
			$(".ui-dialog-titlebar-close").hide();
		}
	});
	$("#confirmDialog").dialog({//检查确认dialog
		autoOpen : false,
		resizable : false,
		draggable : true,
		closeOnEscape : false,
		height : 290,
		width : 390,
		modal : true,
		close : function(){
			$("#confirmDialog")[0].reset();
			checkDialogNum();
			if(dialogcount == 0){
				$(".ui-widget-overlay").remove();
			}
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		},
		open : function(event, ui) {
		},
		buttons : {
			"通过":function() {
				localAuth();
				$("input[name='confirmResult']").val("yes");
			},
			"不通过":function() {
				localAuth();
				$("input[name='confirmResult']").val("no");
			}
		}
	});
};
/**
 * 初始化实物印章类型下拉选项
 */
function initSealTypeSelect(){
	try {
		var integration = GPCache.get(GPCache.G3X, constants.SMS_SWITCH_KEY);
		var list = GPCache.get(GPCache.SMS, GPType.SMS_SEAL_TYPE);
		var options = '<option value="">无章</option>';
		if (constants.SMS_SWITCH_TRUE == integration) {
//			console.log("对接印章管理系统");
			//获取启用状态下的印章
			var seals = queryEanbleSealinfo();
			for(var v=0;v<seals.length;v++){
				var o = seals[v];
				options += ("<option value=\"" + (o.sealNumber +"-"+ o.sealType) + "\" sealsn=\""+o.sealNumber+"\" >" + (o.sealNumber + "(" +list[o.sealType]+ ")" )+"</option>");
			}
		} else if (constants.SMS_SWITCH_FALSE == integration) {
//			console.log("不对接印章管理系统");
			for (var o in list) {
				options += ("<option value=\"" + ("-"+ o) + "\">" + list[o] + "</option>");
			}
		}else{
			alert("印章管理系统对接参数配置错误");
		}
		$(".sealtype").html(options);
	} catch (e) {
		alert("初始化印章类型数据失败:" + e.message);
    }
}

/**
 * 查询启用状态的实物印章
 */
function queryEanbleSealinfo(){
	var url = ctx + "/mechseal/sealhandle/sealHandleAndWhAction_findEnabledSealInfo.action";
	var data = tool.ajaxRequest(url, null);
	if (data.success) {
		if(data.response.responseMessage.success){
			return data.response.pageBean.data;
		}else{
			alert(data.response.responseMessage.message);
		}
		$("#confirmDialog").dialog("close");
		$("#handleDialog").dialog("close");
	}else{
		alert(data.response);
	}
	return null;
}

/**
 * 提交印章装卸申请
 */
function submitSealHandle(){
	var orgval = $("#handleDialog input[name='taskOrg']").val();
	if(orgval==null || orgval==""){
		alert("请选择授权机构");
		return;
	}
	var sealTypearr = $("select[name$='sealType']");
	var sealtypestr = "";
	for(var v=0;v<sealTypearr.length;v++){
		if($(sealTypearr[v]).val().indexOf("-")!=-1){
			sealtypestr+=($(sealTypearr[v]).val().split("-")[1]);
		}else{
			sealtypestr+=$(sealTypearr[v]).val();
		}
	}
	if(/(.).*\1/i.test(sealtypestr)){
		alert("同一个印章类型不能重复安装");
		return;
	}
	$("#handleDialog input[name='bizInfo.deviceNum']").val(ocxbase_sealMachine.getMachineNum());
	// 提交form表单
	var param = $("#handleDialog").serializeForm();
	var url = ctx + "/sealhandle/task/sealHandleTaskListAction_createTask.action?processDefKey=GSS_SEALHANDLE";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		currentTask.taskid = data.response.bizInfo.autoId;
		// 显示等待界面
		showWaitingDialog("正在等待审核，请稍候....","1");
		countapplytime(GPCache.get(GPCache.GSS, GPType.GSS_DOWNTIME,"AUDIT_DOWNTIME"));
		waitApprResult();
	}
}
/**
 * 提交维护申请
 */
function submitSealMainTain(){
	var orgval = $("#maintainDialog input[name='taskOrg']").val();
	if(orgval==null || orgval==""){
		alert("请选择授权机构");
		return;
	}
	$("#maintainDialog input[name='bizInfo.deviceNum']").val(ocxbase_sealMachine.getMachineNum());
	// 提交form表单
	var param = $("#maintainDialog").serializeForm();
	var url = ctx + "/sealhandle/task/sealHandleTaskListAction_createTask.action?processDefKey=GSS_DEVICEMAINTAIN";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		currentTask.taskid = data.response.bizInfo.autoId;
		showWaitingDialog("正在等待审核，请稍候....","1");
		countapplytime(GPCache.get(GPCache.GSS, GPType.GSS_DOWNTIME,"AUDIT_DOWNTIME"));
		waitApprResult();
	}
}
/**
 * 提交验章操作
 */
function submitSealCheck(){
	//打开凭证纸板
	openPaperDoor();
}
/**
 * 提交印章检查确认
 */
function submitsealcheckConfirm(){
	$("input[name='checkpeople']").val(check_people);
	$("input[name='sealDevice.deviceNum']").val(ocxbase_sealMachine.getMachineNum());
	$("input[name='sealHandleinfo.autoId']").val(currentTask.taskid);
	// 提交form表单
	var param = $("#confirmDialog").serializeForm();
	var url = ctx + "/mechseal/sealhandle/sealHandleAndWhAction_sealHandleConfirm.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		if(data.response.responseMessage.success){
			openSideCamera();
			queryMachineInfo();
			alert(data.response.responseMessage.data);
		}else{
			alert(data.response.responseMessage.message);
		}
		$("#confirmDialog").dialog("close");
		$("#handleDialog").dialog("close");
	}else{
		alert(data.response);
	}
}
/**
 * 超时取消任务
 */
function applyTasktimeout(){
	// 提交form表单
	window.clearTimeout(waitting_apprresult_timeout_clear);
	waitting_apprresult_timeout_clear = null;
	var param = {
			"bizInfo.autoId" : currentTask.taskid,
			"processDefKey" : tasktype==1?"GSS_SEALHANDLE":"GSS_DEVICEMAINTAIN"
		};
	var url = ctx + "/sealhandle/task/sealHandleTaskListAction_timoutTask.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		if(data.response.responseMessage.success){
			showWaitingDialog("超时任务取消成功");
			setTimeout(function(){
				hideWaitingDialog();
			}, 2000);
		}else{
			alert(data.response.responseMessage.message);
		}
	}else{
		alert(data.response);
	}
}
/**
 * 查询设备信息
 */
function queryMachineInfo(){
	try {
		var url = ctx + "/mechseal/sealhandle/sealHandleAndWhAction_querySealDeviceInfo.action";
		var param = {
			"sealDevice.deviceNum" : ocxbase_sealMachine.getMachineNum()
		};
		var data = tool.ajaxRequest(url,param);
		if (data.success) {
			if(data.response.responseMessage.success){
				//表单填充数据
				$("#deviceInfoForm").fillForm({"sealDevice":data.response.sealDevice});
				$("#deviceInfoForm input[name='sealDevice.ownerOrganization']").val(Organization.getOrganization(
						$("#deviceInfoForm input[name='sealDevice.ownerOrganization']").val()).organizationName);
				$("#deviceInfoForm input[name='sealDevice.deviceStatus']").
				val(fetchSealDevStatus(data.response.sealDevice.deviceStatus) + "(" + fetchSealDevSubStatus(data.response.sealDevice.deviceSubStatus) + ")");
				$("#deviceInfoForm input[name='sealDevice.deviceType']").
				val(GPCache.get(GPCache.GSS, GPType.MMS_DEVICE_TYPE, data.response.sealDevice.deviceType));
				return true;
			}else{
				showWaitingDialog(data.response.responseMessage.message);
			}
		} else {
			alert(data.response);
		}
		return false;
	} catch (e) {
		return false;
	}
}
/**
 * 查询设备是否可操作
 */
function queryMachineStatus(){
	var url = ctx + "/mechseal/sealhandle/sealHandleAndWhAction_"+(tasktype==1?"queryHandleStatus":"queryMaintainStatus")+".action";
	var param = {
		"sealDevice.autoID" : $("#deviceid").val()
	};
	var data = tool.ajaxRequest(url,param);
	if (data.success) {
		if(data.response.responseMessage.success){
			if(tasktype == 1){
				for(var v=0;v<6;v++){
					$("#handleDialog input[name='configs["+v+"].slotNo']").val(v+1);
				}
				$("#showimgDiv").hide();
				$("#handleDialog").dialog("open");
			}
			if(tasktype == 2){
				$("#maintainDialog")[0].reset();
				$("#maintainDialog").dialog("open");
			}
		}else{
			alert(data.response.responseMessage.message);
		}
	} else {
		alert(data.response);
	}
}

/**
 * 查询印章安装配置信息
 */
function querySealInstallConfig(){
	try {
		var url = ctx + "/mechseal/sealhandle/sealHandleAndWhAction_querySealinstallConfig.action";
		var param = {
			"sealDevice.deviceNum" : ocxbase_sealMachine.getMachineNum()
		};
		var data = tool.ajaxRequest(url,param);
		if (data.success) {
			if(data.response.responseMessage.success){
				$(data.response.configs).each(
						function(i, value) {
							//设置表单值 印章的编号 是否蘸印油  印章类型
							var jq_sealtype = $("#sealtype" + data.response.configs[i].slotNo);
							var th = $(jq_sealtype).parent();
							var inputsn = $(th).find("input[name$='sealSn']").first();
						    $(jq_sealtype).val(data.response.configs[i].sealSn+"-"+data.response.configs[i].sealType);
						    $(inputsn).val($(jq_sealtype).find("option:selected").attr("sealsn"));
						    var jq_sealoil = $("#sealoil" + data.response.configs[i].slotNo);
						    $(jq_sealoil).val(data.response.configs[i].hasSealOil);
						    var sealTypeName = $(th).find("input[name$='sealTypeName']").first();
						    $(sealTypeName).val($(jq_sealtype).find("option:selected").html());
						    var jq_shape = $("#shape" + data.response.configs[i].slotNo);
						    $(jq_shape).val(data.response.configs[i].shape);
						});
			}
		} else {
			alert(data.response);
		}
	} catch (e) {
		return e.message;
	}
}
/**
 * 取消申请
 */
function applyCancel(){
	try {
		$('.ui-dialog-buttonpane').find('button:contains("取消申请")').attr("disabled", true);
		window.clearTimeout(waitting_apprresult_timeout_clear);
		waitting_apprresult_timeout_clear = null;
		var url = ctx + "/mechseal/sealhandle/sealHandleAndWhAction_cancelapply.action";
		var param = {
			"processdefkey" : tasktype==1?"GSS_SEALHANDLE":"GSS_DEVICEMAINTAIN",
			"sealHandleinfo.autoId" : currentTask.taskid
		};
		var data = tool.ajaxRequest(url,param);
		if (data.success) {
			if(data.response.responseMessage.success){
				hideWaitingDialog("1");
			}else{
				alert(data.response.responseMessage.message);
			}
		} else {
			alert(data.response);
		}
	} catch (e) {
		return e.message;
	}
	
}

/**
 * 检查印章安装信息
 */
function checkInstallInfo(){
	var sealObj = ocxbase_sealMachine.getSealInfo();
	if(sealObj.success){
		fillSealNum(sealObj.data);
		var errormsg = "印章检查不通过，错误信息：<br>";
		var returnobj = new Object();
		returnobj.success = true;
		for(var v=1;v<=6;v++){
			if($("#sealtype"+v).val()!=null && $("#sealtype"+v).val()!=""){//v号槽登记有章
				//验证设备内是否有章
				if(sealObj.data.indexOf(v+":")==-1){//无章
					errormsg += v+"号槽有登记印章，但未放入印章<br>";
					returnobj.success = false;
				}
			}else{
				if(sealObj.data.indexOf(v+":")!=-1){//未登记但是有章
					errormsg += v+"号槽内有放入印章，但未登记<br>";
					returnobj.success = false;
				}
			}
		}
		errormsg+="请重试！";
		returnobj.data = errormsg;
		return returnobj;
	}else{
		return sealObj;
	}
}
/**
 * 填充印章号
 */
function fillSealNum(data){
	for(var v=1;v<=6;v++){
		if(data.indexOf(v+":")!=-1){//v槽内有章
			var sealnum = data.split(v+":")[1].substring(0,1);
			$("input[name='configs["+(v-1)+"].sealNum']").val(sealnum);
			var seal_ = new Object();
			seal_.slotNo = v;//槽位
			seal_.sealnum = sealnum;//印章号
			seal_.oil = $("select[name='configs["+(v-1)+"].hasSealOil']").val();//是否蘸印油
			seal_.shape = $("select[name='configs["+(v-1)+"].shape']").val();//印章形状
			sealArr[sealArr.length] = seal_;
		}
	}
}

/**
 * 获取审核的状态
 * 
 * @returns 审核状态pass/refuse/waiting
 */
function getApprovalResult() {
	try {
		var param = {
			"sealHandleinfo.autoId" : currentTask.taskid
		};
		var url = ctx + "/mechseal/sealhandle/sealHandleAndWhAction_queryApprovalResult.action";
		var data = tool.ajaxRequest(url, param);
		if (data.success) {
			return data.response.approveResult;
		} else {
			return "服务器响应失败：" + data.response;
		}
	} catch (e) {
		return e.message;
	}
};

/**
 * 任务是否锁定
 */
function istasklocked(){
	var param = {'bizInfo.autoId' : currentTask.taskid};
	var url = ctx + "/sealhandle/task/sealHandleTaskListAction_isLockedTask.action?processDefKey="+
					(tasktype==1?"GSS_SEALHANDLE":"GSS_DEVICEMAINTAIN");
	var data = tool.ajaxRequest(url, param);
	if(data.success){
		if(data.response.taskLocked){//锁定
			window.clearTimeout(waitting_apprresult_timeout_clear);
			waitting_apprresult_timeout_clear = null;
			$('.ui-dialog-buttonpane').find('button:contains("取消申请")').attr("disabled", true);
			showWaitingDialog("正在审核中，请等待...");
		}else{
			
		}
	}
}

/**
 * 等待印章装卸/维护审批
 */
function waitApprResult(){
	var result = getApprovalResult();
	if (result == "waiting") {//审批中
		istasklocked();//检查任务是否锁定
		// 向本地全局变量获取审核结果的请求频率，可适当调整timeou的时间来调节处理审核结果的时间
		setTimeout("waitApprResult()", 1500);
	} else if (result == "pass") {//同意
		showWaitingDialog("请稍候，正在打开侧门....");
		openMachineElecDoor();//打开电子锁
	} else if (result == "refuse") {//拒绝
		showWaitingDialog("申请审核不通过!");
		setTimeout("hideWaitingDialog()", 3000);
	}else if (result == "timeout" || result == "applycancel" || result == "notask" ) {//超时 或 已取消任务 或 未找到任务 认为已处理过
		
	} else {
		showWaitingDialog("查询审批状态异常,请重试!");
		setTimeout(function(){
			hideWaitingDialog();
		}, 2000);
	}
}

/**
 * 更新印章装卸日志信息
 * @param param
 */
function updateSealHandle(param,callback) {
	var url = ctx + "/mechseal/sealhandle/sealHandleAndWhAction_update.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		var returnobj = new Object();
		if(data.response.responseMessage.success){
			returnobj.success = true;
			callback(returnobj);
		}else{
			returnobj.success = false;
			returnobj.data = data.response.responseMessage.message;
			callback(returnobj);
		}
	} else {
		alert("更新印章装卸日志失败：" + data.response);
	}
}

/**
 * 更新印章装卸信息
 * @param param
 */
function updateSealInstallConfig(param,callback) {
	var url = ctx + "/mechseal/sealhandle/sealHandleAndWhAction_updateSealInstallConfig.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		var returnobj = new Object();
		if(data.response.responseMessage.success){
			returnobj.success = true;
			callback(returnobj);
		}else{
			returnobj.success = false;
			returnobj.data = data.response.responseMessage.message;
			callback(returnobj);
		}
	} else {
		alert("更新印章安装信息失败：" + data.response);
	}
}

/**
 * 本地授权
 */
function localAuth() {
	var operAuth = new top.OperAuth();
	operAuth.operType = "sealInstall_check"; // 权限 (action-auth.xml)
	operAuth.orgLevel = "self";//同机构用户才能审核
	operAuth.authSuccess = function(peopleCode) {
		if (!tool.isNull(peopleCode)) {
			check_people = peopleCode;
			submitsealcheckConfirm();
		} else {
			alert("印章装卸授权方式配置错误，请联系技术人员!");
		}
	};
	operAuth.authCancel = function() {
		alert("必须同机构授权人授权");
	};
	operAuth.auth();
}

/*****************************印控机相关************************/
/**
 * 初始化印控机
 */
function initMachineAndOpenCamera() {
	if (!has_init_machine) {
		var initMachResult = ocxbase_sealMachine.initMachineForTakeSeal();
	    if (initMachResult.success === false) {
	    	showWaitingDialog(initMachResult.data);
	    	return;
	    }
	    if(initMachResult.data.substr(0,8) == sparePartsNo){
	    	chipSoftVersionTag = 1;
	    	hideWaitingDialog();
	    }
	    has_init_machine = true;
		if(queryMachineInfo()){
			if(chipSoftVersionTag == 0 && opertype=="1"){//印章装卸时打开摄像头
		    	OCX_Logger.info(LOGGER._3X,"访问印章装卸模块");
		    	//打开凭证摄像头
		    	openCameraDivice();
		    }else{
		    	OCX_Logger.info(LOGGER._3X,"访问设备维护模块");
		    	hideWaitingDialog();
		    }
		}
	}
};
/**
 * 开始用印
 */
function startSeal(result){
	if(result.code == "1001"){//盖章完成 
		if(seal_index < sealArr.length){
			//槽位sealArr[seal_index].slotNo的盖章坐标
			var i800x = parseInt(800*(parseInt(initPosition[(("pos"+sealArr[seal_index].slotNo))][("x"+useseal_count)]))/2048);
			var i800y = parseInt(800*(parseInt(initPosition[(("pos"+sealArr[seal_index].slotNo))][("y"+useseal_count)]))/2048);
			if(sealArr[seal_index].oil=="0"){//不蘸印油
				ocxbase_sealMachine.notSealOil();
			}
			ocxbase_sealMachine._startSeal(false, 0, 800-i800x, i800y, sealArr[seal_index].sealnum, startSeal);
			if(useseal_count==0 || useseal_count==1){//第一次盖章 或 第二次盖章
				useseal_count++;
			}else{//第三次盖章
				useseal_count=0;
				seal_index++;
			}
		}else{//所有章盖章完成
			seal_index = 0;
			useseal_count = 0;
			setTimeout(function(){
				dealUseSeal("end");
			}, ocxbase_iniHelper.configParam.overcapture_maincamera_delay);
		}
	}else{//盖章异常
		showWaitingDialog(result.msg);
	}
}
/**
 * 用印前打开纸板
 */
function openPaperDoor() {
	var ret = ocxbase_sealMachine.openPaperDoor(doorCloseCallback);
	if (!ret.success) {
		alert(ret.data);
	}
	showWaitingDialog("纸板已打开，请放入印章检查表关闭纸板，并开始验章");
	// 纸板关闭回调函数
	function doorCloseCallback(ret) {
		if (!ret.success) {
			alert(ret.data);
			return;
		}
		showWaitingDialog("正在进行验章，请等待");
		// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
		setTimeout(function() {
			dealUseSeal("start");
		}, ocxbase_iniHelper.configParam.closecapture_maincamera_dealy);
	}
};

/**
 * 用印完成后打开纸板
 */
function sealoverOpenPaperDoor() {
	var ret = ocxbase_sealMachine.openPaperDoor(doorCloseCallback_);
	if (!ret.success) {
		alert(ret.data);
	}
	showWaitingDialog("验章完成，请拿出印章检查表检查并进行印章检查确认操作！");
	// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
	setTimeout(function() {
		hideWaitingDialog();
	}, 1500);
	// 纸板关闭回调函数
	function doorCloseCallback_(ret) {
		if (!ret.success) {
			alert(ret.data);
			return;
		}
	}
};
/**
 * 打开电子锁
 * @returns
 */
function openMachineElecDoor() {
	if(chipSoftVersionTag == 0){
		//录像成功再开侧门
		if (startRecord() == false) {
			return;
		}
		var result = ocxbase_sealMachine.openSideDoor(closeBackdoorCallback, openBackdoorCallBack);
		if (result.success) {
			is_stopvideo = false;
			showWaitingDialog("已打开电子锁，请在20秒之内打开侧门，并在90秒内取章....");
			countdown(90,20);
		} else {
			showWaitingDialog("打开电子锁失败");
			setTimeout("hideWaitingDialog()", 3000);
		}
	}else{
		//备板开侧门
		var result = ocxbase_sealMachine.openBackDoor();
		if (result.success) {
			showWaitingDialog("已打开电子锁，请打开侧门");
			setTimeout("hideWaitingDialog()", 10000);
		} else {
			showWaitingDialog("打开电子锁失败");
			setTimeout("hideWaitingDialog()", 5000);
		}
		$("#maintainDialog").dialog("close");
	}
};

/**
 * 检测侧门是否关闭
 */
function checkSidedoor(){
	ocxbase_sealMachine.querySideDoor(sidedooropen_,sidedoorclose_,errorcallback_);
	/**
	 * 侧门打开
	 */
	function sidedooropen_(){
//		console.log("侧门未关闭");
		//侧门打开，提示关闭侧门
		showWaitingDialog("侧门未关闭，请先关闭");
	}
	/**
	 * 侧门关闭
	 */
	function sidedoorclose_(){
//		console.log("侧门已关闭");
		//关闭侧门后，再检测纸板是否关闭
		checkPaperdooropen();
	}
	/**
	 * 异常回调
	 */
	function errorcallback_(result){
//		console.log("检测侧门状态连接异常");
		//连接异常
		showWaitingDialog(result.data);
	}
}

/**
 * 检测纸板打开状态
 */
function checkPaperdooropen(){
	OCX_MachineOrder.openLight();//开灯
	var result = ocxbase_sealMachine.queryPaperDoorOpen(paperdooropen_,errorcallback_);//开门状态
	if(!result.success){//未开门
		checkPaperdoorclose();
	}
	/**
	 * 开门回调
	 */
	function paperdooropen_(){
//		console.log("纸板门打开");
		//开门不能验章
		showWaitingDialog("纸板门未关闭，请先关闭");
		checkPaperdoorclose();
	}
	/**
	 * 异常回调
	 */
	function errorcallback_(result){
		//连接异常
		showWaitingDialog(result.data);
	}
}
/**
 * 检测纸板关闭状态
 */
function checkPaperdoorclose(){
	ocxbase_sealMachine.queryPaperDoorClose(paperdoorclose_,errorcallback_);//关门状态
	/**
	 * 关门回调
	 */
	function paperdoorclose_(){
//		console.log("纸板门关闭");
		//校验安装的印章是否匹配
		var result_ = checkInstallInfo();
		if(!result_.success){
			showWaitingDialog(result_.data);
			return;
		}else{
			$("#handleDialog input[name='sealDevice.deviceNum']").val(ocxbase_sealMachine.getMachineNum());
			var param = $("#handleDialog").serializeForm();
			updateSealInstallConfig(param,function(result){
				if(!result.success){
					alert(result.data);
					return;
				}else{
//					console.log("开始验章");
					//提交验章操作
					submitSealCheck();
				}
			});
			
		}
	}
	/**
	 * 异常回调
	 */
	function errorcallback_(result){
		//连接异常
		showWaitingDialog(result.data);
	}
}


/**
 * 关闭印控机
 */
function closeSealMachine() {
	try {
		ocxbase_sealMachine.closeMachine();
	} catch (e) {
	}
};
/**
 * 用印处理
 * state:"start"/"end"
 */
function dealUseSeal(state){
	if(has_open_camera_divice){
		var ret = ocxbase_xusbVideo.captureImage(false, state);
		if (ret.success) {
			fileObj.filepath = ret.data.srcImagePath;
			fileObj.filename = ocxbase_xusbVideo.getLastImageName().srcImageName;//文件名称
			appendFile();
			$("#showimgDiv").show();
			$("#showimgDiv").attr("src",fileObj.filepath);
			if(state=="start"){//用印前
				var tmpimg = new Image();
				tmpimg.onload = function(){
					var initdata = new Object();
					initdata.code = "1001";
					startSeal(initdata);
					tmpimg = null;
				};
				tmpimg.onerror = function(){
					alert("图像加载异常，请重试！");
					tmpimg = null;
				};
				tmpimg.src = fileObj.filepath;
			}else{//用印完成后
				$("#sealCheckButton").hide();
				$("#sealConfirmButton").show();
				sealoverOpenPaperDoor();
			}
		}else{
			alert(ret.data);
			return;
		}
	}else{
		alert("凭证摄像头未打开");
		return;
	}
}

/*******************摄像头相关****************************/

/**
 * 摄像头就绪拍照事件
 */
function deviceReady() {
	open_camera_time ++;
	ocxbase_xusbVideo.setCameraReady();
	if (open_camera_time%2 == 1) {
		OCX_Logger.info(LOGGER._3X,"凭证摄像头已就绪");
		setTimeout(function(){
			if(open_camera_time == 1){//初始化页面检测是否存在异常记录
				var sniffResult = ocxbase_exceptionLogHandler.startSniffing(ocxbase_sealMachine.getMachineNum(), true);
				if (!sniffResult.success) {
					showWaitingDialog(sniffResult.data);
				}else{
					//打开侧门摄像头
					setTimeout(function(){
						openSideCamera();
					}, 100);
				}
			}
		}, ocxbase_iniHelper.configParam.open_maincamera_delay);
		has_open_side_camera = false;
		has_open_camera_divice = true;
//		console.log("凭证摄像头已准备就绪");
	}else if (open_camera_time%2 == 0) {//侧门摄像头打开
		OCX_Logger.info(LOGGER._3X,"侧门摄像头已就绪");
		is_side_door_open = false;//侧门未打开
		has_open_camera_divice = false;
		has_open_side_camera = true;
//		console.log("侧门摄像头已准备就绪");
	}
};

/**
 * 摄像头设备连接事件
 */
function deviceConnect(nConnectStatus) {
	// TODO
};

/**
 * 打开凭证摄像头
 */
function openCameraDivice() {
	if (!has_open_camera_divice) {
		var openResult = ocxbase_xusbVideo.openCamera();
		OCX_MachineOrder.openLight();//开灯
		if (openResult.success === false) {
		    var message = openResult.data;
		    showWaitingDialog(message);
		    setTimeout(function(){
		    	//凭证摄像头打开失败时，再次点击验章 打开摄像头，打开纸板
		    	hideWaitingDialog();
		    }, 1000);
		}else{
//			console.log("凭证摄像头及灯光已打开"+new Date().getSeconds());
		}
	}
};

/**
 * 打开侧面摄像头
 */
function openSideCamera() {
	if (!has_open_side_camera) {
		var openResult = ocxbase_xusbVideo.openSideCamera();
		if (openResult.success === false) {
			var message = openResult.data;
			alert("打开侧摄像头失败：" + message);
			return false;
		}
//		console.log("侧门摄像头已打开");
		hideWaitingDialog();
	}
}

/**
 * 开始录像
 */
function startRecord() {
	if (has_open_side_camera == true) {
		ocxbase_sealMachine.sealStartForLG();
		var videoCore = ocxbase_xusbVideo.getVideoCore().data;
		var resolution = ocxbase_xusbVideo.getSideCameraWidthAndHeight();
		OCX_VideoRecorder.setVideoParam(resolution.data.width, resolution.data.height, 185);
		//xVideoRecorder.setVideoCompressorName(1);
		if (OCX_VideoRecorder.addVideoSource(videoCore, 0, 0, resolution.data.width, resolution.data.height).code != "1001") {
			alert("添加视频源失败：" + OCX_VideoRecorder.getLastError());
			return false;
		}
		var date = (new Date()).Format("yyyyMMddhhmmssS");
		fileObj.filename = date + ".asf";
		fileObj.filepath = fileObj.folder + fileObj.filename;
		var startresult = OCX_VideoRecorder.startRecord(fileObj.filepath, 2);
		if (startresult.code != "1001") {
			alert("开始录制视频失败：" + OCX_VideoRecorder.getLastError());
			return false;
		}
	}
}

/**
 * 关闭侧门倒计时
 * time1  关闭侧门倒计时
 * time2 电子锁关闭倒计时
 */
function countdown(time1,time2) {
	var status = ocxbase_sealMachine.sealQuery();
	if (!status.success) {
		connect_exception_count++;
		if(connect_exception_count >= 5){
			// 通讯异常，断电检测
			is_side_door_open = false;
			is_stopvideo = true;
			$("#waitingMsg").html("设备连接异常");
			setTimeout("closeBackdoor()", 1000);
			return;
		}
	}
	connect_exception_count = 0;
	if ((!is_side_door_open&&time2>0) || (time1>0&&is_side_door_open)) {
		if (is_side_door_open) {//侧门打开
			if (!$("#waitingMsg").dialog('isOpen')) {
				$("#waitingMsg").dialog('open');
			}
			$("#waitingMsg").html("已打开电子锁，侧门，请在" + time1 + "秒内完成取章并关闭侧门...");
			time1--;
			interval_down_clear = setTimeout("countdown(" + time1 + ","+time2+")", 1000);
		} else {//侧门未打开
			if (!$("#waitingMsg").dialog('isOpen')) {
				$("#waitingMsg").dialog('open');
			}
			$("#waitingMsg").html("已打开电子锁，请在"+time2+"秒内打开侧门，并在" + time1 + "秒内完成取章并关闭侧门...");
			time1--;
			time2--;
			interval_down_clear = setTimeout("countdown(" + time1 + ","+time2+")", 1000);
		}
	} else {
		window.clearTimeout(interval_down_clear);
		// 倒计时归零
		is_side_door_open = false;
		is_stopvideo = true;
		closeBackdoor();
		return;
	}
}

/**
 * 用印申请倒计时
 */
function countapplytime(seconds){
	if(seconds>0){
		$("#waitingApprMsg").html("正在等待审核，请稍候....任务还剩" + seconds + "秒超时");
		seconds--;
		waitting_apprresult_timeout_clear = setTimeout("countapplytime(" + seconds+")", 1000);
	}else{//任务超时
		window.clearTimeout(waitting_apprresult_timeout_clear);
		waitting_apprresult_timeout_clear = null;
		var result_ = getApprovalResult();
		if(result_ == "waiting"){//如果为未处理，则取消
			showWaitingDialog("正在取消任务，请稍后...");
			applyTasktimeout();//超时取消
		}
	}
}

/**
 * 侧门打开，继续录制
 */
function openBackdoorCallBack(){
	is_side_door_open = true;//侧门已打开
}

/**
 * 关闭侧门->停止录制
 */
function closeBackdoorCallback() {
//	 console.log("回调测试：侧门已关闭");
	window.clearTimeout(interval_down_clear);
	is_side_door_open = false;
//	console.log("调用关侧门回调函数,侧门状态："+is_side_door_open);
	if(!is_stopvideo && !is_side_door_open){//未停止录制过视频  侧门标识为已关闭，不能再上传 防止超时后调用此回调函数，检测侧门状态函数再次调用
//		console.log("正在上传影像文件");
		showWaitingDialog("正在上传影像文件...");
		stopRecord();
	}
}
/**
 * 关闭侧门 停止录制
 */
function closeBackdoor() {
	// console.log("回调测试：侧门已关闭");
	window.clearTimeout(interval_down_clear);
//	console.log("调用关侧门函数,侧门状态："+is_side_door_open);
	if(is_stopvideo && !is_side_door_open){//侧门标识为已关闭，不能再上传 防止超时后调用此回调函数，检测侧门状态函数再次调用
//		console.log("正在上传影像文件");
		showWaitingDialog("正在上传影像文件...");
		stopRecord();
	}
}

/**
 * 停止录制->上传影像
 */
function stopRecord() {
	OCX_VideoRecorder.stopRecord();
	ocxbase_xusbVideo.closeCamera();
	has_open_camera_divice = false;
	has_open_side_camera = false;
	ocxbase_sealMachine.closeOutLayLight();//关闭外置照明灯
	ocxbase_xusbVideo.resetProps();
	setTimeout("addVideo()", 500);
}

/**
 * 上传视频
 */
function addVideo() {
	var param = {"fileFileName":fileObj.filename};
	var fileresult = ocxbase_fileStore.addFile(fileObj.filepath, param);
	if(fileresult.success){
		showWaitingDialog("上传视频成功，请等待机器初始化");
		var storeId = fileresult.data;
		fileObj.storeid = storeId;
		//更新印章装卸日志信息
		var param = {
			"sealHandleinfo.autoId" : currentTask.taskid,
			"sealHandleinfo.storeId" : storeId
		};
		updateSealHandle(param,updatecallback);
		function updatecallback(data){
			if(!data.success){
				showWaitingDialog(data.data);
			}else{
//				console.log("开始打开凭证摄像头");
				$("#sealCheckButton").show();
				$("#submitHandleButton").hide();
				//视频上传成功打开凭证摄像头
				openCameraDivice();
				//检测侧门以及纸板是否关闭，关闭后再验章
				checkSidedoor();//检测侧门是否关闭
			}
		}
	}else{
		hideWaitingDialog();
		alert("上传影像失败：" + fileresult.data);
	}
}
/**
 * 追加影像
 */
function appendFile() {
	var param = {"fileFileName":fileObj.filename};
	var fileresult = ocxbase_fileStore.appendFile(fileObj.filepath, param,fileObj.storeid);
	if(fileresult.success){
		
	}else{
		showWaitingDialog("上传影像失败：" + fileresult.data);
	}
}

/**
 * 展示等待界面
 */
function showWaitingDialog(msg,type) {
	if(type == "1"){//审批等待窗口
		hideWaitingDialog();
		if(!$("#waitingApprDialog").dialog("isOpen"))
			$("#waitingApprDialog").dialog("open");
		$("#waitingApprMsg").html(msg);
	}else{
		hideWaitingDialog("1");
		if(!$("#waitingDialog").dialog("isOpen"))
			$("#waitingDialog").dialog("open");
		$("#waitingMsg").html(msg);
	}
	
};

/**
 * 选择授权中心
 */
function checkAuditOrg(id,type){
	var optParam = {
			isOrgNo:false,
			configType:type
	};
	$("#"+id).dialogAuditOrgTree("radio", top.loginPeopleInfo.orgSid, optParam, null,function(event, treeId, treeNode){
		if(treeNode){
			$("#"+id+" input[name='auditorg']").val(treeNode.organizationShowNameCode);
			$("#"+id+" input[name='taskOrg']").val(treeNode.organizationNo);
		}
	},null,null);
}

/**
 * 关闭等待界面
 */
function hideWaitingDialog(type) {
	checkDialogNum();
	if(type == "1"){
		if($("#waitingApprDialog").dialog("isOpen"))
			$("#waitingApprDialog").dialog("close");
	}else{
		if($("#waitingDialog").dialog("isOpen"))
			$("#waitingDialog").dialog("close");
	}
	//遮罩层显示
	if(dialogcount > 0){
		$(document.body).append('<div class="ui-widget-overlay" style="z-index: 1001; width: 1147px; height: 489px;"/>');
	}else{
		$(".ui-widget-overlay").remove();
	}
};

function checkDialogNum(){
	dialogcount = 0;
	if($("#handleDialog").dialog("isOpen"))dialogcount++;
	if($("#maintainDialog").dialog("isOpen"))dialogcount++;
	if($("#confirmDialog").dialog("isOpen"))dialogcount++;
	if($("#waitingApprDialog").dialog("isOpen"))dialogcount++;
	if($("#waitingDialog").dialog("isOpen"))dialogcount++;
}

/**
 * 页面关闭响应事件
 */
$.onunload(function() {
	try {
		closeSealMachine();
	} catch (e) {
		// alert(e.message);
	}
});