/**
 * 创建于:2015-6-11<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 取章审批JS<br>
 * 
 * @author 孙强
 * @version 1.0.0
 */
$().ready(function() {
	findTask();
})

function findTask(){
	var param = {
			"moduleId" : moduleId
	};
	var url = ctx + "/mechseal/sealmanager/takeSealApprTaskAction_gainTaskAndLock.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		var bizInfo = data.response.bizInfo;
		if(bizInfo==null || bizInfo==""){
			$("#noApply").show();
			$("#applyInfo").hide();
		}else{
			$("#fileType").val(bizInfo.fileType);
			$("#title").val(bizInfo.title);
			$("#reason").val(bizInfo.reason);
			$("#id").val(bizInfo.id);
			$("#applyOrgNo").val(bizInfo.applyOrgNo);
			$("#applyOrgName").val(bizInfo.applyOrgName);
			$("#applyDate").val(bizInfo.applyDate);
			$("#applyTime").val(bizInfo.applyTime);
			$("#applyPeopleCode").val(bizInfo.applyPeopleCode);
			$("#applyPeopleName").val(bizInfo.applyPeopleName);
			$("#takeMode").val(bizInfo.takeMode);
			if (bizInfo.memo != null){
				// 为空会写入字符串"null"
				$("#memo1").val(bizInfo.memo);
			}
			$("#applyPeople").val(bizInfo.applyPeopleName+"("+bizInfo.applyPeopleCode+")");
			$("#applyOrg").val(bizInfo.applyOrgName+"("+bizInfo.applyOrgNo+")");
			var fileTypeName = queryTradeCodeNameByTradeCode(bizInfo.applyOrgNo, bizInfo.fileType)
			$("#fileTypeName").val(fileTypeName);
		}
		
	}
}

function commitTask(taskResult){
	var param = {
			"bizInfo.id" : $("#id").val(),
			"bizInfo.fileType" : $("#fileType").val(),
			"bizInfo.title" : $("#title").val(),
			"bizInfo.reason" : $("#reason").val(),
			"bizInfo.applyOrgNo" : $("#applyOrgNo").val(),
			"bizInfo.applyOrgName" : $("#applyOrgName").val(),
			"bizInfo.applyDate" : $("#applyDate").val(),
			"bizInfo.applyTime" : $("#applyTime").val(),
			"bizInfo.applyPeopleCode" : $("#applyPeopleCode").val(),
			"bizInfo.applyPeopleName" : $("#applyPeopleName").val(),
			"bizInfo.memo": $("#memo").val(),
			"bizInfo.takeMode": $("#takeMode").val(),
			"taskResult" : taskResult
	};
	var url = ctx + "/mechseal/sealmanager/takeSealApprTaskAction_commitTask.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		alert("审核成功");
		$("#noApply").show();
		$("#applyInfo").hide();
	}
}

function unlockIdTask() {
	var lockId = $("#id").val()
	if (lockId != "" && lockId != null) {
		$.ajax({
			type : 'POST',
			url : ctx + "/mechseal/sealmanager/takeSealApprTaskAction_unlockTask.action",
			async : false,
			data : {
				"bizInfo.id" : lockId
			},
			success : function(data) {
			}
		});
	}
}
/**
 * @param orgNo
 *                申请人机构号
 * @param tradeCode
 *                交易代码
 */
function queryTradeCodeNameByTradeCode(orgNo, tradeCode) {
    var param = {
		"orgNo" : orgNo,
		"tradeCode" : tradeCode
    };
    var url = ctx + "/param/paramTradeCodeAction_queryByTradeCode.action";
    var data = tool.ajaxRequest(url, param);
    if (data.success) {
	    return data.response.paramTradeCode.tradeCodeName;
    } else {
	alert(data.response);
    }
};
function pass(){
	var taskResult = "yes";
	commitTask(taskResult);
}

function refuse(){
	var taskResult = "no";
	commitTask(taskResult);
}