var flag;
var sealNoOilArray;
var login_People = null;
var orgMap = new Map();
/**
 * 初始化页面
 */
$(document).ready(function() {
	initInstallDialog();
	initSealInfoDialog();
	initWaitingDialog();
	login_People = top.loginPeopleInfo;
	// 初始化控件
	/*var ret = ocxbase_messageHandler.initOcx();
	if (!ret.success) {
		alert(ret.data);
		return;
	}
	;

	ret = ocxbase_xusbVideo.initOcx();
	if (!ret.success) {
		alert(ret.data);
		return;
	}
	;
	ret = ocxbase_sealMachine.initOcx();
	if (!ret.success) {
		alert(ret.data);
		return;
	}
	;

	ret = ocxbase_fileStore.initOcx(basePath);
	if (!ret.success) {
		alert(ret.data);
		return;
	}
	;*/
	initSealUseSelect();
	initGrid();
	$("#sealOrgNo_Item").val(login_People.orgName+"("+login_People.orgNo+")");
	$("#sealOrgNo_Form").val(login_People.orgNo);
	queryData();

	// 新建表单提交数据验证
	$("#installForm").validationEngine({
		showOnMouseOver : true,
		validationEventTrigger : "keyup blur",
		promptPosition : "centerRight",
		autoPositionUpdate : true,
		onValidationComplete : function() {
		}
	});

	// 初始化异常用印日志处理器
	//deviceExceptionLogHandler.init(ctx);
	initInstallForm();
	// 延时设备初始化
//	showWaitingDialog("设备初始化中，请稍候...");
//	window.setTimeout(function() {
//		initMachine();
//	}, 500);
});

function initGrid() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	$("#sealInstallList").jqGrid(
			{
				width : pageContentWidth,
				height : tableHeight + "px",
				url : ctx + "/mechseal/sealinstall/sealInstallConfigAction_list.action",
				multiselect : false,
				rowNum : 20,
				rownumbers : true,
				viewrecords : true,
				rowList : [ 20, 50, 100 ],
				colNames : [ "使用机构", "印章所属机构", "使用人","设备编号", "印章种类", "印章编号", "是否蘸印油", "操作" ],
				colModel : [
						{
							name : "orgNo",
							index : "orgNo",
							// width : 126,
							align : "center",
							sortable : false,
							formatter : function(value, options, rData) {
								var name = queryOrgByOrgSid(value);
								if(name != null) {
									return name;
								} else {
									return "";
								}
							}
						},
						{
							name : "sealOrgNo",
							index : "sealOrgNo",
							// width : 126,
							align : "center",
							sortable : false,
							formatter : function(value, options, rData) {
								var name = queryOrgByOrgSid(value);
								if(name != null) {
									return name;
								} else {
									return "";
								}
							}
						},
						{
							name : "peopleName",
							index : "peopleName",
							// width : 126,
							align : "center",
							sortable : false
						},
						{
							name : "deviceNum",
							index : "deviceNum",
							// width : 126,
							align : "center",
							sortable : false
						},
						{
							name : "sealType",
							index : "sealType",
							// width : 126,
							align : "center",
							sortable : false,
							formatter : function(value, options, rData) {
								return selectUtils.sealBizTypeCache[value];
							}
						},
						{
							name : "sealNum",
							index : "sealNum",
							// width : 126,
							align : "center",
							sortable : false
						},
						{
							name : "hasSealOil",
							index : "hasSealOil",
							// width : 126,
							align : "center",
							sortable : false,
							formatter : function(value, options, rData) {
								return constants.booleanMap[value];
							}
						},
						{
							name : "autoId",
							index : "autoId",
							// width : 169,
							align : "center",
							sortable : false,
							formatter : function(value, options, rData) {
								return "<button onClick=\"findInstallSeal('"+value+"');return false;\">修改</button>"
										+ "<button onClick=\"sealUnstall('"+value+"');return false;\">卸载</button>";
							}
						} ],
				pager : $("#sealInstallPager"),
				caption : "印章安装信息查询"
			}).trigger("reloadGrid");
	$("#sealInstallList").navGrid("#sealInstallPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

/**
 * 重置查询条件
 */
function resetMethod() {
	$("#queryForm")[0].reset();
};

/**
 * 初始化印章种类下拉框
 */
function initSealUseSelect() {
	selectUtils.initSealBizType("sealType", "1");
	selectUtils.initSealBizType("sealTypeQuery", "1");
};

/**
 * 查询
 */
function query() {
	queryData();
	showMessage("");
};
/**
 * 查询数据，执行查询
 */
function queryData() {
	$("#sealInstallList").jqGrid('search', "#queryForm");
};

function initInstallDialog() {
	$("#dialog").dialog({
		autoOpen : false,
		resizable : false,
		// height : $(window).height(), 不起作用
		width : $(window).width() / 2,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
};

function initSealInfoDialog() {
	$("#sealInfoDialog").dialog({
		autoOpen : false,
		resizable : false,
		// height : $(window).height(), 不起作用
		width : 500,
		modal : true,
		position : {
			at : "center"
		},
		close : function() {
			$("#sealInfoForm")[0].reset();
			for ( var i = 1; i < 7; i++) {
				$("#sealType_" + i).css('background-color', '');
			}
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
};

/**
 * 印章安装
 */
function sealInstall() {
	$("#autoId").val("");
	//var formData = $('#installForm').serialize();  此方式传递参数 was中文乱码
	var param = {
//		"sealInstallConfig.autoId":$("#autoId").val(),
		"sealInstallConfig.orgNo":$("#orgNo").val(),
		"sealInstallConfig.sealOrgNo":$("#sealOrgNo").val(),
		"sealInstallConfig.sealOrgName":$("#sealOrgName").val(),
		"sealInstallConfig.deviceNum":$("#deviceNum").val(),
		"sealInstallConfig.sealType":$("#sealType").val(),
		"sealInstallConfig.sealTypeName":$("#sealType  option:selected").text(),
		"sealInstallConfig.sealNum":$("#sealNum").val(),
		"sealInstallConfig.hasSealOil":$("#hasSealOil").val(),
		"sealInstallConfig.peopleSid":$("#peopleName").val(),
		"sealInstallConfig.peopleName":$("#peopleName option:selected").text(),
		"sealInstallConfig.shape":$("#shape").val(),
		"sealInstallConfig.diameter":$("#diameter").val()
		
	};
	var url = ctx + "/mechseal/sealinstall/sealInstallConfigAction_installSeal.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		if (data.response.responseMessage.success) {
			cancelMethod();
			queryData();
			showMessage(data.response.responseMessage.data);
			showMessage1("");
		} else {
			show(data.response.responseMessage.message);
		}
	} else {
		show("服务器响应失败：" + data.response);
	}
};
/**
 * 印章卸载
 */
function sealUnstall(id) {
	if (confirm("是否卸载该印章？")) {
		var formData = $('#queryForm').serialize();
		var url = ctx + "/mechseal/sealinstall/sealInstallConfigAction_uninstallSeal.action?autoId=" + id;
		var data = tool.ajaxRequest(url, formData);
		if (data.success) {
			if (data.response.responseMessage.success) {
				queryData();
				showMessage(data.response.responseMessage.data);
			} else {
				showMessage(data.response.responseMessage.message);
			}
		} else {
			show("服务器响应失败：" + data.response);
		}
	}
};
/**
 * 待修改印章查询
 */
function findInstallSeal(id) {

	var url = ctx + "/mechseal/sealinstall/sealInstallConfigAction_findInstallSealByAutoId.action";
	var data = tool.ajaxRequest(url, {
		'autoId' : id
	});
	if (data.success) {
		updateMethod(data.response.sealInstallConfig);
	} else {
		show("服务器响应失败：" + data.response);
	}
};
/**
 * 印章修改
 */
function sealUpdate() {
	$("#sealNum").attr("disabled", false);
	//var formData = $('#installForm').serialize(); 此方式传递参数 was中文乱码
	var param = {
		"sealInstallConfig.autoId":$("#autoId").val(),
		"sealInstallConfig.orgNo":$("#orgNo").val(),
		"sealInstallConfig.sealOrgNo":$("#sealOrgNo").val(),
		"sealInstallConfig.sealOrgName":$("#sealOrgName").val(),
		"sealInstallConfig.deviceNum":$("#deviceNum").val(),
		"sealInstallConfig.sealType":$("#sealType").val(),
		"sealInstallConfig.sealTypeName":$("#sealType  option:selected").text(),
		"sealInstallConfig.sealNum":$("#sealNum").val(),
		"sealInstallConfig.hasSealOil":$("#hasSealOil").val(),
		"sealInstallConfig.peopleSid":$("#peopleName").val(),
		"sealInstallConfig.peopleName":$("#peopleName option:selected").text(),
		"sealInstallConfig.shape":$("#shape").val(),
		"sealInstallConfig.diameter":$("#diameter").val()
	};
	var url = ctx + "/mechseal/sealinstall/sealInstallConfigAction_updateSeal.action";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		if (data.response.responseMessage.success) {
			queryData();
			$("#dialog").dialog("close");
			showMessage1(data.response.responseMessage.data);
			showMessage1("");
		} else {
			showMessage1(data.response.responseMessage.message);
		}
	} else {
		show("服务器响应失败：" + data.response);
	}
};

/**
 * 查询当前机构下的人员
 */
function fechPeopleList(){
	 var param = {
		"orgNo" : $("#orgNo").val()
	 };
    var url = ctx + "/mechseal/sealinstall/sealInstallConfigAction_findPersonnelsByOrgNo.action";
    var data = tool.ajaxRequest(url, param);
    if(data.success && data.response.responseMessage.data != null && data.response.responseMessage.data != undefined){
    	$("#peopleName").empty();
    	$("#peopleName").append("<option value = ''>"+"---全部---"+"</option>");
    	var peopleList = data.response.responseMessage.data;
    	$.each(peopleList, function(i, people){
    		$("#peopleName").append("<option value = '" + people.sid + "'>" + people.personnelName + "</option>");
    	});
    }
}

/**
 * 查询已安装的印章编号
 */
function findSealNum() {
	var deviceNum = $("#deviceNum").val();
	var sealNum = $("#sealNum").val();
	var sealType = $("#sealType").val();
	if (deviceNum == undefined || deviceNum == "" || sealNum == undefined || sealNum == "") {
		return;
	}

	var url = ctx + "/mechseal/sealinstall/sealInstallConfigAction_findSealNum.action";
	var data = tool.ajaxRequest(url, {
		'deviceNum' : deviceNum,
		'sealNum' : sealNum,
		'sealType' : sealType
	});
	if (data.success) {
		var seal = data.response.sealInstallConfig;
		if (seal != null) {
			if (flag == 1) {
				showMessage1("该印章编号已安装!");
				closeBtn();
			} else if (flag == 2) {
				showMessage1("");
			}
			return;
		} else {
			openBtn();
			showMessage1("");
		}
	} else {
		show("服务器响应失败：" + data.response);
	}
};

function initInstallForm() {
	$("#orgNo").val(login_People.orgNo);
};

function addMethod() {
	flag = 1;// 1表示增加
	openBtn();
	openInput();
	$("#dialog").attr("title", "印章安装");
	$("#dialog").dialog("open");
	$("#installForm")[0].reset();
	initInstallForm();
	fechPeopleList();
	showMessage1("");
};

function updateMethod(sealInfo) {
	flag = 2;// 2表示修改
	$("#dialog").attr("title", "印章修改");
	$("#dialog").dialog("open");
	showMessage1("");
	closeInput();
	initInstallForm();
	fechPeopleList();

	$("#autoId").val(sealInfo["autoId"]);
	$("#orgNo").val(sealInfo["orgNo"]);
	$("#sealOrgNo").val(sealInfo["sealOrgNo"]);
	$("#sealOrgName").val(queryOrgByOrgSid(sealInfo["sealOrgNo"]));
	$("#deviceNum").val(sealInfo["deviceNum"]);
	$("#sealType").val(sealInfo["sealType"]);
	$("#sealNum").val(sealInfo["sealNum"]);
	$("#hasSealOil").val(sealInfo["hasSealOil"]);	
	$("#peopleName").val(sealInfo["peopleSid"]);
	$("#diameter").val(sealInfo["diameter"]);
	$("#shape").val(sealInfo["shape"]);
};

function confirmMethod() {
//	 验证表单
	if (!$("#installForm").validationEngine("validate")) {
		return;
	}
	var ownerOrg = $("#sealOrgNo").val();
	if(typeof(ownerOrg) == "undefined" || ownerOrg == null || ownerOrg == "" ){
		showMessage1("印章所属机构不能为空！");
		return;
	}
	var deviceNum = $("#deviceNum").val();
	var sealNum = $("#sealNum").val();
	var hasSealOil = $("#hasSealOil").val();
	var sealTypeVal = $("#sealType").val();
//	var peopleCode= $("#peopleName").val();
	if (deviceNum == undefined || deviceNum == "") {
		showMessage1("印控机编号不能为空！");
		return;
	}
	if (sealTypeVal == undefined || sealTypeVal == "") {
		showMessage1("印章种类不能为空！");
		return;
	}
	if (sealNum == undefined || sealNum == "") {
		showMessage1("印章编号不能为空！");
		return;
	}
	if (hasSealOil == undefined || hasSealOil == "") {
		showMessage1("是否不蘸印油不能为空！");
		return;
	}
	
	if (flag == 1) {
		sealInstall();
	} else if (flag == 2) {
		sealUpdate();
	}
};

function cancelMethod() {
	$("#dialog").dialog("close");
	// $("#dialog").reset();
	// 重置dialog内form表单数据
	$("#installForm")[0].reset();
	showMessage1("");
	$("#sealNum").get(0).selectedIndex = 0;
	$("#hasSealOil").get(0).selectedIndex = 0;
	openBtn();
};

/**
 * 显示提示信息
 * 
 * @param message
 *            信息
 */
function showMessage(message) {
	$("#showMessage").text(message);

};

function showMessage1(message) {
	$("#showMessage1").text(message);

};
function show(msg) {
	// 暂时未使用jquery的alert
	alert(msg);
};
/**
 * 隐藏按钮
 */
function closeBtn() {
	$("#confirmBtn").attr("disabled", true);
};

function openBtn() {
	$("#confirmBtn").attr("disabled", false);
};
/**
 * 设置输入框不可编辑
 */
function closeInput() {
	$("#sealMachineCode").unbind('blur');
	$("#sealMachineCode").focus(function() {
		$(this).blur();
	});
	$("#sealNum").attr("disabled", true);
};
/**
 * 设置输入框可编辑
 */
function openInput() {
	$("#sealNum").attr("disabled", false);
	$("#sealMachineCode").unbind('focus');
};

/**
 * 打开电控锁
 */
function openElecLock() {
	var result = ocxbase_sealMachine.openBackDoor();
	if (result.success === false) {
		showMessage(result.data);
	}
};

/**
 * 展示当前印控机印章安装情况
 */
function showMachineSealInfo() {
	var response = ocxbase_sealMachine.getSealInfo();
	if (response.success) {
		var installInfo = response.data.split(',');
		showSealInfo(installInfo);
	} else {
		alert(response.data);
	}

	function showSealInfo(installInfo) {
		var machineNo = ocxbase_sealMachine._getMachineNum().data;
		$("#sealInfoDialog").dialog("open");
		$("#sealInfoForm_orgNo").val(top.loginPeopleInfo.orgNo);
		$("#sealInfoForm_sealMachineCode").val(machineNo);

		// 章槽与章编号的对应
		var sealInMachineList = new Array();
		for ( var i = 0; i < installInfo.length; i++) {
			var sealNum = installInfo[i].split(":");
			if (sealNum.length == 2) {
				$("#sealNum_" + sealNum[0]).val(sealNum[1]);
				sealInMachineList.push(sealNum[1]);
			}
		}

		// 章编号与章种类的对应
		var sealInfoList = querySealInstallInfoList(machineNo);
		if (sealInfoList != null && sealInfoList.length != 0) {
			for ( var j = 0; j < sealInfoList.length; j++) {
				var sealNum = sealInfoList[j].sealNum;
				$("#sealType_" + sealNum).val(selectUtils.sealBizTypeCache[sealInfoList[j].sealUse]);
				$("#sealType_" + sealNum).css('background-color', '#FF3333');

				// 编号与种类对应关系校验
				for ( var k = 0; k < sealInMachineList.length; k++) {
					if (sealNum == sealInMachineList[k]) {
						$("#sealType_" + sealNum).css('background-color', '#66FF66');
						break;
					}
				}
			}
		}
	}

	function querySealInstallInfoList(machineNo) {
		var url = ctx + "/mechseal/sealinstall/sealInstallConfigAction_querySealInfoByOrgAndMachineNo.action";
		var data = tool.ajaxRequest(url, {
			'machineNo' : machineNo
		});
		if (data.success) {
			if (data.response.webResponseJson.state == "normal") {
				return data.response.webResponseJson.data;
			} else {
				alert(data.response.webResponseJson.data);
				return null;
			}
		} else {
			alert("服务器响应失败：" + data.response);
			return null;
		}
	}
};

/**
 * 初始化印控机
 */
function initMachine() {
	// 初始化印控机
	initSealMachine();

	// 打开摄像头
	openCameraDivice();
};

/**
 * 初始化印控机
 */
function initSealMachine() {
	var initMachResult = ocxbase_sealMachine.initMachine();
	if (initMachResult.success === false) {
		showWaitingDialog(initMachResult.data);
	}
};

/**
 * 打开摄像头
 */
var has_open_camera_divice = false; // 摄像头打开标识
function openCameraDivice() {
	if (!has_open_camera_divice) {
		var openResult = ocxbase_xusbVideo._openCamera();
		if (openResult.success === false) {
			var message = openResult.data;
			showWaitingDialog(message);
		}
	}
}

/**
 * 摄像头就绪拍照事件
 */
function deviceReady() {
	// 此timeout是因为纸板关闭后灯光会存在不稳定的情况，在此设置timeout来等待灯光稳定再拍照，可根据具体情况调整timeout时间
	// 如果timeout时间太短，可能会造成第一次用印拍出来的相片色彩异常
	setTimeout(function() {
		has_open_camera_divice = true;
	}, 2000);

	checkDeviceExceptionLog();

	// TODO 检查是否存在异常用印日志
	function checkDeviceExceptionLog() {
		var sniffResult = ocxbase_exceptionLogHandler.startSniffing(ocxbase_sealMachine._getMachineNum().data, true);
		if (sniffResult.success) {
			// 释放页面
			hideWaitingDialog();
		} else {
			showWaitingDialog(sniffResult.data);
		}
	}
}

/**
 * 现场审批
 */
function localApproval() {
	var operAuth = new top.OperAuth();
	operAuth.operType = "sealInstall"; // 权限 (action-auth.xml)
	operAuth.authSuccess = function(peopleCode) {
		if (!tool.isNull(peopleCode)) {
			appr_people_code = peopleCode;
			openElecLock();
		} else {
			alert("前台授权方式配置错误，请联系技术人员!");
		}
	};
	operAuth.authCancel = function() {
		// alert("用印申请未通过现场审核");
	};
	operAuth.auth();
};

/**
 * 摄像头设备连接事件
 */
function deviceConnect(nConnectStatus) {
	// TODO
}

function initWaitingDialog() {
	$("#waitingDialog").dialog({
		autoOpen : false,
		resizable : false,
		draggable : false,
		closeOnEscape : false,
		height : 290,
		width : 390,
		modal : true,
		open : function(event, ui) {
			$(".ui-dialog-titlebar").hide();
			$(".ui-dialog-titlebar-close").hide();
		}
	});
}

/**
 * 展示等待界面
 */
function showWaitingDialog(msg) {
	$("#waitingDialog").dialog("open");
	$("#waitingMsg").html(msg);
}

/**
 * 关闭等待界面
 */
function hideWaitingDialog() {
	$("#waitingDialog").dialog("close");
}

/**
 * 页面关闭响应事件
 */
function closePage() {
	ocxbase_sealMachine.closeMachine();
};


/**
 * 机构树
 */
function choseOrgNoCondition() {
	var organizationSid = top.loginPeopleInfo.orgSid;
    $("#sealOrgName").dialogOrgTree("radio", organizationSid, false, null, null, function(event, treeId, treeNode) {
		if (treeNode) {
			$("#sealOrgName").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
			$("#sealOrgNo").val(treeNode.organizationNo);
			showMessage1("");
		}
    });
};


function choseOrganizationItem(organizationNo,type) {
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#sealOrgNo_Item").dialogOrgTree("radio", organizationSid, false, null,null, function(event, treeId, treeNode){
		if(treeNode){
			$("#"+organizationNo+"_Item").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
			$("#"+organizationNo + "_Form").val(treeNode.organizationNo);
		}
	});
}

function queryOrgByOrgSid(value) {
	var url = ctx
	+ "/ext/po/extOrganizationAction_findOrganizationByOrganizationNo.action";
	var param = {"orgNo":value}
	var result = tool.ajaxRequest(url, param);
	if(result.success) {
		return result.response.organization.organizationName+"("+result.response.organization.organizationNo+")"
	} else {
		return null;
	}
}
