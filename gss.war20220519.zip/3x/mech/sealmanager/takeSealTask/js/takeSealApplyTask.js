//验证某个值为正整数的正则表达式
var regu = /^[1-9]\d*$/;
var login_people = null; // 人员信息
/**
 * 页面初始化加载
 */
$(document).ready(function(){
	initOrgSelect();
	$("#sealOrg").bind("change",showSeals);
	$("#tableType").bind("change",showFiles);
	initUseSealPage();
	initLoginPeople();
	initTaskList();
});

/**
 * 初始化机构人员信息
 */
function initLoginPeople() {
	login_people = top.loginPeopleInfo;
};

/**
 * 初始化任务列表
 */
function initTaskList() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	// 用印信息列表
	$("#useSealList")
			.jqGrid(
					{
						width : pageContentWidth,
						height : tableHeight + "px",
						url : ctx + "/mechseal/sealuse/mechSealUseApplyAction_findSealUseApplyAll.action?moduleId=" + moduleId,
						multiselect : false,
						rowNum : 20,
						rownumbers : true,
						sortable : true,// 是否排序
						sortname : "applyDate",
						sortorder : "desc",
						rowList : [20, 50, 100],
						colNames : ["任务码",/* "印章类型id","印章类型名称",*/ "用印事由", /*"待用印次数", "已用印次数",*/ "申请人", "机构名称", /*"印章所属机构",*/ "申请日期", /*"扫描码",*/ /*"操作"*/"文档详情"],
						colModel : [
								{
									name : "scanNum",
									index : "scanNum",
									align : "center",
									width : 80,
									sortable : false,
									formatter : function(value) {
										return "<a href=\"javascript:void(0)\" onMouseOut=\"showImg('hide','"+value+"',this);\"  onmouseover=\"showImg('show','"+value+"',this);\">" + value + "</a>";
									}
								},
								/*{
									name : "tradeCode",
									index : "tradeCode",
									align : "center",
									width : 80,
									sortable : false
								},{
									name : "tradeCodeName",
									index : "tradeCodeName",
									align : "center",
									width : 80,
									sortable : false
								},*/
								{
									name : "materialName",
									index : "materialName",
									align : "center",
									sortable : false
								},								
								/*{
									name : "applyNum",
									index : "applyNum",
									align : "center",
									width : 90,
									sortable : false
								},
								{
									name : "usedNum",
									index : "usedNum",
									align : "center",
									width : 90,
									sortable : false,
									formatter : function(value, options, rData) {
										return "<font color='red'>" + value + "</font>";
									}
								},*/
								{
									name : "peopleName",
									index : "peopleName",
									align : "center",
									width : 100,
									sortable : false
								},
								{
									name : "applyPeopleOrgName",
									index : "applyPeopleOrgName",
									align : "center",
									sortable : false
								},
								/*{
									name : "sealOrgName",
									index : "sealOrgName",
									align : "center",
									width : "100",
									sortable : false
								},*/
								{
									name : "applyDate",
									index : "applyDate",
									align : "center",
									width : 90,
									sortable : false,
									formatter : function(value, options, rData) {
										return value.substring(0,4)+"-"+value.substring(4,6)+"-"+value.substring(6,8)+" "+
												rData.applyTime.substring(0,2)+":"+rData.applyTime.substring(2,4)+":"+rData.applyTime.substring(4,6);
									}
								},
								/*{
									name : "scanNum",
									index : "scanNum",
									align : "center",
									width : 120,
									sortable : false
								},*/								
								/*{
									name : "id",
									index : "id",
									align : "center",
									width : 185,
									sortable : false,
									formatter : function(value, options, rData) { 
										return "<input type='button' style=\" width:65px; \"  onclick=\"\" value='详情' />";
									}
								}*/
								{
									name : "id",
									index : "id",
									align : "center",
									width : 60,
									sortable : false,
									formatter : function(value, options, rData) { 
										return "<input type='button' style=\" width:65px; \"  onclick=\"showDocDetail('"+rData.scanNum+"');\" value='详情' />";
									}
								}],
						pager : "#useSealPager",
						caption : "我的申请列表"
					}).trigger("reloadGrid");
	$("#useSealList").navGrid("#useSealPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

function initUseSealPage() {
	$("#submitForm").click(function() {
		queryApplyInfoForTerm();
	});
	$("#clearForm").click(function() {
		$("#queryForm")[0].reset();
	});
	$("#sealUseTaskInfo").dialog({
		autoOpen : false,
		resizable : false,
		width : $(window).width() / 2,
		modal : true,
		position : {
			at : "center"
		},
		close : function() {
			initTaskList();
			$("#sealUseApplyForm")[0].reset();
			showFiles();
		}
	});
	$("#docPreview").dialog({
		autoOpen : false,
		resizable : false,
		width : $(window).width() / 2,
		modal : true,
		position : {
			at : "center"
		},
		close : function() {
			initTaskList();
			$("#docPreview").html("");
		}
	});
};

function applyUseSeakTask(){
	$("#sealUseTaskInfo").dialog("open");
}

function queryApplyInfoForTerm() {
	 $("#useSealList").jqGrid("search", "#queryForm");
};

/**
 * 初始化机构数据
 */
function initOrgSelect(){
	var url = ctx + "/sealusetask/create/sealUseTask_initSealOrg.action";
	var result = tool.ajaxRequest(url, null);
	if(result.response.webResponseJson.state == "normal"){
		var orgArray = result.response.webResponseJson.data;
		$.each(orgArray, function(index, organize) {
			$("#sealOrg").append("<option value='"+ organize.orgNo +"'>"+ organize.orgName +"</option>");
		});
	}else{
		var message = reslut.response.webResponseJson.message;
		alert(message);
	}
}

/**
 * 展示印章列表
 */
function showSeals(){
	var orgNo = $("#sealOrg").val();
	//清空下拉列表
	$("#seals").empty();
	if(orgNo == "0"){
		alert("请选择印章使用机构！");
	}else{
		var url = ctx + "/sealusetask/create/sealUseTask_initAvailableSeal.action";
		var param = {
				"orgNo" : orgNo
		};
		var result = tool.ajaxRequest(url, param);
		if(result.response.webResponseJson.state == "normal"){
			var sealArray = result.response.webResponseJson.data;
			$.each(sealArray,function(index,seal){
				if(index == 0){
					$("#seals").append("<div class='form-control' style='width:240px'><input type='checkbox' value='"+ seal.autoId +"'>"+ seal.sealTypeName +"</input>&nbsp;<lable>使用次数:</lable>&nbsp;<input id='seal"+ index+"' type='text' style='width:40px'><lable>&nbsp;&nbsp;&nbsp;</lable></div>");
				}else{
					$("#seals").append("<div class='form-control' style='width:240px;margin-top:5px'><input type='checkbox' value='"+ seal.autoId +"'>"+ seal.sealTypeName +"</input>&nbsp;<lable>使用次数:</lable>&nbsp;<input id='seal"+ index+"' type='text' style='width:40px'><lable>&nbsp;&nbsp;&nbsp;</lable></div>");
				}
			});
		}else{
			var message = result.response.webResponseJson.message;
			$("#seals").append("<div class='form-control' style='width:240px'><p style='color:red'>"+ message +"</p></div>");
		}
	}
}

/**
 * 提交申请
 */
function submitApply(){
	$("#submitBtn").attr("disabled") == "disabled";
	var fileName = $.trim($("#tableTile").val());
	if("" == fileName){
		alert("标题不能为空！");
		return;
	}
	var applyReason = $.trim($("#tableReason").val());
	if("" == applyReason){
		alert("申请原因不能为空！");
		return;
	}
	if("0" == $("#sealOrg").val()){
		alert("请选择机构！");
		return;
	}
	
	//多文件上传
	if($("#tableType").val() == "2") {
		var flag = true;
		$("input[name='uploadFile']").each(function(index){
			var filename=$(this).val();
			if(filename == ""){
				alert("请删除空行");
				flag = false;
				return false;
			}
			var file_suffix = filename.substring(filename.lastIndexOf(".")+1,filename.length);
			if(file_suffix != "docx" && file_suffix != "doc") {
				alert("请选择word文档");
				flag = false;
				return false;
			}
			$("input[name='uploadFile']").each(function(tl){
				if(index != tl && filename == $(this).val()) {
					alert("请选择不同文档");
					flag = false;
					return false;
				}
			});
			if(!flag) {
				return false;
			}
		});
		if(!flag) {
			return;
		}
		if($("#fileTd").find("input[value='']").length > 0) {
			alert("请填写空白栏");
			return;
		}
		for(var i=0;i<$("#fileTd").find("input").length;i++) {
			$("#fileTd").after("<input name=\"tableApply.filepaths\" type=\"hidden\" value=\""+$("#fileTd").find("input")[i].value+"\" />");
		}
		
		sealUseApplyForm.action = ctx + "/sealusetask/create/sealUseTask_createBatchUseSealTask.action";
		sealUseApplyForm.submit();
		return;
	}
	
	var hasFile = $("#fileinput").val();
	if("" == hasFile){
		alert("请选择待上传文件");
		return;
	}
	var fileNum = $.trim($("#fileNum").val());
	if("" == fileNum){
		alert("请输入文件份数！");
		return;
	}else if(!regu.test(fileNum)){
		alert("输入的文件份数不合法！");
		return;
	}
	var elements = $("#seals > div > input:checked");
	if(elements.length == 0){
		alert("请选择当前申请所需要的印章");
		return;
	}else{
		var ids = "";
		var isPass = true;
		$.each(elements,function(index,element){
			var tempNum = $("#seal"+ index).val();
			if(!regu.test(tempNum)){
				isPass = false;
			}
			if(index == 0){
				ids += element.value + "*" + $("#seal"+ index).val();
			}else{
				ids = ids + "|" + element.value + "*" + $("#seal"+ index).val();
			}
		});
		if(!isPass){
			alert("印章使用次数必须为正整数！");
			return;
		}
		$("#sealId").val(ids);
	}
	for(var i=0;i<$("#fileTd").find("input").length;i++) {
		$("#fileTd").after("<input name=\"tableApply.filepaths\" type=\"hidden\" value=\""+$("#fileTd").find("input")[i].value+"\" />");
	}
	sealUseApplyForm.action = ctx + "/sealusetask/create/sealUseTask_createUseSealTask.action";
	$("#sealUseApplyForm").submit();
}

/**
 * 授权码
 */
function creatFastUseSealCode(){
	var url = ctx + "/sealusetask/create/sealUseTask_creatFastUseSealCode.action";
	var param = {};
	var result = tool.ajaxRequest(url, param);
	if(result.response.webResponseJson.state == "normal"){
		var verifyCode = result.response.webResponseJson.data;
		alert("快速用印授权码：\r\n"+verifyCode+"\r\n有效时间"+result.response.webResponseJson.message+"秒");
	}else{
		var message = result.response.webResponseJson.message;
		alert(message);
	}
}

function showFiles(){
	$("#fileTd").html("");
	if($("#tableType").val() == "1") {
		$("#fileTd").prev().html("待上传文件：");
		$("#fileNum").parent().parent().css("display", "");
		$("#seals").parent().parent().css("display", "");
		$("#fileTd").append("<input id=\"fileinput\" class=\"form_label_200\" name=\"uploadFile\" type=\"file\" />");
	} else {
		$("#fileTd").prev().html("待上传文件/打印<br/>份数/盖章次数：");
		$("#fileNum").parent().parent().css("display", "none");
		var str = "<input class=\"form_label_200\" name=\"uploadFile\" type=\"file\" index=1 />" +
				"<input type=\"text\" name=\"tableApply.allPrintNum\" onkeypress=\"return event.keyCode>=48&&event.keyCode<=57\" style=\"width:20px;\" value=\"1\" index=1 />" +
				"<input type=\"text\" name=\"tableApply.sealNum\" onkeypress=\"return event.keyCode>=48&&event.keyCode<=57\" style=\"width:20px;\" value=\"1\" index=1 />" +
				"<select class=\"form_label_220\" style=\"width:80px;\" name=\"tableApply.useSealType\" index=1 ><option value='1'>合同章(实时)</option>" +
				"<option value='2'>合同章(非实时)</option><option value='3'>合同+人名章(实时)</option><option value='4'>合同+人名章(非实时)</option></select>" +
				"<img src='"+ctx+"\\windforce\\common\\images\\ioco_03.png' href='#' onclick='addFile();' index=1 style='width:20px;height:20px;' />" +
				"<img src='"+ctx+"\\windforce\\common\\images\\ioco_04.png' href='#' name='delIcon' onclick='delFile(1);' index=1 style='width:20px;height:20px;' />";
		$("#seals").parent().parent().css("display", "none");
		$("#fileTd").append(str);
	}
}

function addFile(){
	var index = Number($("img[name='delIcon']:last").attr("index")) + 1;
	var str = "<br index="+index+" /><input class=\"form_label_200\" name=\"uploadFile\" type=\"file\" index="+index+" />" +
			"<input type=\"text\" name=\"tableApply.allPrintNum\" onkeypress=\"return event.keyCode>=48&&event.keyCode<=57\" style=\"width:20px;\" value=\"1\" index="+index+" />" +
			"<input type=\"text\" name=\"tableApply.sealNum\" onkeypress=\"return event.keyCode>=48&&event.keyCode<=57\" style=\"width:20px;\" value=\"1\" index="+index+" />" +
			"<select class=\"form_label_220\" style=\"width:80px;\" name=\"tableApply.useSealType\" index="+index+" ><option value='1'>合同章(实时)</option>" +
				"<option value='2'>合同章(非实时)</option><option value='3'>合同+人名章(实时)</option><option value='4'>合同+人名章(非实时)</option></select>" +
			"<img src='"+ctx+"\\windforce\\common\\images\\ioco_03.png' href='#' onclick='addFile();' index="+index+" style='width:20px;height:20px;' />" +
			"<img src='"+ctx+"\\windforce\\common\\images\\ioco_04.png' href='#' name='delIcon' onclick='delFile("+index+");' index="+index+" style='width:20px;height:20px;' />";
	$("#fileTd").append(str);
}

function delFile(index){
	if($("img[name='delIcon']").length == 1) {
		return;
	}
	$("#fileTd [index="+index+"]").remove();
}

function showImg(type, value, obj){
	if(type == "show") {
		var e = event || window.event;
		var pos = obj.getBoundingClientRect();
		$("#qrcodeImg").css("left", pos.right+10);
		$("#qrcodeImg").css("top",pos.bottom>400 ? 395:e.clientY);
		$("#qrcodeImg").qrcode({render: "table",width:100,height:100,text:value});
		$("#qrcodeImg").css("display", "block");
	} else if (type == "hide") {
		$("#qrcodeImg").css("display", "none");
		$("#qrcodeImg").html("");
	}
}

function showDocDetail(scanNum){
	var url = ctx + "/sealusetask/create/sealUseTask_queryDocDetail.action";
	var param = {"scanNum":scanNum};
	var result = tool.ajaxRequest(url, param);
	if(result.response.webResponseJson.state == "normal"){
		var files = result.response.webResponseJson.data;
		$.each(files, function(i, row){
			$('#docPreview').append("<a href='"+row.filePath+"' title='"+row.fileDesc+"'>"+row.fileDesc+"</a><br/>");
		});
		$('#docPreview').dialog('open');
	}else{
		var message = result.response.webResponseJson.message;
		alert(message);
	}
}