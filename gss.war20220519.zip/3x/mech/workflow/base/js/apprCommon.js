﻿var FN_JQGRID = $.fn.jqGrid;

// 行政印章审批
var ADMINAPPR_COLNAMES = [ "autoId", "用印事由", "申请人姓名", "申请人账号", "申请机构", "申请机构号", "申请日期" ];
var ADMINAPPR_COLMODEL = [ {
    name : "autuId",
    index : "id",
    width : 20,
    hidden : true
}, {
    name : "title",
    index : "title",
    width : 120
}, {
    name : "applyPeopleName",
    index : "applyPeopleName",
    width : 120
}, {
    name : "applyPeopleCode",
    index : "applyPeopleCode",
    width : 120
}, {
    name : "applyOrgName",
    index : "applyOrgName",
    width : 120
}, {
    name : "applyOrgNo",
    index : "applyOrgNo",
    width : 120
}, {
    name : "applyTime",
    index : "applyTime",
    width : 120
} ];

var SEALHANDLE_COLNAMES = [ "autoId", "设备编号", "申请类型", "申请人姓名", "申请人账号", "申请机构", "申请时间" ];
var SEALHANDLE_COLMODEL = [ {
    name : "autoId",
    index : "autoId",
    width : 20,
    hidden : true
}, {
    name : "deviceNum",
    index : "deviceNum",
    width : 120
}, {
    name : "operType",
    index : "operType",
    width : 120
}, {
    name : "applyPeopleName",
    index : "applyPeopleName",
    width : 120
}, {
    name : "applyPeopleCode",
    index : "applyPeopleCode",
    width : 120
}, {
    name : "applyOrgNo",
    index : "applyOrgNo",
    width : 120
},{
    name : "applyTime",
    index : "applyTime",
    width : 120
} ];

$.fn.jqGrid = function(pin) {
    if (typeof pin == 'string') {
	var fn = $.jgrid.getAccessor(FN_JQGRID, pin);
	if (!fn) {
	    throw ("jqGrid - No such method: " + pin);
	}
	var args = $.makeArray(arguments).slice(1);
	return fn.apply(this, args);
    }

    var colNames = null, colModel = null;
    if (pin.colType == "adminAppr") {
		colNames = ADMINAPPR_COLNAMES;
		colModel = ADMINAPPR_COLMODEL;
    }
    if (pin.colType == "sealHandleAppr") {
		colNames = SEALHANDLE_COLNAMES;
		colModel = SEALHANDLE_COLMODEL;
    }
    if (colNames) {
	for ( var i = colNames.length - 1; i >= 0; i--) {
	    pin.colNames.splice(0, 0, colNames[i]);
	}
    }
    if (colModel) {
	for ( var i = colModel.length - 1; i >= 0; i--) {
	    pin.colModel.splice(0, 0, colModel[i]);
	}
    }

    var ret = FN_JQGRID.call(this, pin);
    // this.navGrid(pin.pager);
    return ret;
};

$.fn.getTask = function(url, param, callback) {
    $(this).data("taskSealSn", null);
    $(this).validationEngine("hideAll");
    $(this).dialog("open");
    var _this = this;
    if ("undefined" == url || "" == url || null == url || url.length <= 0) {
	url = $.getContextPath() + "/sms/base/smsBaseTaskListAction_gainTask.action";
    }
    $.post(url, param, function(data) {
	if (data.responseMessage.success) {
	    var bizInfo = data.bizInfo;
	    if (bizInfo == null) {
		alert("此任务正在处理或者已处理");
		$(_this).dialog("close");
		return;
	    }
	    $(_this).data("taskSealSn", param.sealSn);
	    $(_this).data("autoId", param["bizInfo.autoId"]);
	    callback(data);
	} else {
	    $.error("读取数据出错: " + data.responseMessage.message);
	}
    });
};

$.fn.getTaskList = function(param) {
    var defaultparam = {
	caption : "",
	url : "",
	urlParam : "",
	operName : "操作",
	pager : "#pager",
	colType : param.colType || "sealInfo",
	operMethod : [],
	result : ""
    };
    param = $.extend(defaultparam, param);
    for ( var i = 0; i < param.operMethod.length; i++) {
	var defaultopermethod = {
	    name : "",
	    method : "",
	    icon : "edit"
	};
	param.operMethod[i] = $.extend(defaultopermethod, param.operMethod[i]);
    }
    var jqGridParam = {
	caption : param.caption,
	url : param.url,
	postData : param.urlParam,
	rownumbers : true,
	multiselect : param.multiselect,
	colType : param.colType,
	pager : param.pager,
	colNames : [],
	colModel : []
    };

    if (param.operMethod.length > 0) {
	jqGridParam.colNames = [ param.operName ];
	jqGridParam.colModel = [ {
	    name : "sealSn",
	    index : "sealSn",
	    width : 80,
	    align : "center",
	    formatter : function(value, options, rData) {
		var html = "<center><div>";
		$.each(param.operMethod, function(i, d) {
		    if (d.method) {
			html += "<div class='icon_" + d.icon + "' onclick='" + d.method + "(\"" + value + "\", \""
				+ rData.node + "\", \"" + options.rowId + "\",\"" + param.result + "\", \"" + d.name
				+ "\", \"" + param.fetchType + "\", \"" + rData.autoId + "\" )' title='" + d.name
				+ "' style='float:left;'></div>";
		    } else if (d.form) {
			html += "<div class='icon_" + d.icon + "' onclick='FN_GETTASKLIST_SHOWFORM(\"" + d.form
				+ "\", \"" + rData.autoId + "\", \"" + value + "\", \"" + rData.node + "\", \"" + d.name
				+ "\", \"" + param.result + "\", \"" + param.fetchType + "\", \"" + d.url
				+ "\")' title='" + d.name + "' style='float:left;'></div>";
		    } else if (d.url) {

		    }
		});
		html += "</div></center>";
		return html;
	    }
	} ];
    }

    $(this).jqGrid(jqGridParam);
    var nav = $.extend({
	edit : false,
	add : false,
	del : false,
	search : false,
	refresh : true
    }, param.nav);
    $(this).navGrid(param.pager, nav);

    $(":submit,:button").button();
    $("body").css("visibility", "visible");
};

function FN_GETTASKLIST_SHOWFORM(form, autoId, sealSn, node, title, result, fetchType, url) {
    $(form).fillTask(autoId, sealSn, node, title, result, fetchType, "", url);
}

$.fn.winform = function(param, listId) {
    listId = listId || "#list";

    $(this).each(function() {
	var dialogParam = preform(param, listId, this);
    });
};

/**
 * height: width: submit:[] check: url recheck:url ok: url seal: createSeal
 * showSeal destroySeal differSeal showDestroySeal showDifferSeal
 */
$.fn.form = function(param, listId) {
    listId = listId || "#list";

    $(this).each(function() {
	var dialogParam = preform(param, listId, this);
	$(this).dialog(dialogParam);
    });

};

function preform(param, listId, form) {
    $(form).data("param", param);
    lockId = $(form).data("autoId");
    var dialogParam = {
	autoOpen : false,
	height : $(form).attr("height") || param.height || 490,
	width : $(form).attr("width") || param.width || 700,
	beforeclose : param.beforeclose,
	open : param.open,
	modal : true,
	buttons : {},
	defaultclose : function() {
	    if ($(form).data("taskSealSn")) {
		$.post($.getContextPath() + "/mechseal/task/" + ajaxReqActionName + "_unlockTask.action", {
		    "bizInfo.autoId" : $(form).data("autoId")
		}, function(data) {
			lockId="";
		});
	    }
	    $(form).validationEngine("hideAll");
	    $(form)[0].reset();
	    $(form).find("input[type=hidden]").val("");
	}
    };

    dialogParam.close = function() {
	if (param.close) {
	    param.close();
	}
	dialogParam.defaultclose();
    };
    $.each(param.submit || [], function(i, d) {
	dialogParam.buttons[d.name] = function(event) {
	    if (d.beforeSubmit) {
		if (d.beforeSubmit() == false) {
		    return;
		}
	    }
	    tasksubmit(event, d.url, form, listId, param.callback, d.data);
	};
    });
    if (param.check) {
	var showMode = $("#showMode").val();
	var buttonMode = $("#buttonMode").val();
	if (buttonMode == constants.APPR_BUTTON_MODE_0) {
	    dialogParam.buttons["提交"] = function(event) {
		if (!judgePassValidation(showMode)) {
		    return;
		}
		$("#checkResult").val("yes");
		tasksubmit(event, param.check, form, listId, param.callback);
	    };
	} else if (buttonMode == constants.APPR_BUTTON_MODE_2) {
	    dialogParam.buttons["同意"] = function(event) {
		if (!judgePassValidation(showMode)) {
		    return;
		}
		$("#checkResult").val("yes");
		tasksubmit(event, param.check, form, listId, param.callback);
	    };
	    dialogParam.buttons["拒绝"] = function(event) {
		if ($.trim($("#checkOpinion").val()) == "") {
		    alert("审核意见不能为空！");
		    $("#checkOpinion").focus();
		    return;
		}
		$("#checkResult").val("no");
		tasksubmit(event, param.check, form, listId, param.callback);
	    };
	    dialogParam.buttons["退回"] = function(event) {
		$("#checkResult").val("revert");
		tasksubmit(event, param.check, form, listId, param.callback);
	    };
	} else {
	    dialogParam.buttons["同意"] = function(event) {
		if (!judgePassValidation(showMode)) {
		    return;
		}
		$("#checkResult").val("yes");
	    var memo= $("#checkOpinion").val();
//	    $("#checkOpinion").val("机构("+loginPeople.orgNo+")下的人员("+loginPeople.peopleName+")已审核,审核意见:"+memo);
	    $("#checkOpinion").val(memo);
		tasksubmit(event, param.check, form, listId, param.callback);
	    };
	    dialogParam.buttons["拒绝"] = function(event) {
		if ($.trim($("#checkOpinion").val()) == "") {
		    alert("审核意见不能为空！");
		    $("#checkOpinion").focus();
		    return;
		}
		$("#checkResult").val("no");
	    var memo= $("#checkOpinion").val();
//	    $("#checkOpinion").val("机构("+loginPeople.orgNo+")下的人员("+loginPeople.peopleName+")已拒绝,审核意见:"+memo);
	    $("#checkOpinion").val(memo);
		tasksubmit(event, param.check, form, listId, param.callback);
	    };
	}
    }
    /*
     * if (param.multicheck) { dialogParam.buttons["同意"] = function(event) {
     * $("#checkResult").val("success"); tasksubmit(event, param.multicheck,
     * form, listId, param.callback); }; dialogParam.buttons["拒绝"] =
     * function(event) { if ($.trim($("#checkOpinion").val()) == "") {
     * alert("审核意见不能为空！"); $("#checkOpinion").focus(); return; }
     * $("#checkResult").val("fail"); tasksubmit(event, param.multicheck, form,
     * listId, param.callback); }; } if (param.check2) {
     * dialogParam.buttons["退回"] = function(event) {
     * $("#checkResult").val("revert"); tasksubmit(event, param.check2, form,
     * listId, param.callback); }; dialogParam.buttons["同意"] = function(event) {
     * $("#checkResult").val("yes"); tasksubmit(event, param.check2, form,
     * listId, param.callback); }; dialogParam.buttons["拒绝"] = function(event) {
     * if ($.trim($("#checkOpinion").val()) == "") { alert("审核意见不能为空！");
     * $("#checkOpinion").focus(); return; } $("#checkResult").val("no");
     * tasksubmit(event, param.check2, form, listId, param.callback); }; }
     */

    $(form).data("seal", param.seal);

    $(form).validationEngine({
	showOnMouseOver : true,
	validationEventTrigger : "blur",
	promptPosition : "topLeft",
	showArrow : true,
	autoPositionUpdate : true,
	onValidationComplete : function() {
	    return;
	}
    });

    return dialogParam;

};

function unlockIdTask(){
	if (lockId != "" && lockId != null) {
		$.ajax({
			type : 'POST',
			url : ctx + "/mechseal/sealmanager/takeSealApprTaskAction_unlockTask.action",
			async : false,
			data : {
				"bizInfo.id" : lockId
			},
			success : function(data) {
				lockId="";
			}
		});
	}
}

// 必填表单校验:审核人员/会签人员
function judgePassValidation(showMode) {
    if ((showMode & constants.APPR_MODE_LIST_NEXT_HANDLER) != 0) {
		if ($.trim($("#apprPeople").val()) == "") {
		    alert("请选择下一审核人员！");
		    return false;
		}
    }
    if ((showMode & constants.APPR_MODE_LIST_MULTI_HANDLER) != 0
	    || (showMode & constants.APPR_MODE_SELECT_APPR_MODE) != 0) {
		var mode = $('input[name="sealUseTaskForm.multiManagerAppr"]:checked').val();
		if (mode == "multi") {
		    var multiPeo = $("#multiPeople").multiselect("getChecked").map(function() {
			return this.value;
		    }).get();
		    if (!multiPeo || multiPeo.length == 0) {
			alert("请选择会签机构！");
			return false;
		    }
		}
    }

    return true;
};

function tasksubmit(event, url, form, listId, callback, data) {
    if (!$(form).validationEngine("validate")) {
	return;
    }
    // 处理会签人员写入
    var value = $("#multiPeople").multiselect("getChecked").map(function() {
	return this.value;
    }).get();
    $("#multiHandlers").val(value.toString());
    data = data ? data() : $(form).serializeForm();
    if ($(form).data("param") && $(form).data("param").beforeSubmit) {
	if (!$(form).data("param").beforeSubmit(data)) {
	    return;
	}
    }

    $(event.target).post(
	    url,
	    data,
	    function(data) {
		if (data.responseMessage.success) {
		    var message = "操作成功";
		    if (data.responseMessage.data) {
			if (/^\w{2}$/.test(data.responseMessage.data)) {
			    if (data.responseMessage.data != "FF" && data.responseMessage.data != "F0") {
				message += "："
					+ getTypeName("NodeCode", data.responseMessage.data, "nodeCode", "nodeName");
			    }
			    if (data.responseMessage.data == "11" || data.responseMessage.data == "51"
				    || data.responseMessage.data == "52") {
				alert(getTypeName("NodeCode", data.responseMessage.data, "nodeCode", "nodeName"));
			    }
			}

		    }

		    if (data.responseMessage.message) {
			message += "：" + data.responseMessage.message;
		    }

		    $.success(message);

		    $(listId).trigger("reloadGrid");
		    $(form).dialog("close");
		    if (callback) {
			callback(data);
		    }
		} else {
		    $.error("操作失败: " + data.responseMessage.message);
		}
	    });
};

$.del = function(url, param, callback) {
    if (confirm("是否要删除?")) {
	$.post(url, param, function(data) {
	    if (data.responseMessage.success) {
		$.success("删除成功");
		$("#list").trigger("reloadGrid");
		if (callback) {
		    callback(data);
		}
	    } else {
		$.error("删除失败: " + data.responseMessage.message);
	    }
	});
    }
};

$.fn.fillTask = function(autoId, sealSn, node, title, result, fetchType, lock, url) {
    var _this = this;

    if (title) {
	$(_this).dialog("option", "title", title);
    }
    $(_this).getTask(
	    url,
	    {
		"bizInfo.autoId" : autoId,
		"sealSn" : sealSn,
		"node" : node,
		"query" : result,
		"fetchType" : fetchType,
		"lock" : lock
	    },
	    function(data) {
		// 页面显示模式
		$("#apprMode").val(data.sealUseTaskForm.apprMode);
		$("#processId").val(data.sealUseTaskForm.processId);
		$("#taskNodeName").val(data.sealUseTaskForm.nodeName);
		$("#multiDept").val(data.sealUseTaskForm.multiDept);
		$("#showMode").val(data.sealUseTaskForm.showMode);
		$("#buttonMode").val(data.sealUseTaskForm.buttonMode);
		$("#adminApprInfo").form({
		    height : 490,
		    check : $.getContextPath() + "/mechseal/task/" + ajaxReqActionName + "_commitTask.action"
		});
		$(_this).fillForm({
		    bizInfo : data.bizInfo
		});
		if ($(_this).data("param") && $(_this).data("param").loadComplete) {
		    $(_this).data("param").loadComplete(data);
		}
		$(_this).find("input[name='bizInfo.status']").val(sealUseConstants.SealUseApplyStatus[data.bizInfo.status]);
		if (data.sealUseTaskForm.urlList != null && data.sealUseTaskForm.urlList.length > 0) {
		    wfStoreFancyBox.showAllThumbnailImageByUrl("img", data.sealUseTaskForm.urlList, "buttons");
		}
		
		// 分类显示-会签人员列表  显示会签机构
		if ((data.sealUseTaskForm.showMode & constants.APPR_MODE_LIST_MULTI_HANDLER) != 0) {
		    //$("#multiDiv").show();
			showDiv("multiDiv", "sealUseTaskForm.multiManager");
		    $("#multiPeople").empty();
		    $("input[type='radio'][name='sealUseTaskForm.multiManagerAppr'][value='multi']").attr("checked", true);
		    var managerRoleList = data.sealUseTaskForm.multiManagerList;
		    $.each(managerRoleList, function(index, manager) {
			$("#multiPeople").append(
				"<option value='" + manager.orgNo + "'>" + manager.orgName + "（" + manager.orgNo
					+ "）</option>");
		    });
		    $("#multiPeople").multiselect({
			noneSelectedText : "请选择",
			checkAllText : "全选",
			uncheckAllText : '全不选',
			selectedList : 4
		    });
		} else {
		    //$("#multiDiv").hide();
			hideDiv("multiDiv", "sealUseTaskForm.multiManager");
		}
		
		// 分类显示-单人审批人员列表 显示分管行长选择列表
		if ((data.sealUseTaskForm.showMode & constants.APPR_MODE_LIST_NEXT_HANDLER) != 0) {
		    //$("#apprDiv").show();
		    showDiv("apprDiv", "sealUseTaskForm.nextHandler");
		    $("#apprPeople").empty();
		    var apprPeopleList = data.sealUseTaskForm.nextHandlerList;
		    $.each(apprPeopleList, function(index, people) {
			$("#apprPeople").append(
				"<option value='" + people.sid + "'>" + people.peopleName + "（" + people.orgName
					+ "）</option>");
		    });

		} else {
			//$("#apprDiv").hide();
			hideDiv("apprDiv", "sealUseTaskForm.nextHandler");
		}
		
		// 分类显示-审批模式选择（普通/会签） 显示审批模式
		if ((data.sealUseTaskForm.showMode & constants.APPR_MODE_SELECT_APPR_MODE) != 0) {
		    // 此模式已包含"会签人员列表"显示模式，所有此模式代码的执行顺序必须在"会签人员列表"后面
			$("input[type='hidden'][name='sealUseTaskForm.multiManagerAppr']").remove();
		    $("input[type='radio'][name='sealUseTaskForm.multiManagerAppr'][value='normal']").attr("checked", true);
		    //$("#apprModeDiv").show();
		    showDiv("apprModeDiv", "sealUseTaskForm.multiManagerAppr");
		    $("#multiPeople").empty();
		    //$("#multiDiv").hide();
		    hideDiv("multiDiv", "sealUseTaskForm.multiManager");
		    var handlerList = data.sealUseTaskForm.multiManagerList;
		    $.each(handlerList, function(index, handler) {
			$("#multiPeople").append(
				"<option value='" + handler.orgNo + "'>" + handler.orgName + "（" + handler.orgNo
				+ "）</option>");
		    });
		    $("#multiPeople").multiselect({
			noneSelectedText : "请选择",
			checkAllText : "全选",
			uncheckAllText : '全不选',
			selectedList : 4
		    });
		    $("input:radio[name='sealUseTaskForm.multiManagerAppr']").unbind("change");
		    $("input:radio[name='sealUseTaskForm.multiManagerAppr']").change(function() {
			var mode = $(this).val();
			if (mode == "normal") {
			    //$("#multiDiv").hide();
			    hideDiv("multiDiv", "sealUseTaskForm.multiManager");
			} else {
			    //$("#multiDiv").show();
			    showDiv("multiDiv", "sealUseTaskForm.multiManager");
			}
		    });
		} else {
			//$("#apprModeDiv").hide();
			hideDiv("apprModeDiv", "sealUseTaskForm.multiManagerAppr");
			var appendhidden = "<input type='hidden' name='sealUseTaskForm.multiManagerAppr' value='"+data.sealUseTaskForm.multiManagerAppr+"' />";
			$(_this).append(appendhidden);
		}
		
		// 分类显示-是否行长审批选择 显示跳至行长审批
		if ((data.sealUseTaskForm.showMode & constants.APPR_MODE_SELECT_PRESIDENT_APPR) != 0) {
			$("input[type='hidden'][name='sealUseTaskForm.presidentAppr']").remove();
		    //$("#presidentApprDiv").show();
		    showDiv("presidentApprDiv", "sealUseTaskForm.presidentAppr");
		} else {
		    //$("#presidentApprDiv").hide();
		    hideDiv("presidentApprDiv", "sealUseTaskForm.presidentAppr");
		    var appendhidden = "<input type='hidden' name='sealUseTaskForm.presidentAppr' value='"+data.sealUseTaskForm.presidentAppr+"' />";
			$(_this).append(appendhidden);
		}

		// 分类显示-是否分管行长审批选择 显示分管行长审批
		if ((data.sealUseTaskForm.showMode & constants.APPR_MODE_SELECT_VICE_APPR) != 0) {
			$("input[type='hidden'][name='sealUseTaskForm.viceAppr']").remove();
//		    $("input:radio[name='sealUseTaskForm.viceAppr']").unbind("change");
//		    $("input:radio[name='sealUseTaskForm.viceAppr']")
//			    .change(
//				    function() {
//					var url = ctx + "/mechseal/task/" + ajaxReqActionName
//						+ "_acquireApprPeopleList.action";
//					var form = $("#adminApprInfo").serialize();
//					var data = tool.ajaxRequest(url, form);
//					if (data.success) {
//					    $("#apprPeople").empty();
//					    var managerRoleList = data.response.sealUseTaskForm.nextHandlerList;
//					    $.each(managerRoleList, function(index, manager) {
//						$("#apprPeople").append(
//							"<option value='" + manager.sid + "'>" + manager.peopleName
//								+ "（" + manager.orgName + "）</option>");
//					    });
//					}
//				    });
		    //$("#viceApprDiv").show();
		    showDiv("viceApprDiv", "sealUseTaskForm.viceAppr");
		} else {
		    //$("#viceApprDiv").hide();
		    hideDiv("viceApprDiv", "sealUseTaskForm.viceAppr");
		    var appendhidden = "<input type='hidden' name='sealUseTaskForm.viceAppr' value='"+data.sealUseTaskForm.viceAppr+"' />";
			$(_this).append(appendhidden);
		}
		//是否办公室主任审批
		var appendhidden_ = "<input type='hidden' name='sealUseTaskForm.officeDirectorAppr' value='"+data.sealUseTaskForm.officeDirectorAppr+"' />";
		$(_this).append(appendhidden_);
		$("#nowHandleName").val(loginPeople.peopleName);
		$("#adminApprInfo").dialog("open");
	    });

};

$(function() {
    $(":submit,:button").button();
});

function showDiv(id, inputname){
	$("input[name='" + inputname + "']").removeAttr("disabled");
	$("#" + id).show();
}

function hideDiv(id, inputname){
	$("input[name='" + inputname + "']").attr("disabled", "disabled");
	$("#" + id).hide();
}