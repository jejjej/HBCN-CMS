﻿var FN_JQGRID = $.fn.jqGrid;
var _param = null;
var _listId = null;
var _form = null;
var paramFlow = null;
var currentNodeId = null;
var scanNum= null;

// 行政印章审批
var ADMINAPPR_COLNAMES = [ "autoId", "用印标题名称", "发起人名称", "发起人账号", "发起机构名称", "发起机构号","状态", "发起日期","发起时间" ];
var ADMINAPPR_COLMODEL = [ {
    name : "id",
    index : "id",
    width : 20,
    sortable : false,
    hidden : true
}, {
    name : "title",
    index : "title",
    sortable : false,
    width : 120
},{
    name : "peopleName",
    index : "peopleName",
    sortable : false,
    width : 120
}, {
    name : "peopleCode",
    index : "peopleCode",
    sortable : false,
    width : 120
}, {
    name : "orgName",
    index : "orgName",
    sortable : false,
    width : 120
}, {
    name : "orgNo",
    index : "orgNo",
    sortable : false,
    width : 120
}, {
	name : "status",
	index : "status",
	align : "center",
	sortable : false,
	formatter : function(value, options, rData) {
		return sealUseConstants.SealUseApplyStatus[value];
    }
},{
    name : "applyDate",
    index : "applyDate",
    width : 120,
    align : "center",
    sortable : false,
    formatter : function(value, options, rData) {
		return value.substring(0,4)+"-"+value.substring(4,6)+"-"+value.substring(6,8)+" "+
				rData.applyTime.substring(0,2)+":"+rData.applyTime.substring(2,4)+":"+rData.applyTime.substring(4,6);
	}
},{
    name : "applyTime",
    index : "applyTime",
    width : 120,
    align : "center",
    sortable : false,
    formatter : function(value, options, rData) {
		return value.substring(0,2)+":"+value.substring(2,4)+":"+value.substring(4,6);
	}
} ];

var SEALHANDLE_COLNAMES = [ "autoId", "设备编号", "申请类型", "申请人姓名", "申请人账号", "申请机构", "申请时间" ];
var SEALHANDLE_COLMODEL = [ {
    name : "id",
    index : "id",
    width : 20,
    hidden : true
}, {
    name : "deviceNum",
    index : "deviceNum",
    width : 120
}, {
    name : "operType",
    index : "operType",
    width : 120
}, {
    name : "applyPeopleName",
    index : "applyPeopleName",
    width : 120
}, {
    name : "applyPeopleCode",
    index : "applyPeopleCode",
    width : 120
}, {
    name : "applyOrgNo",
    index : "applyOrgNo",
    width : 120
},{
    name : "applyTime",
    index : "applyTime",
    width : 120
} ];

$.fn.jqGrid = function(pin) {
    if (typeof pin == 'string') {
	var fn = $.jgrid.getAccessor(FN_JQGRID, pin);
	if (!fn) {
	    throw ("jqGrid - No such method: " + pin);
	}
	var args = $.makeArray(arguments).slice(1);
	return fn.apply(this, args);
    }

    var colNames = null, colModel = null;
    if (pin.colType == "adminAppr") {
		colNames = ADMINAPPR_COLNAMES;
		colModel = ADMINAPPR_COLMODEL;
    }
    if (pin.colType == "sealHandleAppr") {
		colNames = SEALHANDLE_COLNAMES;
		colModel = SEALHANDLE_COLMODEL;
    }
    if (colNames) {
	for ( var i = colNames.length - 1; i >= 0; i--) {
	    pin.colNames.splice(0, 0, colNames[i]);
	}
    }
    if (colModel) {
	for ( var i = colModel.length - 1; i >= 0; i--) {
	    pin.colModel.splice(0, 0, colModel[i]);
	}
    }

    var ret = FN_JQGRID.call(this, pin);
    // this.navGrid(pin.pager);
    return ret;
};

$.fn.getTask = function(url, param, callback) {
    $(this).data("taskSealSn", null);
    $(this).validationEngine("hideAll");
    $(this).dialog("open");
    var _this = this;
    if ("undefined" == url || "" == url || null == url || url.length <= 0) {
	url = $.getContextPath() + "/sms/base/smsBaseTaskListAction_gainTask.action";
    }
    $.post(url, param, function(data) {
	if (data.responseMessage.success) {
	    var bizInfo = data.bizInfo;
	    if (bizInfo == null) {
			alert("此任务正在处理或者已处理");
			$(_this).dialog("close");
		return;
	    }
	    $(_this).data("taskSealSn", param.sealSn);
	    $(_this).data("autoId", param["bizInfo.autoId"]);
	    callback(data);
	} else {
	    $.error("读取数据出错: " + data.responseMessage.message);
	}
    });
};

$.fn.getTaskList = function(param) {
    var defaultparam = {
	caption : "",
	url : "",
	urlParam : "",
	operName : "操作",
	pager : "#pager",
	colType : param.colType || "sealInfo",
	operMethod : [],
	result : ""
    };
    param = $.extend(defaultparam, param);
    for ( var i = 0; i < param.operMethod.length; i++) {
	var defaultopermethod = {
	    name : "",
	    method : "",
	    icon : "edit"
	};
	param.operMethod[i] = $.extend(defaultopermethod, param.operMethod[i]);
    }
    var jqGridParam = {
	caption : param.caption,
	url : param.url,
	postData : param.urlParam,
	rownumbers : true,
	multiselect : param.multiselect,
	colType : param.colType,
	pager : param.pager,
	colNames : [],
	colModel : []
    };

    if (param.operMethod.length > 0) {
	jqGridParam.colNames = [ param.operName ];
	jqGridParam.colModel = [ {
	    name : "sealSn",
	    index : "sealSn",
	    width : 80,
	    align : "center",
	    formatter : function(value, options, rData) {
		var html = "<center><div>";
		$.each(param.operMethod, function(i, d) {
		    if (d.method) {
			html += "<div class='icon_" + d.icon + "' onclick='" + d.method + "(\"" + value + "\", \""
				+ rData.node + "\", \"" + options.rowId + "\",\"" + param.result + "\", \"" + d.name
				+ "\", \"" + param.fetchType + "\", \"" + rData.autoId + "\" )' title='" + d.name
				+ "' style='float:left;'></div>";
		    } else if (d.form) {
			html += "<div class='icon_" + d.icon + "' onclick='FN_GETTASKLIST_SHOWFORM(\"" + d.form
				+ "\", \"" + rData.id + "\", \"" + value + "\", \"" + rData.node + "\", \"" + d.name
				+ "\", \"" + param.result + "\", \"" + param.fetchType + "\", \"" + rData.scanNum +"\", \"" + d.url
				+ "\")' title='" + d.name + "' style='float:left;'></div>";
		    } else if (d.url) {

		    }
		});
		html += "</div></center>";
		return html;
	    }
	} ];
    }

    $(this).jqGrid(jqGridParam);
    var nav = $.extend({
	edit : false,
	add : false,
	del : false,
	search : false,
	refresh : true
    }, param.nav);
    $(this).navGrid(param.pager, nav);
    $(":submit,:button").button();
    $("body").css("visibility", "visible");
    var grid = $("#list");
    var columnNames = grid.jqGrid('getGridParam','colModel');
    for (i = 0; i < columnNames.length; i++) {
       grid.setColProp(columnNames[i].index, { sortable: false });
    }
};

function FN_GETTASKLIST_SHOWFORM(form, autoId, sealSn, node, title, result, fetchType, scanNum,url) {
	showDocDetail(scanNum);
    $(form).fillTask(autoId, sealSn, node, title, result, fetchType, "", url);
}

$.fn.winform = function(param, listId) {
    listId = listId || "#list";

    $(this).each(function() {
    	var dialogParam = preform(param, listId, this);
    });
};

/**
 * height: width: submit:[] check: url recheck:url ok: url seal: createSeal
 * showSeal destroySeal differSeal showDestroySeal showDifferSeal
 */
$.fn.form = function(param, listId) {
    listId = listId || "#list";

    $(this).each(function() {
	var dialogParam = preform(param, listId, this);
		$(this).dialog(dialogParam);
    });

};

function preform(param, listId, form) {
    $(form).data("param", param);
    lockId = $("#id").val();
    var dialogParam = {
	autoOpen : false,
	height : $(form).attr("height") || param.height || 490,
	width : $(form).attr("width") || param.width || 700,
	beforeclose : param.beforeclose,
	open : param.open,
	modal : true,
	buttons : {},
	defaultclose : function() {
		$.post($.getContextPath() + "/mechseal/task/" + ajaxReqActionName + "_unlockTask.action", {
		    "bizInfo.id" : $("#id").val()
		}, function(data) {
			lockId="";
		});
	    $(form).validationEngine("hideAll");
	    $(form)[0].reset();
	    $(form).find("input[type=hidden]").val("");
	}
    };
    _param = param;
    _listId = listId;
    _form = form;
    dialogParam.close = function() {
	if (param.close) {
	    param.close();
	}
	dialogParam.defaultclose();
    };
    $.each(param.submit || [], function(i, d) {
	dialogParam.buttons[d.name] = function(event) {
	    if (d.beforeSubmit) {
		if (d.beforeSubmit() == false) {
		    return;
		}
	    }
	    tasksubmit(event, d.url, form, listId, param.callback, d.data);
	};
    });
    if (param.check) {
		if(_t == "0001") {
			$("#newMemo_b").attr("disabled","disabled");
			$("#newMemo_c").attr("disabled","disabled");
			document.getElementById("newMemoTr").style.display = "";
			document.getElementById("newMemoBTr").style.display = "none";
			document.getElementById("newMemoCTr").style.display = "none";
			dialogParam.buttons["提交"] = function(event) {
				
				var apprMemo =  $.trim($("#apprMemo").val());
				var newMemo =  $.trim($("#newMemo").val());
				
				if (apprMemo == "0" && newMemo != "") {
					if(newMemo.length > 500) {
						alert("复核意见备注输入字符长度不得超过500");
						return;
					}
					var result = formatterParamFlow(paramFlow,currentNodeId,"");
					if(result){
						$("#status").val("001");
						$("#isGroupAppr").val("0");
						$("#nextHandleDiv").dialog("open");
					} else {
						return;
					}
				} else if (apprMemo == "1" && newMemo != "") {
					$("#status").val("003");
					tasksubmit(event, param.check, form, listId, param.callback);
				} else if (apprMemo == "2" && newMemo != "") {
					$("#status").val("012");
					tasksubmit(event, param.check, form, listId, param.callback);
				}else {
					alert("请选择好意见并填写好备注，意见 与 备注信息 都不能为默认状态！");
					return;
				}
			};
			dialogParam.buttons["保存"] = function(event) {
				$("#status").val("007");//后台判断保存标志
				tasksubmit(event, param.check, form, listId, param.callback);
			}
		} else if (_t == "0002") {
			$("#newMemo").attr("disabled","disabled");
			$("#newMemo_b").attr("disabled","disabled");
			document.getElementById("newMemoTr").style.display = "";
			document.getElementById("newMemoBTr").style.display = "";
			document.getElementById("newMemoCTr").style.display = "";
			
			
			var status = $("#status").val();
			var isGroupAppr = $("#isGroupAppr").val();
			dialogParam.buttons["终审"] = function(event) {
				if(status == "001" && isGroupAppr != "1") {
					var apprMemo = $.trim($("#newMemo_b").val());
					if(apprMemo == "" || apprMemo == null) {
						alert("请输入审核意见备注！");
						return;
					}
					if(apprMemo.length > 500) {
						alert("审核意见备注输入字符长度不能超过500");
						return;
					}
				} else {
					var apprMemo =  $.trim($("#newMemo_c").val());
					if(apprMemo == "" || apprMemo == null) {
						alert("请输入意见备注！");
						return;
					}
					if(apprMemo.length > 500) {
						alert("意见备注输入字符长度不能超过500");
						return;
					}
				}
				$("#isGroupAppr").val("0");
				var apprMemo =  $.trim($("#apprMemo").val());
				if (apprMemo == "0") {
					var rs = formatterParamFlow(paramFlow,currentNodeId,"final");
					if(rs) {
						$("#status").val("004");
					} else {
						return;
					}
				} else {
					alert("请选择同意意见");
					return;
				}
				removeDis();
				tasksubmit(event, param.check, form, listId, param.callback);
			};
			dialogParam.buttons["提交"] = function(event) {
				if(status == "001" && isGroupAppr != "1") {
					var apprMemo =  $.trim($("#newMemo_b").val());
					if(apprMemo == "" || apprMemo == null) {
						alert("请输入审核意见备注！");
						return;
					}
					if(apprMemo.length > 500) {
						alert("输入不能长度不能超过500");
						return;
					}
				} else {
					var apprMemo =  $.trim($("#newMemo_c").val());
					if(apprMemo == "" || apprMemo == null) {
						alert("请输入意见备注！");
						return;
					}
					if(apprMemo.length > 500) {
						alert("输入不能长度不能超过500");
						return;
					}
				}
				var apprMemo =  $.trim($("#apprMemo").val());
				if (apprMemo == "1") {
					$("#status").val("003");
				} else if (apprMemo == "2") {
					$("#status").val("012");
				} else {
					alert("请选择非同意意见");
					return;
				}
				removeDis();
				tasksubmit(event, param.check, form, listId, param.callback);
			};
			if (status == "001" && isGroupAppr != "1") {
				$("#newMemo_c").attr("disabled","disabled");
				$("#newMemo_b").removeAttr("disabled");
				document.getElementById("newMemoTr").style.display = "";
				document.getElementById("newMemoBTr").style.display = "";
				document.getElementById("newMemoCTr").style.display = "none";
				
				dialogParam.buttons["提交组内人审核"] = function(event) {
					var apprMemo =  $.trim($("#newMemo_b").val());
					if(apprMemo == "" || apprMemo == null) {
						alert("请输入审核意见备注！");
						return;
					}
					if(apprMemo.length > 500) {
						alert("输入不能长度不能超过500");
						return;
					}
					var apprMemo =  $.trim($("#apprMemo").val());
					if (apprMemo == "0") {
						var rs = formatterParamFlow(paramFlow,currentNodeId,"");
						if(rs) {
							$("#status").val("001");
							$("#isGroupAppr").val("1");
						} else {
							return;
						}
					} else {
						alert("请选择同意意见");
						return;
					}
					$("#nextHandleDiv").dialog("open");
				};
			}
			dialogParam.buttons["保存"] = function(event) {
				$("#status").val("007");//后台判断保存标志
				tasksubmit(event, param.check, form, listId, param.callback);
			}
		}
    }
    $(form).data("seal", param.seal);

    $(form).validationEngine({
	showOnMouseOver : true,
	validationEventTrigger : "blur",
	promptPosition : "topLeft",
	showArrow : true,
	autoPositionUpdate : true,
	onValidationComplete : function() {
	    return;
	}
    });

    return dialogParam;

};

function removeDis(){
	$("#newMemo").removeAttr("disabled");
	$("#newMemo_b").removeAttr("disabled");
	$("#newMemo_c").removeAttr("disabled");
}

function unlockIdTask(){
	if (lockId != "" && lockId != null) {
		$.ajax({
			type : 'POST',
			data : {
				"bizInfo.id" : lockId
			},
			url : ctx + "/mechseal/task/" + ajaxReqActionName + "_unlockTask.action",
			async : false,
			success : function(data) {
				lockId="";
			}
		});
	}
}

// 必填表单校验:审核人员/会签人员
function judgePassValidation(showMode) {
    if ((showMode & constants.APPR_MODE_LIST_NEXT_HANDLER) != 0) {
		if ($.trim($("#apprPeople").val()) == "") {
		    alert("请选择下一审核人员！");
		    return false;
		}
    }
    if ((showMode & constants.APPR_MODE_LIST_MULTI_HANDLER) != 0
	    || (showMode & constants.APPR_MODE_SELECT_APPR_MODE) != 0) {
		var mode = $('input[name="sealUseTaskForm.multiManagerAppr"]:checked').val();
		if (mode == "multi") {
		    var multiPeo = $("#multiPeople").multiselect("getChecked").map(function() {
			return this.value;
		    }).get();
		    if (!multiPeo || multiPeo.length == 0) {
			alert("请选择会签机构！");
			return false;
		    }
		}
    }
    return true;
};

function tasksubmit(event, url, form, listId, callback, data) {
    data = data ? data() : $(form).serializeForm();
    if ($(form).data("param") && $(form).data("param").beforeSubmit) {
		if (!$(form).data("param").beforeSubmit(data)) {
		    return;
		}
    }

    $(event.target).post(
	    url,
	    data,
	    function(data) {
			if (data.responseMessage.success) {
			    var message = "操作成功";
			    clearVal();
			    if (data.responseMessage.data) {
					if (/^\w{2}$/.test(data.responseMessage.data)) {
					    if (data.responseMessage.data != "FF" && data.responseMessage.data != "F0") {
						message += "："
							+ getTypeName("NodeCode", data.responseMessage.data, "nodeCode", "nodeName");
					    }
					    if (data.responseMessage.data == "11" || data.responseMessage.data == "51"
						    || data.responseMessage.data == "52") {
						alert(getTypeName("NodeCode", data.responseMessage.data, "nodeCode", "nodeName"));
					    }
					}
	
			    }
	
			    if (data.responseMessage.message) {
			    	message += "：" + data.responseMessage.message;
			    }
	
			    $.success(message);
	
			    $(listId).trigger("reloadGrid");
			    $(form).dialog("close");
			    if (callback) {
			    	callback(data);
			    }
			} else {
			    $.error("操作失败: " + data.responseMessage.message);
			}
	    });
};

$.del = function(url, param, callback) {
    if (confirm("是否要删除?")) {
	$.post(url, param, function(data) {
	    if (data.responseMessage.success) {
		$.success("删除成功");
		$("#list").trigger("reloadGrid");
		if (callback) {
		    callback(data);
		}
	    } else {
		$.error("删除失败: " + data.responseMessage.message);
	    }
	});
    }
};

$.fn.fillTask = function(autoId, sealSn, node, title, result, fetchType, lock, url) {
    var _this = this;
    if (title) {
	$(_this).dialog("option", "title", title);
    }
    $(_this).getTask(
	    url,
	    {
			"bizInfo.id" : autoId,
			"id":autoId
	    },
	    function(data) {
	    	var storeId = data.bizInfo.storeId;
	    	$("#status").val(data.bizInfo.status);
	    	$("#storeId").val(null);
	    	$("#isGroupAppr").val(data.bizInfo.isGroupAppr);
		    $("#nowHandleName").val(loginPeople.peopleName);
//		    $("#runSealfuncs").val(data.bizInfo.runSealfunc);
		    $("#runSealfuncs")[0].selectedIndex= data.bizInfo.runSealfunc;
		    $("#fileTypeNames")[0].selectedIndex= sealUseConstants.SealFileType[data.bizInfo.extInfo.fileType];
		    $("#runSealfuncs").attr("disabled","disabled");
		    $("#fileTypeNames").attr("disabled","disabled");
		    $("#id").val(data.bizInfo.id);
		    scanNum = data.bizInfo.scanNum;
			$("#adminApprInfo").form({
			    height : 490,
			    check : $.getContextPath() + "/mechseal/task/" + ajaxReqActionName + "_commitTask.action"
			});
			$(_this).fillForm({
			    bizInfo : data.bizInfo
//			    mechSealInfo:data.mechSealInfo
			});
			$("#seals").empty();
			$.each(data.mechSealInfos,function(i,item){
				showSealsDetail(item.sealId,item.applyNum);
			});
			if ($(_this).data("param") && $(_this).data("param").loadComplete) {
			    $(_this).data("param").loadComplete(data);
			}
			if (data.paramFlow != null) {
				paramFlow = data.paramFlow;
				currentNodeId = data.bizInfo.extInfo.currentNodeId;
				$("#adminApprInfo").dialog("open");
			} else {
				alert("请检查流程配置");
				return;
			} 
	    });

};

function formatterParamFlow(data,nodeId,btnType) {
	var paramFlow = eval('(' + data.flowParam + ')');
	var useSealNode = data.useSealNode;
	var rs = true;
	if (btnType == "final") {
		findUseSealNodeInfo(useSealNode);
	} else {
		var length = 0;
		for (var p in paramFlow) {
			length ++;
		}
		var nowNodeId = nodeId.substring(4);
		if (nowNodeId < length) {
			nowNodeId ++;
			var nodeId = "node"+nowNodeId;
			$.each(paramFlow, function(i, d) {
				if (nodeId == i) {
					var roleGroupSid = d.split("-")[1];
					var orgType = d.split("-")[0];
					$("#currentOrgType").val(orgType)
					$("#currentNodeId").val(nodeId)
					$("#roleGroupSid").val(roleGroupSid);
					$("#roleGroupName").val(roleGroupMap.get(roleGroupSid));
					rs = findPeopleInfo(orgType,roleGroupSid,"0");
					
				}
			});
		} else {
			findUseSealNodeInfo(useSealNode);
		}
	}
	return rs;
}

function findUseSealNodeInfo(useSealNode) {
	$("#status").val("004");
	var roleGroupSid = useSealNode.split("-")[1];
	var orgType = useSealNode.split("-")[0];
	$("#currentOrgType").val(orgType)
	$("#currentNodeId").val("useSealNode")
	$("#roleGroupSid").val(roleGroupSid);
	$("#roleGroupName").val(roleGroupMap.get(roleGroupSid));
}

function clearVal() {
	paramFlow = null;
	currentNodeId = null;
	$("#btnUpload").attr("disabled", false);
    $("#nextHandleDiv").dialog("close")
    $("#storeId").val("");
    $("#apprStoreId").val("");
}
$(function() {
    $(":submit,:button").button();
});

function showDiv(id, inputname){
	$("input[name='" + inputname + "']").removeAttr("disabled");
	$("#" + id).show();
}

function hideDiv(id, inputname){
	$("input[name='" + inputname + "']").attr("disabled", "disabled");
	$("#" + id).hide();
}

$("#docPreview").dialog({
	autoOpen : false,
	resizable : false,
	width : $(window).width() / 2,
	modal : true,
	position : {
		at : "center"
	},
	close : function() {
		initTaskList();
		$("#docPreview").html("");
	}
});

function showDocDetail(scanNum){
	var url = ctx + "/sealusetask/create/sealUseTask_queryDocDetail.action";
	var param = {"scanNum":scanNum};
	var result = tool.ajaxRequest(url, param);
	if(result.response.webResponseJson.state == "normal"){
		var files = result.response.webResponseJson.data;
		var html = "";
		for(var i = 0; i < files.length; i ++) {
			html += "<a href='"+files[i].filePath+"' title='"+files[i].fileDesc+"'>"+files[i].fileDesc+"</a><br/>";
		}
		$('#docword').html(html);
	}else{
		var message = result.response.webResponseJson.message;
		alert(message);
	}
}

var roleGroupMap = new Map();
function initAllRoleGroups () {
	try {
		var url = ctx + "/gss/paramflow/gssParamFlow_queryAllRoleGroupInfo.action";
		var param = {};
		var data = tool.ajaxRequest(url,param);
		var roleGroupData = null;
		if (data.success) {
			if(data.response.responseMessage.success && data.response.responseMessage.data && data.response.responseMessage.data != null){
				roleGroupData = data.response.responseMessage.data;
				if (roleGroupData && roleGroupData != null && roleGroupData.length > 0) {
					$(roleGroupData).each(
							function(i, value) {
								var roleGroup = value.split(",");
								var roleGroupSid = roleGroup[0];
								var roleGroupName = roleGroup[1];
								roleGroupMap.put(roleGroupSid,roleGroupName);
							});
				}
			}
		} else {
			alert(data.response);
		}
	} catch (e) {
		return e.message;
	}
}

function findPeopleInfo (orgType,roleGroupSid,type) {
	var result = true;
	try {
		var url = ctx + "/ext/po/extPersonnelAction_findPersonnelByOrgAndRoleGroup.action";
		var param = {"orgType":orgType,"roleGroupSid":roleGroupSid};
		var data = tool.ajaxRequest(url,param);
		var option = "<option value=''>--请选择--</option>";
		if (data.success) {
			if (data.response.personnels != null && data.response.personnels.length > 0) {
				var personnels = data.response.personnels;
				$(personnels).each(
					function(i,value) {
						option += "<option value='"+value.sid+"'>"+value.personnelName+"</option>";
					}
				);
				$("#nextHandlerSid").html(option);
			} else {
				$("#paperType option:first").prop("selected", 'selected');
				alert("下一节点未配置相关人员");
				result = false;
			}
		} else {
			alert(data.response.responseMessage.message);
			result = false;
		}
		return result;
	} catch (e) {
		return e.message;
	}
}

function changePeopleTr() {
	var memo = $("#apprMemo").val();
	if(memo == "0") {
		memo = "同意";
		document.getElementById("nextPeopleTr").style.display = "";
	} else if(memo == "1") {
		memo = "不同意";
		document.getElementById("nextPeopleTr").style.display = "none";
	} else if(memo == "2") {
		memo = "退回客户经理";
		document.getElementById("nextPeopleTr").style.display = "none";
	} else {
		document.getElementById("nextPeopleTr").style.display = "none";
	}
	$("#memo").val(memo);
}

function uploadFile() {
	fileUploadHandler.active()
}

function initDialogAndFileUpload() {
	fileUploadHandler.init(basePath, "body-wrapper", function(r) {
		if (r.storeId == null) {
			alert("未上传任何文件！");
			return;
		}
		$("#storeId").val(r.storeId);
		$("#btnUpload").attr("disabled", "disabled");
		var isGroupAppr = $("#isGroupAppr").val();
		if(isGroupAppr == "0") {
		 	$("#apprStoreId").val(r.storeId);
		} else if(isGroupAppr == "1") {
			$("#groupApprStoreId").val(r.storeId);
		} else {
			$("#storeId").val(r.storeId);
		}
	});
	
	$("#nextHandleDiv").dialog({
		autoOpen : false,
		resizable : false,
		width : $(window).width() / 2,
		modal : true,
		position : {
			at : "center"
		},
		buttons:{
			"确定": function(event) {
				var nextHandlerSid = $("#nextHandlerSid").val();
				if("" == nextHandlerSid) {
					alert("请选择审核人");
					return;
				}
				
				$("#apprPeopleSid").val(nextHandlerSid);
				removeDis();
				tasksubmit(event, _param.check, _form, _listId, _param.callback);
			}
		},
		close : function() {
		}
	});
}

var sealMap = new Map();
function initSeals(sealId){
	//清空下拉列表
	var url = ctx + "/mechseal/sealinstall/sealInstallConfigAction_findInstallSealByAutoId.action";
	var param = {"autoId":sealId};
	var result = tool.ajaxRequest(url, param);
	if(result.success){
		return result.response.sealInstallConfig;
	}else{
		var message = result.response.responseMessage.message;
		alert(message);
	}
}

function showSealsDetail(sealId,sealApplyNum) {
	var sealConfig = initSeals(sealId);
	var sealName = "印章不存在";
	if(sealConfig != null) {
		sealName = sealConfig.sealTypeName + "(" + sealConfig.deviceNum + ")";
	}
	var str = "<div id='divSealNum'><input disabled='disabled' value='"+sealName+"' style='width:300px;'/><input maxlength='10' style='width:50px;' disabled='disabled' value='"+sealApplyNum+"' /></div>";
	$("#seals").append(str);
}