/**
 * 创建于:2015-5-07<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 资料采集JS<br>
 * 
 * @author 孙强
 * @version 1.0.0
 */

var has_open_camera_divice = false; // 摄像头打开标识

var wait_open_camera_count = 0; // 等待摄像头打开次数

var image_file_path = top.yzjgssRootPath + "\\yzjgss\\resources\\3x\\img\\"; // 凭证拍照图片本地暂存路径

var img_path = ""; // 凭证图片全路径

var capture_success = false; // 拍照结果

/**
 * 本批次采集的用印图像
 */
var imgArr = new Array();
/**
 * 当前图像序号
 */
var showCurrent = -1;

var storeId = "";

function File(path, num, mediatype, optFlag) {
	// 本地绝对路径
	this.path = path;
	// 文件序号
	this.num = num;
	// 文件标记
	this.mediatype = mediatype;
	// 是否盖章
	this.optFlag = optFlag;
};

$(document).ready(function() {

	fileUploadHandler.init(basePath, "body-wrapper", function(r) {
		if (r.storeId == null) {
			alert("未上传任何文件！");
			return;
		}
		$("#btnUpload").attr("disabled", "disabled");
		storeId = r.storeId;
	});

	if (orgType == 2) {
		// 申请机构为支行
		$("#managerApprDiv").hide();
		$("#multiManagerDiv").hide();
		$("#multiViceApprDiv").hide();
		$("#multiViceDiv").hide();
		$("#viceApprDiv").hide();
		$("#presidentApprDiv").hide();
		listBranchLeader();
	} else {
		// 申请机构为部门
		$("#nextHandlerDiv").hide();
	}

	$("input:radio[name='isMultiManagerAppr']").change(function() {
		var mode = $(this).val();
		if (mode == "no") {
			$("#multiManagerDiv").hide();
			$("#peoplecodeMsg").text("");
		} else {
			$("#multiManagerDiv").show();
			listMultiManager();
		}
	});

	$("input:radio[name='isMultiVicePresidentAppr']").change(function() {
		var mode = $(this).val();
		if (mode == "no") {
			$("#multiViceDiv").hide();
			$("#peoplecodeMsg").text("");
		} else {
			$("#multiViceDiv").show();
			listMultiVicePresident();
		}
	});

	$("#multiManagerDiv").hide();
	$("#multiViceDiv").hide();
	initWaitingDialog();

	selectUtils.initTradeCode("paperType", 1);
	// listManagerRole();
	// 初始化拍照控件
	if (!ocxObject.initOcx(ocxObject.OCX_XUSBVideo, document.body, ctx + '/activex/api/', 'run')) {
		alert("初始化拍照控件失败");
		return;
	}

	// 初始化日志控件
	if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, ctx + '/activex/api/', 'run')) {
		alert("初始化日志控件失败");
		return;
	}

	// 初始化文件上传控件
//	if (!ocxObject.initOcx(ocxObject.httpInterface, document.body, ctx + '/activex/api/', 'run')) {
//		alert("初始化文件上传控件失败");
//		return;
//	}

	// 初始化印控机控件
	if (!ocxObject.initOcx(ocxObject.OCX_MachineOrder, document.body, ctx + '/activex/api/', 'run')) {
		alert("初始化印控机控件失败");
		return;
	}

	// 初始化图片处理控件
	if (!ocxObject.initOcx(ocxObject.OCX_ImgHelper, document.body, ctx + '/activex/api/', 'run')) {
		alert("初始化图片处理控件失败");
		return;
	}

	// 初始化文件上传控件
//	if (!ocxObject.initOcx(ocxObject.OCX_Libcurl, document.body, ctx + '/activex/api/', 'run')) {
//		alert("初始化文件上传控件失败");
//		return;
//	}

	// 延时设备初始化
	showWaitingDialog("设备初始化中，请稍候...");
	window.setTimeout(function() {
		// openCameraDivice();
		hideWaitingDialog();
	}, 500);

});

/**
 * 加载经理审批列表
 */
function listBranchLeader() {
	var url = ctx + "/mechseal/task/adminHRXJApplyTaskAction_listBranchLeader.action";
	var data = tool.ajaxRequest(url, '');
	if (data.success) {
		var leaderList = data.response.leaderList;
		if (orgType == 2 && leaderList.length == 0) {
			alert("请先配置支行领导");
			$("#btnSubmit").attr("disabled", "disabled");
		}
		$.each(leaderList,
				function(index, leader) {
					$("#apprPeopleCode").append(
							"<option value='" + leader.sid + "'>" + leader.peopleName + "（" + leader.peopleCode
									+ "）</option>");
				});
	}
};

/**
 * 加载会签经理人员列表
 */
function listMultiManager() {
	$("#multiPeople").empty();
	var url = ctx + "/mechseal/task/adminHRXJApplyTaskAction_listMultiManager.action";
	var data = tool.ajaxRequest(url, '');
	if (data.success) {
		var managerRoleList = data.response.multiManagerList;
		$.each(managerRoleList,
				function(index, manager) {
					$("#multiManager").append(
							"<option value='" + manager.sid + "'>" + manager.peopleName + "（" + manager.orgName
									+ "）</option>");
				});
	}
	$("#multiManager").multiselect({
		noneSelectedText : "请选择",
		checkAllText : "全选",
		uncheckAllText : '全不选',
		selectedList : 4
	});
};

/**
 * 加载会签部门列表
 */
function listMultiVicePresident() {
	$("#multiVicePresident").empty();
	var url = ctx + "/mechseal/task/adminHRXJApplyTaskAction_listMultiVicePresident.action";
	var data = tool.ajaxRequest(url, '');
	if (data.success) {
		var vicePresidentList = data.response.multiVicePresidentList;
		$.each(vicePresidentList, function(index, vicePresident) {
			$("#multiVicePresident").append(
					"<option value='" + vicePresident.sid + "'>" + vicePresident.peopleName + "（"
							+ vicePresident.orgName + "）</option>");
		});
	}
	$("#multiVicePresident").multiselect({
		noneSelectedText : "请选择",
		checkAllText : "全选",
		uncheckAllText : '全不选',
		selectedList : 4
	});
};

/**
 * 打开摄像头
 */
function openCameraDivice() {
	if (!has_open_camera_divice) {
		var openResult = xUSBVideo.openC2400Camera();
		has_open_camera_divice = true;
		if (openResult != 0) {
			var message = xUSBVideo.getErrorMessage(openResult);
			showWaitingDialog(message);
		}
	}
};
/**
 * 关闭摄像头
 */
function closeCameraDivice() {
	xUSBVideo.closeCamera;
	has_open_camera_divice = false;
};

/**
 * 摄像头就绪拍照事件
 */
function deviceReady() {
	// 此timeout是因为纸板关闭后灯光会存在不稳定的情况，在此设置timeout来等待灯光稳定再拍照，可根据具体情况调整timeout时间
	// 如果timeout时间太短，可能会造成第一次用印拍出来的相片色彩异常
	setTimeout(function() {
		has_open_camera_divice = true;
	}, 2000);

	hideWaitingDialog();
};

/**
 * 摄像头设备连接事件
 */
function deviceConnect(nConnectStatus) {
	// TODO
};

function initWaitingDialog() {
	$("#waitingDialog").dialog({
		autoOpen : false,
		resizable : false,
		draggable : false,
		closeOnEscape : false,
		height : 290,
		width : 390,
		modal : true,
		open : function(event, ui) {
			$(".ui-dialog-titlebar").hide();
			$(".ui-dialog-titlebar-close").hide();
		}
	});
};

/**
 * 展示等待界面
 */
function showWaitingDialog(msg) {
	$("#waitingDialog").dialog("open");
	$("#waitingMsg").html(msg);
};

/**
 * 关闭等待界面
 */
function hideWaitingDialog() {
	$("#waitingDialog").dialog("close");
};

/**
 * 采集图像
 */
function collectImg() {
	var paper = $("#paperType").val();
	if ("" == paper) {
		$("#paperTypeMsg").text("*请选择文件类型").css("color", "red");
		return;
	} else {
		$("#paperTypeMsg").text("");
	}

	if (!/^\+?[1-9][0-9]*$/.test($("#applynum").val())) {
		$("#applynumMsg").text("*用印数量必须为大于等于1的数字").css("color", "red");
		return;
	}
	if (parseInt($("#applynum").val()) > 200) {
		$("#applynumMsg").text("*单次提交文件不能超过200").css("color", "red");
		return;
	} else {
		$("#applynumMsg").text("");
	}

	if (!/^\+?[1-9][0-9]*$/.test($("#fileNum").val())) {
		$("#batchNumMsg").text("*申请数量必须为大于等于1的数字").css("color", "red");
		return;
	}
	if (parseInt($("#fileNum").val()) > 200) {
		$("#batchNumMsg").text("*单次提交文件不能超过200").css("color", "red");
		return;
	} else {
		$("#batchNumMsg").text("");
	}

	var peopleCode = $("#apprPeopleCode").val();
	if ("-1" == peopleCode) {
		$("#peoplecodeMsg").text("*请选择经理审批").css("color", "red");
		return;
	} else {
		$("#peoplecodeMsg").text("");
	}

	var mode = $("#modeSelect").children('option:selected').val();
	if (mode == "multi") {
		var value = $("#multiPeople").multiselect("getChecked").map(function() {
			return this.value;
		}).get();
		if (value.length < 1) {
			$("#multiPeopleMsg").text("*请至少选择一名会签经理审批").css("color", "red");
			return;
		} else {
			$("#multiPeopleMsg").text("");
		}
	}

	showImgDiv();
};
/**
 * 显示div
 */
function showImgDiv() {
	// 设置默认图片
	document.getElementById("printpaperImg").src = ctx + "/3x/common/images/voucherImg.png";
	// 图片显示
	document.all.printpaper.style.display = "block";
	// 设置宽度
	document.all.tempPrintPaper.style.width = document.documentElement.scrollWidth;
	// 设置高度
	document.all.tempPrintPaper.style.height = document.documentElement.scrollHeight;
	// 屏蔽右键
	document.oncontextmenu = function() {
		event.returnValue = false;
	};
	$("#beforeBTN").attr("disabled", true);
	$("#afterBTN").attr("disabled", true);
	$("#getPicBTN").attr("disabled", true);
	$("#flag").val(constants.ADMIN_SEAL_USE_FALSE);
};
/**
 * 拍摄图像
 */

function getPicture() {
	Capture();
};
/**
 * 获取图片，并返回图片名称
 * 
 * @param 参数
 * @returns {String}
 */
function Capture() {
	// 时间戳
	var timestamp = Date.parse(new Date());
	img_path = image_file_path + timestamp + ".jpg";
	capture_success = xUSBVideo.captureImage(img_path, "", 0);
	var file = null;
	showCurrent = imgArr.length;
	if (capture_success) {
		// 显示图片
		file = new File(img_path, showCurrent + 1, constants.ADMIN_FILE_APPLY, constants.ADMIN_SEAL_USE_FALSE);
		showFileImg(file.path);
		imgArr[imgArr.length] = file;
		// 补拍按钮
		$("#getPicBTN").attr("disabled", false);
		if (imgArr.length >= 1) {
			if (showCurrent > 0) {
				$("#beforeBTN").attr("disabled", false);
			} else {
				$("#beforeBTN").attr("disabled", true);
			}
			if (showCurrent < imgArr.length - 1) {
				$("#afterBTN").attr("disabled", false);
			} else {
				$("#afterBTN").attr("disabled", true);
			}
			if (imgArr[showCurrent].optFlag == "isSeal") {
				$("#msg").html("←第" + (imgArr[showCurrent].num) + "份文件(用印)");
				$("#flagBTN").attr("disabled", true);
				$("#cancelflagBTN").attr("disabled", false);
			} else {
				$("#msg").html("←第" + (imgArr[showCurrent].num) + "份文件");
				$("#cancelflagBTN").attr("disabled", true);
				$("#flagBTN").attr("disabled", false);
			}

		}
		if (parseInt($.trim($("#fileNum").val())) <= imgArr.length) {
			$("#captureBTN").attr("disabled", true);
		}

	} else {
		alert("拍照失败");
	}
};

/**
 * 图像显示
 * 
 * @param path
 */
function showFileImg(path) {
	$("#printpaperImg").attr("src", path);

	// add by Rickychen 2015-05-31 图片超过屏幕分辨率时改变图片的分辨率
	var img = document.getElementById("printpaperImg");
	img.onload = function() {
		var printImgObj = img;
		var imageRealHeight = $(printImgObj).height();
		var rate = ($(window).height() - 100) / imageRealHeight;
		if (rate < 1) {
			// printImgObj.style.width = parseInt(100 * rate) + "%";
			printImgObj.style.width = "100%";
		}
	};
};

/**
 * 补拍图像
 */
function repeatPicture() {
	// 时间戳
	var timestamp = Date.parse(new Date());
	img_path = image_file_path + timestamp + ".jpg";
	capture_success = xUSBVideo.captureImage(img_path, "", 0);
	if (capture_success) {
		if (imgArr.length == 0) {
			showCurrent = 0;
			var vfile = new File(img_path, showCurrent + 1, constants.ADMIN_FILE_APPLY, null);
			imgArr[imgArr.length] = vfile;
		} else {
			imgArr[showCurrent].path = img_path;
		}
		showFileImg(img_path);
		if (parseInt($.trim($("#fileNum").val())) <= imgArr.length) {
			$("#captureBTN").attr("disabled", true);
		}
	} else {
		alert("拍照失败");
	}
};

/**
 * 前一张
 */
function beforeOne() {
	$("#getPicBTN").attr("disabled", true);
	var file_ = imgArr[showCurrent - 1];
	if (!file_)
		return;
	showCurrent--;
	showFileImg(file_.path);
	$("#beforeBTN").attr("disabled", true);
	$("#afterBTN").attr("disabled", true);
	setTimeout(function() {
		$("#getPicBTN").attr("disabled", false);
		if (showCurrent < 1) {
			$("#beforeBTN").attr("disabled", true);
			$("#afterBTN").attr("disabled", false);
		}
		if (showCurrent >= imgArr.length - 1) {
			$("#beforeBTN").attr("disabled", false);
			$("#afterBTN").attr("disabled", true);
		}
		if (imgArr.length - 1 > showCurrent && showCurrent >= 1) {
			$("#beforeBTN").attr("disabled", false);
			$("#afterBTN").attr("disabled", false);
		}
		if (imgArr.length == parseInt($.trim($("#fileNum").val()))) {
			$("#captureBTN").attr("disabled", true);
		} else {
			$("#captureBTN").attr("disabled", false);
		}
		if (imgArr[showCurrent].optFlag == "isSeal") {
			$("#msg").html("←第" + (imgArr[showCurrent].num) + "份文件(用印)");
			$("#flagBTN").attr("disabled", true);
			$("#cancelflagBTN").attr("disabled", false);
		} else {
			$("#msg").html("←第" + (imgArr[showCurrent].num) + "份文件");
			$("#cancelflagBTN").attr("disabled", true);
			$("#flagBTN").attr("disabled", false);
		}

	}, 500);
};

/**
 * 后一张
 */
function afterOne() {
	$("#getPicBTN").attr("disabled", true);
	var file_ = imgArr[showCurrent + 1];
	if (!file_)
		return;
	showCurrent++;
	showFileImg(file_.path);
	$("#beforeBTN").attr("disabled", true);
	$("#afterBTN").attr("disabled", true);
	// $("#getPicBTN").attr("disabled",true);
	setTimeout(function() {
		$("#getPicBTN").attr("disabled", false);
		if (showCurrent < 1) {
			$("#beforeBTN").attr("disabled", true);
			$("#afterBTN").attr("disabled", false);
		}
		if (showCurrent >= imgArr.length - 1) {
			$("#beforeBTN").attr("disabled", false);
			$("#afterBTN").attr("disabled", true);
		}
		if (imgArr.length - 1 > showCurrent && showCurrent >= 1) {
			$("#beforeBTN").attr("disabled", false);
			$("#afterBTN").attr("disabled", false);
		}
		if (imgArr.length == parseInt($.trim($("#fileNum").val()))) {
			$("#captureBTN").attr("disabled", true);
		} else {
			$("#captureBTN").attr("disabled", false);
		}
		if (imgArr[showCurrent].optFlag == "isSeal") {
			$("#msg").html("←第" + (imgArr[showCurrent].num) + "份文件(用印)");
			$("#flagBTN").attr("disabled", true);
			$("#cancelflagBTN").attr("disabled", false);
		} else {
			$("#msg").html("←第" + (imgArr[showCurrent].num) + "份文件");
			$("#cancelflagBTN").attr("disabled", true);
			$("#flagBTN").attr("disabled", false);
		}

	}, 500);
};

/**
 * 标记用印
 */
function optFlag() {
	imgArr[showCurrent].optFlag = constants.ADMIN_SEAL_USE_TRUE;
	$("#flagBTN").attr("disabled", true);
	$("#cancelflagBTN").attr("disabled", false);
};

function cancelFlag() {
	imgArr[showCurrent].optFlag = constants.ADMIN_SEAL_USE_FALSE;
	$("#cancelflagBTN").attr("disabled", true);
	$("#flagBTN").attr("disabled", false);
};

/**
 * 提交申请
 */
function submitForm() {
	// if (parseInt($("#fileNum").val()) > imgArr.length) {
	// alert("图像未采集完毕,请先采集完成");
	// return;
	// }
	// if (!confirm("是否检查完毕所有采集文件图像并确定上传?")) {
	// return;
	// }
	// 第一次上传图片路径
	// var imgPath_1 = imgArr[0].path;
	// var imgParam_1 = {
	// "mediatype" : imgArr[0].mediatype,
	// "optFlag" : imgArr[0].optFlag
	// };
	// // 上传图片
	// storeId = fileStore.uploadFile(imgPath_1, imgParam_1);
	// // 循环上传
	// for ( var i = 1; i < imgArr.length; i++) {
	// var imgPath = imgArr[i].path;
	// var imgParam = {
	// "mediatype" : imgArr[i].mediatype,
	// "optFlag" : imgArr[i].optFlag
	// };
	// // 上传图片
	// fileStore.appendFile(imgPath, imgParam, storeId);
	//
	// }

	if (storeId == "") {
		alert("请上传文件");
		return;
	}
	var multiManager = $("#multiManager").multiselect("getChecked").map(function() {
		return this.value;
	}).get();
	var multiVicePresident = $("#multiVicePresident").multiselect("getChecked").map(function() {
		return this.value;
	}).get();
	// 提交form表单
	var param = {
		"bizInfo.storeId" : storeId,
		"bizInfo.tradeCode" : $("#paperType").val(),
		"bizInfo.tradeCodeName" : $("#paperType option:selected").text(),
		"bizInfo.title" : $("#title").val(),
		"bizInfo.materialName" : $("#materialName").val(),
		"bizInfo.fileNum" : $("#fileNum").val(),
		"bizInfo.applyNum" : $("#applynum").val(),
		"bizInfo.moduleName" : $("#moduleName").val(),
		"apprPeopleCode" : $("#apprPeopleCode").val(),
		"isMultiManagerAppr" : $("input[name='isMultiManagerAppr']:checked").val(),
		"multiManager" : multiManager.toString(),
		"isMultiVicePresidentAppr" : $("input[name='isMultiVicePresidentAppr']:checked").val(),
		"multiVicePresident" : multiVicePresident.toString(),
		"isVicePresidentAppr" : $("input[name='isVicePresidentAppr']:checked").val(),
		"isPresidentAppr" : $("input[name='isPresidentAppr']:checked").val()
	};
	var url = ctx + "/mechseal/task/adminHRXJApplyTaskAction_createTask.action?processDefKey=GSS_ADMIN_HRXJ";
	var data = tool.ajaxRequest(url, param);
	if (data.success) {
		if (data.response.responseMessage.success) {
			alert("提交申请成功");
			collectExits();
		} else {
			alert(data.response.responseMessage.message);
		}

	} else {
		alert("无响应");
	}
};

/**
 * 退出采集
 */
function collectExits() {
	$("#msg").html("");
	showCurrent = -1;
	imgArr = new Array();
	storeId = "";
	$("#captureBTN").attr("disabled", false);
	$("#beforeBTN").attr("disabled", true);
	$("#afterBTN").attr("disabled", true);
	$("#getPicBTN").attr("disabled", true);
	$("#flag").val("");
	// 隐藏div
	document.all.printpaper.style.display = "none";
	document.getElementById("printpaperImg").src = ctx + "/3x/common/images/voucherImg.png";
	// 取消右键屏蔽
	document.oncontextmenu = function() {
		event.returnValue = true;
	};
	$("#title").val("");
	$("#applynum").val("");
	$("#fileNum").val("");
};

/**
 * 非空检查
 * 
 * @param value
 * @returns {Boolean}
 */
function isNull(value) {
	if (value == null || value == "undefined" || value == "") {
		return true;
	}
	return false;
};

/**
 * 选着图片
 */
function spinR() {
	var file = imgArr[showCurrent];
	var attr = file.path.split(".");
	var filename = attr[0];
	filepath_ = filename + "_" + ".jpg";
	imghelper.rotateImage(file.path, filepath_, 90);
	file.path = filepath_;
	showFileImg(file.path);
};

function spinL() {
	var file = imgArr[showCurrent];
	var attr = file.path.split(".");
	var filename = attr[0];
	filepath_ = filename + "_" + ".jpg";
	imghelper.rotateImage(file.path, filepath_, -90);
	file.path = filepath_;
	showFileImg(file.path);
};

function uploadImg() {
	fileUploadHandler.active();
}