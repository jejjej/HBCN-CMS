/**
 * 创建于:2016-10-31<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 印章检查<br>
 * 
 * @author lxy
 * @version 1.0.0
 */

var machine_num;
var useseal_count = 0;
var allCount=0;//印章检查总计盖章次数
var lastPositionInt = 1;
var ifNotException = true;

var chipSoftVersionTag = 0;//主板备板标记 0主板 1备版
var sparePartsNo = "G3600200";

//盖章坐标
var sealPositions = [["","",""],["540,220","560,220","580,220"],["390,220","410,220","430,220"],["240,220","260,220","280,220"],["540,400","560,400","580,400"],["390,400","410,400","430,400"],["240,400","260,400","280,400"]];

var showAlert = true;
var processWait = 100;// 进度条每隔多久进行一次递增（单位毫秒）
var processStepSize = 10; // 进度条每次递增多少像素(此变量暂时没用上)
var processTimeOut = 10000; // 进度条超时时间(单位毫秒)
// 使用的摄像头分辨率常数
var CAMERA_RES_WIDTH = 2048;
var CAMERA_RES_HEIGHT = 1536;

// 凭证图像
var use_cut_img = true;
var src_img_path, cut_img_path;
var big_pic_width = 0, big_pic_height = 0;
var small_pic_width = 0, small_pic_height = 0;
var display_pic_width = 0, display_pic_height = 0;

$().ready(
		function() {
			$(":button").button();
			// 初始化控件
			var ret = ocxbase_messageHandler.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			ret = ocxbase_fileStore.initOcx(basePath);
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			ret = ocxbase_xusbVideo.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};
			ret = ocxbase_sealMachine.initOcx();
			if (!ret.success) {
				ocxbase_messageHandler.showTipMessage(ret.data);
				return;
			};

		    
			// 初始化设备
			ocxbase_messageHandler.showTipMessage("设备初始化中，请稍候...");
			
			var queryurl = ctx + "/3xbase/useSealCheckErrorAction_findErrorRecord.action";
			var dealurl = ctx + "/3xbase/useSealCheckErrorAction_updateErrorRecord.action";
			ocxbase_exceptionLogHandler.setExceptionData(queryurl, null, dealurl, null);
			
			window.setTimeout(function() {
				var connResult = ocxbase_machineAndCameraConnProxy.connect(machineReady);
				if (!connResult.success) {
					ocxbase_messageHandler.dealErrorMssage(connResult.data);
				}
			}, 500);
			
			window.setTimeout(function() {
				var initMachResult = ocxbase_sealMachine.initMachineForTakeSeal();
			    if (initMachResult.success === false) {
			    	ocxbase_messageHandler.showTipMessage(initMachResult.data+"...");
			    	return;
			    }
			    if(initMachResult.data.substr(0,8) == sparePartsNo){
			    	chipSoftVersionTag = 1;
			    	ocxbase_messageHandler.showTipMessage("印章检查不能使用设备紧急接口，请更换接口...");
			    }
			}, 500);
		});

/**
 * 现场人员对检查审批
 */
function localApproval() {
	var operAuth = new top.OperAuth();
	operAuth.operType = "sealCheck"; // 权限 (action-auth.xml)
	operAuth.authSuccess = function(peopleCode) {
		if (!tool.isNull(peopleCode)) {
			appr_people_code = peopleCode;
			$("#checkPeopleCode").val(peopleCode);
		    var param = {
		    		"gssSealCheckInfo.checkPeopleCode" : peopleCode,
		    		"gssSealCheckInfo.autoId" : $("#autoId").val()
		    	    };
		    	    var url = ctx + "/mech/sealcheck/sealCheckAction_checkandUpdateSealCheckPeople.action";
		    	    var data = tool.ajaxRequest(url, param);
		    	    if (data.success) {
		    	    	var res = data.response.responseMessage.data;
		    	    	if(res=='1'){
	    					
	    					document.getElementById("authResButton").disabled = "true";
	    					var state;
	    					if(document.getElementById("sealCheckPass").checked){
	    						state = '1';
	    					}else{
	    						state = '0';
	    					}
	    					var checkRemark = document.getElementById("checkRemark");
	    					var checkRemarkVal = checkRemark.value;
	    					$.ajax({
	    						type : "post",
	    						url : ctx+"/mech/sealcheck/sealCheckAction_updateSealCheckStautsAndRemard.action",
	    						data : {
	    							"gssSealCheckInfo.checkPeopleCode" : $("#checkPeopleCode").val(),
	    							"gssSealCheckInfo.autoId" : $("#autoId").val(),
	    							"gssSealCheckInfo.state" : state,
	    							"gssSealCheckInfo.checkRemark" : checkRemarkVal
	    						},
	    						async : false,
	    						success : function(result) {
	    							if (result == "true") {
	    			    	    		ocxbase_messageHandler.showTipMessage("印章检查结果录入及授权完成，本次印章检查结束...");
	    			    				window.setTimeout(function() {
	    			    					$("#localApprovalBtnTd").css('display', 'none');
	    			    					ocxbase_messageHandler.hideWaittingDialog();
	    			    					closeOperAuthRes();
	    			    				}, 3000);
	    							} else {
	    			    	    		ocxbase_messageHandler.showTipMessage("印章检查结果录入失败，请重新录入...");
	    			    				window.setTimeout(function() {
	    			    					ocxbase_messageHandler.hideWaittingDialog();
	    			    				}, 500);
	    								document.getElementById("authButton").disabled = "";
	    							}
	    						}
	    					});
		    				window.setTimeout(function() {
		    					ocxbase_messageHandler.hideWaittingDialog();
		    				}, 3000);
		    	    	}else if(res=='0'){
		    	    		ocxbase_messageHandler.showTipMessage("授权人机构与当前印控机机构不一致，请重新授权...");
		    				window.setTimeout(function() {
		    					ocxbase_messageHandler.hideWaittingDialog();
		    				}, 3000);
		    	    	}else{
		    	    		ocxbase_messageHandler.showTipMessage("印控机表查询异常...");
		    				window.setTimeout(function() {
		    					ocxbase_messageHandler.hideWaittingDialog();
		    				}, 3000);
		    	    	}
		    	    }else{
		    	    	ocxbase_messageHandler.dealErrorMssage("验证授权人机构与当前印控机机构是否一致时异常，请联系技术人员...");
//		    	    	return "";
		    	    }
//			openElecLock()
		} else {
			alert("前台授权方式配置错误，请联系技术人员!");
		}
	};
	operAuth.authCancel = function() {
		// alert("用印申请未通过现场审核");
	};
	operAuth.auth();
};

/**
 * 打开授权框
 */
function operAuthResInput() {
	var bgDiv = document.createElement("div");
	bgDiv.setAttribute('id', 'authRes_bgDiv');
	bgDiv.style.position = "absolute";
	bgDiv.style.top = "0px";
	bgDiv.style.left = "0px";
	bgDiv.style.width = "100%";
	bgDiv.style.height = "100%";
	bgDiv.style.background = "#777";
	bgDiv.style.zIndex = "12";
	bgDiv.style.filter = "progid:DXImageTransform.Microsoft.Alpha(style=3,opacity=25,finishOpacity=75";
	bgDiv.style.opacity = "0.6";
	document.body.appendChild(bgDiv);
	
	localApproval();
//	openAuthResPage();
}

/**
 * 打开印章检查结果录入页面
 */
function openAuthResPage() {
	var strTitle = "印章检查结果录入";
	var msgw, msgh, bordercolor;
	msgw = 400;// 提示窗口的宽度
	msgh = 200;// 提示窗口的高度
	titleheight = 25; // 提示窗口标题高度
	bordercolor = "#66cccc";// 提示窗口的边框颜色
	titlecolor = "#99CCFF";// 提示窗口的标题颜色
	var authResDiv = document.createElement("div");
	authResDiv.setAttribute("id", "authResDiv");
	authResDiv.setAttribute("align", "center");
	authResDiv.style.background = "white";
	// authDiv.style.border = "1px solid ";
	authResDiv.style.position = "absolute";
	authResDiv.style.left = "55%";
	authResDiv.style.top = "50%";
	authResDiv.style.font = "12px/1.6em Verdana, Geneva, Arial, Helvetica, sans-serif";
	authResDiv.style.marginLeft = "-225px";
	authResDiv.style.marginTop = -75 + document.documentElement.scrollTop + "px";
	authResDiv.style.width = msgw + "px";
	authResDiv.style.height = msgh + "px";
	authResDiv.style.textAlign = "center";
	authResDiv.style.lineHeight = "25px";
	authResDiv.style.zIndex = "13";
	var title = document.createElement("h4");
	title.setAttribute("id", "authResTitle");
	title.setAttribute("align", "right");
	title.style.margin = "0";
	title.style.padding = "3px";
	title.style.background = bordercolor;
	title.style.filter = "progid:DXImageTransform.Microsoft.Alpha(startX=20, startY=20, finishX=100, finishY=100,style=1,opacity=75,finishOpacity=100);";
	title.style.opacity = "0.75";
	// title.style.border = "1px solid ";// + bordercolor;
	title.style.height = "18px";
	title.style.font = "12px Verdana, Geneva, Arial, Helvetica, sans-serif";
	title.style.color = "white";
	title.style.cursor = "pointer";
	title.title = "点击关闭";
	title.innerHTML = "<table border='0' width='400px' style='vertical-align:top'><tr style='vertical-align:top'><td align='left'><b>"
			+ strTitle
			+ "</b></td><td align='right' id='closeButton_authRes'>关闭&nbsp;</td></tr></table></div>";
	var input = document.createElement("div");
	input.style.marginTop = "6px";
	input.innerHTML = "<table><tr><td width='100' align='center' class='font_red'>检查结果:</td><td width='300' align='center' class='font_red'>"+
		              "<input  type='radio' id='sealCheckPass' checked='checked' name='sealCheckP'  style='outline: none;width: 20px;'/>"+
					  "<a id = 'sealCheckPass' style='cursor:hand;'>通过</a>" +
					  "<input  type='radio'  id='sealCheckNoPass'   name='sealCheckP' style='outline: none; width: 20px;'/>"+
					  "<a id = 'sealCheckNo' style='cursor:hand;'>不通过</a><br> </td>"+
					  "<tr><td width='100' align='center' class='font_red'>检查备注:</td>"+
					  "<td width='300' align='center'><textArea name='checkRemark' id='checkRemark' type='text' style='width:250px;height:100px;' value=''></textArea></td></tr>"+
					  "</table>"+
					  "<input type='button' value='提交' style='margin-left:155px' id='authResButton'/>";

	document.body.appendChild(authResDiv);
	authResDiv.appendChild(title);
	authResDiv.appendChild(input);
	document.getElementById("closeButton_authRes").onclick = function() {
		closeOperAuthRes();
	};
	document.getElementById("authResButton").onclick = function() {
		var checkRemark = document.getElementById("checkRemark");
		var checkRemarkVal = checkRemark.value;
		if (checkRemarkVal == null || checkRemarkVal.length == 0) {
			alert("请输入授权备注");
			checkRemark.focus();
			document.getElementById("authResButton").disabled = "";
			return;
		}else{
			operAuthResInput();
			
		}
	    	    
	};
}
/**
 * 关闭授权框
 */
function closeOperAuthRes() {
	var auth_bgDiv = document.getElementById("authRes_bgDiv");
	var authDiv = document.getElementById("authResDiv");
	document.body.removeChild(authDiv);
	if(auth_bgDiv!=null){
	document.body.removeChild(auth_bgDiv);
	}
}



/**
 * 设备连接结果回调事件
 * 验证本地印章信息与数据库中信息是否一致
 */
function machineReady(ret) {
	var errorMsg = "";
	var flag = true;
	if (ret.success) {
		machine_num = ocxbase_sealMachine.getMachineNum();
		
        $("#deviceNo").val(machine_num);
        $("#machineNum").val(machine_num);
        
        // 检查设备使用机构与检查申请人员机构是否一致
        var param = {
        		"deviceNum" : machine_num
        	    };
        	    var url = ctx + "/mech/sealcheck/sealCheckAction_checkApplyandDeviceOrg.action";
        	    var data = tool.ajaxRequest(url, param);
        	    if (data.success) {
            	 var resStr = new Array();
           	   if(data.response.responseMessage.message!="3" && data.response.responseMessage.data!=null){
           		resStr = data.response.responseMessage.data.split(",");
           		  $("#deviceStyle").val(resStr[0]);
           		  $("#deviceStatus").val(resStr[1]);
          	    if(data.response.responseMessage.message=="1"){

        	    }else if(data.response.responseMessage.message=="0"){
        	    	alert("设备使用机构与检查申请人机构不一致，不能进行印章检查!");
        	    	errorMsg = "设备使用机构与检查申请人机构不一致;";
        	    	 flag = false;
        	    	ocxbase_messageHandler.hideWaittingDialog();
        	    }else if(data.response.responseMessage.message=="2"){
        	    	alert("设备不在启用状态，不能进行印章检查!");
        	    	errorMsg = "设备不在启用状态;";
                    $("#deviceStatus").addClass("red");
        	    	 flag = false;
        	    	ocxbase_messageHandler.hideWaittingDialog();
        	    }
           	 }else{
         	    	alert("设备在系统中未登记，不能进行印章检查!");
        	    	errorMsg = "设备在系统中未登记;";
        	    	$("#deviceStatus").addClass("red");
        	    	flag = false;
        	    	ocxbase_messageHandler.hideWaittingDialog();
           	    }

          }else{
        	    alert("检查设备使用机构与检查申请人员机构是否一致时异常，请联系技术人员!");
        	    errorMsg = "检查设备使用机构与检查申请人员机构是否一致时异常;";
        	    flag = false;
        	    ocxbase_messageHandler.hideWaittingDialog();
        	   }
        
       var sealInfos =  checkSealNoAndCellNo(machine_num);//数据库
       var localSealInfos = new Array();
       localSealInfos = ocxbase_sealMachine.getSealInfo().data.split(",");//本地
       for (i=0;i<localSealInfos.length ;i++ ) {
    	   var infos= new Array();
    	   infos = localSealInfos[i].split(":");
    	   $("#localslotNo"+(infos[0])).val(infos[1]+"号章");
       } 
       
       var dbSealInfos = new Array();
       dbSealInfos = sealInfos.split(",");
       for (i=0;i<dbSealInfos.length ;i++ ) {
    	   var dbinfos= new Array();
    	   dbinfos = dbSealInfos[i].split(":");
    	   $("#dbslotNo"+(dbinfos[0])).val(dbinfos[1]+"号章");
       } 
       
       for(i=1;i<=6 ;i++){
    	   var  dbslotNo = $("#dbslotNo"+(i)).val();
    	   var  localslotNo = $("#localslotNo"+(i)).val();
    	   if(dbslotNo !=localslotNo){
    		   alert("印控机内"+i+"号槽位章号与数据库印章安装表中章号不匹配");
    		   errorMsg = errorMsg+"印控机内"+i+"号槽位章号与数据库印章安装表中章号不匹配;";
   
    		   $(("#dbslotNo"+i)).addClass("red");
    		   $(("#localslotNo"+i)).addClass("red");
    		   
    		   flag = false;
    	   }else if(dbslotNo ==localslotNo && dbslotNo!=""){
    		   $(("#dbslotNo"+i)).addClass("green");
    		   $(("#localslotNo"+i)).addClass("green");
    	   }
       }
  
       $("#checkMemo").val(errorMsg);
       if(errorMsg!=""){
		var updateRet = ocxbase_bizInfoAjax.bizInfo.updateSealCheckResult(ctx
				+ "/mech/sealcheck/sealCheckAction_createSealCheckInfo.action");
		if (!updateRet.success) {
			ocxbase_messageHandler.dealErrorMssage(updateRet.data);
			return;
		}else{
			$("#autoId").val(updateRet.data);
		}
       }
        
	     if(flag && ifNotException){
	    	   $("#applyBtnTd").css('display', "");
	       }else{
		   		setTimeout(function() {
		   			ocxbase_messageHandler.hideWaittingDialog();
		   			}, 500);
	    	  return; 
	       }
	     
	     
		// 初始化用印范围红框顶点数据 sealBoundaryUtil.js
		var boundaryRet = setMaxMinDistance(machine_num);
		if (!boundaryRet) {
			return;
		}
		ocxbase_messageHandler.showTipMessage("初始化成功...");
		setTimeout(function() {
		ocxbase_messageHandler.hideWaittingDialog();
		}, 500);
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}
};

// 打开纸板
function openPaperDoor() {
	$('#applyBtn').attr("disabled", true);

	ocxbase_utils.sealImageHandler.clearSealImage();
	var ret = ocxbase_sealMachine.openPaperDoor(doorCloseCallback);
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	} else {
		if($("#autoId").val()==""){
		ocxbase_messageHandler.showTipMessage("请放入印章检查表...");
		}else{
		ocxbase_messageHandler.showTipMessage("本次印章检查结束，如需重新进行检查请点击左侧'印章检查'菜单重新初始化印控机...");
		}
	}

	// 纸板关闭回调函数
	function doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
		// 释放相应按钮
		if($("#autoId").val()==""){
		$("#commitBtnTd").css('display', "");
		}
		ocxbase_messageHandler.hideWaittingDialog();
	}
};

//通过印控机编号查寻印章安装信息
function checkSealNoAndCellNo(machine_num) {
    var param = {
	"deviceNum" : machine_num
    };
    var url = ctx + "/mech/sealcheck/sealCheckAction_checkSealNoAndCellNo.action";
    var data = tool.ajaxRequest(url, param);
    if (data.success) {
	return data.response.responseMessage.data;
    }else{
    	return "";
    }
};

/**
 * 印章检查过程处理<br>
 * 
 * @param state：'start'、'end'
 * @param useSealSuccess：true/false(非用印结束时可传入null)
 * @param useSealErrorMsg：用印异常信息(非用印结束时可传入null)
 */
function dealUseSealProcess(state, useSealSuccess, useSealErrorMsg) {
	var srcImgPath, cutImgPath, transImagePath;
	var ret = ocxbase_xusbVideo.captureImage(false, state);
	if (ret.success) {
		srcImgPath = ret.data.srcImagePath;
		cutImgPath = ret.data.cutImagePath;
		transImagePath = ret.data.transImagePath;
		src_img_path = srcImgPath;
		cut_img_path = cutImgPath;
		// 显示凭证图像
//		document.getElementById("voucherImg").src = transImagePath;
	} else {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
		return;
	}

	if ("start" == state) {
		// 上传用印前凭证图像
		var uploadRet;
		if (use_cut_img) {
			uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cut_img_path, "add");
			
		} else {
			uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(src_img_path, "add");
		}
		
		//创建印章检查表
		var createRet = ocxbase_bizInfoAjax.bizInfo.updateSealCheckResult(ctx
				+ "/mech/sealcheck/sealCheckAction_createSealCheckInfo.action");
		if (!createRet.success) {
			ocxbase_messageHandler.dealErrorMssage(createRet.data);
			return;
		}else{
			$("#autoId").val(createRet.data);
		}
		
		if (!uploadRet.success) {
			ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
			return;
		}


	} else if ("end" == state) {
		var uploadRet = ocxbase_bizInfoAjax.storeInfo.uploadVoucherImg(cutImgPath, "append");
		if (!uploadRet.success) {
			ocxbase_messageHandler.dealErrorMssage(uploadRet.data);
			return;
		}
		//更新图片
		var appendRet = ocxbase_bizInfoAjax.bizInfo.updateSealCheckResult(ctx
				+ "/mech/sealcheck/sealCheckAction_updateSealCheckInfoForImg.action");
		if (!appendRet.success) {
			ocxbase_messageHandler.dealErrorMssage(appendRet.data);
			return;
		}else{
			$("#autoId").val(appendRet.data);
		}
		
		if (useSealSuccess) {
			useSealCompletedOpenPaperDoor();
//			ocxbase_messageHandler.showTipMessage("印章检查结束，请取出印章检查表并关闭纸板并对此次印章检查授权...");
			 $("#commitBtnTd").css('display', "none");
		} else {
			ocxbase_messageHandler.dealErrorMssage(useSealErrorMsg);
			return;
		}
	}

	$('#applyBtn').attr("disabled", false);
};
/**
 * 转换坐标格式
 * @param xPosition
 * @param yPosition
 * @returns {Array}
 */
function dealPosition(xPosition,yPosition){
	// 计算盖章坐标
	// 用原图还是裁剪图片
	var imgWidth = big_pic_width;
	var imgHeight = big_pic_height;
	if (use_cut_img) {
		imgWidth = small_pic_width;
		imgHeight = small_pic_height;
	}
	// 用印裁剪图片并裁剪成功时需计算在原图中的坐标
	var useSealXpos = multiply(xPosition / 100, imgWidth);
	var useSealYpos = multiply(yPosition / 100, imgHeight);
	if (!ocxbase_xusbVideo.imageIs2048_1536(imgWidth, imgHeight)) {
		var ret = ocxbase_xusbVideo.getLastCutInSrcPosition(useSealXpos, useSealXpos);
		if (ret.success) {
			useSealXpos = ret.data.x;
			useSealYpos = ret.data.y;
		} else {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
	}
	return new Array(useSealXpos,useSealYpos);
}

//印章检查
function checkSeal(){

	ocxbase_messageHandler.showTipMessage("准备开始印章检查...");

	// 隐藏切换图片按钮
	$("#switchVoucherImageId").css('display', 'none');

	// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
	setTimeout(function() {
		dealUseSealProcess("start", true, "");
	}, 500);


	// 是否盖骑缝章
	var isAcrossPageSeal = false;
	var useSealPattern = $("#useSealPattern").val();
	if (useSealPattern == "2") {
		isAcrossPageSeal = true;
	}

	// 计算盖章角度
	var angle;
	var cutAngle = ocxbase_xusbVideo.getLastCutImageAngle();
	if (cutAngle.success) {
		angle = cutAngle.data + ocxbase_utils.sealImageHandler.getSealAngle();
		angle = (angle + 360) % 360;
	} else {
		ocxbase_messageHandler.dealErrorMssage(cutAngle.data);
		return;
	}
	
	
	ocxbase_messageHandler.showTipMessage("正在进行印章检查...");
	
    for(i=1;i<sealPositions.length;i++){//计算总盖章次数
    	if(hasSealInTheMachineSealPos(i)){
    		allCount = allCount+3;
    	}
    }


    
	// 开始用印
	var result = {};
	result.code = "1001";
    startSeal(result);
    
	
};

var initPosition = {
		pos1:{x0:470,y0:590,x1:530,y1:590,x2:590,y2:590},
		pos2:{x0:1060,y0:590,x1:1120,y1:590,x2:1180,y2:590},
		pos3:{x0:1520,y0:590,x1:1580,y1:590,x2:1640,y2:590},
		pos4:{x0:470,y0:1100,x1:530,y1:1100,x2:590,y2:1100},
		pos5:{x0:1060,y0:1100,x1:1120,y1:1100,x2:1180,y2:1100},
		pos6:{x0:1520,y0:1100,x1:1580,y1:1100,x2:1640,y2:1100}
};//2048*1536下取的坐标点




/**
 * 开始盖章
 */
function startSeal(result){
	if(result.code == "1001"){//盖章完成 
		if(useseal_count < allCount){
			if(lastPositionInt<7){
		    	if(hasSealInTheMachineSealPos(lastPositionInt)){
		    		var sealNums = getSealNumBySealPos(lastPositionInt);//查询槽位相应章号
		    		var ifoil = findSealIfOilBySealNum(machine_num,sealNums);//查询数据库是否蘸印油
					if(ifoil=="0"){//不蘸印油
						ocxbase_sealMachine.notSealOil();
					}
						if( useseal_count%3==0){//第一次盖章
//							var XandYPos =  dealPosition(sealPositions[i][0].split(",")[0],sealPositions[i][0].split(",")[1]);
//							alert("槽位："+i+"坐标："+sealPositions[i][0].split(",")[0]+"-"+sealPositions[i][0].split(",")[1]);
							var i800x = parseInt(800*(parseInt(initPosition[(("pos"+lastPositionInt))][("x0")]))/2048);
							var i800y = parseInt(800*(parseInt(initPosition[(("pos"+lastPositionInt))][("y0")]))/2048);
							ocxbase_messageHandler.showTipMessage(sealNums+"号章正在进行第[1]次盖章...");
							ocxbase_sealMachine._startSeal(false, 0, 800-i800x,i800y, sealNums, startSeal);
							useseal_count++;
						}else if(useseal_count%3==1){//第二次盖章
							var i800x = parseInt(800*(parseInt(initPosition[(("pos"+lastPositionInt))][("x1")]))/2048);
							var i800y = parseInt(800*(parseInt(initPosition[(("pos"+lastPositionInt))][("y1")]))/2048);
							ocxbase_messageHandler.showTipMessage(sealNums+"号章正在进行第[2]次盖章...");
							ocxbase_sealMachine._startSeal(false, 0, 800-i800x,i800y, sealNums, startSeal);
							useseal_count++;
						}else if(useseal_count%3==2){//第三次盖章
							var i800x = parseInt(800*(parseInt(initPosition[(("pos"+lastPositionInt))][("x2")]))/2048);
							var i800y = parseInt(800*(parseInt(initPosition[(("pos"+lastPositionInt))][("y2")]))/2048);
							ocxbase_messageHandler.showTipMessage(sealNums+"号章正在进行第[3]次盖章...");
							ocxbase_sealMachine._startSeal(false, 0, 800-i800x,i800y, sealNums, startSeal);
							useseal_count++;
							lastPositionInt++;
						}
		    	}else{
	    			lastPositionInt++;
	    			var result = {};
	    			result.code = "1001";
	    		    
	    		    startSeal(result);
	    		}
		    }

		}else{
			//所有章盖章完成  存储图像
			/**$.ajax({
				type : "post",
				url : ctx+"/mech/sealcheck/sealCheckAction_updateSealCheckImg.action",
				data : {
					"gssSealCheckInfo.autoId" : $("#autoId").val(),
					"gssSealCheckInfo.storeId" : $("#storeId").val()
				},
				async : false,
				success : function(result) {
					if (result == "true") {
	    	    		ocxbase_messageHandler.showTipMessage("印章检查图像存储完成...");
	    				window.setTimeout(function() {
	    					ocxbase_messageHandler.hideWaittingDialog();
	    				}, 500);
					} else {
	    	    		ocxbase_messageHandler.showTipMessage("印章检查图像存储失败，请重新检查...");
	    				window.setTimeout(function() {
	    					ocxbase_messageHandler.hideWaittingDialog();
	    				}, 500);
						document.getElementById("authButton").disabled = "";
					}
				}
			});
			*/
			
			ocxbase_messageHandler.showTipMessage("印章检查成功...");
			// 由于摄像头性能可能存在不佳，造成拍取的图像都是几百上千恩毫秒之前的图像，timeout太短可能图像内容存在机器臂
			var obj;
			var memo;
				var ret = {};
				ret.message = "印章检查成功";
				memo = "印章检查成功";
				obj = ocxbase_utils.genOptResult(true, ret);
				setTimeout(function() {
					dealUseSealProcess("end", obj.success, memo);
					//ocxbase_messageHandler.hideWaittingDialog();
				}, 500);
			} 
	}else{//盖章异常
		OCX_MachineOrder.closeCom();
		var errorMsg = "";
		if(result.code == "9000"){
			ocxbase_messageHandler.showTipMessage("印章检查时通讯异常，请检查设备或设备连接.如需重新进行检查请点击左侧'印章检查'菜单重新初始化印控机...");
			errorMsg = "印章检查盖章时通讯异常，请检查设备或设备连接后重新进行印章检查";
		}else if(result.code == "9421"){
			ocxbase_messageHandler.showTipMessage("印章检查时其他异常，请检查设备或设备连接.如需重新进行检查请点击左侧'印章检查'菜单重新初始化印控机...");
			errorMsg = "印章检查盖章时其他异常，请检查设备或设备连接后重新进行印章检查";
		}else{
			ocxbase_messageHandler.showTipMessage("印章检查时其他异常，请检查设备或设备连接.如需重新进行检查请点击左侧'印章检查'菜单重新初始化印控机...");
			errorMsg = "印章检查盖章时其他异常，请检查设备或设备连接后重新进行印章检查";
		}
		ifNotException = false;
		$("#applyBtnTd").css('display', 'none');
		$("#commitBtnTd").css('display', "none");
		$("#checkMemo").val(errorMsg);
	       if(errorMsg!=""){
				var updateRet = ocxbase_bizInfoAjax.bizInfo.updateSealCheckResult(ctx
						+ "/mech/sealcheck/sealCheckAction_updateSealCheckInfo.action");
				if (!updateRet.success) {
					ocxbase_messageHandler.dealErrorMssage(updateRet.data);
					return;
				}else{
					$("#autoId").val(updateRet.data);
				}
		       }
		window.setTimeout(function() {
			ocxbase_messageHandler.hideWaittingDialog();
		}, 3000);
	       
		//alert(result.data);
	}
};

/**
 * 判断印控机里面sealPos章槽是否有章
 * 
 * @param sealPos
 *                章号
 * @returns 0:有章；E1026:无章；其他:异常
 */
function  hasSealInTheMachineSealPos(sealPos){    
	var sealInfo = OCX_MachineOrder.getSealInfo();
	if(sealInfo.code == "1001"){
		var sealInfoList = sealInfo.data.split(",");
		for(var i=0;i<sealInfoList.length;i++){
			var seal = sealInfoList[i].split(":");
			if(seal.length == 2 && seal[0] == sealPos){
				return true;				
			}
		}
	}else{
		return false;
	}
};

/**
 * 查找印控机中sealPos槽中章号
 * 
 * @param sealPos
 *                章号
 * @returns 0:有章；E1026:无章；其他:异常
 */
function  getSealNumBySealPos(sealPos){    
	var sealInfo = OCX_MachineOrder.getSealInfo();
	if(sealInfo.code == "1001"){
		var sealInfoList = sealInfo.data.split(",");
		for(var i=0;i<sealInfoList.length;i++){
			var seal = sealInfoList[i].split(":");
			if(seal.length == 2 && seal[0] == sealPos){
				return parseInt(seal[1]);				
			}
		}
	}else{
		return 0;
	}
};


//通过印控机编号查寻印章安装信息
function findSealIfOilBySealNum(machine_num,sealNum) {
    var param = {
	"deviceNum" : machine_num,
	"sealNum" : sealNum
    };
    var url = ctx + "/mech/sealcheck/sealCheckAction_findSealIfOilBySealNum.action";
    var data = tool.ajaxRequest(url, param);
    if (data.success) {
	return data.response.responseMessage.data;
    }else{
    	return "";
    }
};


// 用印结束弹出纸板
function useSealCompletedOpenPaperDoor() {
	
	var ret = ocxbase_sealMachine.openPaperDoor(_doorCloseCallback);
	
	if (!ret.success) {
		ocxbase_messageHandler.dealErrorMssage(ret.data);
	}
	setTimeout(function() {
		ocxbase_messageHandler.hideWaittingDialog();
	}, 1000);
//	localApproval();
	openAuthResPage();
//	alert("印章检查结束，请取出印章检查表,关闭纸板并对此次印章检查授权.");
	setTimeout(function() {
		$("#localApprovalBtnTd").css('display', '');
	}, 800);
	// 纸板关闭回调函数
	function _doorCloseCallback(ret) {
		if (!ret.success) {
			ocxbase_messageHandler.dealErrorMssage(ret.data);
			return;
		}
	}
};



// 重置属性缓存
function resetPropsCache() {
	document.getElementById("voucherImg").onload = null;
	clearSealCanvas("sealCanvasDiv");
	document.getElementById("voucherImg").src = ctx + "/3x/ocxbase/useSealFramework/ocxbase_voucherImg.png";
	ocxbase_messageHandler.hideWaittingDialog();
	use_cut_img = true;
	src_img_path = null;
	cut_img_path = null;
	$("#applyBtnTd").css('display', '');
	$('#applyBtn').attr("disabled", false);
	$("#mechSealUseApplyInfo")[0].reset();
	$("#commitBtnTd").css('display', 'none');
	ocxbase_messageHandler.hideAllButton();
	ocxbase_utils.sealImageHandler.clearSealImage();
	$("#rotateSealImageId").css('display', 'none');
	$("#status").val("");
};

/**
 * 页面关闭响应事件
 */
function closePage() {
	ocxbase_machineAndCameraConnProxy.disconnect();
};
