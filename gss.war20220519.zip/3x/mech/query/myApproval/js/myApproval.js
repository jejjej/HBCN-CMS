function myApprovalInit() {
    // 我的用印申请列表
    var pageHeaderHeight = $(".pageHeader").css("height");
    var pageContentWidth = $(".pageContent").width() - 2;
    pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
    var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
    // 列表
    $("#myApprovalList")
	    .jqGrid(
		    {
			width : pageContentWidth,
			height : tableHeight + "px",
			url : ctx + "/mechseal/query/listMyApprovalAction_list.action",
			multiselect : false,
			rowNum : 20,
			rownumbers : true,
			rowList : [ 20, 50, 100 ],
			colNames : [ "用印模式", "文件类型", "用印事由", "申请机构", "申请人", "申请日期", "审批日期", "待用印次数", "已用印次数", "审批结果", "文件图像", "用印图像" ],
			colModel : [
				{
				    name : "UseSealBizInfo.moduleName",
				    index : "UseSealBizInfo.moduleName",
				    align : "center",
				    width : 80,
				    sortable : false,
				    formatter : function(value, options, rData) {
				    	return constants.MODULE_MAP[value];
				    }
				},
				{
				    name : "UseSealBizInfo.tradeCodeName",
				    index : "UseSealBizInfo.tradeCodeName",
				    align : "center",
				    width : 80,
				    sortable : false
				},
				{
				    name : "UseSealBizInfo.title",
				    index : "UseSealBizInfo.title",
				    align : "center",
				    width : 80,
				    sortable : false
				},
				{
				    name : "UseSealBizInfo.applyOrgName",
				    index : "UseSealBizInfo.applyOrgName",
				    align : "center",
				    width : 60,
				    sortable : false
				},
				{
				    name : "UseSealBizInfo.applyPeopleName",
				    index : "UseSealBizInfo.applyPeopleName",
				    width : 60,
				    align : "center",
				    sortable : false
				},
				{
				    name : "UseSealBizInfo.applyTime",
				    index : "UseSealBizInfo.applyTime",
				    align : "center",
				    width : 90,
				    sortable : false
				},
				{
				    name : "operateTime",
				    index : "operateTime",
				    align : "center",
				    width : 90,
				    sortable : false
				},
				{
				    name : "UseSealBizInfo.applyNum",
				    index : "UseSealBizInfo.applyNum",
				    width : 50,
				    align : "center",
				    sortable : false
				},
				{
				    name : "UseSealBizInfo.usedNum",
				    index : "UseSealBizInfo.usedNum",
				    align : "center",
				    width : 58,
				    sortable : false
				},
				{
				    name : "result",
				    index : "result",
				    align : "center",
				    width : 40,
				    sortable : false,
				    formatter : function(value, options, rData) {
				    	return sealUseConstants.SealUseOptOperateResult[value];
				    }
				},
				{
				    name : "UseSealBizInfo.storeId",
				    index : "UseSealBizInfo.storeId",
				    width : 40,
				    align : "center",
				    sortable : false,
				    formatter : function(value, options, rData) {
						if (null == value || value == "") {
						    return "无";
						} else {
						    var html = "<img src='"
							    + ctx
							    + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='文件图像'  title='文件图像'  onclick=\"startViewImage('"
							    + value + "');\"/>";
						    return html;
						}
				    }
				},
				{
				    name : "UseSealBizInfo.autoId",
				    index : "UseSealBizInfo.autoId",
				    width : 40,
				    align : "center",
				    sortable : false,
				    formatter : function(value, options, rData) {
				    	var status = rData.status;
						if (status == "005" || status == "006" || status == "007" || status == "008") {
							 var html = "<img src='"
								    + ctx
								    + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='用印图像'  title='用印图像'  onclick=\"showStampedImages('"
								    + value + "');\"/>";
							 return html;
						    
						} else {
							return "无";
						}
				    }
				}],
			pager : "#pager"
		    });

};

function querySealApplyForTerm() {
    $("#myApprovalList").jqGrid("search", "#search");
};

/**
 * 图片展示
 * 
 * @param storeId
 */
function startViewImage(storeId) {
    wfStoreFancyBox.showAllImageByStoreId(storeId, "buttons");
};

function showStampedImages(bizId){
	var data = {
			"bizId" : bizId
	};
	var url = ctx + "/mechseal/query/listMyApprovalAction_queryStampedImageUrlList.action";
    var result = tool.ajaxRequest(url, data);
    if (result.success) {
    	if (result.response.responseMessage.success){
    		var urlList = result.response.urlList;
    		wfStoreFancyBox.showAllImageByUrl(urlList, "buttons");
    	}else{
    		alert(result.response.responseMessage.message);
    	}
    }else {
    	alert(result.response);
    }
};