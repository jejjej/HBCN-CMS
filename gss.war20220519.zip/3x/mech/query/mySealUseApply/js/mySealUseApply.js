/**
 * 我的用印申请加载
 */
function myApplyInit() {
    $("#delegationDLG").dialog({
	autoOpen : false,
	resizable : false,
	height : 160,
	width : 300,
	modal : true,
	buttons : {},
	close : function() {
	    $("#form")[0].reset();
	}
    });
    // 加载申请状态
    var sealStatusContent = "<option value=' '>全部</option>";
    for ( var key in sealUseConstants.SealUseApplyStatus) {
	sealStatusContent += "<option value='" + key + "'>" + sealUseConstants.SealUseApplyStatus[key] + "</option>";
    }
    $("#que_status").html(sealStatusContent);
    // 查询展示该部门下所有人员
    listDeptAllPeoPles();
    // 我的用印申请列表
    var pageHeaderHeight = $(".pageHeader").css("height");
    var pageContentWidth = $(".pageContent").width() - 2;
    pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
    var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
    // 列表
    $("#myApplyList")
	    .jqGrid(
		    {
			width : pageContentWidth,
			height : tableHeight + "px",
			url : ctx + "/mechseal/query/listMySealUseApply_queryMySealUseApply.action",
			multiselect : false,
			rowNum : 20,
			rownumbers : true,
			rowList : [ 20, 50, 100 ],
			colNames : [ "用印模式", "文件类型", "用印事由", "文件持有人", "申请时间", "采集数量", "待用印次数", "已用印次数", "状态",
				 "备注", "图像", "操作" ],
			colModel : [
				{
				    name : "moduleName",
				    index : "moduleName",
				    align : "center",
				    width : 80,
				    sortable : false,
				    formatter : function(value, options, rData) {
					return constants.MODULE_MAP[value];
				    }
				},
				{
				    name : "tradeCodeName",
				    index : "tradeCodeName",
				    align : "center",
				    width : 100,
				    sortable : false
				},
				{
				    name : "title",
				    index : "title",
				    align : "center",
				    width : 100,
				    sortable : false
				},
				{
				    name : "fileOwnerName",
				    index : "fileOwnerName",
				    align : "center",
				    width : 70,
				    sortable : false
				},
				{
				    name : "applyTime",
				    index : "applyTime",
				    width : 70,
				    align : "center",
				    sortable : false
				},
				{
				    name : "fileNum",
				    index : "fileNum",
				    align : "center",
				    width : 45,
				    sortable : false
				},
				{
				    name : "applyNum",
				    index : "applyNum",
				    width : 45,
				    align : "center",
				    sortable : false
				},
				{
				    name : "usedNum",
				    index : "usedNum",
				    align : "center",
				    width : 45,
				    sortable : false
				},
				{
				    name : "status",
				    index : "status",
				    align : "center",
				    width : 90,
				    sortable : false,
				    formatter : function(value, options, rData) {
					return sealUseConstants.SealUseApplyStatus[value];
				    }
				},
				{
				    name : "memo",
				    index : "memo",
				    align : "center",
				    width : 90,
				    sortable : false
				},
				{
				    name : "storeId",
				    index : "storeId",
				    width : 30,
				    align : "center",
				    sortable : false,
				    formatter : function(value, options, rData) {
					if (null == value || value == "") {
					    return "无";
					} else {
					    var html = "<img src='"
						    + ctx
						    + "/gss/common/images/gss/image.png' style='cursor:pointer;margin-left:3px;' alt='用印图像'  title='用印图像'  onclick=\"startViewImage('"
						    + value + "');\"/>";
					    return html;

					}
				    }
				},
				{
				    name : "autoId",
				    index : "autoId",
				    align : "center",
				    width : 60,
				    sortable : false,
				    formatter : function(value, options, rData) {
					if (rData.status == sealUseConstants.WAITTING_USE_SEAL) {
					    var html = "<input type='button' onclick=\"delegation('" + value
						    + "');\" value='转授权' />";
					    return html;
					} else {
					    return "无";
					}
				    }
				}, ],
			pager : "#myApplyListPager"
		    });

};

function querySealApplyForTerm() {
    $("#myApplyList").jqGrid("search", "#sealApplyIterm");
};

/**
 * 转授权
 * 
 * @param id
 */
function delegation(id) {
    $("#id").val(id);
    $("#delegationDLG").dialog("open");

};

function submitForm() {
    var param = {
	"id" : $("#id").val(),
	"operatorCode" : $("#operatorCode").val()
    };
    var url = ctx + "/mechseal/query/listMySealUseApply_delegation.action";
    var data = tool.ajaxRequest(url, param);
    if (data.response.responseMessage.success) {
    	alert("转授权成功");
    	location.reload();
    }else{
    	alert(data.response.responseMessage.message);
    }
};

/**
 * 查询获取部门下所有人员
 */
function listDeptAllPeoPles() {
    var url = ctx + "/mechseal/query/listMySealUseApply_listDeptAllPeoPles.action";
    var data = tool.ajaxRequest(url, '');
    if (data.success) {
	var xPeoples = data.response.arrayList;
	if (xPeoples != null) {
	    $("#operatorCode").append("<option value=''>--请选择--</option>");
	    $(xPeoples).each(
		    function(i, value) {
			$("#operatorCode").append(
				"<option value='" + xPeoples[i].peopleCode + "'>" + xPeoples[i].peopleName + "("
					+ xPeoples[i].peopleCode + ")</option>");
		    });
	} else {
	    alert("该机构下无人员");
	}
    } else {
    	alert(data.response);
    }
};

/**
 * 图片展示
 * 
 * @param storeId
 */
function startViewImage(storeId) {
    wfStoreFancyBox.showAllImageByStoreId(storeId, "buttons");
};