var fileIndex=1;


/**
 * 设备编号从Excel文件导入
 * 
 * @returns {Boolean}
 */
function deviceImport() {
	if(null == $.trim($("#file").val()) || "" ==  $.trim($("#file").val())){
		alert("导入数据异常：请选择需要导入的模板文件.");
		return;
	}
	
	var fileName = $.trim($("#file").val());
	var suffix1 = "xls",suffix2 = "xlsx";
	var falg1 = fileName.substring(fileName.length-suffix1.length)==suffix1;
	var falg2 = fileName.substring(fileName.length-suffix2.length)==suffix2;
	if(falg1){//只要有一个满足条件即可
		$("#loading").ajaxStart(function() {//开始上传文件时显示一个图片
			$("#importBtn").attr("disabled",true);//禁用按钮
			$(this).show();
		}).ajaxComplete(function() {//文件上传完成将图片隐藏起来
			$("#importBtn").attr("disabled",false);//启用按钮
			$(this).hide();
		});
		//$.ajaxFileUpload({url:用于文件上传的服务器端请求地址,secureuri:一般设置为false,fileElementId : 'file',//文件上传空间的id属性,dataType : 'json',//返回值类型 一般设置为json,success : function(data, status){ //服务器成功响应处理函数});
//		$.ajaxFileUpload({url : ctx+"/mmsfile/deviceExcelFileImportAction!importSealDevNumsFromExcel.action?processDefKey=MMS_REGISTER",secureuri : false,fileElementId : 'file',dataType : 'json',success : function(res, status){ //服务器成功响应处理函数
		$.ajaxFileUpload({url : ctx+"/peopleUseSeal/peopleUseSealInfoTemplate_addTemplate.action",secureuri : false,fileElementId : 'file',dataType : 'json',success : function(res, status){ //服务器成功响应处理函数
				if(res.responseMessage.success){
//					if("success" == res.result){
//						alert("录入数据成功！");
//					}else{
//						alert(res.result);
//					}
					alert("录入数据成功！");
				}else{
//					alert("导入数据异常：文件导入过程异常。");
					alert(res.responseMessage.message);
				}
			},error : function(res, status, e){//服务器响应失败处理函数
				alert("导入数据异常：文件导入过程异常。");
			}
		});
	}else{
		alert("导入数据异常：系统只支持Excel模板文件导入,请选择正确的模板文件.");
		return;
	}
}

/**
 * 模版下载
 */
function templateUpload(){
	window.location.href=ctx+"/upload/peopleUseSeal.xls";
}

function importTemplate(){
	$("#fileImport").dialog("open");
}



/**
 * 初始化Grid数据
 */
$(function() {
//	fileUploadHandler.initAjaxUpload(basePath, "uploadDiv","after_sealUse_file", function(r) {
//		if (r.storeId == null) {
//			alert("未上传任何文件！");
//			return;
//		}
//		alert(r.storeId);
////		$("#btnUpload").attr("disabled", "disabled");
////		fileId = r.storeId;
//	});
	
	$("#uploadDiv").dialog({
		autoOpen : false,
		resizable : false,
		closeOnEscape:false,
		height : 200, 
		width : 700,
		modal : true,
		buttons : {
		    "开始上传": function(){
		    	startUploadFile();
			},
			"增加":function(){
				fileIndex++;
				var fileInput='<input type="file" id="'+'file'+''+fileIndex+'" name="file"  onkeypress="return false;"  size="40"/><span id="'+fileIndex+'_result"></span>';
				$("#uploadDiv").append(fileInput);
			},
//			"删除":function(){
//				if(fileIndex==1){
//					alert("只有一个，无法删除");
//					return;
//				}
//				$("#file"+fileIndex).remove();
//				$('#'+fileIndex+"_result").remove();
//				fileIndex--;
//			},
			"关闭":function(){
				$("#uploadDiv").dialog("close");
			}
		},
		close : function() {
//			fileIndex=1;
//			$("#uploadDiv").empty();
//			var fileInput='<input type="file" id="'+'file'+''+fileIndex+'" name="file"  onkeypress="return false;"  size="40"/><span id="'+fileIndex+'_result"></span>';
//			$("#uploadDiv").append(fileInput);
			if($("#attached").val()){
				$("#btnUpload").attr("disabled", "disabled");
			}else{
				alert("没有上传附件");
			}
		},
		open : function(){
		}
	});
});

function uploadImg(){
	$("#uploadDiv").dialog("open");
	
//	var storeId=$("#attached").val();
//	if(storeId&&'null'!=storeId){
////		fileUploadHandler.reactive(storeId,constants.MEDIATYPE_SEALUSE_AFTER);
//		fileUploadHandler.reactive(storeId);
//	}else{
////		fileUploadHandler.active(constants.MEDIATYPE_SEALUSE_AFTER);
//		fileUploadHandler.active();
//	}
}

function startUploadFile(){
//	for(var i=1;i<=fileIndex;i++){
//		uploadFile(i);
//	}
	
	uploadFile(1);
}
var index2=1;
function uploadFile(index){
	if(!$('#file'+index).val()){
		$("#" + index + "_result").css("color", "red");
		$("#" + index + "_result").html("[×]");
		
		if(index2>=fileIndex){
			return;
		}
		index2++;
		uploadFile(index2);
		return;
	}
	var storeId2=$("#attached").val();
	if(storeId2){//已经上传，后面追加
		$.ajaxFileUpload({url : ctx+"/store/curlFileStoreAction_appendAffixObject.action?storeId="+storeId2,secureuri : false,fileElementId : 'file'+index,dataType : 'json',success : function(res, status){ //服务器成功响应处理函数
			if(res.state='normal'){
				$("#" + index + "_result").css("color", "green");
				$("#" + index + "_result").html("[√]");
				
				if(index2>=fileIndex){
					return;
				}
				index2++;
				uploadFile(index2);
			}else{
				$("#" + index + "_result").css("color", "red");
				$("#" + index + "_result").html("[×]");
			}
		},error : function(res, status, e){//服务器响应失败处理函数
			alert("上传附件异常。");
		}
		});
	}else{
		$.ajaxFileUpload({url : ctx+"/store/curlFileStoreAction_addAffixObject.action",secureuri : false,fileElementId : 'file'+index,dataType : 'json',success : function(res, status){ //服务器成功响应处理函数
			if(res.state='normal'){
				var storeId=res.data;
				$("#attached").val(storeId);
				$("#" + index + "_result").css("color", "green");
				$("#" + index + "_result").html("[√]");
//				$("#btnUpload").attr("disabled", "disabled");
//				$("#uploadDiv").dialog("close");
				if(index2>=fileIndex){
					return;
				}
				index2++;
				uploadFile(index2);
			}else{
//			alert(res.data);
				$("#" + index + "_result").css("color", "red");
				$("#" + index + "_result").html("[×]");
			}
		},error : function(res, status, e){//服务器响应失败处理函数
			alert("上传附件异常。");
		}
		});
	}
}

function submitForm(){
	var params = $("#addForm").serializeForm();
	$.post(ctx+"/peopleUseSeal/peopleUseSealInfoAction_add.action",params,function(data){
		if(data.responseMessage.success){
			alert("单笔录入成功");
			$("#addForm")[0].reset();
			
			fileIndex=1;
			$("#uploadDiv").empty();
			var fileInput='<input type="file" id="'+'file'+''+fileIndex+'" name="file"  onkeypress="return false;"  size="40"/><span id="'+fileIndex+'_result"></span>';
			$("#uploadDiv").append(fileInput);
		}else{
			alert(data.responseMessage.message);
		}
	});
}

function initOrgNo() {
	var loginPeople = top.loginPeopleInfo;
	$("#organizationSid_Item").val(loginPeople.orgName+"("+loginPeople.orgNo+")");
	$("#operatorOrgNo").val(loginPeople.orgNo);
}



/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo,organizationName){
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#sealOwnerOrg").radioOrgTree(true,organizationSid,0,false,function(event, treeId, treeNode){
		if(treeNode){
//			$("#organizationSid_Item").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
//			$("#"+organizationNo).val(treeNode.organizationNo);
			$("#"+organizationName).val(treeNode.organizationName);
			$("#"+organizationNo).val(treeNode.organizationNo);
		}
	});
}