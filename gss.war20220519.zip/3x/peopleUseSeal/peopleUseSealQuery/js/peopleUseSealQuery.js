var fileIndex=1;


/**
 * 设备编号从Excel文件导入
 * 
 * @returns {Boolean}
 */
function deviceImport() {
	if(null == $.trim($("#file").val()) || "" ==  $.trim($("#file").val())){
		alert("导入数据异常：请选择需要导入的模板文件.");
		return;
	}
	
	var fileName = $.trim($("#file").val());
	var suffix1 = "xls",suffix2 = "xlsx";
	var falg1 = fileName.substring(fileName.length-suffix1.length)==suffix1;
	var falg2 = fileName.substring(fileName.length-suffix2.length)==suffix2;
	if(falg1){//只要有一个满足条件即可
		$("#loading").ajaxStart(function() {//开始上传文件时显示一个图片
			$("#importBtn").attr("disabled",true);//禁用按钮
			$(this).show();
		}).ajaxComplete(function() {//文件上传完成将图片隐藏起来
			$("#importBtn").attr("disabled",false);//启用按钮
			$(this).hide();
		});
		//$.ajaxFileUpload({url:用于文件上传的服务器端请求地址,secureuri:一般设置为false,fileElementId : 'file',//文件上传空间的id属性,dataType : 'json',//返回值类型 一般设置为json,success : function(data, status){ //服务器成功响应处理函数});
//		$.ajaxFileUpload({url : ctx+"/mmsfile/deviceExcelFileImportAction!importSealDevNumsFromExcel.action?processDefKey=MMS_REGISTER",secureuri : false,fileElementId : 'file',dataType : 'json',success : function(res, status){ //服务器成功响应处理函数
		$.ajaxFileUpload({url : ctx+"/peopleUseSeal/peopleUseSealInfoTemplate_addTemplate.action",secureuri : false,fileElementId : 'file',dataType : 'json',success : function(res, status){ //服务器成功响应处理函数
				if(res.responseMessage.success){
//					if("success" == res.result){
//						alert("录入数据成功！");
//					}else{
//						alert(res.result);
//					}
					alert("录入数据成功！");
				}else{
//					alert("导入数据异常：文件导入过程异常。");
					alert(res.responseMessage.message);
				}
			},error : function(res, status, e){//服务器响应失败处理函数
				alert("导入数据异常：文件导入过程异常。");
			}
		});
	}else{
		alert("导入数据异常：系统只支持Excel模板文件导入,请选择正确的模板文件.");
		return;
	}
}

/**
 * 模版下载
 */
function templateUpload(){
	window.location.href=ctx+"/upload/peopleUseSeal.xls";
}

function importTemplate(){
	$("#fileImport").dialog("open");
}





/**
 * 初始化Grid数据
 */
$(function() {
	$("#fileImport").dialog({
		autoOpen : false,
		resizable : false,
		closeOnEscape:false,
		height : 200, 
		width : 700,
		modal : true,
		buttons : {

		},
		close : function() {
		},
		open : function(){
		}
	});
	
	$("#updateDiv").dialog({
		autoOpen : false,
		resizable : false,
		closeOnEscape:false,
		height : 700, 
		width : 700,
		modal : true,
		buttons : {
//		    "确定": function(){
//		    	update();
//		    }
		},
		close : function() {
			$("#updateForm")[0].reset();
		},
		open : function(){
			initUpload();
		}
	});
	
	$("#uploadDiv").dialog({
		autoOpen : false,
		resizable : false,
		closeOnEscape:false,
		height : 200, 
		width : 700,
		modal : true,
		buttons : {
		    "开始上传": function(){
		    	startUploadFile();
			},
			"增加":function(){
				fileIndex++;
				var fileInput='<input type="file" id="'+'file'+''+fileIndex+'" name="file"  onkeypress="return false;"  size="40"/><span id="'+fileIndex+'_result"></span>';
				$("#uploadDiv").append(fileInput);
			},
//			"删除":function(){
//				if(fileIndex==1){
//					alert("只有一个，无法删除");
//					return;
//				}
//				$("#file"+fileIndex).remove();
//				$('#'+fileIndex+"_result").remove();
//				fileIndex--;
//			},
			"关闭":function(){
				$("#uploadDiv").dialog("close");
			}
		},
		close : function() {
//			fileIndex=1;
//			$("#uploadDiv").empty();
//			var fileInput='<input type="file" id="'+'file'+''+fileIndex+'" name="file"  onkeypress="return false;"  size="40"/><span id="'+fileIndex+'_result"></span>';
//			$("#uploadDiv").append(fileInput);
			if($("#updateAttached").val()){
				$("#btnUpload").attr("disabled", "disabled");
			}else{
				alert("没有上传附件");
			}
		},
		open : function(){
			
		}
	});
	
	initOrgNo();
	initSealType();
	initPage();
});

function initSealType(){
	var params = {
			
	};
	$.post(ctx+"/report/takeRetuenSealReportAction_findSealType.action",params,function(data){
		if(data.responseMessage.success){
			var sealTypeMap=data.sealMap;
			var sealTypeContent = "<option value=' '>全部</option>";
			for ( var key in sealTypeMap) {
				sealTypeContent += "<option value='" + key + "'>" + sealTypeMap[key] + "</option>";
			}
			$("#sealType").html(sealTypeContent);
			
		}else{
			alert(res.responseMessage.message);
		}
	});
	
}

function initOrgNo() {
	var loginPeople = top.loginPeopleInfo;
//	$("#organizationSid_Item").val(loginPeople.orgName+"("+loginPeople.orgNo+")");
//	$("#operatorOrgNo").val(loginPeople.orgNo);
	$("#applyOrg").val(loginPeople.orgNo);
	$("#applyOrgName").val(loginPeople.orgName);
}

function initPage(){
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() -2;
		pageHeaderHeight = pageHeaderHeight.substr(0,pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight -pageHeaderHeight + 6 - 50*2 ;
	$("#logPeopleManageList").jqGrid(
		{
			width : pageContentWidth,
			height : tableHeight,
			url : ctx + "/peopleUseSeal/peopleUseSealInfoAction_list.action",
			multiselect : false,
			postData : {
				"queryBean.params.applyOrg" : top.loginPeopleInfo.orgNo
			},
			rowNum : 20,
			rownumbers : true,
			sortname : "applyTime",
			sortorder : "desc",
			rowList : [ 20, 50, 100 ],
			colNames : ["流水号", "申请机构", "申请人","申请时间", "文件类型", "审批人", "保管人", "印章类型", "印章所属机构", "印章名称",
			            "文件名称", "附件", "审批时间", "申请审批状态", "用印原因", "创建时间", "修改时间", "普通用印次数", "骑缝用印次数","包含敏感信息", "操作" ],
			colModel : [
					{
						name : "orderNo",
						index : "orderNo",
						align : "center",
						width : 60,
						sortable : true,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "applyOrg",
						index : "applyOrg",
						align : "center",
						width : 60,
						sortable : true
					},
					{
						name : "applyPeople",
						index : "applyPeople",
						align : "center",
						width : 60,
						sortable : true,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "applyTime",
						index : "applyTime",
						align : "center",
						width : 60,
						sortable : true,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "fileType",
						index : "fileType",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "apprPeople",
						index : "apprPeople",
						align : "center",
						width : 60,
						sortable : false
					},
					{
						name : "savePeople",
						index : "savePeople",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "sealType",
						index : "sealType",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "sealOwnerOrg",
						index : "sealOwnerOrg",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "sealName",
						index : "sealName",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "fileName",
						index : "fileName",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "attached",
						index : "attached",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							if(!value){
								return '无';
							}else{
								var html = "<a onclick=\"openFilesDialog('"
									+ value
									+ "','apply')\" style='text-decoration:underline;color:blue;cursor: hand;'>附件</a>";
								return html;
							}
						}
					},
					{
						name : "apprTime",
						index : "apprTime",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "apprState",
						index : "apprState",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "useSealCausal",
						index : "useSealCausal",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "createTime",
						index : "createTime",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "updateTime",
						index : "updateTime",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "useSealNum",
						index : "useSealNum",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "acrossPageSealUseNum",
						index : "acrossPageSealUseNum",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "isSensitive",
						index : "isSensitive",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							if(value=='0'){
								return '否';
							}
							return '是';
						}
					},
					{
						name : "sid",
						index : "sid",
						align : "center",
						width : 80,
						sortable : false,
						formatter : function(value, options, rData) {
							var html = "<a onclick=\"toUpdate('"
							    + value
							    + "')\" style='text-decoration:underline;color:blue;cursor: hand;'>修改</a>";
							
							html = html + "&nbsp;" + "<a onclick=\"deletePeopleUseSeal('"
						    + value
						    + "')\" style='text-decoration:underline;color:blue;cursor: hand;'>删除</a>";
							return html;
						}
					} ],
			pager : "#logPeopleManagePager",
			caption : "人工用印列表"
		}).trigger("reloadGrid");
	
	$("#logPeopleManageList").navGrid("#logPeopleManagePager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
}

function toUpdate(sid){
	var params = {
			"peopleUseSealInfo.sid" : sid
		};
	$.post(ctx+"/peopleUseSeal/peopleUseSealInfoAction_findBySid.action",params,function(data){
		if(data.responseMessage.success){
			$("#updateSid").val(sid);
			var peopleUseSealInfo=data.peopleUseSealInfo;
			
			$("#updateAttached").val(peopleUseSealInfo.attached);
			
			$("#updateOrderNo").val(peopleUseSealInfo.orderNo);
//			$("#updateApplyOrg").val(peopleUseSealInfo.applyOrg);
			$("#updateSealName").val(peopleUseSealInfo.sealName);
			$("#updateSealType").val(peopleUseSealInfo.sealType);
			$("#updateFileType").val(peopleUseSealInfo.fileType);
			$("#updateCreateTime").val(peopleUseSealInfo.createTime);
			$("#updateApprTime").val(peopleUseSealInfo.apprTime);
			$("#updateUseSealNum").val(peopleUseSealInfo.useSealNum);
			$("#updateAcrossPageSealUseNum").val(peopleUseSealInfo.acrossPageSealUseNum);
			$("#updateSealOwnerOrg").val(peopleUseSealInfo.sealOwnerOrg);
			$("#updateSealOwnerOrgName").val(peopleUseSealInfo.sealOwnerOrgName);
			$("#updateApprPeople").val(peopleUseSealInfo.apprPeople);
			$("#updateApprState").val(peopleUseSealInfo.apprState);
			$("#updateSavePeople").val(peopleUseSealInfo.savePeople);
			$("#updateFileName").val(peopleUseSealInfo.fileName);
			$("#updateUseSealCausal").val(peopleUseSealInfo.useSealCausal);
			$("#updateIsSensitive").val(peopleUseSealInfo.isSensitive);
			
			$("#updateDiv").dialog("open");
		}else{
			alert(data.responseMessage.message);
		}
	});
}

function uploadImg(){
	$("#uploadDiv").dialog("open");
}

function startUploadFile(){
	uploadFile(1);
}

var index2=1;
function uploadFile(index){
	if(!$('#file'+index).val()){
		$("#" + index + "_result").css("color", "red");
		$("#" + index + "_result").html("[×]");
		
		if(index2>=fileIndex){
			return;
		}
		index2++;
		uploadFile(index2);
		return;
	}
	var storeId2=$("#updateAttached").val();
	if(storeId2){//已经上传，后面追加
		$.ajaxFileUpload({url : ctx+"/store/curlFileStoreAction_appendAffixObject.action?storeId="+storeId2,secureuri : false,fileElementId : 'file'+index,dataType : 'json',success : function(res, status){ //服务器成功响应处理函数
			if(res.state='normal'){
				$("#" + index + "_result").css("color", "green");
				$("#" + index + "_result").html("[√]");
				
				if(index2>=fileIndex){
					return;
				}
				index2++;
				uploadFile(index2);
			}else{
				$("#" + index + "_result").css("color", "red");
				$("#" + index + "_result").html("[×]");
			}
		},error : function(res, status, e){//服务器响应失败处理函数
			alert("上传附件异常。");
		}
		});
	}else{
		$.ajaxFileUpload({url : ctx+"/store/curlFileStoreAction_addAffixObject.action",secureuri : false,fileElementId : 'file'+index,dataType : 'json',success : function(res, status){ //服务器成功响应处理函数
			if(res.state='normal'){
				var storeId=res.data;
				$("#updateAttached").val(storeId);
				$("#" + index + "_result").css("color", "green");
				$("#" + index + "_result").html("[√]");
//				$("#btnUpload").attr("disabled", "disabled");
//				$("#uploadDiv").dialog("close");
				if(index2>=fileIndex){
					return;
				}
				index2++;
				uploadFile(index2);
			}else{
//			alert(res.data);
				$("#" + index + "_result").css("color", "red");
				$("#" + index + "_result").html("[×]");
			}
		},error : function(res, status, e){//服务器响应失败处理函数
			alert("上传附件异常。");
		}
		});
	}
}


function update(){
	var params = $("#updateForm").serializeForm();
	$.post(ctx+"/peopleUseSeal/peopleUseSealInfoAction_update.action",params,function(data){
		if(data.responseMessage.success){
			alert("修改成功");
			$("#updateDiv").dialog("close");
			queryData();
			
		}else{
			alert(data.responseMessage.message);
		}
	});
}

function initUpload(){
	$("#btnUpload").attr("disabled", false);
	fileIndex=1;
	index2=1;
	$("#uploadDiv").empty();
	var fileInput='<input type="file" id="'+'file'+''+fileIndex+'" name="file"  onkeypress="return false;"  size="40"/><span id="'+fileIndex+'_result"></span>';
	$("#uploadDiv").append(fileInput);
}

function submitForm(){
	update();
}

function deletePeopleUseSeal(sid){
	if(!confirm('确定删除？')){
		return;
	}
	var params = {
			'peopleUseSealInfo.sid':sid
	};
	$.post(ctx+"/peopleUseSeal/peopleUseSealInfoAction_delete.action",params,function(data){
		if(data.responseMessage.success){
			alert("删除成功");
			queryData();
		}else{
			alert(data.responseMessage.message);
		}
	});
}

function openFilesDialog(storeId){
	wfStoreFancyBox.showAllThumbnailImageInDialogByStoreId("filesDLG", storeId, "button", "");
}

/**
 * 查询数据，执行查询
 */
function queryData() {
	$("#logPeopleManageList").jqGrid("search", "#queryForm");
}

/**
 * 重置查询条件
 */
function resetMethod() {
	$("#queryForm")[0].reset();
//	initOrgNo();
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo,organizationName){
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#applyOrg").radioOrgTree(true,organizationSid,0,false,function(event, treeId, treeNode){
		if(treeNode){
//			$("#organizationSid_Item").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
//			$("#"+organizationNo).val(treeNode.organizationNo);
			$("#"+organizationNo).val(treeNode.organizationNo);
			$("#"+organizationName).val(treeNode.organizationName);
		}
	});
}