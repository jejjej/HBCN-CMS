//判断是否是egde浏览器，其他浏览器正常访问
if(window.showModalDialog==undefined){
	var loginPeople = {
			peopleSid : "",
			orgName : "",
			orgNo : ""
	};
}else{
	var loginPeople = null;
}
var boolenPage;  //共用一个页面，用于区分返回参数值
/**
 * 页面初始化加载
 */
$(document).ready(function() {
	initOrgNo();
	initTaskList();
	initUseSealPage();
});
var sealUseConstant = new Object();
sealUseConstants.SealUseApplyStatus = {
	"0" : "启用", 
	"1" : "停用",
	"2" : "销毁" 
};
/**
 * 初始化任务列表
 */
function initTaskList() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight
			+ 6 - 50 * 2;
	var url = ctx+ "/mechseal/task/sealUseInstallAction_gainSealInstallList2.action";
	// 用印信息列表
	$("#useSealList").jqGrid(
			{
				width : pageContentWidth,
				height : tableHeight + "px",
				url : url,
				multiselect : false,
				postData : {
//					"queryBean.params.sealOrgNo" : loginPeople.orgNo,
					"queryBean.params.like_sealStoragePeople" : loginPeople.peopleSid
				},
				rowNum : 20,
				rownumbers : true,
				sortable : true,// 是否排序
				sortname : "applyDate",
				sortorder : "desc",
				ondblClickRow : function(row) {
					var rowData = $("#useSealList").getRowData(row);
					//判断是否是egde浏览器，其他浏览器正常访问
					if(window.showModalDialog==undefined){
						if(boolenPage == 1){
							//这个赋值方法仅适用于通过window.open()方法打开的父子页面。切勿使用于其他框架。
							window.opener.document.getElementById("addSealType").value = rowData.sealType;
							window.opener.document.getElementById("addSealName").value = rowData.sealName;
							window.opener.document.getElementById("addSealOwnerOrg").value = rowData.sealOrgNo;
							window.opener.document.getElementById("addSealOwnerOrgName").value = rowData.sealOrgName;
							window.opener.document.getElementById("sealautoId").value = rowData.sealApprovalPeople;
							window.opener.document.getElementById("sealApprovalPeopleName").value = rowData.sealApprovalPeopleName;
						}else if(boolenPage == 2){
							//这个赋值方法仅适用于通过window.open()方法打开的父子页面。切勿使用于其他框架。
							window.opener.document.getElementById("updateSealType").value = rowData.sealType;
							window.opener.document.getElementById("updateSealName").value = rowData.sealName;
							window.opener.document.getElementById("updateSealOwnerOrg").value = rowData.sealOrgNo;
							window.opener.document.getElementById("updateSealOwnerOrgName").value = rowData.sealOrgName;
							window.opener.document.getElementById("updateSealautoId").value = rowData.sealApprovalPeople;
						}
					}else{
						window.returnValue = rowData;
					}
					window.close();
				},
				rowList : [ 20, 50, 100 ],
				colNames : [ "ID","所属机构", "所属机构名称", "印章种类", "印章类型", "印章类型",
						"印章名称", "维护时间", "章面字样 ", "审批人","审批人名称", "印章保管人","印章保管人","设备编号","槽位", "印章状态" ],
				colModel : [
				            {
					name : "autoId",
					index : "autoId",
					align : "center",
					hidden:true,
					sortable : false
				},{
					name : "sealOrgNo",
					index : "sealOrgNo",
					align : "center",
					sortable : false
				}, {
					name : "sealOrgName",
					index : "sealOrgName",
					align : "center",
					sortable : false
				}, {
					name : "sealGroup",
					index : "sealGroup",
					align : "center",
					sortable : false
				}, {
					name : "sealType",
					index : "sealType",
					hidden:true,
					align : "center",
					sortable : false
				}, {
					name : "sealTypeName",
					index : "sealTypeName",
					align : "center",
					sortable : false
				}, {
					name : "sealName",
					index : "sealName",
					align : "center",
					sortable : false
				}, {
					name : "maintainTime",
					index : "maintainTime",
					align : "center",
					sortable : false
				}, {
					name : "faceFont",
					index : "faceFont",
					align : "center",
					sortable : false
				}, {
					name : "sealApprovalPeople",
					index : "sealApprovalPeople",
					align : "center",
					width : 80,
					hidden:true,
					sortable : false
				}, {
					name : "sealApprovalPeopleName",
					index : "sealApprovalPeopleName",
					align : "center",
					width : 80,
					sortable : false
				}, {
					name : "sealStoragePeople",
					index : "sealStoragePeople",
					hidden:true,
					align : "center",
					sortable : false
				},
				 {
					name : "sealStoragePeopleName",
					index : "sealStoragePeopleName",
					align : "center",
					sortable : false
				},{
					name : "deviceNum",
					index : "deviceNum",
					align : "center",
					hidden:true,
					sortable : false
				},{
					name : "sealNum",
					index : "sealNum",
					align : "center",
					hidden:true,
					sortable : false
				}, {
					name : "sealStutas",
					index : "sealStutas",
					align : "center",
					sortable : false,
					formatter : function(value, options, rData) {
						return sealUseConstants.SealUseApplyStatus[value];
					}
				}],
				pager : "#useSealPager",
				caption : "我的选择列表"
			}).trigger("reloadGrid");
	$("#useSealList").navGrid("#useSealPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

function initUseSealPage() {
	$("#submitForm").click(function() {
		queryApplyInfoForTerm();
	});
};
function queryApplyInfoForTerm() {
	$("#useSealList").jqGrid("search", "#queryForm");
};
function initOrgNo() {
	//判断是否是egde浏览器，其他浏览器正常访问
	if(window.showModalDialog==undefined){
		var variables = window.location.search;//获取url中携带的参数
		if(variables !=null && variables != ""){//判断数据是否有效
	        var variablesDe = decodeURI(variables);//重新编码,防止中文参数乱码
	        var variableArray  = variablesDe.substr(1).split("&");//将参数进行分割到数组中
	        for (var i= 0;i<variableArray.length;i++) {//遍历数组
	            var variable =  variableArray[i].split("="); //参数名key与参数值按=号进行分割成数组
	            switch(variable[0]) {   //将参数分解开来
	                case "peopleSid": //参数 peopleSid
	                	loginPeople.peopleSid = variable[1]; //variable[1]  参数 peopleSid 的值
	                    break;
	                case "orgName": //参数 orgName
	                	loginPeople.orgName = variable[1]; //variable[1]  参数 orgName 的值
	                    break;
	                case "orgNo": //参数 orgNo
	                	loginPeople.orgNo = variable[1]; //variable[1]  参数 orgNo 的值
	                	break;
	                case "boolenPage": //参数 boolenPage
	                	boolenPage = variable[1]; //variable[1]  参数 boolenPage 的值
	                	break;
	                   default:
	            }
	        }
		}
	}else{
		loginPeople = window.dialogArguments;
	}
	$("#organizationSid_Item").val(
			loginPeople.orgName + "(" + loginPeople.orgNo + ")");
	$("#sealOrgNo").val(loginPeople.orgNo);
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo) {
	var organizationSid = "00000000000000000000000000000000";
	$("#organizationSid_Item").radioOrgTree(
			true,
			organizationSid,
			0,
			false,
			function(event, treeId, treeNode) {
				if (treeNode) {
					$("#organizationSid_Item").val(
							treeNode.organizationName + "("
									+ treeNode.organizationNo + ")");
					$("#sealOrgNo").val(treeNode.organizationNo);
				}
			});
}
