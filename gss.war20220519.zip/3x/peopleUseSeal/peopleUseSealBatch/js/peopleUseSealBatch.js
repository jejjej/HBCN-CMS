var fileIndex=1;

var loginPeople = null;

/**
 * 设备编号从Excel文件导入
 * 
 * @returns {Boolean}
 */
function deviceImport() {
	if(null == $.trim($("#file").val()) || "" ==  $.trim($("#file").val())){
		alert("导入数据异常：请选择需要导入的模板文件.");
		return;
	}
	
	var fileName = $.trim($("#file").val());
	var suffix1 = "xls",suffix2 = "xlsx";
	var falg1 = fileName.substring(fileName.length-suffix1.length)==suffix1;
	var falg2 = fileName.substring(fileName.length-suffix2.length)==suffix2;
	if(falg1){//只要有一个满足条件即可
		$("#loading").ajaxStart(function() {//开始上传文件时显示一个图片
			$("#importBtn").attr("disabled",true);//禁用按钮
			$(this).show();
		}).ajaxComplete(function() {//文件上传完成将图片隐藏起来
			$("#importBtn").attr("disabled",false);//启用按钮
			$(this).hide();
		});
		//$.ajaxFileUpload({url:用于文件上传的服务器端请求地址,secureuri:一般设置为false,fileElementId : 'file',//文件上传空间的id属性,dataType : 'json',//返回值类型 一般设置为json,success : function(data, status){ //服务器成功响应处理函数});
//		$.ajaxFileUpload({url : ctx+"/mmsfile/deviceExcelFileImportAction!importSealDevNumsFromExcel.action?processDefKey=MMS_REGISTER",secureuri : false,fileElementId : 'file',dataType : 'json',success : function(res, status){ //服务器成功响应处理函数
		$.ajaxFileUpload({url : ctx+"/peopleUseSeal/peopleUseSealInfoTemplate_addTemplate.action",secureuri : false,fileElementId : 'file',dataType : 'json',success : function(res, status){ //服务器成功响应处理函数
				if(res.responseMessage.success){
//					if("success" == res.result){
//						alert("录入数据成功！");
//					}else{
//						alert(res.result);
//					}
					alert("录入数据成功！");
					queryData();
				}else{
//					alert("导入数据异常：文件导入过程异常。");
					alert(res.responseMessage.message);
				}
			},error : function(res, status, e){//服务器响应失败处理函数
				alert("导入数据异常：文件导入过程异常。");
			}
		});
	}else{
		alert("导入数据异常：系统只支持Excel模板文件导入,请选择正确的模板文件.");
		return;
	}
}

/**
 * 模版下载
 */
function templateUpload(){
	window.location.href=ctx+"/upload/peopleUseSeal.xls";
}

function importTemplate(){
	$("#fileImport").dialog("open");
}





/**
 * 初始化Grid数据
 */
$(function() {
	$("#fileImport").dialog({
		autoOpen : false,
		resizable : false,
		closeOnEscape:false,
		height : 200, 
		width : 700,
		modal : true,
		buttons : {

		},
		close : function() {
		},
		open : function(){
		}
	});
	
	$("#addDiv").dialog({
		autoOpen : false,
		resizable : false,
		closeOnEscape:false,
		height : 700, 
		width : 700,
		modal : true,
		buttons : {
		},
		close : function() {
			$("#addIsSensitive").val('0');
			$("#updateIsSensitive").val('0');
			gradeChange('addIsSensitive');
			gradeChange('updateIsSensitive');
			
			$("#addForm")[0].reset();
		},
		open : function(){
			initUpload();
		}
	});
	$("#filesDLG1").dialog({
		autoOpen : false,
		resizable : false,
		height: $(window).height() /6*2.7,
		width : $(window).width() /2*1.2,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
	$("#updateDiv").dialog({
		autoOpen : false,
		resizable : false,
		closeOnEscape:false,
		height : 700, 
		width : 700,
		modal : true,
		buttons : {
//		    "确定": function(){
//		    	update();
//		    }
		},
		close : function() {
			$("#addIsSensitive").val('0');
			$("#updateIsSensitive").val('0');
			gradeChange('addIsSensitive');
			gradeChange('updateIsSensitive');
			
			$("#updateForm")[0].reset();
		},
		open : function(){
			initUpload();
		}
	});
	
	$("#uploadDiv").dialog({
		autoOpen : false,
		resizable : false,
		closeOnEscape:false,
		height : 200, 
		width : 700,
		modal : true,
		buttons : {
		    "开始上传": function(){
		    	startUploadFile();
			},
//			"增加":function(){
//				fileIndex++;
//				var fileInput='<input type="file" id="'+'file'+''+fileIndex+'" name="file"  onkeypress="return false;"  size="40"/><span id="'+fileIndex+'_result"></span>';
//				$("#uploadDiv").append(fileInput);
//			},
//			"删除":function(){
//				if(fileIndex==1){
//					alert("只有一个，无法删除");
//					return;
//				}
//				$("#file"+fileIndex).remove();
//				$('#'+fileIndex+"_result").remove();
//				fileIndex--;
//			},
			"关闭":function(){
				$("#uploadDiv").dialog("close");
			}
		},
		close : function() {
			var addOrUpdate=$("#addOrUpdate").val();
			if(addOrUpdate=='1'){//增加
				if($("#attached").val()){
					$("#btnUpload").attr("disabled", "disabled");
				}else{
					alert("没有上传附件");
				}
			}else if(addOrUpdate=='2'){//修改
				if($("#updateAttached").val()){
					$("#updateBtnUpload").attr("disabled", "disabled");
				}else{
					alert("没有上传附件");
				}
			}
		},
		open : function(){
			
		}
	});
	
	$("#dialogTwo").dialog({
		autoOpen : false,
		resizable : false,
		height : $(window).height(),
		width : $(window).width()/9*8,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
	
	$("#sealNameDialog").dialog({
		autoOpen : false,
		resizable : false,
		height : $(window).height(),
		width : $(window).width()/9*8,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
	$("#sealApproverDialog").dialog({
		autoOpen : false,
		resizable : false,
		height : $(window).height(),
		width : $(window).width()/9*8,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
	
	initOrgNo();
	initSealType('sealType');
	initPage();
	
//	apprPeoples('addApprPeople');
//	savePeoples('addSavePeople');
//	apprPeoples('updateApprPeople');
//	savePeoples('updateSavePeople');
});

function initSealType(sealTypeId){
	var params = {
			
	};
	$.post(ctx+"/report/takeRetuenSealReportAction_findSealType.action",params,function(data){
		if(data.responseMessage.success){
			var sealTypeMap=data.sealMap;
			var sealTypeContent = "<option value=' '>全部</option>";
			for ( var key in sealTypeMap) {
				sealTypeContent += "<option value='" + key + "'>" + sealTypeMap[key] + "</option>";
			}
			$("#"+sealTypeId).html(sealTypeContent);
			
		}else{
			alert(res.responseMessage.message);
		}
	});
	
}

function initOrgNo() {
	loginPeople = top.loginPeopleInfo;
//	$("#organizationSid_Item").val(loginPeople.orgName+"("+loginPeople.orgNo+")");
//	$("#operatorOrgNo").val(loginPeople.orgNo);
//	$("#applyOrg").val(loginPeople.orgNo);
//	$("#applyOrgName").val(loginPeople.orgName);
	
	$("#sealOrgNo_Item").val(loginPeople.orgName+"("+loginPeople.orgNo+")");
	$("#sealOrgNo_Form").val(loginPeople.orgNo);
}

function initPage(){
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() -2;
		pageHeaderHeight = pageHeaderHeight.substr(0,pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight -pageHeaderHeight + 6 - 50*2 ;
	$("#logPeopleManageList").jqGrid(
		{
			width : pageContentWidth+350,
			height : tableHeight,
			url : ctx + "/peopleUseSeal/peopleUseSealInfoAction_list.action",
			multiselect : false,
			postData : {
//				"queryBean.params.applyOrg" : top.loginPeopleInfo.orgNo
			},
			rowNum : 20,
			rownumbers : true,
			sortname : "createTime",
			sortorder : "desc",
			rowList : [ 20, 50, 100 ],
			colNames : ["流水号", "申请机构", "申请人","申请时间", "文件类型", "审批人", "保管人", "印章类型", "印章所属机构", "印章名称",
			            "文件名称", "附件", "审批时间", "申请审批状态", "用印原因", "创建时间", /*"修改时间",*/ "普通用印次数", "骑缝用印次数","包含敏感信息", "用印时间", "操作" ],
			colModel : [
					{
						name : "orderNo",
						index : "orderNo",
						align : "center",
						width : 60,
						sortable : true,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "applyOrgName",
						index : "applyOrgName",
						align : "center",
						width : 60,
						sortable : true
					},
					{
						name : "applyPeopleName",
						index : "applyPeopleName",
						align : "center",
						width : 60,
						sortable : true,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "applyTime",
						index : "applyTime",
						align : "center",
						width : 60,
						sortable : true,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "fileType",
						index : "fileType",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "apprPeopleName",
						index : "apprPeopleName",
						align : "center",
						width : 60,
						sortable : false
					},
					{
						name : "savePeopleName",
						index : "savePeopleName",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "sealType",
						index : "sealType",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "sealOwnerOrgName",
						index : "sealOwnerOrgName",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "sealName",
						index : "sealName",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "fileName",
						index : "fileName",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "attached",
						index : "attached",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							if(!value){
								return '无';
							}else{
								var html = "<a onclick=\"openFilesDialog('"
									+ value
									+ "','apply')\" style='text-decoration:underline;color:blue;cursor: hand;'>附件</a>";
								return html;
							}
						}
					},
					{
						name : "apprTime",
						index : "apprTime",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "apprState",
						index : "apprState",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "useSealCausal",
						index : "useSealCausal",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "createTime",
						index : "createTime",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					/*{
						name : "updateTime",
						index : "updateTime",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},*/
					{
						name : "useSealNum",
						index : "useSealNum",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							if(value==0||value==""){
								return "0";
							}
							return value;
						}
					},
					{
						name : "acrossPageSealUseNum",
						index : "acrossPageSealUseNum",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							if(value==0||value==""){
								return "0";
							}
							return value;
						}
					},
					{
						name : "isSensitive",
						index : "isSensitive",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							if(value=='0'){
								return '否';
							}
							return '是';
						}
					},
					{
						name : "useSealTime",
						index : "useSealTime",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "sid",
						index : "sid",
						align : "center",
						width : 80,
						sortable : false,
						formatter : function(value, options, rData) {
//							var html = "<a onclick=\"toUpdate('"
//							    + value
//							    + "')\" style='text-decoration:underline;color:blue;cursor: hand;'>修改</a>";
							var html = ''; 
							html = html + "&nbsp;" + "<a onclick=\"deletePeopleUseSeal('"
						    + value
						    + "')\" style='text-decoration:underline;color:blue;cursor: hand;'>删除</a>";
							return html;
						}
					} ],
			pager : "#logPeopleManagePager",
			caption : "人工用印列表"
		}).trigger("reloadGrid");
	
	$("#logPeopleManageList").navGrid("#logPeopleManagePager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
}

function toUpdate(sid){
	$("#addOrUpdate").val('2');
	selectSealType('updateSealType');
//	apprPeoples('updateApprPeople');
//	savePeoples('updateSavePeople');
	
	var params = {
			"peopleUseSealInfo.sid" : sid
		};
	$.post(ctx+"/peopleUseSeal/peopleUseSealInfoAction_findBySid.action",params,function(data){
		if(data.responseMessage.success){
			$("#updateSid").val(sid);
			var peopleUseSealInfo=data.peopleUseSealInfo;
			
			$("#updateAttached").val(peopleUseSealInfo.attached);
			
			$("#updateOrderNo").val(peopleUseSealInfo.orderNo);
//			$("#updateApplyOrg").val(peopleUseSealInfo.applyOrg);
			$("#updateSealName").val(peopleUseSealInfo.sealName);
			$("#updateSealType").val(peopleUseSealInfo.sealType);
			$("#hideUpdateSealType").val(peopleUseSealInfo.sealType);
			$("#updateFileType").val(peopleUseSealInfo.fileType);
			$("#updateApplyTime").val(peopleUseSealInfo.applyTime);
			$("#updateApprTime").val(peopleUseSealInfo.apprTime);
			$("#updateUseSealNum").val(peopleUseSealInfo.useSealNum);
			$("#updateAcrossPageSealUseNum").val(peopleUseSealInfo.acrossPageSealUseNum);
			$("#updateSealOwnerOrg").val(peopleUseSealInfo.sealOwnerOrg);
			$("#updateSealOwnerOrgName").val(peopleUseSealInfo.sealOwnerOrgName);
			
//			$("#updateApprPeople").val(peopleUseSealInfo.apprPeople);
			var options = "<option value=\""+ peopleUseSealInfo.apprPeople+"\">" + peopleUseSealInfo.apprPeopleName + "</option>";
			$("#updateApprPeople").html(options);
			
			$("#updateApprState").val(peopleUseSealInfo.apprState);
//			$("#updateSavePeople").val(peopleUseSealInfo.savePeople);
			$("#updateApplyPeople").val(peopleUseSealInfo.applyPeople);
			$("#updateApplyPeopleName").val(peopleUseSealInfo.applyPeople);
			$("#updateFileName").val(peopleUseSealInfo.fileName);
			$("#updateUseSealCausal").val(peopleUseSealInfo.useSealCausal);
			$("#updateIsSensitive").val(peopleUseSealInfo.isSensitive);
			
			$("#updateDiv").dialog("open");
			if(peopleUseSealInfo.isSensitive==1){
				$("#updateBtnUpload").attr("disabled", "disabled");
				$("#updateAttached").attr("disabled", "disabled");
				$("#updateFile").attr("disabled", "disabled");
			}
		}else{
			alert(data.responseMessage.message);
		}
	});
}

function updateUploadImg(){
	$("#uploadDiv").dialog("open");
}

function uploadImg(){
	$("#uploadDiv").dialog("open");
}

function startUploadFile(){
	var addOrUpdate=$("#addOrUpdate").val();
	if(addOrUpdate=='1'){//增加
		uploadFile(1,'attached');
	}else if(addOrUpdate=='2'){//修改
		uploadFile(1,'updateAttached');
	}
}

var index2=1;
function uploadFile(index,attachedId){
	if(!$('#file'+index).val()){
		$("#" + index + "_result").css("color", "red");
		$("#" + index + "_result").html("[×]");
		
		if(index2>=fileIndex){
			return;
		}
		index2++;
		uploadFile(index2,attachedId);
		return;
	}
	var storeId2=$("#"+attachedId).val();
	if(storeId2){//已经上传，后面追加
		$.ajaxFileUpload({url : ctx+"/store/curlFileStoreAction_appendAffixObject.action?storeId="+storeId2,secureuri : false,fileElementId : 'file'+index,dataType : 'json',success : function(res, status){ //服务器成功响应处理函数
			if(res.state='normal'){
				$("#" + index + "_result").css("color", "green");
				$("#" + index + "_result").html("[√]");
				
				if(index2>=fileIndex){
					return;
				}
				index2++;
				uploadFile(index2,attachedId);
			}else{
				$("#" + index + "_result").css("color", "red");
				$("#" + index + "_result").html("[×]");
			}
		},error : function(res, status, e){//服务器响应失败处理函数
			alert("上传附件异常。");
		}
		});
	}else{
		$.ajaxFileUpload({url : ctx+"/store/curlFileStoreAction_addAffixObject.action",secureuri : false,fileElementId : 'file'+index,dataType : 'json',success : function(res, status){ //服务器成功响应处理函数
			if(res.state='normal'){
				var storeId=res.data;
				$("#"+attachedId).val(storeId);
				$("#" + index + "_result").css("color", "green");
				$("#" + index + "_result").html("[√]");
				if(index2>=fileIndex){
					return;
				}
				index2++;
				uploadFile(index2,attachedId);
			}else{
				$("#" + index + "_result").css("color", "red");
				$("#" + index + "_result").html("[×]");
			}
		},error : function(res, status, e){//服务器响应失败处理函数
			alert("上传附件异常。");
		}
		});
	}
}


function update(){
	var params = $("#updateForm").serializeForm();
	$.post(ctx+"/peopleUseSeal/peopleUseSealInfoAction_update.action",params,function(data){
		if(data.responseMessage.success){
			alert("修改成功");
			$("#updateDiv").dialog("close");
			queryData();
			
		}else{
			alert(data.responseMessage.message);
		}
	});
}

function initUpload(){
	$("#updateBtnUpload").attr("disabled", false);
	$("#btnUpload").attr("disabled", false);
//	$("#attached").attr("disabled", false);
	
	fileIndex=1;
	index2=1;
	$("#uploadDiv").empty();
	var fileInput='<input type="file" id="'+'file'+''+fileIndex+'" name="file"  onkeypress="return false;"  size="40"/><span id="'+fileIndex+'_result"></span>';
	$("#uploadDiv").append(fileInput);
}

function updateSubmitForm(){
	var updateSealType=$("#updateSealType").val();
	$("#hideUpdateSealType").val(updateSealType);
	
	if($("#updateUseSealCausal").val().length>300){
		alert("用印原因最大字数为300");
		return ;
	}
	if($("#updateFileName").val().length>100){
		alert("文件名称最大字数为100");
		return ;
	}
	update();
}

function deletePeopleUseSeal(sid){
	if(!confirm('确定删除？')){
		return;
	}
	var params = {
			'peopleUseSealInfo.sid':sid
	};
	$.post(ctx+"/peopleUseSeal/peopleUseSealInfoAction_delete.action",params,function(data){
		if(data.responseMessage.success){
			alert("删除成功");
			queryData();
		}else{
			alert(data.responseMessage.message);
		}
	});
}

function openFilesDialog(storeId){
	wfStoreFancyBox.showAllThumbnailImageInDialogByStoreId("filesDLG", storeId, "button", "");
}


/**
 * 展示所有图片缩略图<br>
 * 点击缩略图展示图片流
 * 
 * @param divId
 *            缩略图所在的divId
 * @param storeId
 *            文件存储ID
 * @param effectType
 *            展示效果 gallery/buttons/thumbs
 */
wfStoreFancyBox.showAllThumbnailImageByStoreId = function(divId, storeId, effectType) {
	try {
		// 获取图片url
		var docObjects = this.fetchFile(storeId);
		if (docObjects == null || docObjects.length <= 0) {
			this.showMessage("图像未生成");
			return;
		}

		// 动态添加图片显示div
		$("#" + this.fancybox_pelementid).remove();
		var p = "<p id='" + this.fancybox_pelementid + "'></p>";
		$("#" + divId).html(p);
		var run = '2';
		var hasImage = false;
		for ( var i = 0; i < docObjects.length; i++) {
			var url = docObjects[i].fileUrl;
//			var aaa=url.substring(url.indexOf('storeServer')+11);
			url=ctx+"/peopleUseSeal/fileDownloadAction2.action?filePath="+url.substring(url.indexOf('storeServer')+11);
			
			var fileName = docObjects[i].propertyList.origFileName;
			if (url != null && url != undefined && url != "") {
				hasImage = true;
				var path = url.split("/");
				var name = path[path.length - 1].split(".");
				var fileType = name[1];
				var html = null;
//				if("asf" == fileType){
//					var encodeuri = encodeURI(url);
//					html = '<a href="javascript:openvideo(\''+encodeuri+'\')">' + '<img style="width:120px;" src="'+ctx+'/gss/common/js/fancyBox/file.jpg" /></a>&nbsp;';
//					$("#videoDiv").remove();
//					$(document.body).append("<div id='videoDiv'></div>");
//				}else if ("jpg" == fileType || "JPG" == fileType || "png" == fileType || "PNG" == fileType) {
//					var tempUrlPath = url.substring(0,url.lastIndexOf("."));
//					var tempUrlFileType = url.substring(url.lastIndexOf("."));
//					var thumbUrl = tempUrlPath + "_thumb" + tempUrlFileType;
//					if(/msie 8\.0/i.test(navigator.userAgent.toLowerCase())){
//						html = '<a class="' + this.class_arr[effectType] + '" data-fancybox-group="' + effectType
//						+ '" href="' + url + '">' + '<v:image style="width:120px;height:120px;" class="vml" id="storeImg_'+i+'" src="' + thumbUrl + 
//						'" title="' + fileName  + '" /></a>&nbsp;';
//					}else{
//						html = '<a class="' + this.class_arr[effectType] + '" data-fancybox-group="' + effectType
//						+ '" href="' + url + '">' + '<img style="width:120px;" id="storeImg_' + i + '" src="' + thumbUrl
//						+ '" title="' + fileName + '"/></a>&nbsp;';
//					}
//				} else {
//					html = '<a target="_blank" href="' + url + '">' + '<img style="width:120px;" id="storeImg_' + i
//							+ '" src="' + ctx + '/gss/common/js/fancyBox/file.jpg" title="' + fileName + '"/></a>&nbsp;';
//				}
				if (docObjects[i].propertyList.synchroStatus =='2') {
					run = '3';

					html =	'<table><tr><td>附件已转存至FILENET</td></tr>'+
					'<tr><td><span >附件 流水号：</span><span>' + docObjects[i].propertyList.orderNo +'0 </span></td></tr> <tr><td><span> 请联系总行/分行系统管理员获取  </span></td></table>';
					$("#filesDLG1").html('');
					$("#filesDLG1").html(html);
					$("#filesDLG1").attr("title", "图像信息查看");
		    		$("#filesDLG1").dialog("open")
		    		
				}else{
					html = '<a target="_blank" href="' + url + '">' + '<img style="width:120px;" id="storeImg_' + i
					+ '" src="' + ctx + '/gss/common/js/fancyBox/file.jpg" title="' + fileName + '"/></a>&nbsp;';
					$("#" + this.fancybox_pelementid).append(html);
					
				}
			}
		}

		// 添加fancybox图片展示效果
		if (hasImage) {
			if (!this.thumbnailByStoreHasInit) {
				this.initFancybox(effectType);
				this.thumbnailByStoreHasInit = true;
			}
		} else {
			this.showMessage("图像不存在！");
		}
	} catch (e) {
		this.showMessage("展示列表图片失败：" + e.message);
	}
	$("div.fancybox-overlay").bgiframe();
	return run;
};






/**
 * 查询数据，执行查询
 */
function queryData() {
	$("#logPeopleManageList").jqGrid("search", "#queryForm");
}

/**
 * 重置查询条件
 */
function resetMethod() {
	$("#queryForm")[0].reset();
	$("#dialogTwo").dialog("close");
//	initOrgNo();
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo,organizationName){
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#applyOrg").radioOrgTree(true,organizationSid,0,false,function(event, treeId, treeNode){
		if(treeNode){
//			$("#organizationSid_Item").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
//			$("#"+organizationNo).val(treeNode.organizationNo);
			$("#"+organizationNo).val(treeNode.organizationNo);
			$("#"+organizationName).val(treeNode.organizationName);
		}
	});
}

function addPeopleUseSeal(){
	$("#addOrUpdate").val('1');
	
	selectSealType('addSealType');
	
//	apprPeoples('addApprPeople');
//	savePeoples('addSavePeople');
	findOrderNo();
	$("#addDiv").dialog("open");
}

function findOrderNo(){
	$.post(ctx+"/peopleUseSeal/peopleUseSealInfoAction_findOrderNo.action",{},function(data){
		if(data.responseMessage.success){
			$("#addOrderNo").val(data.orderNo);
		}else{
			alert(data.responseMessage.message);
		}
	});
	
}

function selectSealType(sealTypeId){
	var params = {
			
	};
	$.post(ctx+"/report/takeRetuenSealReportAction_findSealType.action",params,function(data){
		if(data.responseMessage.success){
			var sealTypeMap=data.sealMap;
			var sealTypeContent = "<option value=' '>请选择</option>";
			for ( var key in sealTypeMap) {
				sealTypeContent += "<option value='" + key + "'>" + sealTypeMap[key] + "</option>";
			}
			$("#"+sealTypeId).html(sealTypeContent);
			
		}else{
			alert(data.responseMessage.message);
		}
	});
	
}

function apprPeoples(id){
	var params = {
//			'roleGroupSid':'shenpi'
	};
	$.post(ctx+"/peopleUseSeal/peopleUseSealInfoAction_findApprPeople.action",params,function(data){
		if(data.responseMessage.success){
			var apprPeoples=data.list;
			var sealTypeContent = "<option value=' '>请选择</option>";
			for(var i=0;i<apprPeoples.length;i++){
//				sealTypeContent += "<option value='" + apprPeoples[i]['peopleCode'] + "'>" + apprPeoples[i]['peopleName'] + "</option>";
				sealTypeContent += "<option value='" + apprPeoples[i] + "'>" + apprPeoples[i] + "</option>";
			}
			$("#"+id).html(sealTypeContent);
			
		}else{
			alert(data.responseMessage.message);
		}
	});
}

function savePeoples(id){
	var params = {
//			'roleGroupSid':'7524A2D724234E7090822DFA0813A2FE'
	};
	$.post(ctx+"/peopleUseSeal/peopleUseSealInfoAction_findSealStoragePeople.action",params,function(data){
		if(data.responseMessage.success){
			var apprPeoples=data.list;
			var sealTypeContent = "<option value=' '>请选择</option>";
			for(var i=0;i<apprPeoples.length;i++){
//				sealTypeContent += "<option value='" + apprPeoples[i]['peopleCode'] + "'>" + apprPeoples[i]['peopleName'] + "</option>";
				sealTypeContent += "<option value='" + apprPeoples[i] + "'>" + apprPeoples[i] + "</option>";
			}
			$("#"+id).html(sealTypeContent);
			
		}else{
			alert(data.responseMessage.message);
		}
	});
}


function addUploadFile(fileId,attachedId,flag){
	if(flag=="1"){//增加
		var isSensitive=$("#addIsSensitive").val();
		var file=$("#"+fileId).val();
		if(isSensitive==0){
			if(!file){
				$("#"+attachedId).val();
				var file = $("#"+fileId) ;
				file.after(file.clone().val(""));      
				file.remove();
				alert("文件不能为空");
				return;
			}
		}else{
			submitForm();
			return;
		}
	}else{//修改
//		var isSensitive=$("#updateIsSensitive").val();
//		var file=$("#"+fileId).val();
//		if(isSensitive==0){
//			if(!file){
//				alert("文件不能为空");
//				return;
//			}
//		}else{
//			updateSubmitForm();
//			return;
//		}
		var file=$("#"+fileId).val();
		if(!file){
			updateSubmitForm();
			return;
		}
	}
	
//	var storeId2=$("#"+attachedId).val();
//	if(storeId2){//已经上传，后面追加
//		$.ajaxFileUpload({url : ctx+"/store/curlFileStoreAction_appendAffixObject.action?storeId="+storeId2,secureuri : false,fileElementId : fileId,dataType : 'json',success : function(res, status){ //服务器成功响应处理函数
//			if(res.state='normal'){
//				if(flag=="1"){//增加
//					submitForm();
//				}else{//修改
//					updateSubmitForm();
//				}
//			}else{
//				$("#attached").val();
//				var file = $("#addFile") ;
//				file.after(file.clone().val(""));      
//				file.remove();
//				alert("上传附件失败。");
//			}
//		},error : function(res, status, e){//服务器响应失败处理函数
//			$("#attached").val();
//			var file = $("#addFile") ;
//			file.after(file.clone().val(""));      
//			file.remove();
//			alert("上传附件异常。");
//		}
//		});
//	}else{
		$.ajaxFileUpload({url : ctx+"/store/curlFileStoreAction_addAffixObject.action",secureuri : false,fileElementId : fileId,dataType : 'json',success : function(res, status){ //服务器成功响应处理函数
			if(res.state='normal'){
				var storeId=res.data;
				$("#"+attachedId).val(storeId);
				if(flag=="1"){//增加
					submitForm();
				}else{//修改
					updateSubmitForm();
				}
			}else{
				$("#attached").val();
				var file = $("#addFile") ;
				file.after(file.clone().val(""));      
				file.remove();
				alert("上传附件失败。");
			}
		},error : function(res, status, e){//服务器响应失败处理函数
			$("#attached").val();
			var file = $("#addFile") ;
			file.after(file.clone().val(""));      
			file.remove();
			alert("上传附件异常。");
		}
		});
//	}
}


function submitForm(){
	var addSealType=$("#addSealType").val();
	$("#hideAddSealType").val(addSealType);
	if($("#addUseSealCausal").val().length>300){
		alert("用印原因最大字数为300");
		$("#attached").val();
		var file = $("#addFile") ;
		file.after(file.clone().val(""));      
		file.remove();  
		return ;
	}
	if($("#addFileName").val().length>100){
		alert("文件名称最大字数为100");
		$("#attached").val();
		var file = $("#addFile") ;
		file.after(file.clone().val(""));      
		file.remove();
		return ;
	}
	var params = $("#addForm").serializeForm();

	$.post(ctx+"/peopleUseSeal/peopleUseSealInfoAction_add.action",params,function(data){
		if(data.responseMessage.success){
			alert("单笔录入成功");
			$("#addForm")[0].reset();
			$("#addDiv").dialog("close");
			queryData();
			
//			fileIndex=1;
//			$("#uploadDiv").empty();
//			var fileInput='<input type="file" id="'+'file'+''+fileIndex+'" name="file"  onkeypress="return false;"  size="40"/><span id="'+fileIndex+'_result"></span>';
//			$("#uploadDiv").append(fileInput);
		}else{
			$("#attached").val();
			var file = $("#addFile") ;
			file.after(file.clone().val(""));      
			file.remove();
			alert(data.responseMessage.message);
		}
	});
}



//function applyUseSelect() {
//	//判断是否是egde浏览器，其他浏览器正常访问
//	if(window.showModalDialog==undefined){
//		var returnValue = window.open(ctx+"/3x/peopleUseSeal/peopleUseSealBatch/ui/peopleUseSealQueryTask.jsp?peopleSid=" + loginPeople.peopleSid + "&orgName=" + loginPeople.orgName + "&orgNo=" + loginPeople.orgNo + "&boolenPage=1","","width=880,height=510,left=350,top=100,toolbar=no,menubar=no,scrollbars=no,resizable=no,location=no,status=no");
//	}else{
//		var returnValue = window.showModalDialog(ctx+"/3x/peopleUseSeal/peopleUseSealBatch/ui/peopleUseSealQueryTask.jsp",loginPeople,"dialogWidth=880px;dialogHeight=510px;resizable:no;dialogLeft:350px;dialogTop:100px;status:no;scroll:no;resizable:no");
//	}
//	if(!returnValue){
//		return;
//	}
//	//判断是否是egde浏览器，其他浏览器正常访问
//	if(window.showModalDialog!=undefined){
//		document.getElementById("addSealType").value = returnValue.sealType;
////		document.getElementById("sealTypeName").value = returnValue.sealTypeName;
//		document.getElementById("addSealName").value = returnValue.sealName;
//		document.getElementById("addSealOwnerOrg").value = returnValue.sealOrgNo;
//		document.getElementById("addSealOwnerOrgName").value = returnValue.sealOrgName;
//		document.getElementById("sealautoId").value = returnValue.sealApprovalPeople;
//	}
//	var array =new Array();
//	var arrayname =new Array();
//	//判断是否是egde浏览器，其他浏览器正常访问
//	if(window.showModalDialog==undefined){
//		var arr = $("#sealautoId").val();
//	}else{
//		var arr=returnValue.sealApprovalPeople;
//	}
//	
//	var options = '';
//	options+="<option value=\"\">--请选择--</option>";
//	if(arr=='null'||arr==''||!arr){
//		
//	}else{
//		//判断是否是egde浏览器，其他浏览器正常访问
//		if(window.showModalDialog==undefined){
//			array = arr.split(",");
//			arrayname = $("#sealApprovalPeopleName").val().split(",");
//		}else{
//			array=returnValue.sealApprovalPeople.split(",");
//			arrayname=returnValue.sealApprovalPeopleName.split(",");
//		}
//		for (var i=0;i<array.length;i++) {
//			options += "<option value=\""+ queryPeople(array[i])+"\">" + arrayname[i] + "</option>";
//		}
//	}
//	$("#addApprPeople").html(options);
//	//保管人
////	var stoPeople=returnValue.sealStoragePeople;
////	var options2 = '';
////	var array2 =new Array();
////	var arrayname2 =new Array();
////	if(stoPeople){
////		array2=returnValue.sealStoragePeople.split(",");
////		arrayname2=returnValue.sealStoragePeopleName.split(",");
////
////		for (var i=0;i<array2.length;i++) {
////			options2 += "<option value=\""+ queryPeople(array2[i])+"\">" + arrayname2[i] + "</option>";
////		}
////	}
////	$("#addSavePeople").html(options2);
//}

function updateApplyUseSelect(){
	//判断是否是egde浏览器，其他浏览器正常访问
	if(window.showModalDialog==undefined){
		var returnValue = window.open(ctx+"/3x/peopleUseSeal/peopleUseSealBatch/ui/peopleUseSealQueryTask.jsp?peopleSid=" + loginPeople.peopleSid + "&orgName=" + loginPeople.orgName + "&orgNo=" + loginPeople.orgNo + "&boolenPage=2","","width=880,height=510,left=350,top=100,toolbar=no,menubar=no,scrollbars=no,resizable=no,location=no,status=no");
	}else{
		var returnValue = window.showModalDialog(ctx+"/3x/peopleUseSeal/peopleUseSealBatch/ui/peopleUseSealQueryTask.jsp",loginPeople,"dialogWidth=880px;dialogHeight=510px;resizable:no;dialogLeft:350px;dialogTop:100px;status:no;scroll:no;resizable:no");
	}
	if(!returnValue){
		return;
	}
	//判断是否是egde浏览器，其他浏览器正常访问
	if(window.showModalDialog!=undefined){
		document.getElementById("updateSealType").value = returnValue.sealType;
		document.getElementById("updateSealName").value = returnValue.sealName;
		document.getElementById("updateSealOwnerOrg").value = returnValue.sealOrgNo;
		document.getElementById("updateSealOwnerOrgName").value = returnValue.sealOrgName;
		document.getElementById("updateSealautoId").value = returnValue.sealApprovalPeople;
	}
	
	
	var array =new Array();
	var arrayname =new Array();
	//判断是否是egde浏览器，其他浏览器正常访问
	if(window.showModalDialog==undefined){
		var arr = $("#updateSealautoId").val();
	}else{
		var arr=returnValue.sealApprovalPeople;
	}
	var options = '';
	options+="<option value=\"\">--请选择--</option>";
	if(arr=='null'||arr==''||!arr){
		
	}else{
		//判断是否是egde浏览器，其他浏览器正常访问
		if(window.showModalDialog==undefined){
			array = arr.split(",");
			arrayname = $("#sealApprovalPeopleName").val().split(",");
		}else{
			array=returnValue.sealApprovalPeople.split(",");
			arrayname=returnValue.sealApprovalPeopleName.split(",");
		}
		for (var i=0;i<array.length;i++) {
			options += "<option value=\""+ queryPeople(array[i])+"\">" + arrayname[i] + "</option>";
		}
	}
	$("#updateApprPeople").html(options);
	
	
	//保管人
//	var stoPeople=returnValue.sealStoragePeople;
//	var options2 = '';
//	var array2 =new Array();
//	var arrayname2 =new Array();
//	if(stoPeople){
//		array2=returnValue.sealStoragePeople.split(",");
//		arrayname2=returnValue.sealStoragePeopleName.split(",");
//
//		for (var i=0;i<array2.length;i++) {
//			options2 += "<option value=\""+ queryPeople(array2[i])+"\">" + arrayname2[i] + "</option>";
//		}
//	}
//	$("#updateSavePeople").html(options2);
}

function queryPeople(id){
	var result = '';
	var params = {
			'xPeopleInfo.sid':id
	};
	var url=ctx+"/peopleUseSeal/peopleUseSealInfoAction_queryPeopleBySid.action";
	$.ajax({
		type : "post",
		url : url,
		data : params,
		dataType : "json",
		async : false,
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0" || XMLHttpRequest.status != "200") {
				result = "服务器或网络异常";
				alert(result);
			}
		},
		success : function(response) {
			if(response.responseMessage.success){
				if(response.xPeopleInfo){
					result=response.xPeopleInfo.peopleCode;
				}
			}else{
				alert(response.responseMessage.message);
			}
		}
	});
	return result;
	
}

function gradeChange(div){
	
	var objs=document.getElementById(div);
	var grade=objs.options[objs.selectedIndex].value;
	if(grade==1){
		$("#btnUpload").attr("disabled", "disabled");
		$("#attached").attr("disabled", "disabled");
		$("#updateBtnUpload").attr("disabled", "disabled");
		$("#addFile").attr("disabled", "disabled");
		$("#updateFile").attr("disabled", "disabled");
		
	}else{
		$("#btnUpload").attr("disabled", false);
		$("#attached").attr("disabled", false);
		$("#updateBtnUpload").attr("disabled", false);
		$("#addFile").attr("disabled", false);
		$("#updateFile").attr("disabled", false);
		
	}
}


var applyPeopleFlag='';
function apprbtn(flag) {
	applyPeopleFlag=flag;
	$("#dialogTwo").dialog("open");
	initPeople();
};



function initPeople() {
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 100;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	$("#peopleList").jqGrid(
			{
				width : pageContentWidth,
				height : tableHeight + "px",
				url : ctx + "/peopleUseSeal/peopleUseSealInfoAction_queryPeople.action",
				multiselect : false,
				rowNum : 20,
				rownumbers : true,
				viewrecords : true,
				multiselect: true,
				rowList : [ 20, 50, 100 ],
				colNames : [ "","用户姓名", "用户代码"/*, "角色"*/],
				colModel : [
						{
							name : "sid",
							index : "sid",
							align : "center",
							sortable : false,
							hidden:true
						},
						{
							name : "peopleName",
							index : "peopleName",
							align : "center",
							sortable : false
						},
						{
							name : "peopleCode",
							index : "peopleCode",
							align : "center",
							sortable : false
						} ],
				pager : $("#peoplePager"),
				gridComplete: function() {
		            var rowIds = jQuery("#peopleList").jqGrid("getDataIDs");
		            for(var k=0; k<rowIds.length; k++) {
		               var curRowData = jQuery("#peopleList").jqGrid('getRowData', rowIds[k]);
		               var curChk = $("#"+rowIds[k]+"", jQuery("#peopleList")).find(":checkbox");
		               curChk.attr('name', 'personnelCHKBOX');   //给每一个checkbox赋名字
		               curChk.attr('value', curRowData['peopleCode']+','+curRowData['peopleName']);   //给checkbox赋值
		            } 
		        },
				caption : "人员信息查询"
			}).trigger("reloadGrid");
	$("#peopleList").navGrid("#peoplePager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};


function choseOrganizationItem(organizationNo,type) {
//	var organizationSid = top.loginPeopleInfo.orgSid;
	var organizationSid = "00000000000000000000000000000000";
	$("#sealOrgNo_Item").dialogOrgTree("radio", organizationSid, false, null,null, function(event, treeId, treeNode){
		if(treeNode){
			$("#"+organizationNo+"_Item").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
			$("#"+organizationNo + "_Form").val(treeNode.organizationNo);
			$("#orgSid").val(treeNode.sid);
		}
	});
}

/**
 * 查询
 */
function query() {
	queryDatas();
};
/**
 * 查询数据，执行查询
 */
function queryDatas() {
	$("#peopleList").jqGrid('search', "#queryFormTwo");
};


/**
 * 提交表单
 */
function commit() {
	var checkedVals = new Array();
	var checkedPeopleNames=new Array();
	$(":checkbox[name=personnelCHKBOX][checked]").each(function(){
		var people=$(this).val();
		var peopleCode= people.split(',')[0];
		var peopleName= people.split(',')[1];
		checkedVals.push(peopleCode);
		checkedPeopleNames.push(peopleName);
	});
	if(checkedVals.length != 1){
		alert("人员只能选择一个！");
		return;
	}
	if(applyPeopleFlag=='1'){//增加
		$("#addApplyPeople").val(checkedVals.toString());
		$("#addApplyPeopleName").val(checkedPeopleNames.toString());
	}
	if(applyPeopleFlag=='2'){//修改
		$("#updateApplyPeople").val(checkedVals.toString());
		$("#updateApplyPeopleName").val(checkedPeopleNames.toString());
	}
	$("#dialogTwo").dialog("close");
};





//审批人
//function apprPeopleSelect() {
//	var sealautoId= $("#sealautoId").val();
//	if(sealautoId==""){
//		alert("没有印章！");
//		return;
//	}
//	//判断是否是egde浏览器，其他浏览器照常
//	if(window.showModalDialog==undefined){
//		var returnValue = window.open(ctx+"/3x/mech/sealuse/sealUseTask/ui/sealUseApplyHfQueryPeople.jsp?sealautoId=" + sealautoId + "&boolenPage=2","","width=880,height=510,left=350,top=100,toolbar=no,menubar=no,scrollbars=no,resizable=no,location=no,status=no");
//	}else{
//		var returnValue = window.showModalDialog(ctx+"/3x/mech/sealuse/sealUseTask/ui/sealUseApplyHfQueryPeople.jsp",sealautoId,"dialogWidth=880px;dialogHeight=510px;resizable:no;dialogLeft:350px;dialogTop:100px;status:no;scroll:no;resizable:no");
//	}
//	
//	if(returnValue==undefined){
//		return;
//	}
//	//判断是否是egde浏览器，其他浏览器照常
//	if(window.showModalDialog!=undefined){
//		$("#addApprPeople").val( returnValue.peopleCode);
//	}
//}

//审批人
function updateApprPeopleSelect() {
	var sealautoId= $("#updateSealautoId").val();
	if(sealautoId==""){
		alert("没有印章！");
		return;
	}
	//判断是否是egde浏览器，其他浏览器照常
	if(window.showModalDialog==undefined){
		var returnValue = window.open(ctx+"/3x/mech/sealuse/sealUseTask/ui/sealUseApplyHfQueryPeople.jsp?sealautoId=" + sealautoId + "&boolenPage=3","","width=880,height=510,left=350,top=100,toolbar=no,menubar=no,scrollbars=no,resizable=no,location=no,status=no");
	}else{
		var returnValue = window.showModalDialog(ctx+"/3x/mech/sealuse/sealUseTask/ui/sealUseApplyHfQueryPeople.jsp",sealautoId,"dialogWidth=880px;dialogHeight=510px;resizable:no;dialogLeft:350px;dialogTop:100px;status:no;scroll:no;resizable:no");
	}
	if(returnValue==undefined){
		return;
	}
	//判断是否是egde浏览器，其他浏览器照常
	if(window.showModalDialog!=undefined){
		$("#updateApprPeople").val( returnValue.peopleCode);
	}
}

//**********************************************			印章名称弹窗				********************************************************
/**
 * 初始化印章名称列表
 */
function initTaskListSealName(boolenPage) {
	$("#organizationSid_ItemSealName").val(loginPeople.orgName + "(" + loginPeople.orgNo + ")");
	$("#sealOrgNoSealName").val(loginPeople.orgNo);
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 165;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	var url = ctx+ "/mechseal/task/sealUseInstallAction_gainSealInstallList2.action";
	// 用印信息列表
	$("#useSealListSealName").jqGrid(
		{
			width : pageContentWidth,
			height : tableHeight + "px",
			url : url,
			multiselect : false,
			postData : {
				"queryBean.params.like_sealStoragePeople" : loginPeople.peopleSid
			},
			rowNum : 20,
			rownumbers : true,
			sortable : true,// 是否排序
			sortname : "applyDate",
			sortorder : "desc",
			ondblClickRow : function(row) {
				var rowData = $("#useSealListSealName").getRowData(row);
				if(boolenPage == 1){
					$("#addSealType").val(rowData.sealType)
					$("#addSealName").val(rowData.sealName)
					$("#addSealOwnerOrg").val(rowData.sealOrgNo)
					$("#addSealOwnerOrgName").val(rowData.sealOrgName)
					$("#sealautoId").val(rowData.sealApprovalPeople)
					$("#sealApprovalPeopleName").val(rowData.sealApprovalPeopleName)
				}else if(boolenPage == 2){
					//这个赋值方法仅适用于通过window.open()方法打开的父子页面。切勿使用于其他框架。
					window.opener.document.getElementById("updateSealType").value = rowData.sealType;
					window.opener.document.getElementById("updateSealName").value = rowData.sealName;
					window.opener.document.getElementById("updateSealOwnerOrg").value = rowData.sealOrgNo;
					window.opener.document.getElementById("updateSealOwnerOrgName").value = rowData.sealOrgName;
					window.opener.document.getElementById("updateSealautoId").value = rowData.sealApprovalPeople;
				}
				$("#sealNameDialog").dialog("close");
			},
			rowList : [ 20, 50, 100 ],
			colNames : [ "ID", "所属机构", "所属机构名称", "印章种类", "印章类型", "印章类型", "印章名称", "维护时间", "章面字样 ", "审批人", "审批人名称", "印章保管人", "印章保管人", "设备编号", "槽位", "印章状态" ],
			colModel : [
			    {
					name : "autoId",
					index : "autoId",
					align : "center",
					hidden:true,
					sortable : false
				},
				{
					name : "sealOrgNo",
					index : "sealOrgNo",
					align : "center",
					sortable : false
				}, 
				{
					name : "sealOrgName",
					index : "sealOrgName",
					align : "center",
					sortable : false
				}, 
				{
					name : "sealGroup",
					index : "sealGroup",
					align : "center",
					sortable : false
				}, 
				{
					name : "sealType",
					index : "sealType",
					hidden:true,
					align : "center",
					sortable : false
				}, 
				{
					name : "sealTypeName",
					index : "sealTypeName",
					align : "center",
					sortable : false
				}, 
				{
					name : "sealName",
					index : "sealName",
					align : "center",
					sortable : false
				}, 
				{
					name : "maintainTime",
					index : "maintainTime",
					align : "center",
					sortable : false
				}, 
				{
					name : "faceFont",
					index : "faceFont",
					align : "center",
					sortable : false
				}, 
				{
					name : "sealApprovalPeople",
					index : "sealApprovalPeople",
					align : "center",
					width : 80,
					hidden:true,
					sortable : false
				}, 
				{
					name : "sealApprovalPeopleName",
					index : "sealApprovalPeopleName",
					align : "center",
					width : 80,
					sortable : false
				}, 
				{
					name : "sealStoragePeople",
					index : "sealStoragePeople",
					hidden:true,
					align : "center",
					sortable : false
				},
				{
					name : "sealStoragePeopleName",
					index : "sealStoragePeopleName",
					align : "center",
					sortable : false
				},
				{
					name : "deviceNum",
					index : "deviceNum",
					align : "center",
					hidden:true,
					sortable : false
				},
				{
					name : "sealNum",
					index : "sealNum",
					align : "center",
					hidden:true,
					sortable : false
				}, 
				{
					name : "sealStutas",
					index : "sealStutas",
					align : "center",
					sortable : false,
					formatter : function(value, options, rData) {
						if(value == "0"){
							return "启用";
						}else if(value == "1"){
							return "停用";
						}else if(value == "2"){
							return "销毁";
						}
					}
				}
			],
		pager : "#useSealPagerSealName",
		caption : "我的选择列表"
	}).trigger("reloadGrid");
	$("#useSealListSealName").navGrid("#useSealPagerSealName", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

/**
 * 打开印章名称窗口
 */
function openSealNameDialog(boolenPage){
	$("#sealNameDialog").dialog("open");
	initTaskListSealName(boolenPage);
}

/**
 * 印章名称选择机构
 */
function checkOrganizationItemSealName(organizationNo) {
	var organizationSid = "00000000000000000000000000000000";
	$("#organizationSid_ItemSealName").radioOrgTree(true, organizationSid, 0, false, function(event, treeId, treeNode) {
		if (treeNode) {
			$("#organizationSid_ItemSealName").val(treeNode.organizationName + "(" + treeNode.organizationNo + ")");
			$("#sealOrgNoSealName").val(treeNode.organizationNo);
		}
	});
}

/**
 * 印章名称提交头部条件搜索按钮
 */
function querySubmitFomrSealName(){
	$("#useSealListSealName").jqGrid("search", "#queryFormSealName");
}

//*************************************				审批人				*******************************************
/**
 * 初始化任务列表
 */
function initTaskListApprover(boolenPage) {
	var sealautoId = $("#sealautoId").val();
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 165;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight + 6 - 50 * 2;
	var url = ctx+ "/mechseal/task/sealUseInstallAction_queryPeopleByseal.action";
	// 用印信息列表
	$("#usePeopleListApprover").jqGrid(
		{
			width : pageContentWidth,
			height : tableHeight + "px",
			url : url,
			multiselect : false,
			postData:{
				"sealautoId":sealautoId
			},
			rowNum : 1000,
			rownumbers : true,
			sortable : false,// 是否排序
			ondblClickRow : function(row) {
				var rowData = $("#usePeopleListApprover").getRowData(row);
				if(boolenPage == 1){
					$("#apprPeopleName").val(rowData.peopleName);
					$("#apprPeopleSid").val(rowData.sid);
				}else if(boolenPage == 2){
					$("#addApprPeople").val(rowData.peopleCode);
				}else if(boolenPage == 3){
					$("#updateApprPeople").val(rowData.peopleCode);
				}
				$("#sealApproverDialog").dialog("close");
			},
			rowList : [ 20, 50, 100 ],
			colNames : [ "ID","用户姓名(User Name)", "用户代码(User Code)", "所属机构(Affiliated Institution)"],
			colModel : [
			    {
					name : "sid",
					index : "sid",
					align : "center",
					hidden:true,
					sortable : false
				},
				{
					name : "peopleName",
					index : "peopleName",
					align : "center",
					sortable : false
				}, 
				{
					name : "peopleCode",
					index : "peopleCode",
					align : "center",
					sortable : false
				}, 
				{
					name : "orgName",
					index : "orgName",
					align : "center",
					sortable : false
				}
			],
			pager : "#useSealPagerApprover",
			caption : "人员选择列表(User Selection List)"
	}).trigger("reloadGrid");
	$("#usePeopleListApprover").navGrid("#useSealPagerApprover", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
};

/**
 * 打开审批人窗口
 */
function openSealApproverDialog(boolenPage){
	var sealautoId = $("#sealautoId").val();
	if(sealautoId==""){
		alert("请选择印章！");
		return;
	}
	$("#sealApproverDialog").dialog("open");
	initTaskListApprover(boolenPage);
}

/**
 * 审批人打开柜员机构
 */
function checkOrganizationItemApprover(organizationNo) {
	var organizationSid = "00000000000000000000000000000000";
	$("#organizationSid_ItemApprover").radioOrgTree(true, organizationSid, 0, false, function(event, treeId, treeNode) {
		if (treeNode) {
			$("#organizationSid_ItemApprover").val(treeNode.organizationName + "(" + treeNode.organizationNo + ")");
			$("#sealOrgNoApprover").val(treeNode.organizationNo);
		}
	});
}

/**
 * 审批人提交头部条件搜索按钮
 */
function querySubmitFomrApprover(){
	$("#usePeopleListApprover").jqGrid("search", "#queryFormApprover");
}