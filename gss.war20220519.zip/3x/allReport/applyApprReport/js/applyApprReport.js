var sealUseConstants = new Object();
sealUseConstants.SealUseApplyStatus = {
		"0" : "等待提交(Pending Submission)",
		"1" : "等待审批(Pending Approval)",
		"2" : "审批通过(Approved)",
		"3" : "审批拒绝(Rejected)"
    
};

/**
 * 初始化Grid数据
 */
$(function() {
//	initOrgNo();
	initPage();
	queryStatu();
//	initSealType();
//	initSealSeate();
	
	$("#filesDLG1").dialog({
		autoOpen : false,
		resizable : false,
		height: $(window).height() /6*2.7,
		width : $(window).width() /2*0.9,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
});

function initSealType(){
	var params = {
			
	};
	$.post(ctx+"/report/takeRetuenSealReportAction_findSealType.action",params,function(data){
		if(data.responseMessage.success){
			var sealTypeMap=data.sealMap;
			var sealTypeContent = "<option value=' '>全部</option>";
			for ( var key in sealTypeMap) {
				sealTypeContent += "<option value='" + key + "'>" + sealTypeMap[key] + "</option>";
			}
			$("#sealType").html(sealTypeContent);
			
		}else{
			alert(res.responseMessage.message);
		}
	});
	
}

function initSealSeate(){
	var params = {
			
	};
	$.post(ctx+"/report/takeRetuenSealReportAction_findSealState.action",params,function(data){
		if(data.responseMessage.success){
			var sealStateMap=data.sealMap;
			var sealTypeContent = "<option value=''>全部</option>";
			for ( var key in sealStateMap) {
				sealTypeContent += "<option value='" + key + "'>" + sealStateMap[key] + "</option>";
			}
			$("#sealState").html(sealTypeContent);
			
		}else{
			alert(res.responseMessage.message);
		}
	});
}

function initOrgNo() {
	var loginPeople = top.loginPeopleInfo;
	$("#applyOrg").val(loginPeople.orgNo);
	$("#applyOrgName").val(loginPeople.orgName+"("+loginPeople.orgNo+")");
}

function initPage(){
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() -2;
		pageHeaderHeight = pageHeaderHeight.substr(0,pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight -pageHeaderHeight + 6 - 50*2 ;
	$("#logPeopleManageList").jqGrid(
		{
			width : pageContentWidth+300,
			height : tableHeight,
			url : ctx + "/report/applyApprReportAction_list.action",
			multiselect : false,
//			postData : {
//				"queryBean.params.sealOrg" : top.loginPeopleInfo.orgNo
//			},
			rowNum : 20,
			rownumbers : true,
//			sortname : "takeSealDateTime",
//			sortorder : "desc",
			rowList : [ 20, 50, 100 ],
			colNames : [ "流水号", "申请机构名称", "申请人", "申请时间", "文件类型","审批人","保管人","印章类型", "印章所属机构", "印章名称",
							"文件名称","附件", "审批时间","申请审批状态","用印原因","用印状态","用印时间"],
					colModel : [
							{
								name : "tradeCode",
								index : "tradeCode",
								align : "center",
								sortable : false
							},
							{
								name : "applyPeopleOrgName",
								index : "applyPeopleOrgName",
								align : "center",
								sortable : false
							},
							{
								name : "peopleName",
								index : "peopleName",
								align : "center",
								sortable : false
							},
							{
								name : "applyDate",
								index : "applyDate",
								align : "center",
								sortable : false
							},
							{
								name : "applyDate",
								index : "applyDate",
								align : "center",
								sortable : false,
								formatter : function(value, options, rData) {
									return "一般文件";
								}
							},
							{
								name : "nextHandlerName",
								index : "nextHandlerName",
								align : "center",
								sortable : false
							},
							{
								name : "useSealPeopleName",
								index : "useSealPeopleName",
								align : "center",
								width : 160,
								sortable : false,
								formatter : function(value, options, rData) {
									return value;
								}
							},
							 { name : "sealTypeName", 
								index : "sealTypeName",
							 align : "center",
							 sortable : false 
							 },
							 { name : "sealOrgName", 
							  index : "sealOrgName",
							  align : "center", 
							  sortable : false
							  },
							  { name :"title", 
							  index : "title",
							  align :"center",
							  sortable : false 
							  },
							 
							{
								name : "applyTitle",
								index : "applyTitle",
								align : "center",
								sortable : false
							},
							{
								name : "requestId",
								index : "requestId",
								align : "center",
								width : 60,
								sortable : false,
								formatter : function(value, options, rData) {
									if(!value){
										return '无';
									}else{
										var html = "<a onclick=\"openFilesDialog('"
											+ value
											+ "','apply')\" style='text-decoration:underline;color:blue;cursor: hand;'>附件</a>";
										return html;
										
									}
								}
							},
							{
								name : "checkTime",
								index : "checkTime",
								align : "center",
								width : 160,
								sortable : false,
								formatter : function(value, options, rData) {
									return value;
								}
							},
							{
								name : "status",
								index : "status",
								align : "center",
								sortable : false,
								formatter : function(value, options, rData) {
									return sealUseConstants.SealUseApplyStatus[value];
								}
							},{
								name : "useSealReason",
								index : "useSealReason",
								align : "center",
								sortable : false
							},
							{
								name : "usedStatus",
								index : "usedStatus",
								align : "center",
								width : 160,
								sortable : false,
								formatter : function(value, options, rData) {
									return value;
								}
							},
							{
								name : "fileOwnerCode",
								index : "fileOwnerCode",
								align : "center",
								width : 160,
								sortable : false,
								formatter : function(value, options, rData) {
									return value;
								}
							}
							],
			pager : "#logPeopleManagePager",
			caption : "申请及审批列表"
		}).trigger("reloadGrid");
	
	$("#logPeopleManageList").navGrid("#logPeopleManagePager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true,
		excel : false
	}).navButtonAdd('#logPeopleManagePager',{
		caption:"导出excel",
		buttonicon:"ui-icon-excel",
		onClickButton:function(){
			var ge_applyDate = $('#ge_applyDate').val();
			var le_applyDate = $('#le_applyDate').val();
			
			if(le_applyDate=='' || ge_applyDate==''){
				alert('导出时申请时间不能为空');
				return;
			}
			
			$.ajax({
				type : "post",
				url : ctx + "/report/transferPowerReportAction_findSum.action",
				dataType : "json",
				async : false,
				success : function(response) {
					var data = response.data;
					if(MonthsBetw(ge_applyDate,le_applyDate)>data){
					     alert('导出时申请时间不能超出'+ data +'个月');
						return;
					} 
					
					
					var str = '<form id="postForm" action="'+ ctx +'/report/applyApprReportAction_report.action" method="post" style="display:hidden;">'+
					          		'<input type="hidden" id="status" name="status" value="'+ ($('#status').find("option:selected").val()==" "?"":$('#status').find("option:selected").val()) +'" />'+
					                '<input type="hidden" id="useSealPeopleName" name="useSealPeopleName" value="'+ $('#useSealPeopleName').val() +'" />'+
					                '<input type="hidden" id="peopleName" name="peopleName" value="'+ $('#peopleName').val() +'" />'+
					                '<input type="hidden" id="nextHandlerName" name="nextHandlerName" value="'+ $('#nextHandlerName').val() +'" />'+
					                '<input type="hidden" id="ge_applyDate" name="ge_applyDate" value="'+ $('#ge_applyDate').val() +'" />'+
					                '<input type="hidden" id="le_applyDate" name="le_applyDate" value="'+ $('#le_applyDate').val() +'" />'+
					                '<input type="hidden" id="sealOrgNo" name="sealOrgNo" value="'+ $('#sealOrgNo').val() +'" />'+
					                '<input type="hidden" id="applyOrgName" name="applyOrgName" value="'+ $('#applyOrgName').val() +'" />'+
					                '<input type="hidden" id="sealName" name="sealName" value="'+ $('#sealName').val() +'" />'+
					                '<input type="hidden" id="title" name="title" value="'+ $('#title').val() +'" />'+
					                '<input type="hidden" id="tradeCode" name="tradeCode" value="'+ $('#tradeCode').val() +'" />'+
					                '<input type="hidden" id="applyPeopleOrgNo" name="applyPeopleOrgNo" value="'+ $('#applyOrg').val() +'" />'+
					          '</form>';
                   
					$("#div1").html("");
					$("#div1").html(str);
					$("#postForm").submit();
					
					
//					$.ajaxFileUpload({url : ctx + "/report/applyApprReportAction_report.action"+
//					        "?queryBean.params.le_applyDate=" + $('#le_applyDate').val()+
//		                  	"&queryBean.params.ge_applyDate=" +  $('#ge_applyDate').val(),
//		//					"&queryBean.params.like_nextHandlerName=" +  $('#nextHandlerName').val()+
//		//					"&queryBean.params.like_peopleName=" +  $('#peopleName').val()+
//		//					"&queryBean.params.like_useSealPeopleName=" +  $('#useSealPeopleName').val()+
//		//					
//		//					"&queryBean.params.usedStatus=" +   ($('#usedStatus').find("option:selected").val()==undefined?'':$('#usedStatus').find("option:selected").val())+
//		//					"&queryBean.params.status=" +   ($('#status').find("option:selected").val()==" "?'':$('#status').find("option:selected").val())+
//		//					
//		//					"&queryBean.params.sealOrgNo=" +  $('#sealOrgNo').val()+
//		//					"&queryBean.params.applyOrgName=" +  $('#applyOrgName').val()+
//		//					"&queryBean.params.like_tradeCode=" +  $('#tradeCode').val(),
//					        
//					dataType : 'json',
//					success : function(res, status){}
//					})
				}
			})	
			
			
		}
	}) ;
}

function MonthsBetw(date1, date2) {
	var year1 = parseInt(date1.slice(0,4)),
	month1 = parseInt(date1.slice(4,6).slice(0,1)=='0'?date1.slice(4,6).slice(1,2):date1.slice(4,6)),
	year2 = parseInt(date2.slice(0,4)),
	month2 = parseInt(date2.slice(4,6).slice(0,1)=='0'?date2.slice(4,6).slice(1,2):date2.slice(4,6)),
	months = (year2 - year1) * 12 + (month2 - month1);
	return months;
}

function submitForm(){
	update();
}

function deletePeopleUseSeal(sid){
	if(!confirm('确定删除？')){
		return;
	}
	var params = {
			'peopleUseSealInfo.sid':sid
	};
	$.post(ctx+"/peopleUseSeal/peopleUseSealInfoAction_delete.action",params,function(data){
		if(data.responseMessage.success){
			alert("删除成功");
			queryData();
		}else{
			alert(res.responseMessage.message);
		}
	});
}

function queryStatu() {
	var params = {};
	$.post(ctx+"/report/applyApprReportAction_queryStatus.action",params,function(data){
		if(data.responseMessage.success){
			var isFinshUseSealStateMap = data.isFinshUseSealStateMap;
			var apprStatusMap = data.apprStatusMap;
			var isFinshUseSealState = "<option value=' '>全部</option>";
			var apprStatus = "<option value=' '>全部</option>";
			for ( var key in isFinshUseSealStateMap) {
				isFinshUseSealState += "<option value='" + key + "'>" + isFinshUseSealStateMap[key] + "</option>";
			}
			for(var key in apprStatusMap) {
				apprStatus += "<option value='" + key + "'>" + apprStatusMap[key] + "</option>";
			}
			$("#useStatus").html(isFinshUseSealState);
			$("#status").html(apprStatus);
		}else{
			alert(res.responseMessage.message);
		}
	});
}

/**
 * 查询数据，执行查询
 */
function queryData() {
	$("#logPeopleManageList").jqGrid("search", "#queryForm");
}

/**
 * 重置查询条件
 */
function resetMethod() {
	$("#queryForm")[0].reset();
//	initOrgNo();
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo,organizationName){
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#applyOrg").radioOrgTree(true,organizationSid,0,false,function(event, treeId, treeNode){
		if(treeNode){
			$("#"+organizationNo).val(treeNode.organizationNo);
			$("#"+organizationName).val(treeNode.organizationName);
		}
	});
}






function openFilesDialog(storeId){
	wfStoreFancyBox.showAllThumbnailImageInDialogByStoreId("filesDLG", storeId, "button", "");
}

/**
 * 展示所有图片缩略图<br>
 * 点击缩略图展示图片流
 * 
 * @param divId
 *            缩略图所在的divId
 * @param storeId
 *            文件存储ID
 * @param effectType
 *            展示效果 gallery/buttons/thumbs
 */
wfStoreFancyBox.showAllThumbnailImageByStoreId = function(divId, storeId, effectType) {
	try {
		// 获取图片url
		var docObjects = this.fetchFile(storeId);
		if (docObjects == null || docObjects.length <= 0) {
			this.showMessage("图像未生成");
			return;
		}

		// 动态添加图片显示div
		$("#" + this.fancybox_pelementid).remove();
		var p = "<p id='" + this.fancybox_pelementid + "'></p>";
		$("#" + divId).html(p);
		var run = '2';
		var hasImage = false;
		for ( var i = 0; i < docObjects.length; i++) {
			var url = docObjects[i].fileUrl;
//			var aaa=url.substring(url.indexOf('storeServer')+11);
			url=ctx+"/peopleUseSeal/fileDownloadAction2.action?filePath="+url.substring(url.indexOf('storeServer')+11);
			
			var fileName = docObjects[i].propertyList.origFileName;
			if (url != null && url != undefined && url != "") {
				hasImage = true;
				var path = url.split("/");
				var name = path[path.length - 1].split(".");
				var fileType = name[1];
				var html = null;
//				if("asf" == fileType){
//					var encodeuri = encodeURI(url);
//					html = '<a href="javascript:openvideo(\''+encodeuri+'\')">' + '<img style="width:120px;" src="'+ctx+'/gss/common/js/fancyBox/file.jpg" /></a>&nbsp;';
//					$("#videoDiv").remove();
//					$(document.body).append("<div id='videoDiv'></div>");
//				}else if ("jpg" == fileType || "JPG" == fileType || "png" == fileType || "PNG" == fileType) {
//					var tempUrlPath = url.substring(0,url.lastIndexOf("."));
//					var tempUrlFileType = url.substring(url.lastIndexOf("."));
//					var thumbUrl = tempUrlPath + "_thumb" + tempUrlFileType;
//					if(/msie 8\.0/i.test(navigator.userAgent.toLowerCase())){
//						html = '<a class="' + this.class_arr[effectType] + '" data-fancybox-group="' + effectType
//						+ '" href="' + url + '">' + '<v:image style="width:120px;height:120px;" class="vml" id="storeImg_'+i+'" src="' + thumbUrl + 
//						'" title="' + fileName  + '" /></a>&nbsp;';
//					}else{
//						html = '<a class="' + this.class_arr[effectType] + '" data-fancybox-group="' + effectType
//						+ '" href="' + url + '">' + '<img style="width:120px;" id="storeImg_' + i + '" src="' + thumbUrl
//						+ '" title="' + fileName + '"/></a>&nbsp;';
//					}
//				} else {
//					html = '<a target="_blank" href="' + url + '">' + '<img style="width:120px;" id="storeImg_' + i
//							+ '" src="' + ctx + '/gss/common/js/fancyBox/file.jpg" title="' + fileName + '"/></a>&nbsp;';
//				}
				
				if (docObjects[i].propertyList.synchroStatus =='2') {
					run = '3';

					html =	'<table><tr><td>附件已转存至FILENET</td></tr>'+
//					'<tr><td><span > 批次流水号：</span><span>' + docObjects[i].propertyList.orderNo  +'</span></td></tr>'+
					'<tr><td><span > 附件流水号：</span><span>' + docObjects[i].propertyList.orderNo  +'0</span></td></tr>'+
					'<tr><td><span > 请联系总行/分行系统管理员获取 </span></td></tr>'+
					'</table>';
					$("#filesDLG1").html('');
					$("#filesDLG1").html(html);
					$("#filesDLG1").attr("title", "图像信息查看");
		    		$("#filesDLG1").dialog("open")
		    		
				}else{
					html = '<a target="_blank" href="' + url + '">' + '<img style="width:120px;" id="storeImg_' + i
					+ '" src="' + ctx + '/gss/common/js/fancyBox/file.jpg" title="' + fileName + '"/></a>&nbsp;';
					$("#" + this.fancybox_pelementid).append(html);
				}
			}
		}

		// 添加fancybox图片展示效果
		if (hasImage) {
			if (!this.thumbnailByStoreHasInit) {
				this.initFancybox(effectType);
				this.thumbnailByStoreHasInit = true;
			}
		} else {
			this.showMessage("图像不存在！");
		}
	} catch (e) {
		this.showMessage("展示列表图片失败：" + e.message);
	}
	$("div.fancybox-overlay").bgiframe();
	return run;
};
