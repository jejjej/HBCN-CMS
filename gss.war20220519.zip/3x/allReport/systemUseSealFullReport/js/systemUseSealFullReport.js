


/**
 * 初始化Grid数据
 */
$(function() {
//	initOrgNo();
	initSealType();
	initPage();
	initshowImage();
});

function initSealType(){
	var params = {
			
	};
	$.post(ctx+"/report/takeRetuenSealReportAction_findSealType.action",params,function(data){
		if(data.responseMessage.success){
			var sealTypeMap=data.sealMap;
			var sealTypeContent = "<option value=' '>全部</option>";
			for ( var key in sealTypeMap) {
				sealTypeContent += "<option value='" + key + "'>" + sealTypeMap[key] + "</option>";
			}
			$("#sealType").html(sealTypeContent);
			
		}else{
			alert(res.responseMessage.message);
		}
	});
	
}

function initOrgNo() {
	var loginPeople = top.loginPeopleInfo;
//	$("#organizationSid_Item").val(loginPeople.orgName+"("+loginPeople.orgNo+")");
//	$("#operatorOrgNo").val(loginPeople.orgNo);
	$("#applyOrg").val(loginPeople.orgNo);
	$("#applyOrgName").val(loginPeople.orgName);
}

function initPage(){
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() -2;
		pageHeaderHeight = pageHeaderHeight.substr(0,pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight -pageHeaderHeight + 6 - 50*2 ;
	$("#logPeopleManageList").jqGrid(
		{
			width : 2000,
			height : tableHeight,
			url : ctx + "/report/systemUseSealFullAction_list.action",
			multiselect : false,
//			postData : {
//				"queryBean.params.applyOrg" : top.loginPeopleInfo.orgNo
//			},
			rowNum : 20,
			rownumbers : true,
//			sortname : "applyTime",
//			sortorder : "desc",
			rowList : [ 20, 50, 100 ],
			colNames : ["流水号", "申请机构", "申请人","申请时间", "审批人", "审批时间", "印章所属机构", "印章名称", 
			            "文件类型", "文件名称", "高敏感信息", "用印原因", "用印时间","用印次数","普通用印次数","骑缝用印次数", "保管人", "附件","图像信息" ],
//			            "文件类型",   "印章类型",   "申请审批状态",   

			            colModel : [
			    					{
			    						name : "UseSealBizInfo.requestId",
			    						index : "UseSealBizInfo.requestId",
			    						align : "center",
			    						width : 100,
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							return value;
			    						}
			    					},
			    					{
			    						name : "UseSealBizInfo.applyOrgName",
			    						index : "UseSealBizInfo.applyOrgName",
			    						align : "center",
			    						width : 200,
			    						sortable : false
			    					},
			    					{
			    						name : "applyPeopleName",
			    						index : "applyPeopleName",
			    						align : "center",
			    						width : 120,
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							return value;
			    						}
			    					},
			    					{
			    						name : "applyTime",
			    						index : "applyTime",
			    						align : "center",
			    						width : 120,
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							return value;
			    						}
			    					},
			    					{
			    						name : "checkPeopleName",
			    						index : "checkPeopleName",
			    						align : "center",
			    						width : 120,
			    						sortable : false
			    					},
			    					{
			    						name : "UseSealBizInfo.checkTime",
			    						index : "UseSealBizInfo.checkTime",
			    						align : "center",
			    						width : 120,
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							return value;
			    						}
			    					},
			    					{
			    						name : "sealOrgNo",
			    						index : "sealOrgNo",
			    						align : "center",
			    						width : 200,
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							return value;
			    						}
			    					},
			    					{
			    						name : "sealName",
			    						index : "sealName",
			    						align : "center",
			    						width : 120,
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							return value;
			    						}
			    					},
			    					{
			    						name : "fileName",
			    						index : "fileName",
			    						align : "center",
			    						width : 120,
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							return "一般文件";
			    						}
			    					},
			    					{
			    						name : "fileName",
			    						index : "fileName",
			    						align : "center",
			    						width : 120,
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							return value;
			    						}
			    					},
			    					{
			    						name : "UseSealBizInfo.isInclouldSecret",
			    						index : "UseSealBizInfo.isInclouldSecret",
			    						align : "center",
			    						width : 100,
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							if(value=='0'){
			    								return '否';
			    							}
			    							return '是';
			    						}
			    					},
			    					{
			    						name : "UseSealBizInfo.useSealCause",
			    						index : "UseSealBizInfo.useSealCause",
			    						align : "center",
			    						width : 200,
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							return value;
			    						}
			    					},
			    					{
			    						name : "checkCode",
			    						index : "checkCode",
			    						align : "center",
			    						width : 100,
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							return value;
			    						}
			    					},
			    					{
			    						name : "UseSealBizInfo.useSealCnt",
			    						index : "UseSealBizInfo.useSealCnt",
			    						align : "center",
			    						width : 50,
			    						sortable : false
			    					},
			    					{
			    						name : "UseSealBizInfo.useSealNomalCnr",
			    						index : "UseSealBizInfo.useSealNomalCnr",
			    						align : "center",
			    						width : 50,
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							if(value==""||value==null){
			    								value="0";
			    							}

			    							return value;
			    						}
			    					}
			    					,
			    					{
			    						name : "useSealSeamwordScnr",
			    						index : "useSealSeamwordScnr",
			    						width : 50,
			    						align : "center",
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							if(value==""||value==null){
			    								value="0";
			    							}

			    							return value;
			    						}
			    					},
			    					{
			    						name : "useSealPeopleName",
			    						index : "useSealPeopleName",
			    						align : "center",
			    						width : 120,
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							return value;
			    						}
			    					},
			    					{
			    						name : "UseSealBizInfo.storeId",
			    						index : "UseSealBizInfo.storeId",
			    						align : "center",
			    						width : 80,
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							if(!value){
			    								return '无';
			    							}else{
			    								if(rData.isInclouldSecret==0){
			    									var html = "<a onclick=\"openFilesDialog('"
			    										+ value
			    										+ "','apply')\" style='text-decoration:underline;color:blue;cursor: hand;'>附件</a>";
			    									return html;
			    								}
			    								
			    							}
			    						}
			    					},
			    					{
			    						name : "autoId",
			    						index : "autoId",
			    						width : 100,
			    						align : "center",
			    						sortable : false,
			    						formatter : function(value, options, rData) {
			    							
//			    							console.log();
//			    							console.log(rData);
//			    							console.log('useSealCnt       '+rData.useSealCnt);
//			    							console.log('UseSealBizInfo.useSealCnt       '+);
//						
////			    							if(rData.isInclouldSecret==0 && rData.useSealCnt!=null && (rData.useSealCnt>0 || rData.useSealSeamwordScnr>0 || rData.useSealNomalCnr>0)){
			    							if(rData.isInclouldSecret==0 && rData['UseSealBizInfo.useSealCnt']>0 ){
				                                 
			    								return "<button onClick=\"showImage1('"+value+"');return false;\">查看图像</button>";
			    							}
			    							
			    						}
			    					}
			    					
			    					],            
			            
			            
			            
//			colModel : [
//					{
//						name : "UseSealBizInfo.requestId",
//						index : "UseSealBizInfo.requestId",
//						align : "center",
//						width : 100,
//						sortable : false,
//						formatter : function(value, options, rData) {
//							return value;
//						}
//					},
//					{
//						name : "UseSealBizInfo.applyOrgName",
//						index : "UseSealBizInfo.applyOrgName",
//						align : "center",
//						width : 200,
//						sortable : false
//					},
//					{
//						name : "applyPeopleName",
//						index : "applyPeopleName",
//						align : "center",
//						width : 120,
//						sortable : false,
//						formatter : function(value, options, rData) {
//							return value;
//						}
//					},
//					{
//						name : "applyTime",
//						index : "applyTime",
//						align : "center",
//						width : 120,
//						sortable : false,
//						formatter : function(value, options, rData) {
//							return value;
//						}
//					},
//					{
//						name : "checkPeopleName",
//						index : "checkPeopleName",
//						align : "center",
//						width : 120,
//						sortable : false
//					},
//					{
//						name : "UseSealBizInfo.checkTime",
//						index : "UseSealBizInfo.checkTime",
//						align : "center",
//						width : 120,
//						sortable : false,
//						formatter : function(value, options, rData) {
//							return value;
//						}
//					},
//					{
//						name : "sealOrgNo",
//						index : "sealOrgNo",
//						align : "center",
//						width : 200,
//						sortable : false,
//						formatter : function(value, options, rData) {
//							return value;
//						}
//					},
//					{
//						name : "sealName",
//						index : "sealName",
//						align : "center",
//						width : 120,
//						sortable : false,
//						formatter : function(value, options, rData) {
//							return value;
//						}
//					},
//					{
//						name : "fileName",
//						index : "fileName",
//						align : "center",
//						width : 120,
//						sortable : false,
//						formatter : function(value, options, rData) {
//							return "一般文件";
//						}
//					},
//					{
//						name : "fileName",
//						index : "fileName",
//						align : "center",
//						width : 120,
//						sortable : false,
//						formatter : function(value, options, rData) {
//							return value;
//						}
//					},
//					{
//						name : "UseSealBizInfo.isInclouldSecret",
//						index : "UseSealBizInfo.isInclouldSecret",
//						align : "center",
//						width : 100,
//						sortable : false,
//						formatter : function(value, options, rData) {
//							if(value=='0'){
//								return '否';
//							}
//							return '是';
//						}
//					},
//					{
//						name : "UseSealBizInfo.useSealCause",
//						index : "UseSealBizInfo.useSealCause",
//						align : "center",
//						width : 200,
//						sortable : false,
//						formatter : function(value, options, rData) {
//							return value;
//						}
//					},
//					{
//						name : "checkCode",
//						index : "checkCode",
//						align : "center",
//						width : 100,
//						sortable : false,
//						formatter : function(value, options, rData) {
//							return value;
//						}
//					},
//					{
//						name : "UseSealBizInfo.useSealCnt",
//						index : "UseSealBizInfo.useSealCnt",
//						align : "center",
//						width : 50,
//						sortable : false,
//						formatter : function(value, options, rData) {
//							return value;
//						}
//					},
//					{
//						name : "UseSealBizInfo.useSealNomalCnr",
//						index : "UseSealBizInfo.useSealNomalCnr",
//						align : "center",
//						width : 50,
//						sortable : false,
//						formatter : function(value, options, rData) {
//							return value;
//						}
//					}
//					,
//					{
//						name : "useSealSeamwordScnr",
//						index : "useSealSeamwordScnr",
//						width : 50,
//						align : "center",
//						sortable : false,
//						formatter : function(value, options, rData) {
//							return value;
//						}
//					},
//					{
//						name : "useSealPeopleName",
//						index : "useSealPeopleName",
//						align : "center",
//						width : 120,
//						sortable : false,
//						formatter : function(value, options, rData) {
//							return value;
//						}
//					},
//					{
//						name : "UseSealBizInfo.storeId",
//						index : "UseSealBizInfo.storeId",
//						align : "center",
//						width : 80,
//						sortable : false,
//						formatter : function(value, options, rData) {
//							if(!value){
//								return '无';
//							}else{
//								if(rData.isInclouldSecret==0){
//									var html = "<a onclick=\"openFilesDialog('"
//										+ value
//										+ "','apply')\" style='text-decoration:underline;color:blue;cursor: hand;'>附件</a>";
//									return html;
//								}
//								
//							}
//						}
//					},
//					{
//						name : "autoId",
//						index : "autoId",
//						width : 100,
//						align : "center",
//						sortable : false,
//						formatter : function(value, options, rData) {
//							if(rData.isInclouldSecret==0 && rData.useSealCnt!=null && rData.useSealCnt>0){
//								return "<button onClick=\"showImage('"+value+"');return false;\">查看图像</button>";
//							}
//							
//						}
//					}
//					
//					],
			pager : "#logPeopleManagePager",
			caption : "系统用印列表"
		}).trigger("reloadGrid");
	$("#logPeopleManageList").navGrid("#logPeopleManagePager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true,
		excel : false
	})
	.navButtonAdd('#logPeopleManagePager',{
		caption:"导出excel",
		buttonicon:"ui-icon-excel", 
		onClickButton:function(){
			var ge_applyTime = $('#ge_applyTime').val();
			var le_applyTime = $('#le_applyTime').val();
			var ge_checkCode = $('#ge_checkCode').val();
			var le_checkCode = $('#le_checkCode').val();
			
			if((ge_applyTime=='' || le_applyTime=='')&&(ge_checkCode=='' || le_checkCode=='')){
				alert('导出时申请时间与用印日期不能为空');
				return;
			}
			if(ge_applyTime!='' && ge_checkCode!='' ){
				if(le_applyTime == ''){
					alert('导出时申请时间不能为空');
					return;
				}
				if(le_checkCode == ''){
					alert('导出时用印日期不能为空');
					return;
				}
			}
			if(le_applyTime!='' && le_checkCode!='' ){
				if(ge_applyTime == ''){
					alert('导出时申请时间不能为空');
					return;
				}
				if(ge_checkCode == ''){
					alert('导出时用印日期不能为空');
					return;
				}
			}
			$.ajax({
				type : "post",
				url : ctx + "/report/transferPowerReportAction_findSum.action",
				dataType : "json",
				async : false,
				success : function(response) {
					var data = response.data;
					var n = true;
					if(ge_applyTime!='' || le_applyTime!=''){
						if(MonthsBetw(ge_applyTime,le_applyTime)>data){
						    alert('导出时申请时间不能超出'+ data +'个月');
							n = false;
							return;
						} 
					}
					if(n){
						if(ge_checkCode!='' || le_checkCode!=''){
							if(MonthsBetw(ge_checkCode,le_checkCode)>data){
							    alert('导出时用印日期不能超出'+ data +'个月');
								return;
							} 
						}
					}
					
					var str = '<form id="postForm" action="'+ ctx +'/report/systemUseSealFullAction_report.action" method="post" style="display:hidden;">'+
					          		'<input type="hidden" id="sealType" name="sealType" value="'+ ($('#sealType').find("option:selected").val()==" "?"":$('#sealType').find("option:selected").val()) +'" />'+
					                '<input type="hidden" id="applyPeopleName" name="applyPeopleName" value="'+ $('#applyPeopleName').val() +'" />'+
					                '<input type="hidden" id="useSealPeopleName" name="useSealPeopleName" value="'+ $('#useSealPeopleName').val() +'" />'+
					                '<input type="hidden" id="checkPeopleName" name="checkPeopleName" value="'+ $('#checkPeopleName').val() +'" />'+
					                '<input type="hidden" id="ge_applyTime" name="ge_applyTime" value="'+ $('#ge_applyTime').val() +'" />'+
					                '<input type="hidden" id="le_applyTime" name="le_applyTime" value="'+ $('#le_applyTime').val() +'" />'+
					                '<input type="hidden" id="ge_checkCode" name="ge_checkCode" value="'+ $('#ge_checkCode').val() +'" />'+
					                '<input type="hidden" id="le_checkCode" name="le_checkCode" value="'+ $('#le_checkCode').val() +'" />'+
					                '<input type="hidden" id="sealOrgNo" name="sealOrgNo" value="'+ $('#sealOrgNo').val() +'" />'+
					                '<input type="hidden" id="fileName" name="fileName" value="'+ $('#fileName').val() +'" />'+
//					                '<input type="hidden" id="isInclouldSecret" name="isInclouldSecret"value="'+  $('#isInclouldSecret').find("option:selected").val() +'" />'+
					                '<input type="hidden" id="sealName" name="sealName" value="'+ $('#sealName').val() +'" />'+
					                '<input type="hidden" id="applyOrgName" name="applyOrgName" value="'+ $('#applyOrgName').val() +'" />'+
					                '<input type="hidden" id="requestId" name="requestId" value="'+ $('#requestId').val() +'" />'+
					                '<input type="hidden" id="applyOrgNo" name="applyOrgNo" value="'+ $('#applyOrg').val() +'" />'+
					          '</form>';
                   
					$("#div1").html("");
					$("#div1").html(str);
					$("#postForm").submit();
					
					
//					$.post(ctx+"/report/systemUseSealFullAction_report.action",params,function(data){
//						
//					});
					
//					$.ajaxFileUpload({url : ctx + "/report/systemUseSealFullAction_report.action"+
//					        "?queryBean.params.ge_applyTime=" + $('#ge_applyTime').val()+
//		                  	"&queryBean.params.le_applyTime=" +  $('#le_applyTime').val()+
//					        "&queryBean.params.ge_checkCode=" + $('#ge_checkCode').val()+
//		                  	"&queryBean.params.le_checkCode=" +  $('#le_checkCode').val(),
//		//					"&queryBean.params.like_checkPeopleName=" +  $('#checkPeopleName').val()+
//		//					"&queryBean.params.sealOwnerOrgName=" +  $('#sealOwnerOrgName').val()+
//		//					"&queryBean.params.like_fileName=" +  $('#fileName').val()+
//		//					
//		//					"&queryBean.params.sealType=" +   ($('#sealType').find("option:selected").val()==" "?"":$('#sealType').find("option:selected").val())+
//		//					"&queryBean.params.isInclouldSecret_int=" +   $('#isInclouldSecret').find("option:selected").val()+
//		//					
//		//					"&queryBean.params.like_sealName=" +  $('#sealName').val()+
//		//					"&queryBean.params.like_useSealPeopleName=" +  $('#useSealPeopleName').val()+
//		//					"&queryBean.params.like_applyPeopleName=" +  $('#applyPeopleName').val()+
//		//					"&queryBean.params.applyOrgName=" +  $('#applyOrgName').val()+
//		//					"&queryBean.params.like_requestId=" +  $('#requestId').val(),
//					        
//					dataType : 'json',
//					success : function(res, status){}
//					})
				}
			})	
			
			
		}
	}) ;
}

var allcnt;
var nowcnt;
var localautoid;
function showImage1(autoid){
	localautoid = autoid;
	//查询用印有多少图像，返回记录数
	$.ajax({
	    type:"post",
	    url: ctx + "/report/systemUseSealFullAction_imageUnm.action?bizkey="+autoid,
	    success:function(res) {
	    	allcnt = res.map.size;
	    	allcnt1 = res.map.synchroStatus;
	    	tlist = res.map.tlist;
	    	
	    	if (allcnt1 != '2') {
				
	    		nowcnt = 1;
	    		$("#showImage").attr("title", "图像信息查看");
	    		$("#showImage").dialog("open");
	    		$.ajax({
	    			type:"post",
	    			url: ctx + "/report/systemUseSealFullAction_showImage.action",
	    			data : {
	    				bizkey : localautoid,
	    				pageindex : nowcnt
	    			},
	    			success:function(dataa) {
	    				var element = document.getElementById('useImage');
	    				element.src =dataa;
	    			},
	    			error:function() {
	    				alert("数据请求失败");
	    			}
	    		});
			} else {
				
				var str =	'<table><tr><td>图像已转存至FILENET</td></tr>';
//				for ( var i = 0; i < tlist.length; i++) {
//					str += '<tr><td><span >批次 流水号：</span><span>' + tlist[0] +'</span></td></tr>';
					str += '<tr><td><span >用印影像 流水号：</span><span>' + tlist[0] +'1</span></td></tr>';
//				}
				str += '<tr><td><span> 请联系总行/分行系统管理员获取  </span></td></tr></table>';
				
				$("#showImage1").html('');
				$("#showImage1").html(str);
				$("#showImage1").attr("title", "图像信息查看");
	    		$("#showImage1").dialog("open");
	    		
	    		
	    		
	    		
	    		
	    		
//	    		$("#fj").text(objectid);
//	    		$("#yq").text(objectid +"_0");
//	    		$("#yh").text(objectid +"_1");
	    		
			}
	    	
	    	
	    	
	    },
	    error:function() {
	        alert("数据请求失败");
	    }
	});
}
function MonthsBetw(date1, date2) {
	date1 = date1.split("-");
	date2 = date2.split("-");
	var year1 = parseInt(date1[0]),
	month1 = parseInt(date1[1].slice(0,1)=='0'?date1[1].slice(1,2):date1[1]),
	year2 = parseInt(date2[0]),
	month2 = parseInt(date2[1].slice(0,1)=='0'?date2[1].slice(1,2):date2[1]),
	months = (year2 - year1) * 12 + (month2 - month1);
	return months;
}
function lastpageimage(){
	if((nowcnt-1)<=0){
		   alert("已经是第一页");
		   return ;
	}
	$.ajax({
	    type:"post",
	    url: ctx + "/report/systemUseSealFullAction_lastpageimage.action",
	    data : {
	    	bizkey : localautoid,
	    	pageindex : nowcnt-1
	    },
	    success:function(dataa) {
	    	var element = document.getElementById('useImage');
            element.src =dataa;
            nowcnt = nowcnt-1;
	    },
	    error:function() {
	        alert("数据请求失败");
	    }
	});
}

function nextpageimage(){
	if((nowcnt+1)>allcnt){
		   alert("已达到最大页");
		   return ;
	}
	$.ajax({
	    type:"post",
	    url: ctx + "/report/systemUseSealFullAction_nextpageimage.action",
	    data : {
	    	bizkey : localautoid,
	    	pageindex : nowcnt+1
	    },
	    success:function(dataa) {
	    	var element = document.getElementById('useImage');
            element.src =dataa;
            nowcnt = nowcnt+1;
	    },
	    error:function() {
	        alert("数据请求失败");
	    }
	});
}

function initshowImage() {
	$("#showImage").dialog({
		autoOpen : false,
		resizable : false,
		height: $(window).height() /3*2.7,
		width : $(window).width() /2*0.9,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
	$("#showImage1").dialog({
		autoOpen : false,
		resizable : false,
		height: $(window).height() /6*2.7,
		width : $(window).width() /2*0.9,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
	$("#filesDLG1").dialog({
		autoOpen : false,
		resizable : false,
		height: $(window).height() /6*2.7,
		width : $(window).width() /2*0.9,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
};

function openFilesDialog(storeId){
	wfStoreFancyBox.showAllThumbnailImageInDialogByStoreId("filesDLG", storeId, "button", "");
}

/**
 * 展示所有图片缩略图<br>
 * 点击缩略图展示图片流
 * 
 * @param divId
 *            缩略图所在的divId
 * @param storeId
 *            文件存储ID
 * @param effectType
 *            展示效果 gallery/buttons/thumbs
 */
wfStoreFancyBox.showAllThumbnailImageByStoreId = function(divId, storeId, effectType) {
	try {
		// 获取图片url
		var docObjects = this.fetchFile(storeId);
		if (docObjects == null || docObjects.length <= 0) {
			this.showMessage("图像未生成");
			return;
		}

		// 动态添加图片显示div
		$("#" + this.fancybox_pelementid).remove();
		var p = "<p id='" + this.fancybox_pelementid + "'></p>";
		$("#" + divId).html(p);

		var hasImage = false;
		var run = '2';
		
		for ( var i = 0; i < docObjects.length; i++) {
			var url = docObjects[i].fileUrl;
//			var aaa=url.substring(url.indexOf('storeServer')+11);
			url=ctx+"/peopleUseSeal/fileDownloadAction2.action?filePath="+url.substring(url.indexOf('storeServer')+11);
			
			var fileName = docObjects[i].propertyList.origFileName;
			
			
			
			if (url != null && url != undefined && url != "") {
				hasImage = true;
				var path = url.split("/");
				var name = path[path.length - 1].split(".");
				var fileType = name[1];
				var html = null;
//				if("asf" == fileType){
//					var encodeuri = encodeURI(url);
//					html = '<a href="javascript:openvideo(\''+encodeuri+'\')">' + '<img style="width:120px;" src="'+ctx+'/gss/common/js/fancyBox/file.jpg" /></a>&nbsp;';
//					$("#videoDiv").remove();
//					$(document.body).append("<div id='videoDiv'></div>");
//				}else if ("jpg" == fileType || "JPG" == fileType || "png" == fileType || "PNG" == fileType) {
//					var tempUrlPath = url.substring(0,url.lastIndexOf("."));
//					var tempUrlFileType = url.substring(url.lastIndexOf("."));
//					var thumbUrl = tempUrlPath + "_thumb" + tempUrlFileType;
//					if(/msie 8\.0/i.test(navigator.userAgent.toLowerCase())){
//						html = '<a class="' + this.class_arr[effectType] + '" data-fancybox-group="' + effectType
//						+ '" href="' + url + '">' + '<v:image style="width:120px;height:120px;" class="vml" id="storeImg_'+i+'" src="' + thumbUrl + 
//						'" title="' + fileName  + '" /></a>&nbsp;';
//					}else{
//						html = '<a class="' + this.class_arr[effectType] + '" data-fancybox-group="' + effectType
//						+ '" href="' + url + '">' + '<img style="width:120px;" id="storeImg_' + i + '" src="' + thumbUrl
//						+ '" title="' + fileName + '"/></a>&nbsp;';
//					}
//				} else {
//					html = '<a target="_blank" href="' + url + '">' + '<img style="width:120px;" id="storeImg_' + i
//							+ '" src="' + ctx + '/gss/common/js/fancyBox/file.jpg" title="' + fileName + '"/></a>&nbsp;';
//				}
				if (docObjects[i].propertyList.synchroStatus =='2') {
					run = '3';

					html =	'<table><tr><td>附件已转存至FILENET</td></tr>'+
//					'<tr><td><span >批次 流水号：</span><span>' + docObjects[i].propertyList.orderNo +'</span></td></tr>'+
					'<tr><td><span >附件 流水号：</span><span>' + docObjects[i].propertyList.orderNo +'0</span></td></tr>'+
					'<tr><td><span> 请联系总行/分行系统管理员获取  </span></td></tr></table>';
					$("#filesDLG1").html('');
					$("#filesDLG1").html(html);
					$("#filesDLG1").attr("title", "图像信息查看");
		    		$("#filesDLG1").dialog("open")
		    		
				}else{
					html = '<a target="_blank" href="' + url + '">' + '<img style="width:120px;" id="storeImg_' + i
					+ '" src="' + ctx + '/gss/common/js/fancyBox/file.jpg" title="' + fileName + '"/></a>&nbsp;';
					$("#" + this.fancybox_pelementid).append(html);
				}
			}
		}

		// 添加fancybox图片展示效果
		
		if (hasImage) {
			if (!this.thumbnailByStoreHasInit) {
				this.initFancybox(effectType);
				this.thumbnailByStoreHasInit = true;
			}
		} else {
			this.showMessage("图像不存在！");
		}
	} catch (e) {
		this.showMessage("展示列表图片失败：" + e.message);
	}
	$("div.fancybox-overlay").bgiframe();
	
	return run;
};

/**
 * 查询数据，执行查询
 */
function queryData() {
	$("#logPeopleManageList").jqGrid("search", "#queryForm");
}

/**
 * 重置查询条件
 */
function resetMethod() {
	$("#queryForm")[0].reset();
//	initOrgNo();
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo,organizationName){
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#applyOrg").radioOrgTree(true,"00000000000000000000000000000000",0,false,function(event, treeId, treeNode){
		if(treeNode){
//			$("#organizationSid_Item").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
//			$("#"+organizationNo).val(treeNode.organizationNo);
			$("#"+organizationNo).val(treeNode.organizationNo);
			$("#"+organizationName).val(treeNode.organizationName);
		}
	});
}

/**
 * 选择机构
 */
function checkOrganizationItem1(organizationNo,organizationName){
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#sealOrgNo").radioOrgTree(true,organizationSid,0,false,function(event, treeId, treeNode){
		if(treeNode){
//			$("#organizationSid_Item").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
//			$("#"+organizationNo).val(treeNode.organizationNo);
//			$("#sealOrgNo").val(treeNode.organizationNo);
			$("#"+organizationNo).val(treeNode.organizationNo);
			$("#"+organizationName).val(treeNode.organizationName);
		}
	});
}