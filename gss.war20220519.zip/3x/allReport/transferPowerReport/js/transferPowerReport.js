/**
 * 初始化Grid数据
 */
$(function() {
	initPage();
	
//	//当前时间
//	var dates = new Date;
//	var year = dates.getFullYear(); //获取当前年
//	var mon = dates.getMonth() + 1; //获取当前月
//	var date = dates.getDate(); //获取当前日
//	//最小时间
//	var yearmin;  //根据当前时间为中点往前前2.5年的年份
//	var monmin;  //根据当前时间为中点往前推2.5年的月份
//	var datemin;  //根据当前时间为中点往前推能2.5的日
//	//最大时间
//	var yearmax;  //根据当前时间为中点往后推2.5年的年份
//	var monmax;  //根据当前时间为中点往后推2.5年的月份
//	var datemax;  //根据当前时间为中点往后推2.5年的日
//	//计算最小、最大时间
//	if(mon - 6 <= 0){
//		yearmin = year - 3;  //计算最小年份
//		monmin = 12 + (mon - 6);  //计算最小月份
//		yearmax = year + 2;  //计算最大年份
//		monmax = mon + 6;  //计算最大月份
//	}else{
//		yearmin = year -2;  //计算最小年份
//		monmin = mon - 6;
//		yearmax = year + 3;  //计算最大年份
//		monmax = mon - 6;  //计算最大月份
//	}
//	//计算日期
//	if(date == 28 || date == 29 || date == 30 || date == 31){
//		if(monmin == 2){
//			if(yearmin % 4 == 0){  //闰年
//				if(date == 28 || date == 29){
//					datemin = date;
//					datemax = date;
//				}else{
//					datemin = 29;
//					datemax = 29;
//				}
//			}else{  //平年
//				datemin = 28;
//				datemax = 28;
//			}
//		}else{
//			if(monmin == 4 || monmin == 6 || monmin == 9 || monmin == 11){
//				if(date == 31){
//					datemin = 30;
//					datemax = 30;
//				}
//			}
//		}
//	}else{
//		datemin = date;
//		datemax = date;
//	}
//	$("#ge_startDate").click(function(){
//		var ge_endDate = $("#ge_endDate").val();
//		var le_endDate = $("#le_endDate").val();
//		var le_startDate = $("#le_startDate").val();
//		if(ge_endDate == ""){
//			if(le_endDate == ""){
//				if(le_startDate == ""){
//					WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:yearmin + '-' + monmin + '-' + datemin, maxDate:yearmax + '-' + monmax + "-" + datemax});
//				}else{
//					WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:yearmin + '-' + monmin + '-' + datemin, maxDate:le_startDate});
//				}
//			}else{
//				if(le_startDate == ""){
//					WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:yearmin + '-' + monmin + '-' + datemin, maxDate:le_endDate});
//				}else{
//					WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:yearmin + '-' + monmin + '-' + datemin, maxDate:le_startDate});
//				}
//			}
//		}else{
//			if(le_startDate == ""){
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:yearmin + '-' + monmin + '-' + datemin, maxDate:ge_endDate});
//			}else{
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:yearmin + '-' + monmin + '-' + datemin, maxDate:le_startDate});
//			}
//		}
////		if(le_startDate == ""){
////			WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:yearmin + '-' + monmin + '-' + datemin, maxDate:yearmax + '-' + monmax + "-" + datemax});
////		}else{
////			WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:yearmin + '-' + monmin + '-' + datemin, maxDate:le_startDate});
////		}
//	});
//	$("#le_startDate").click(function(){
//		var ge_endDate = $("#ge_endDate").val();
//		var le_endDate = $("#le_endDate").val();
//		var ge_startDate = $("#ge_startDate").val();
//		if(ge_endDate == ""){
//			if(le_endDate == ""){
//				if(ge_startDate == ""){
//					WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:yearmin + '-' + monmin + '-' + datemin, maxDate:yearmax + '-' + monmax + "-" + datemax});
//				}else{
//					WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:ge_startDate, maxDate:yearmax + '-' + monmax + "-" + datemax});
//				}
//			}else{
//				if(ge_startDate == ""){
//					WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:yearmin + '-' + monmin + '-' + datemin, maxDate:le_endDate});
//				}else{
//					WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:ge_startDate, maxDate:yearmax + '-' + monmax + "-" + datemax});
//				}
//			}
//		}else{
//			if(ge_startDate == ""){
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:yearmin + '-' + monmin + '-' + datemin, maxDate:ge_endDate});
//			}else{
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:ge_startDate, maxDate:yearmax + '-' + monmax + "-" + datemax});
//			}
//		}
////		if(ge_startDate == ""){
////			WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:yearmin + '-' + monmin + '-' + datemin, maxDate:yearmax + '-' + monmax + "-" + datemax});
////		}else{
////			WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:ge_startDate, maxDate:yearmax + '-' + monmax + "-" + datemax});
////		}
//	});
//	$("#ge_endDate").click(function(){
//		var ge_startDate = $("#ge_startDate").val();
//		var le_endDate = $("#le_endDate").val();
//		if(ge_startDate == ""){
//			if(le_endDate == ""){
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:yearmin + '-' + monmin + '-' + datemin, maxDate:yearmax + '-' + monmax + "-" + datemax});
//			}else{
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:yearmin + '-' + monmin + '-' + datemin, maxDate:le_endDate});
//			}
//		}else{
//			if(le_endDate == ""){
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:ge_startDate, maxDate:yearmax + '-' + monmax + "-" + datemax});
//			}else{
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:ge_startDate, maxDate:le_endDate});
//			}
//		}
//		
//	});
//	$("#le_endDate").click(function(){
//		var ge_startDate = $("#ge_startDate").val();
//		var ge_endDate = $("#ge_endDate").val();
//		if(ge_startDate == ""){
//			if(ge_endDate == ""){
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:yearmin + '-' + monmin + '-' + datemin, maxDate:yearmax + '-' + monmax + "-" + datemax});
//			}else{
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:ge_endDate, maxDate:yearmax + '-' + monmax + "-" + datemax});
//			}
//		}else{
//			if(ge_endDate == ""){
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:ge_startDate, maxDate:yearmax + '-' + monmax + "-" + datemax});
//			}else{
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:ge_endDate, maxDate:yearmax + '-' + monmax + "-" + datemax});
//			}
//		}
//		
//	});
//	生效日开始时间输入框格式
//	$("#ge_startDate").click(function(){
//		var ge_endDate = $("#ge_endDate").val();
//		var le_endDate = $("#le_endDate").val();
//		var le_startDate = $("#le_startDate").val();
//		if(ge_endDate == "" && le_endDate == ""){
//			if(le_startDate == ""){
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd'});
//			}else{
//				var le_startDateminyear = parseInt(le_startDate.split("-", 1) - 5);  //格式化年
//				var le_startDateminmon_date = le_startDate.substring(4);  //截取-月-日
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:le_startDateminyear + "" + le_startDateminmon_date, maxDate:le_startDate});
//			}
//		}
//		WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd'});
//	});
	$("#ge_startDate").blur(function(){
		var ge_endDate = $("#ge_endDate").val();
		var le_endDate = $("#le_endDate").val();
		if(ge_endDate != "" || le_endDate != ""){
			$("#ge_startDate").val("");
			alert("授权生效日条件与授权截止日条件只能二选一：现在已选择授权截止日条件！");
		}
	});
	
//	生效日结束时间输入框格式
//	$("#le_startDate").click(function(){
//		var ge_endDate = $("#ge_endDate").val();
//		var le_endDate = $("#le_endDate").val();
//		var ge_startDate = $("#ge_startDate").val();
//		if(ge_endDate == "" && le_endDate == ""){
//			if(ge_startDate == ""){
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd'});
//			}else{
//				var ge_startDatemaxyear = parseInt(ge_startDate.split("-", 1)) + 5;  //格式化年
//				var ge_startDatemaxmon_date = ge_startDate.substring(4);  //截取-月-日
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:ge_startDate, maxDate:ge_startDatemaxyear + "" + ge_startDatemaxmon_date});
//			}
//		}
//		WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd'});
//	});
	$("#le_startDate").blur(function(){
		var ge_endDate = $("#ge_endDate").val();
		var le_endDate = $("#le_endDate").val();
		if(ge_endDate != "" || le_endDate != ""){
			$("#le_startDate").val("");
			alert("授权生效日条件与授权截止日条件只能二选一：现在已选择授权截止日条件！");
		}
	});
	
//	授权截止日开始时间输入框格式
//	$("#ge_endDate").click(function(){
//		var ge_startDate = $("#ge_startDate").val();
//		var le_startDate = $("#le_startDate").val();
//		var le_endDate = $("#le_endDate").val();
//		if(ge_startDate =="" && le_startDate == ""){
//			if(le_endDate == ""){
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd'});
//			}else{
//				var le_endDateminyear = parseInt(le_endDate.split("-", 1) - 5);  //格式化年
//				var le_endDateminmon_date = le_endDate.substring(4);  //截取-月-日
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:le_endDateminyear + "" + le_endDateminmon_date, maxDate:le_endDate});
//			}
//		}
//		WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd'});
//	});
	$("#ge_endDate").blur(function(){
		var ge_startDate = $("#ge_startDate").val();
		var le_startDate = $("#le_startDate").val();
		if(ge_startDate != "" || le_startDate != ""){
			$("#ge_endDate").val("");
			alert("授权生效日条件与授权截止日条件只能二选一：现在已选择授权生效日条件！");
		}
	});
	
//	授权截止日结束时间输入框格式
//	$("#le_endDate").click(function(){
//		var ge_startDate = $("#ge_startDate").val();
//		var le_startDate = $("#le_startDate").val();
//		var ge_endDate = $("#ge_endDate").val();
//		if(ge_startDate =="" && le_startDate == ""){
//			if(ge_endDate == ""){
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd'});
//			}else{
//				var ge_endDatemaxyear = parseInt(ge_endDate.split("-", 1)) + 5;  //格式化年
//				var ge_endDatemaxmon_date = ge_endDate.substring(4);  //截取-月-日
//				WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd', minDate:ge_endDate, maxDate:ge_endDatemaxyear + "" + ge_endDatemaxmon_date});
//			}
//		}
//		WdatePicker({skin:'whyGreen', dateFmt:'yyyy-MM-dd'});
//	});
	$("#le_endDate").blur(function(){
		var ge_startDate = $("#ge_startDate").val();
		var le_startDate = $("#le_startDate").val();
		if(ge_startDate != "" || le_startDate != ""){
			$("#le_endDate").val("");
			alert("授权生效日条件与授权截止日条件只能二选一：现在已选择授权生效日条件！");
		}
	});
});

function initSealType(){
	var params = {
			
	};
	$.post(ctx+"/report/takeRetuenSealReportAction_findSealType.action",params,function(data){
		if(data.responseMessage.success){
			var sealTypeMap=data.sealMap;
			var sealTypeContent = "<option value=' '>全部</option>";
			for ( var key in sealTypeMap) {
				sealTypeContent += "<option value='" + key + "'>" + sealTypeMap[key] + "</option>";
			}
			$("#sealType").html(sealTypeContent);
			
		}else{
			alert(res.responseMessage.message);
		}
	});
	
}

function initSealSeate(){
	var params = {
			
	};
	$.post(ctx+"/report/takeRetuenSealReportAction_findSealState.action",params,function(data){
		if(data.responseMessage.success){
			var sealStateMap=data.sealMap;
			var sealTypeContent = "<option value=' '>全部</option>";
			for ( var key in sealStateMap) {
				sealTypeContent += "<option value='" + key + "'>" + sealStateMap[key] + "</option>";
			}
			$("#sealState").html(sealTypeContent);
			
		}else{
			alert(res.responseMessage.message);
		}
	});
}

function initOrgNo() {
	var loginPeople = top.loginPeopleInfo;
	$("#sealOrg").val(loginPeople.orgNo);
	$("#sealOrgName").val(loginPeople.orgName+"("+loginPeople.orgNo+")");
}

function initPage(){
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() -2;
		pageHeaderHeight = pageHeaderHeight.substr(0,pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight -pageHeaderHeight + 6 - 50*2 ;
	$("#logPeopleManageList").jqGrid(
		{
			width : pageContentWidth+500,
			height : tableHeight,
			url : ctx + "/report/transferPowerReportAction_list.action",
			multiselect : false,
//			postData : {
//				"queryBean.params.sealOrg" : top.loginPeopleInfo.orgNo
//			},
			rowNum : 20,
			rownumbers : true,
//			sortname : "takeSealDateTime",
//			sortorder : "desc",
			rowList : [ 20, 50, 100 ],
			colNames : ["申请编号", "被委托授权审批人工号","被委托授权审批人","被委托授权审批人所属机构", "审批人工号","审批人","审批人所属机构","委托授权权限名称", "授权生效日", /*"结束时间",*/"授权截止日","操作人","状态"],
			colModel : [
					{
						name : "applicationFormNo",
						index : "applicationFormNo",
						align : "center",
						width : 80,
						sortable : false
					},
					{
						name : "revicePeopleNo",
						index : "revicePeopleNo",
						align : "center",
						width : 80,
						sortable : false
					},
					{
						name : "revicePeopleName",
						index : "revicePeopleName",
						align : "center",
						width : 80,
						sortable : false
					},
					{
						name : "revicePeopleOrgName",
						index : "revicePeopleOrgName",
						align : "center",
						width : 80,
						sortable : false,
						formatter : function(value, options, rData) {
							
							return value;
						}
					},
					{
						name : "transferPeopleNo",
						index : "transferPeopleNo",
						align : "center",
						width : 80,
						sortable : false
					},
					{
						name : "transferPeopleName",
						index : "transferPeopleName",
						align : "center",
						width : 80,
						sortable : false
					},
					{
						name : "transferPeopleOrgName",
						index : "transferPeopleOrgName",
						align : "center",
						width : 80,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "reviceSealName",
						index : "reviceSealName",
						align : "center",
						width : 80,
						sortable : false,
						formatter : function(value, options, rData) {
							
							return value;
						}
					},
					{
						name : "startTime",
						index : "startTime",
						align : "center",
						width : 80,
						sortable : false,
						formatter : function(value, options, rData) {
							var startTime = "";
							if(rData.startDate!=null){
								startTime += rData.startDate;
							}
							if(rData.startTime!=null){
								startTime += " "+rData.startTime;
							}
							return startTime;
						}
					},
					{
						name : "endTime",
						index : "endTime",
						align : "center",
						width : 80,
						sortable : false,
						formatter : function(value, options, rData) {
							var endTime = "";
							if(rData.endDate!=null){
								endTime += rData.endDate;
							}
							if(rData.endTime!=null){
								endTime += " "+rData.endTime;
							}
							return endTime;
						}
					},
					/*{
						name : "cannelDate",
						index : "cannelDate",
						align : "center",
						width : 80,
						sortable : false,
						formatter : function(value, options, rData) {
							var endTime = "";
							if(rData.cannelDate!=null){
								endTime += rData.cannelDate;
							}
							if(rData.cannelTime!=null){
								endTime += " "+rData.cannelTime;
							}
							return endTime;
						}
					},*/
					{
						name : "optPeopleName",
						index : "optPeopleName",
						align : "center",
						width : 80,
						sortable : false,
						formatter : function(value, options, rData) {
							
							return value;
						}
					},
					{
						name : "status",
						index : "status",
						align : "center",
						width : 80,
						formatter : function(value, options, rData) {
							var status = "";
							if(rData.status==0){
								status = "待生效(Pending Effective)";
							}else if(rData.status==1){
								status = "生效中(Effective)";
							}else if(rData.status==2){
								status = "正常结束(Closed)";
							}else if(rData.status==3){
//								status = "提前收回";
								status = "撤销(Revoked)";
							}else if(rData.status==4){
								status = "撤销(Revoked)";
							}
							return status;
						}
					}],
			pager : "#logPeopleManagePager",
			caption : "审批人权限委托授权分发列表"
		}).trigger("reloadGrid");
	
	$("#logPeopleManageList").navGrid("#logPeopleManagePager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true,
		excel : false
	}).navButtonAdd('#logPeopleManagePager',{
		caption:"导出excel",
		buttonicon:"ui-icon-excel", 
		onClickButton:function(){
			var ge_endDate = $('#ge_endDate').val();
			var le_endDate = $('#le_endDate').val();
			var ge_startDate = $('#ge_startDate').val();
			var le_startDate = $('#le_startDate').val();
			if(ge_startDate > le_startDate){
				alert("“授权生效日”开始时间不能大于结束时间！")
				return;
			}
			if(ge_startDate != '' || le_startDate != ''){
				if(ge_endDate != '' || le_endDate != ''){
					alert("“授权生效日”条件与“授权截止日”条件只能二选一");
					return;
				}
			}
			if(ge_startDate != ''){
				if(le_startDate == ''){
					alert("时间范围请填写完整：“授权生效日”结束时间不能为空！");
					return;
				}
			}else{
				if(le_startDate != ''){
					alert("时间范围请填写完整：“授权生效日”开始时间不能为空！");
					return;
				}
			}
			if(ge_endDate != ''){
				if(le_endDate == ''){
					alert("时间范围请填写完整：“授权截止日”结束时间不能为空！");
					return;
				}
			}else{
				if(le_endDate != ''){
					alert("时间范围请填写完整：“授权截止日”开始时间不能为空！");
					return;
				}
			}
			if(ge_endDate == '' && le_endDate == '' && ge_startDate == '' && le_startDate == ''){
				alert("请必须选择“授权生效日”条件或“授权截止日”条件做导出必要条件");
				return;
			}
			$.ajax({
				type : "post",
				url : ctx + "/report/transferPowerReportAction_findSum.action",
				dataType : "json",
				async : false,
				success : function(response) {
					var data = response.data;
					var n = true;
					if(ge_endDate != '' || le_endDate != ''){
						if(MonthsBetw(ge_endDate,le_endDate) > 60){
						    alert('导出时"授权截止日"开始时间与结束之间不能超出5年');
							n = false;
							return;
						} 
					}
					if(n){
						if(ge_startDate!='' || le_startDate!=''){
							if(MonthsBetw(ge_startDate,le_startDate) > 60){
							     alert('导出时"授权生效日"开始时间与结束时间不能超出5年');
								return;
							} 
						}
					}
					
					var str = '<form id="postForm" action="'+ ctx +'/report/transferPowerReportAction_report.action?type=2" method="post" style="display:hidden;">'+
				                '<input type="hidden" id="ge_startDate" name="ge_startDate" value="'+ $('#ge_startDate').val() +'" />'+
				                '<input type="hidden" id="le_startDate" name="le_startDate" value="'+ $('#le_startDate').val() +'" />'+
				                '<input type="hidden" id="ge_endDate" name="ge_endDate" value="'+ $('#ge_endDate').val() +'" />'+
				                '<input type="hidden" id="le_endDate" name="le_endDate" value="'+ $('#le_endDate').val() +'" />'+
				                '<input type="hidden" id="revicePeopleNo" name="revicePeopleNo" value="'+ $('#revicePeopleNo').val() +'" />'+
				                '<input type="hidden" id="transferPeopleNo" name="transferPeopleNo" value="'+ $('#transferPeopleNo').val() +'" />'+
				                '<input type="hidden" id="revicePeopleName" name="revicePeopleName" value="'+ $('#revicePeopleName').val() +'" />'+
				                '<input type="hidden" id="transferPeopleName" name="transferPeopleName" value="'+ $('#transferPeopleName').val() +'" />'+
				                '<input type="hidden" id="reviceSealName" name="reviceSealName" value="'+ $('#reviceSealName').val() +'" />'+
				                '<input type="hidden" id="in_status" name="in_status" value="'+ $('#in_status').val() +'" />'+
				          '</form>';
                   
					$("#div1").html("");
					$("#div1").html(str);
					$("#postForm").submit();
					
//					$.ajaxFileUpload({url : ctx + "/report/transferPowerReportAction_report.action?type=2"+
//					        "&queryBean.params.ge_startDate=" + $('#ge_startDate').val()+
//		                  	"&queryBean.params.le_startDate=" +  $('#le_startDate').val()+
//							"&queryBean.params.ge_endDate=" +  $('#ge_endDate').val()+
//							"&queryBean.params.le_endDate=" +  $('#le_endDate').val(),
//		//					"&queryBean.params.like_revicePeopleNo=" +  $('#revicePeopleNo').val()+
//		//					"&queryBean.params.like_reviceSealName=" +  $('#reviceSealName').val()+
//		//					"&queryBean.params.like_transferPeopleName=" +  $('#transferPeopleName').val()+
//		//					"&queryBean.params.like_revicePeopleName=" +  $('#revicePeopleName').val()+
//		//					"&queryBean.params.like_transferPeopleNo=" +  $('#transferPeopleNo').val(),
//					        
//					dataType : 'json',
//					success : function(res, status){}
//					})
					
				}
			})
			
		}
	}) ;
}



function MonthsBetw(date1, date2) {
	date1 = date1.split("-");
	date2 = date2.split("-");
	var year1 = parseInt(date1[0]),
	month1 = parseInt(date1[1].slice(0,1)=='0'?date1[1].slice(1,2):date1[1]),
	year2 = parseInt(date2[0]),
	month2 = parseInt(date2[1].slice(0,1)=='0'?date2[1].slice(1,2):date2[1]),
	months = (year2 - year1) * 12 + (month2 - month1);
	return months;
}
function submitForm(){
	update();
}

function deletePeopleUseSeal(sid){
	if(!confirm('确定删除？')){
		return;
	}
	var params = {
			'peopleUseSealInfo.sid':sid
	};
	$.post(ctx+"/peopleUseSeal/peopleUseSealInfoAction_delete.action",params,function(data){
		if(data.responseMessage.success){
			alert("删除成功");
			$("#logPeopleManageList").trigger("reloadGrid");
		}else{
			alert(res.responseMessage.message);
		}
	});
}


/**
 * 查询数据，执行查询
 */
function queryData() {
	var ge_startDate = $("#ge_startDate").val();
	var le_startDate = $("#le_startDate").val();
	if(ge_startDate == ""){
		if(le_startDate != ""){
			alert("授权生效日开始时间不能为空！")
			return;
		}
	}else{
		if(le_startDate == ""){
			alert("授权生效日结束时间不能为空！")
			return;
		}
	}
	if(ge_startDate > le_startDate){
		alert("授权生效日开始时间不能大于结束时间！")
		return;
	}
	var ge_endDate = $("#ge_endDate").val();
	var le_endDate = $("#le_endDate").val();
	if(ge_endDate == ""){
		if(le_endDate != ""){
			alert("授权截止日开始时间不能为空！")
			return;
		}
	}else{
		if(le_endDate == ""){
			alert("授权截止日结束时间不能为空！")
			return;
		}
	}
	if(ge_endDate > le_endDate){
		alert("授权截止开始时间不能大于结束时间！")
		return;
	}
	$("#logPeopleManageList").jqGrid("search", "#queryForm");
}

/**
 * 重置查询条件
 */
function resetMethod() {
	$("#queryForm")[0].reset();
//	initOrgNo();
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo){
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#sealOrg").radioOrgTree(true,organizationSid,0,false,function(event, treeId, treeNode){
		if(treeNode){
			$("#sealOrg").val(treeNode.organizationNo);
//			$("#"+organizationNo).val(treeNode.organizationNo);
			$("#"+organizationNo).val(treeNode.organizationName+"("+treeNode.organizationNo+")");
		}
	});
}