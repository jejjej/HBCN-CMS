


/**
 * 初始化Grid数据
 */
$(function() {
//	initOrgNo();
	initPage();
	initAuthSeate();
//	initSealType();
//	initSealSeate();
});

function initAuthSeate(){
	var params = {
			
	};
	$.post(ctx+"/report/transferPowerReportAction_findAuthState.action",params,function(data){
		if(data.responseMessage.success){
			var sealStateMap=data.sealMap;
			var sealTypeContent = "<option value=' '>全部</option>";
			for ( var key in sealStateMap) {
				sealTypeContent += "<option value='" + key + "'>" + sealStateMap[key] + "</option>";
			}
			$("#status").html(sealTypeContent);
			
		}else{
			alert(res.responseMessage.message);
		}
	});
}

function initSealType(){
	var params = {
			
	};
	$.post(ctx+"/report/takeRetuenSealReportAction_findSealType.action",params,function(data){
		if(data.responseMessage.success){
			var sealTypeMap=data.sealMap;
			var sealTypeContent = "<option value=' '>全部</option>";
			for ( var key in sealTypeMap) {
				sealTypeContent += "<option value='" + key + "'>" + sealTypeMap[key] + "</option>";
			}
			$("#sealType").html(sealTypeContent);
			
		}else{
			alert(res.responseMessage.message);
		}
	});
	
}

function initSealSeate(){
	var params = {
			
	};
	$.post(ctx+"/report/takeRetuenSealReportAction_findSealState.action",params,function(data){
		if(data.responseMessage.success){
			var sealStateMap=data.sealMap;
			var sealTypeContent = "<option value=' '>全部</option>";
			for ( var key in sealStateMap) {
				sealTypeContent += "<option value='" + key + "'>" + sealStateMap[key] + "</option>";
			}
			$("#sealState").html(sealTypeContent);
			
		}else{
			alert(res.responseMessage.message);
		}
	});
}


function initOrgNo() {
	var loginPeople = top.loginPeopleInfo;
	$("#sealOrg").val(loginPeople.orgNo);
	$("#sealOrgName").val(loginPeople.orgName+"("+loginPeople.orgNo+")");
}

function initPage(){
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() -2;
		pageHeaderHeight = pageHeaderHeight.substr(0,pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight -pageHeaderHeight + 6 - 50*2 ;
	$("#logPeopleManageList").jqGrid(
		{
			width : pageContentWidth,
			height : tableHeight,
			url : ctx + "/report/transferPowerReportAction_list1.action",
			multiselect : false,
//			postData : {
//				"queryBean.params.sealOrg" : top.loginPeopleInfo.orgNo
//			},
			rowNum : 20,
			rownumbers : true,
//			sortname : "takeSealDateTime",
//			sortorder : "desc",
			rowList : [ 20, 50, 100 ],
			colNames : ["申请编号","印章所属机构","印章名称", "转出人","转出人员工号","接收人","接收人员工号", "权限转移生效日", "权限转移截至日",/*"撤销时间",*/"电子锁权限转移状态"],
			colModel : [
					{
						name : "applicationFormNo",
						index : "applicationFormNo",
						align : "center",
						width : 80,
						sortable : false
					},{
						name : "sealOrgNo",
						index : "sealOrgNo",
						align : "center",
						width : 80,
						sortable : false
					},{
						name : "sealName",
						index : "sealName",
						align : "center",
						width : 80,
						sortable : false
					},{
						name : "transferPeopleName",
						index : "transferPeopleName",
						align : "center",
						width : 80,
						sortable : false
					},{
						name : "transferPeopleNo",
						index : "transferPeopleNo",
						align : "center",
						width : 80,
						sortable : false
					},{
						name : "revicePeopleName",
						index : "revicePeopleName",
						align : "center",
						width : 80,
						sortable : false
					},{
						name : "revicePeopleNo",
						index : "revicePeopleNo",
						align : "center",
						width : 80,
						sortable : false
					},{
						name : "startDateTime",
						index : "startDateTime",
						align : "center",
						width : 80,
						sortable : false
					},{
						name : "endDateTime",
						index : "endDateTime",
						align : "center",
						width : 80,
						sortable : false
					},{
						name : "status",
						index : "status",
						align : "center",
						width : 80
					}],
			pager : "#logPeopleManagePager",
			caption : "电子锁权限转移统计表"
		}).trigger("reloadGrid");
	
	$("#logPeopleManageList").navGrid("#logPeopleManagePager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true,
		excel : false
	}).navButtonAdd('#logPeopleManagePager',{
		caption:"导出excel",
		buttonicon:"ui-icon-excel", 
		onClickButton:function(){
			var ge_endDate = $('#ge_endDate').val();
			var le_endDate = $('#le_endDate').val();
			var ge_startDate = $('#ge_startDate').val();
			var le_startDate = $('#le_startDate').val();
			
			if((ge_endDate=='' || le_endDate=='' )&&(ge_startDate=='' || le_startDate=='')){
				alert('导出时权限转移生效日与权限转移截止日不能为空');
				return;
			}
			
			if(ge_endDate!='' && ge_startDate!='' ){
				if(le_endDate == ''){
					alert('导出时权限转移截止日不能为空');
					return;
				}
				if(le_startDate == ''){
					alert('导出时权限转移生效日不能为空');
					return;
				}
			}
			if(le_endDate!='' && le_startDate!='' ){
				if(ge_endDate == ''){
					alert('导出时权限转移截止日不能为空');
					return;
				}
				if(ge_startDate == ''){
					alert('导出时权限转移生效日不能为空');
					return;
				}
			}
			
			
			
			
			$.ajax({
				type : "post",
				url : ctx + "/report/transferPowerReportAction_findSum.action",
				dataType : "json",
				async : false,
				success : function(response) {
					
					var data = response.data;
					var n = true;
					if(ge_endDate!='' || le_endDate!=''){
						if(MonthsBetw(ge_endDate,le_endDate)>data){
						    alert('导出时权限转移截止日不能超出'+ data +'个月');
							n = false;	
							return;
						} 
					}
					if(n){
						if(ge_startDate!='' || le_startDate!=''){
							if(MonthsBetw(ge_startDate,le_startDate)>data){
							    alert('导出时权限转移生效日不能超出'+ data +'个月');
								return;
							} 
						}
					}
					
					
					var str = '<form id="postForm" action="'+ ctx +'/report/transferPowerReportAction_report.action?type=1" method="post" style="display:hidden;">'+
					                '<input type="hidden" id="ge_startDate" name="ge_startDate" value="'+ $('#ge_startDate').val() +'" />'+
					                '<input type="hidden" id="le_startDate" name="le_startDate" value="'+ $('#le_startDate').val() +'" />'+
					                '<input type="hidden" id="ge_endDate" name="ge_endDate" value="'+ $('#ge_endDate').val() +'" />'+
					                '<input type="hidden" id="le_endDate" name="le_endDate" value="'+ $('#le_endDate').val() +'" />'+
					                '<input type="hidden" id="revicePeopleNo" name="revicePeopleNo" value="'+ $('#revicePeopleNo').val() +'" />'+
					                '<input type="hidden" id="transferPeopleNo" name="transferPeopleNo" value="'+ $('#transferPeopleNo').val() +'" />'+
					                '<input type="hidden" id="revicePeopleName" name="revicePeopleName" value="'+ $('#revicePeopleName').val() +'" />'+
					                '<input type="hidden" id="transferPeopleName" name="transferPeopleName" value="'+ $('#transferPeopleName').val() +'" />'+
					                '<input type="hidden" id="sealName" name="sealName" value="'+ $('#sealName').val() +'" />'+
					                '<input type="hidden" id="sealOrg" name="sealOrg" value="'+ $('#sealOrg').val() +'" />'+
					                '<input type="hidden" id="status" name="status" value="'+ $('#status').find("option:selected").val() +'" />'+
					          '</form>';
                   
					$("#div1").html("");
					$("#div1").html(str);
					$("#postForm").submit();
					
//					$.ajaxFileUpload({url : ctx + "/report/transferPowerReportAction_report.action?type=1"+
//					        "&queryBean.params.ge_startDate=" + $('#ge_startDate').val()+
//		                  	"&queryBean.params.le_startDate=" +  $('#le_startDate').val()+
//							"&queryBean.params.ge_endDate=" +  $('#ge_endDate').val()+
//							"&queryBean.params.le_endDate=" +  $('#le_endDate').val(),
//		//					"&queryBean.params.like_revicePeopleNo=" +  $('#revicePeopleNo').val()+
//		//					"&queryBean.params.like_reviceSealName=" +  $('#reviceSealName').val()+
//		//					"&queryBean.params.like_transferPeopleName=" +  $('#transferPeopleName').val()+
//		//					"&queryBean.params.like_revicePeopleName=" +  $('#revicePeopleName').val()+
//		//					"&queryBean.params.like_transferPeopleNo=" +  $('#ransferPeopleNo').val()+
//		//					"&queryBean.params.status_int=" +  $('#status').find("option:selected").val()+
//		//					"&queryBean.params.like_sealName=" +  $('#sealName').val(),
//					        
//					dataType : 'json',
//					success : function(res, status){}
//					})
					
				}
				
			})
			
			
		}
	}) ;
}

function MonthsBetw(date1, date2) {
	date1 = date1.split("-");
	date2 = date2.split("-");
	var year1 = parseInt(date1[0]),
	month1 = parseInt(date1[1].slice(0,1)=='0'?date1[1].slice(1,2):date1[1]),
	year2 = parseInt(date2[0]),
	month2 = parseInt(date2[1].slice(0,1)=='0'?date2[1].slice(1,2):date2[1]),
	months = (year2 - year1) * 12 + (month2 - month1);
	return months;
}

function submitForm(){
	update();
}

function deletePeopleUseSeal(sid){
	if(!confirm('确定删除？')){
		return;
	}
	var params = {
			'peopleUseSealInfo.sid':sid
	};
	$.post(ctx+"/peopleUseSeal/peopleUseSealInfoAction_delete.action",params,function(data){
		if(data.responseMessage.success){
			alert("删除成功");
			queryData();
		}else{
			alert(res.responseMessage.message);
		}
	});
}


/**
 * 查询数据，执行查询
 */
function queryData() {
	$("#logPeopleManageList").jqGrid("search", "#queryForm");
}

/**
 * 重置查询条件
 */
function resetMethod() {
	$("#queryForm")[0].reset();
//	initOrgNo();
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo){
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#sealOrg").radioOrgTree(true,organizationSid,0,false,function(event, treeId, treeNode){
		if(treeNode){
			$("#sealOrg").val(treeNode.organizationNo);
//			$("#"+organizationNo).val(treeNode.organizationNo);
			$("#"+organizationNo).val(treeNode.organizationName+"("+treeNode.organizationNo+")");
		}
	});
}