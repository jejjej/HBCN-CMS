

/**
 * 初始化Grid数据
 */
$(function() {
//	initOrgNo();
	initSealType();
	initPage();
	
	$("#filesDLG1").dialog({
		autoOpen : false,
		resizable : false,
		height: $(window).height() /6*2.7,
		width : $(window).width() /2*0.9,
		modal : true,
		position : {
			at : "center"
		},
		open : function(event, ui) {
			$(".ui-dialog-titlebar").show();
			$(".ui-dialog-titlebar-close").show();
		}
	});
});

function initSealType(){
	var params = {
			
	};
	$.post(ctx+"/report/takeRetuenSealReportAction_findSealType.action",params,function(data){
		if(data.responseMessage.success){
			var sealTypeMap=data.sealMap;
			var sealTypeContent = "<option value=' '>全部</option>";
			for ( var key in sealTypeMap) {
				sealTypeContent += "<option value='" + key + "'>" + sealTypeMap[key] + "</option>";
			}
			$("#sealType").html(sealTypeContent);
			
		}else{
			alert(res.responseMessage.message);
		}
	});
	
}

function initOrgNo() {
	var loginPeople = top.loginPeopleInfo;
//	$("#applyOrg").val(loginPeople.orgNo);
//	$("#applyOrgName").val(loginPeople.orgName);
	$("#sealOwnerOrg").val(loginPeople.orgNo);
	$("#sealOwnerOrgName").val(loginPeople.orgName);
}

function initPage(){
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() -2;
		pageHeaderHeight = pageHeaderHeight.substr(0,pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight -pageHeaderHeight + 6 - 50*2 ;
	$("#logPeopleManageList").jqGrid(
		{
			width : pageContentWidth+350,
			height : tableHeight,
			url : ctx + "/report/useSealReportAction_allList.action",
			multiselect : false,
			postData : {
//				"queryBean.params.applyOrg" : top.loginPeopleInfo.orgNo
			},
			rowNum : 20,
			rownumbers : true,
			sortname : "createTime",
			sortorder : "desc",
			rowList : [ 20, 50, 100 ],
			colNames : ["流水号", "申请机构", "申请人","申请时间", "文件类型", "审批人", "保管人", "印章类型", "印章所属机构", "印章名称",
			            "文件名称", "附件", "审批时间", "申请审批状态", "用印原因", "创建时间", /*"修改时间",*/ "普通用印次数", "骑缝用印次数","包含敏感信息", "用印时间"],
			colModel : [
					{
						name : "orderNo",
						index : "orderNo",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "applyOrgName",
						index : "applyOrgName",
						align : "center",
						width : 60,
						sortable : false
					},
					{
						name : "applyPeopleName",
						index : "applyPeopleName",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "applyTime",
						index : "applyTime",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "fileType",
						index : "fileType",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "apprPeopleName",
						index : "apprPeopleName",
						align : "center",
						width : 60,
						sortable : false
					},
					{
						name : "savePeopleName",
						index : "savePeopleName",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "sealType",
						index : "sealType",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "sealOwnerOrgName",
						index : "sealOwnerOrgName",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "sealName",
						index : "sealName",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "fileName",
						index : "fileName",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "attached",
						index : "attached",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							if(!value){
								return '无';
							}else{
								var html = "<a onclick=\"openFilesDialog('"
									+ value
									+ "','apply')\" style='text-decoration:underline;color:blue;cursor: hand;'>附件</a>";
								return html;
							}
						}
					},
					{
						name : "apprTime",
						index : "apprTime",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "apprState",
						index : "apprState",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "useSealCausal",
						index : "useSealCausal",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "createTime",
						index : "createTime",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					/*{
						name : "updateTime",
						index : "updateTime",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},*/
					{
						name : "useSealNum",
						index : "useSealNum",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							if(value==0||value==""){
								return "0";
							}
							return value;
						}
					},
					{
						name : "acrossPageSealUseNum",
						index : "acrossPageSealUseNum",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							if(value==0||value==""){
								return "0";
							}
							return value;
						}
					},
					{
						name : "isSensitive",
						index : "isSensitive",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							
							return value;
						}
					}
					,{
						name : "useSealTime",
						index : "useSealTime",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					}
					],
			pager : "#logPeopleManagePager",
			caption : "人工用印列表"
		}).trigger("reloadGrid");
	
	$("#logPeopleManageList").navGrid("#logPeopleManagePager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true,
		excel : false
	})
	.navButtonAdd('#logPeopleManagePager',{
		caption:"导出excel",
		buttonicon:"ui-icon-excel", 
		onClickButton:function(){
			var oDate2 = $('#ge_applyTime').val();
			var oDate3 = $('#le_applyTime').val();
			
			if(oDate2=='' || oDate3=='' ||oDate2==null || oDate3==null){
				alert('导出时申请日期不能为空');
				return;
			}
			
			$.ajax({
				type : "post",
				url : ctx + "/report/transferPowerReportAction_findSum.action",
				dataType : "json",
				async : false,
				success : function(response) {
					var data = response.data;
					if(MonthsBetw(oDate2,oDate3)>data){
					     alert('导出时申请日期不能超出'+ data +'个月');
						return;
					} 
					
					
					var str = '<form id="postForm" action="'+ ctx +'/report/useSealReportAction_report.action" method="post" style="display:hidden;">'+
					          		'<input type="hidden" id="isSensitive" name="isSensitive" value="'+ ($('#isSensitive').find("option:selected").val()==" "?"":$('#isSensitive').find("option:selected").val()) +'" />'+
					          		'<input type="hidden" id="isBatch" name="isBatch" value="'+ ($('#isBatch').find("option:selected").val()==" "?"":$('#isBatch').find("option:selected").val()) +'" />'+
					                '<input type="hidden" id="sealName" name="sealName" value="'+ $('#sealName').val() +'" />'+
					                '<input type="hidden" id="sealOwnerOrg" name="sealOwnerOrg" value="'+ $('#sealOwnerOrg').val() +'" />'+
					                '<input type="hidden" id="applyPeopleName" name="applyPeopleName" value="'+ $('#applyPeopleName').val() +'" />'+
					                '<input type="hidden" id="fileName" name="fileName" value="'+ $('#fileName').val() +'" />'+
					                '<input type="hidden" id="savePeopleName" name="savePeopleName" value="'+ $('#savePeopleName').val() +'" />'+
					                '<input type="hidden" id="ge_applyTime" name="ge_applyTime" value="'+ $('#ge_applyTime').val() +'" />'+
					                '<input type="hidden" id="le_applyTime" name="le_applyTime" value="'+ $('#le_applyTime').val() +'" />'+
					                '<input type="hidden" id="apprPeopleName" name="apprPeopleName" value="'+ $('#apprPeopleName').val() +'" />'+
					                '<input type="hidden" id="orderNo" name="orderNo" value="'+ $('#orderNo').val() +'" />'+
					          '</form>';
                   
					$("#div1").html("");
					$("#div1").html(str);
					$("#postForm").submit();
				  
//					$.ajaxFileUpload({url : ctx+"/report/useSealReportAction_report.action"+
//		//			         "?queryBean.params.like_sealName=" + $('#sealName').val() +
//		//			        "&queryBean.params.like_orderNo=" + $('#orderNo').val()+
//		//                    "&queryBean.params.sealOwnerOrg=" +  $('#sealOwnerOrg').val()+
//		//					"&queryBean.params.sealOwnerOrgName=" +  $('#sealOwnerOrgName').val()+
//		//					"&queryBean.params.like_applyPeopleName=" + $('#applyPeopleName').val()+
//		//					"&queryBean.params.like_fileName=" +  $('#fileName').val()+
//		//					"&queryBean.params.like_savePeopleName=" +  $('#savePeopleName').val()+
//		//					"&queryBean.params.isSensitive=" +   $('#isSensitive').find("option:selected").val()+
//		//					"&queryBean.params.isBatch=" +   $('#isBatch').find("option:selected").val()+
//							"?queryBean.params.ge_applyTime=" +  $('#ge_applyTime').val()+
//							"&queryBean.params.le_applyTime=" +  $('#le_applyTime').val(),
//		//					"&queryBean.params.like_apprPeopleName=" + $('#apprPeopleName').val(),
//					dataType : 'json',
//					success : function(res, status){}
//					})
					
				}
			})	
			
			
			
		}
	}) ;
}


function uploadImg(){
	$("#uploadDiv").dialog("open");
}


function MonthsBetw(date1, date2) {
	date1 = date1.split("-");
	date2 = date2.split("-");
	var year1 = parseInt(date1[0]),
	month1 = parseInt(date1[1].slice(0,1)=='0'?date1[1].slice(1,2):date1[1]),
	year2 = parseInt(date2[0]),
	month2 = parseInt(date2[1].slice(0,1)=='0'?date2[1].slice(1,2):date2[1]),
	months = (year2 - year1) * 12 + (month2 - month1);
	return months;
}




function openFilesDialog(storeId){
	wfStoreFancyBox.showAllThumbnailImageInDialogByStoreId("filesDLG", storeId, "button", "");
}

/**
 * 展示所有图片缩略图<br>
 * 点击缩略图展示图片流
 * 
 * @param divId
 *            缩略图所在的divId
 * @param storeId
 *            文件存储ID
 * @param effectType
 *            展示效果 gallery/buttons/thumbs
 */
wfStoreFancyBox.showAllThumbnailImageByStoreId = function(divId, storeId, effectType) {
	try {
		// 获取图片url
		var docObjects = this.fetchFile(storeId);
		if (docObjects == null || docObjects.length <= 0) {
			this.showMessage("图像未生成");
			return;
		}

		// 动态添加图片显示div
		$("#" + this.fancybox_pelementid).remove();
		var p = "<p id='" + this.fancybox_pelementid + "'></p>";
		$("#" + divId).html(p);
		var run = '2';
		var hasImage = false;
		for ( var i = 0; i < docObjects.length; i++) {
			var url = docObjects[i].fileUrl;
//			var aaa=url.substring(url.indexOf('storeServer')+11);
			url=ctx+"/peopleUseSeal/fileDownloadAction2.action?filePath="+url.substring(url.indexOf('storeServer')+11);
			
			var fileName = docObjects[i].propertyList.origFileName;
			if (url != null && url != undefined && url != "") {
				hasImage = true;
				var path = url.split("/");
				var name = path[path.length - 1].split(".");
				var fileType = name[1];
				var html = null;
//				if("asf" == fileType){
//					var encodeuri = encodeURI(url);
//					html = '<a href="javascript:openvideo(\''+encodeuri+'\')">' + '<img style="width:120px;" src="'+ctx+'/gss/common/js/fancyBox/file.jpg" /></a>&nbsp;';
//					$("#videoDiv").remove();
//					$(document.body).append("<div id='videoDiv'></div>");
//				}else if ("jpg" == fileType || "JPG" == fileType || "png" == fileType || "PNG" == fileType) {
//					var tempUrlPath = url.substring(0,url.lastIndexOf("."));
//					var tempUrlFileType = url.substring(url.lastIndexOf("."));
//					var thumbUrl = tempUrlPath + "_thumb" + tempUrlFileType;
//					if(/msie 8\.0/i.test(navigator.userAgent.toLowerCase())){
//						html = '<a class="' + this.class_arr[effectType] + '" data-fancybox-group="' + effectType
//						+ '" href="' + url + '">' + '<v:image style="width:120px;height:120px;" class="vml" id="storeImg_'+i+'" src="' + thumbUrl + 
//						'" title="' + fileName  + '" /></a>&nbsp;';
//					}else{
//						html = '<a class="' + this.class_arr[effectType] + '" data-fancybox-group="' + effectType
//						+ '" href="' + url + '">' + '<img style="width:120px;" id="storeImg_' + i + '" src="' + thumbUrl
//						+ '" title="' + fileName + '"/></a>&nbsp;';
//					}
//				} else {
//					html = '<a target="_blank" href="' + url + '">' + '<img style="width:120px;" id="storeImg_' + i
//							+ '" src="' + ctx + '/gss/common/js/fancyBox/file.jpg" title="' + fileName + '"/></a>&nbsp;';
//				}
				if (docObjects[i].propertyList.synchroStatus =='2') {
					run = '3';

					html =	'<table><tr><td>附件已转存至FILENET</td></tr>'+
//					'<tr><td><span >批次 流水号：</span><span>' + docObjects[i].propertyList.orderNo +'</span></td></tr>'+
					'<tr><td><span >附件 流水号：</span><span>' + docObjects[i].propertyList.orderNo +'0</span></td></tr>'+
					'<tr><td><span> 请联系总行/分行系统管理员获取  </span></td></tr>'
					+'</table>';
					$("#filesDLG1").html('');
					$("#filesDLG1").html(html);
					$("#filesDLG1").attr("title", "图像信息查看");
		    		$("#filesDLG1").dialog("open")
		    		
				}else{
					html = '<a target="_blank" href="' + url + '">' + '<img style="width:120px;" id="storeImg_' + i
					+ '" src="' + ctx + '/gss/common/js/fancyBox/file.jpg" title="' + fileName + '"/></a>&nbsp;';
					$("#" + this.fancybox_pelementid).append(html);
				}
			}
		}

		// 添加fancybox图片展示效果
		if (hasImage) {
			if (!this.thumbnailByStoreHasInit) {
				this.initFancybox(effectType);
				this.thumbnailByStoreHasInit = true;
			}
		} else {
			this.showMessage("图像不存在！");
		}
	} catch (e) {
		this.showMessage("展示列表图片失败：" + e.message);
	}
	$("div.fancybox-overlay").bgiframe();
	return run;
};






/**
 * 查询数据，执行查询
 */
function queryData() {
	$("#logPeopleManageList").jqGrid("search", "#queryForm");
}

/**
 * 重置查询条件
 */
function resetMethod() {
	$("#queryForm")[0].reset();
	
	
//	alert($('#queryForm').serialize());
//	initOrgNo();
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo,organizationName){
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#" + organizationNo).radioOrgTree(true,organizationSid,0,false,function(event, treeId, treeNode){
		if(treeNode){
//			$("#organizationSid_Item").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
//			$("#"+organizationNo).val(treeNode.organizationNo);
			$("#"+organizationNo).val(treeNode.organizationNo);
			$("#"+organizationName).val(treeNode.organizationName);
		}
	});
}