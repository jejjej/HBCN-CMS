/**
 * 创建于:2015-5-12<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 用印常量
 * 
 * @author Rickychen
 * @version 1.0.0
 */

var sealUseConstants = new Object();

/**
 * 用印申请-用印状态
 */
sealUseConstants.WAITTING_APPROVAL = "001";
sealUseConstants.APPROVAL_PASS = "002";
sealUseConstants.APPROVAL_REFUSE = "003";
sealUseConstants.WAITTING_USE_SEAL = "004";
sealUseConstants.START_USE = "005";
sealUseConstants.USE_SEAL_SUCCESS = "006";
sealUseConstants.USE_SEAL_DISCONNECT = "007";
sealUseConstants.USE_SEAL_EXCEPTION = "008";
sealUseConstants.APPROVAL_TIMEOUT = "009";
sealUseConstants.USE_SEAL_CANCEL = "010";

sealUseConstants.SealUseApplyStatus = {
	"001" : "审批中",
	"002" : "审批通过",
	"003" : "审批拒绝",
	"004" : "等待用印",
	"005" : "开始用印",
	"006" : "用印成功",
	"007" : "用印中通讯异常",
	"008" : "用印异常",
	"000" : "复核中",
	"012" : "客户经理处理",
	"013" : "已删除",
	"101" : "提交业务申请",
	"102" : "打印验证码成功",
	"103" : "打印验证码失败",

	"201" : "等待经理审批",
	"202" : "等待经理会签审批",
	"203" : "等待分管行长审批",
	"204" : "等待行长审批",
	"205" : "等待印章管理员审批",
	"206" : "等待办公室主任审批",
	"207" : "等待文书传递", // 等待文书审批
	"208" : "等待会签文书传递", // 真实状态为等待文书会签审批，由于文书提交给经理无法更新业务状态，故合并为会签审批
	"209" : "等待文书传递", // 等待文书确认
	"210" : "等待申请人员确认",
	"0011":	"仅保存",
	"301" : "等待授信管理部门审批",
	"302" : "等待风险合规部门审批",
	"303" : "等待其他部门审批"
};

/**
 * 用印日志-用印状态
 */
sealUseConstants.LOG_STATUS_WAITTING_USE = "waitting_use";
sealUseConstants.LOG_STATUS_START_USE = "start_use";
sealUseConstants.LOG_STATUS_DISCONNECT = "disconnect";
sealUseConstants.LOG_STATUS_SUCCESS = "success";
sealUseConstants.LOG_STATUS_FAIL = "fail";

sealUseConstants.sealUseLogStatus = {
	"start_use" : "开始用印",
	"disconnect" : "用印中通讯异常",
	"success" : "用印完成",
	"fail" : "用印异常"
};

/**
 * 用印操作日志-操作类型
 */
sealUseConstants.OPT_TYPE_VHOUCHER_APPLY = "voucher_apply";
sealUseConstants.OPT_TYPE_MANAGER_APPR = "manager_appr";
sealUseConstants.OPT_TYPE_DIRECTOR_APPR = "director_appr";
sealUseConstants.OPT_TYPE_SUB_APPR = "sub_appr";
sealUseConstants.OPT_TYPE_BRANCH_APPR = "branch_appr";
sealUseConstants.OPT_TYPE_HEAD_APPR = "head_appr";
sealUseConstants.OPT_TYPE_WAITTING_USE_SEAL = "waitting_use_seal";
sealUseConstants.OPT_TYPE_USE_SEAL_LOCAL_APPR = "use_seal_local_appr";
sealUseConstants.OPT_TYPE_START_USE_SEAL = "start_use_seal";
sealUseConstants.OPT_TYPE_USE_SEAL_FINISH = "use_seal_finish";

sealUseConstants.SealUseOptOperateType = {
	"voucher_apply" : "用印凭证采集",
	"manager_appr" : "部门经理审核",
	"multi_manager_appr" : "部门经理会签审核",
	"secretary_appr" : "部门文书审核",
	"multi_secretary_appr" : "部门文书会签提交",
	"secretary_confirm" : "部门文书确认",
	"applicat_confirm" : "申请人员确认",
	"director_appr" : "办公室主任审核",
	"vice_president_appr" : "分管行长审核",
	"president_appr" : "行长审核",
	"seal_admin_appr" : "印章管理员审核",
	"print_code" : "打印验证码",
	"use_apply" : "申请用印",
	"use_appr" : "用印审批",
	"use_seal_local_appr" : "用印现场监督",
	"start_use_seal" : "开始用印"
};

sealUseConstants.SealUseOptOperateResult = {
	"yes" : "通过",
	"no" : "拒绝",
	"pass" : "通过",
	"refuse" : "拒绝",
	"revert" : "退回",
	"success" : "成功",
	"fail" : "失败"
};

sealUseConstants.TakeSealApplyResult = {
	"approving" : "待审核",
	"pass" : "通过",
	"refuse" : "拒绝",
	"open" : "已取章",
	"upload" : "已保存影像",
	"unopen" : "开侧门超时"
}

sealUseConstants.SealFileType ={
		"1":"0",
		"2":"1"
}
sealUseConstants.RunSealFunc ={
		"0":"打印盖章",
		"1":"开门盖章"
}