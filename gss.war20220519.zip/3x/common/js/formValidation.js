/**
 * 创建于:2015-4-8<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 表单验证<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var formValidation = new Object();

formValidation.init = function(formId, position) {
    $('#' + formId).validationEngine({
	showOnMouseOver : true,
	validationEventTrigger : "keyup blur",
	promptPosition : position,
	autoPositionUpdate : true,
	onValidationComplete : function() {
	}
    });
};

/**
 * 印章编码
 */
function sealCodeValidation(field) {
    if (!/^\d{3}$/.test($(field).val())) {
	return "* 请输入3位数字";
    }
};

/**
 * select
 */
function selectValidation(field) {
    if ($(field).val() == "") {
	return "* 必选项";
    }
};

/**
 * 只允许数字
 * 
 * @param field
 * @returns {String}
 */
function onlyNumber(field) {
    if ($(field).val() != "") {
	if (!/^[0-9]+$/.test($(field).val())) {
	    return "* 请输入数字";
	}
    }
};
