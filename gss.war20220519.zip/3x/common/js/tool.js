/**
 * 创建于:2014-10-31<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 工具包<br>
 * 
 * @author RickyChen
 * @author huhongbin
 * @version 1.0.0
 */

/**
 * 乘法运算<br>
 * js自带的乘法运行符*存在bug
 * 
 * @param arg1
 *            参数1
 * @param arg2
 *            参数2
 */
function multiply(arg1, arg2) {
	var m = 0, s1 = arg1.toString(), s2 = arg2.toString();
	try {
		m += s1.split(".")[1].length
	} catch (e) {
	}
	try {
		m += s2.split(".")[1].length
	} catch (e) {
	}
	return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m)
};

/**
 * 格式化时间
 * 
 * @param fmt
 * @returns
 */
Date.prototype.Format = function(fmt) {
	var o = {
		"M+" : this.getMonth() + 1, // 月份
		"d+" : this.getDate(), // 日
		"h+" : this.getHours(), // 小时
		"m+" : this.getMinutes(), // 分
		"s+" : this.getSeconds(), // 秒
		"q+" : Math.floor((this.getMonth() + 3) / 3), // 季度
		"S" : this.getMilliseconds()
	// 毫秒
	};
	if (/(y+)/.test(fmt))
		fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
	for ( var k in o)
		if (new RegExp("(" + k + ")").test(fmt))
			fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
	return fmt;
};

var tool = new Object();

/**
 * 判断变量是否为空
 * 
 * @returns 如果为null/undefined/''返回true，否则返回false
 */
tool.isNull = function(arg) {
	if (arg == null || arg == undefined || "" == arg || "" == $.trim(arg)) {
		return true;
	}
	return false;
};

/**
 * 获取审批模式参数配置
 * 
 * @param orgNo
 *            机构号
 * @param approvalBiz
 *            审批类型
 * @param async
 *            异步标识；true:异步；false:同步
 * @returns 参数值
 */
tool.getApprovalModeByOrgAndBiz = function(orgNo, approvalBiz, async) {
	var url = ctx + "/param/paramApprovalModeAction_findApprovalModeByOrgAndBiz.action";
	var data = {
		"orgNo" : orgNo,
		"approvalBiz" : approvalBiz
	};
	var result = this.ajaxRequest(url, data, async);
	if (result.success && result.response.responseMessage.success) {
		return result.response.responseMessage.data;
	}

	return result.response.responseMessage.message;
};

/**
 * 获取印控机属性参数
 * 
 * @param machineNum
 *            机器编号
 * @param async
 *            异步标识；true:异步；false:同步
 * @returns 印控机属性Object
 */
tool.getMachineProp = function(defaultProp, machineNum, async) {
	try {
		var url = ctx + "/param/paramMachinePropAction_findMachineProp.action";
		var data = {
			"defaultProp" : defaultProp,
			"paramMachineProp.machineNum" : machineNum
		};
		var result = this.ajaxRequest(url, data, async);
		if (result.success && result.response.responseMessage.success) {
			var propJson = result.response.paramMachineProp.propJson;
			var propObject = (new Function("return " + propJson))();
			return propObject;
		}

		throw new Error(result.response.responseMessage.message);
	} catch (e) {
		throw e;
	}
};

/**
 * ajax请求
 * 
 * @param url
 *            请求url
 * @param data
 *            请求提交的数据
 * 
 * @returns result.success：true/false；result.response:errorMsg/WebResponseJson
 */
tool.ajaxRequest = function(url, data) {
	var result = {};
	result.success = false;
	result.response = "";
	$.ajax({
		type : "post",
		url : url,
		data : data,
		dataType : "json",
		async : false,
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0" || XMLHttpRequest.status != "200") {
				result.response = "服务器或网络异常";
			}
		},
		success : function(response) {
			result.success = true;
			result.response = response;
		}
	});
	return result;
};

/**
 * 用model初始化表单数据<br>
 * <li>用id来识别表单属性而非name</li>
 * <li>表单属性必须要有id属性，并且id的值为属性的名字</li>
 * 
 * @author Rickychen
 */
tool.initForm = function(/* Object */obj) {
	for ( var key in obj) {
		var value = obj[key];
		if (value instanceof Object) {
			tool.initForm(value);
		} else {
			var existProp = $('#' + key);
			if (existProp) {
				$('#' + key).val(value);
			}
		}
	}
};

/**
 * 获取wf中的缓存数据
 */
tool.getParamFromWFCache = function(namespace, key) {
	try {
		// 创建后台设置的命名空间
		var cacheSpace = top.WFCache.getCacheSpace(namespace);
		// 获取该命名空间下的所有缓存值
		var cache = top.WFCache.getPageCache(cacheSpace);
		// 根据key，获取该缓存下的某个值
		return cache.get(key);
	} catch (e) {
		throw e;
	}
};

tool.querySealNum = function(machineCode, tradeCode) {
	var flagSMS = GPCache.get(GPCache.G3X, constants.SMS_SWITCH_KEY);
	if (flagSMS == constants.SMS_SWITCH_FALSE) {
		// 不对接SMS，查询本地安装信息
		var param = {
			'machineCode' : machineCode,
			'tradeCode' : tradeCode
		};
		var url = ctx + "/mechseal/sealuse/mechSealUseAction_querySealNum.action";
		var data = tool.ajaxRequest(url, param);
		if (data.success) {
			var sealNum = data.response.webResponseJson.data;
			if (data.response.webResponseJson.state == "normal") {
				return sealNum;
			} else {
				throw new Error(sealNum);
			}
		} else {
			throw new Error(data.response);
		}
	} else if (flagSMS == constants.SMS_SWITCH_TRUE) {
		// 对接SMS，查询印章管理安装信息
		var sealNum = smsInterface.querySealNum(machineCode, tradeCode);
		return sealNum;
	}
}

/**
 * 印控机使用权限与工作时间校验
 * 
 * @param orgNo
 *            机构号
 * @param deviceNum
 *            设备编号
 * 
 * @returns 能否使用印控机，obj为返回结果集，包过返回的result值与返回的信息data
 */
tool.checkSealMachine = function(orgNo, deviceNum) {
	var obj = {};// 设备校验返回结果集
	try {
		var mmsIntegrationSwitch = GPCache.get(GPCache.G3X, constants.MMS_SWITCH_KEY);
		if (mmsIntegrationSwitch == constants.MMS_SWITCH_FALSE) {
			// 不对接印控机管理系统
			obj.success = true;
			obj.data = "";
			return obj;
		} else if (mmsIntegrationSwitch == constants.MMS_SWITCH_TRUE) {
			// 对接印控机管理系统
			// 权限校验结果集
			var checkMachineObj = mmsInterface.checkSealMachineSwitch(orgNo, deviceNum);
			if (checkMachineObj.success) {
				// 设备使用时间校验结果集
				var checkMachineWorkTimeObj = mmsInterface.checkMachineWorkTimeSwitch(orgNo);
				if (checkMachineWorkTimeObj.success) {
					// 在设备的使用时间内
					return checkMachineWorkTimeObj;
				} else {
					// 不在设备使用时间内
					return checkMachineWorkTimeObj;
				}
				// 有权限使用设备
				return checkMachineObj;
			} else {
				// 没有权限使用设备
				return checkMachineObj;
			}
		} else {
			// 配置文件配置错误
			var data = "GSSParam.param.xml是否对接【印控机管理系统】配置错误！";
			obj.success = false;
			obj.data = data;
			return obj;
		}
	} catch (e) {
		obj.result = false;
		obj.data = e.message;
		return obj;
	}

};