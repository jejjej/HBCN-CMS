﻿var FN_JQGRID = $.fn.jqGrid;

// 行政印章审批
var ADMINAPPR_COLNAMES = [ "autoId", "用印事由", "申请人姓名", "申请人账号", "申请机构", "申请机构号", "申请日期" ];
var ADMINAPPR_COLMODEL = [ {
	name : "id",
	index : "id",
	width : 20,
	hidden : true
}, {
	name : "title",
	index : "title",
	width : 120
}, {
	name : "peopleName",
	index : "peopleName",
	width : 120
}, {
	name : "peopleCode",
	index : "peopleCode",
	width : 120
}, {
	name : "orgName",
	index : "orgName",
	width : 120
}, {
	name : "orgNo",
	index : "orgNo",
	width : 120
}, {
	name : "applyDate",
	index : "applyDate",
	width : 120
} ];

$.fn.jqGrid = function(pin) {
	if (typeof pin == 'string') {
		var fn = $.jgrid.getAccessor(FN_JQGRID, pin);
		if (!fn) {
			throw ("jqGrid - No such method: " + pin);
		}
		var args = $.makeArray(arguments).slice(1);
		return fn.apply(this, args);
	}

	var colNames = null, colModel = null;
	if (pin.colType == "adminAppr") {
		colNames = ADMINAPPR_COLNAMES;
		colModel = ADMINAPPR_COLMODEL;
	}

	if (colNames) {
		for (var i = colNames.length - 1; i >= 0; i--) {
			pin.colNames.splice(0, 0, colNames[i]);
		}
	}
	if (colModel) {
		for (var i = colModel.length - 1; i >= 0; i--) {
			pin.colModel.splice(0, 0, colModel[i]);
		}
	}

	var ret = FN_JQGRID.call(this, pin);
	// this.navGrid(pin.pager);
	return ret;
};

$.fn.getTask = function(url,param, callback) {
	$(this).data("taskSealSn", null);
	$(this).validationEngine("hideAll");
	$(this).dialog("open");
	var _this = this;
	if ("undefined" == url || "" == url || null == url || url.length <= 0) {
		url = $.getContextPath()
		+ "/sms/base/smsBaseTaskListAction_gainTask.action";
	}
	$.post(url, param, function(data) {
		if (data.responseMessage.success) {
			var bizInfo = data.bizInfo;
			if (bizInfo == null) {
				alert("此任务正在处理或者已处理");
				$(_this).dialog("close");
				return;
			}
			$(_this).data("taskSealSn", param.sealSn);
			$(_this).data("autoId", param["bizInfo.id"]);
			callback(data);
		} else {
			$.error("读取数据出错: " + data.responseMessage.message);
		}
	});
};

$.fn.getTaskList = function(param) {
	var defaultparam = {
		caption : "",
		url : "",
		urlParam : "",
		operName : "操作",
		pager : "#pager",
		colType : param.colType || "sealInfo",
		operMethod : [],
		result : ""
	};
	param = $.extend(defaultparam, param);
	for (var i = 0; i < param.operMethod.length; i++) {
		var defaultopermethod = {
			name : "",
			method : "",
			icon : "edit"
		};
		param.operMethod[i] = $.extend(defaultopermethod, param.operMethod[i]);
	}
	var jqGridParam = {
		caption : param.caption,
		url : param.url,
		postData : param.urlParam,
		rownumbers : true,
		multiselect : param.multiselect,
		colType : param.colType,
		pager : param.pager,
		colNames : [],
		colModel : []
	};

	if (param.operMethod.length > 0) {
		jqGridParam.colNames = [ param.operName ];
		jqGridParam.colModel = [ {
			name : "sealSn",
			index : "sealSn",
			width : 80,
			align : "center",
			formatter : function(value, options, rData) {
				var html = "<center><div>";
				$.each(param.operMethod, function(i, d) {
					if (d.method) {
						html += "<div class='icon_" + d.icon + "' onclick='" + d.method + "(\"" + value + "\", \""
								+ rData.node + "\", \"" + options.rowId + "\",\"" + param.result + "\", \"" + d.name
								+ "\", \"" + param.fetchType + "\", \"" + rData.autoId + "\" )' title='" + d.name
								+ "' style='float:left;'></div>";
					} else if (d.form) {
						html += "<div class='icon_" + d.icon + "' onclick='FN_GETTASKLIST_SHOWFORM(\"" + d.form
								+ "\", \"" + rData.id + "\", \"" + value + "\", \"" + rData.node + "\", \"" + d.name
								+ "\", \"" + param.result + "\", \"" + param.fetchType + "\", \"" + d.url
								+ "\")' title='" + d.name + "' style='float:left;'></div>";
					} else if (d.url) {

					}
				});
				html += "</div></center>";
				return html;
			}
		} ];
	}

	$(this).jqGrid(jqGridParam);
	var nav = $.extend({
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	}, param.nav);
	$(this).navGrid(param.pager, nav);

	$(":submit,:button").button();
	$("body").css("visibility", "visible");
};

function FN_GETTASKLIST_SHOWFORM(form, autoId, sealSn, node, title, result, fetchType, url) {
	$(form).fillTask(autoId, sealSn, node, title, result, fetchType, "", url);
}

$.fn.winform = function(param, listId) {
	listId = listId || "#list";

	$(this).each(function() {
		var dialogParam = preform(param, listId, this);
	});
};

/**
 * height: width: submit:[] check: url recheck:url ok: url seal: createSeal
 * showSeal destroySeal differSeal showDestroySeal showDifferSeal
 */
$.fn.form = function(param, listId) {
	listId = listId || "#list";

	$(this).each(function() {
		var dialogParam = preform(param, listId, this);
		$(this).dialog(dialogParam);
	});

};

function preform(param, listId, form) {
	$(form).data("param", param);
	var dialogParam = {
		autoOpen : false,
		height : $(form).attr("height") || param.height || 490,
		width : $(form).attr("width") || param.width || 700,
		beforeclose : param.beforeclose,
		open : param.open,
		modal : true,
		buttons : {},
		defaultclose : function() {
			if ($(form).data("taskSealSn")) {
				$.post($.getContextPath() + "/mechseal/task/adminApprAction_unlockTask.action", {
					"bizInfo.id" : $(form).data("autoId")
				}, function(data) {
				});
			}
			$(form).validationEngine("hideAll");
			$(form)[0].reset();
			$(form).find("input[type=hidden]").val("");
		}
	};

	dialogParam.close = function() {
		if (param.close) {
			param.close();
		}
		dialogParam.defaultclose();
	};
	$.each(param.submit || [], function(i, d) {
		dialogParam.buttons[d.name] = function(event) {
			if (d.beforeSubmit) {
				if (d.beforeSubmit() == false) {
					return;
				}
			}
			tasksubmit(event, d.url, form, listId, param.callback, d.data);
		};
	});
	if (param.check) {
		dialogParam.buttons["同意"] = function(event) {
			$("#checkResult").val("yes");
			tasksubmit(event, param.check, form, listId, param.callback);
		};
		dialogParam.buttons["拒绝"] = function(event) {
			if ($.trim($("#checkOpinion").val()) == "") {
				alert("审核意见不能为空！");
				$("#checkOpinion").focus();
				return;
			}
			$("#checkResult").val("no");
			tasksubmit(event, param.check, form, listId, param.callback);
		};
	}
	if (param.multicheck) {
		dialogParam.buttons["同意"] = function(event) {
			$("#checkResult").val("success");
			tasksubmit(event, param.multicheck, form, listId, param.callback);
		};
		dialogParam.buttons["拒绝"] = function(event) {
			if ($.trim($("#checkOpinion").val()) == "") {
				alert("审核意见不能为空！");
				$("#checkOpinion").focus();
				return;
			}
			$("#checkResult").val("fail");
			tasksubmit(event, param.multicheck, form, listId, param.callback);
		};
	}
	if (param.check2) {
		dialogParam.buttons["退回"] = function(event) {
			$("#checkResult").val("revert");
			tasksubmit(event, param.check2, form, listId, param.callback);
		};
		dialogParam.buttons["同意"] = function(event) {
			$("#checkResult").val("yes");
			tasksubmit(event, param.check2, form, listId, param.callback);
		};
		dialogParam.buttons["拒绝"] = function(event) {
			if ($.trim($("#checkOpinion").val()) == "") {
				alert("审核意见不能为空！");
				$("#checkOpinion").focus();
				return;
			}
			$("#checkResult").val("no");
			tasksubmit(event, param.check2, form, listId, param.callback);
		};
	}

	$(form).data("seal", param.seal);

	$(form).validationEngine({
		showOnMouseOver : true,
		validationEventTrigger : "blur",
		promptPosition : "topLeft",
		showArrow : true,
		autoPositionUpdate : true,
		onValidationComplete : function() {
			return;
		}
	});

	return dialogParam;

}

function tasksubmit(event, url, form, listId, callback, data) {
	if (!$(form).validationEngine("validate")) {
		return;
	}
	data = data ? data() : $(form).serializeForm();

	if ($(form).data("param") && $(form).data("param").beforeSubmit) {
		if (!$(form).data("param").beforeSubmit(data)) {
			return;
		}
	}

	$(event.target).post(
			url,
			data,
			function(data) {
				if (data.responseMessage.success) {
					var message = "操作成功";
					if (data.responseMessage.data) {
						if (/^\w{2}$/.test(data.responseMessage.data)) {
							if (data.responseMessage.data != "FF" && data.responseMessage.data != "F0") {
								message += "："
										+ getTypeName("NodeCode", data.responseMessage.data, "nodeCode", "nodeName");
							}
							if (data.responseMessage.data == "11" || data.responseMessage.data == "51"
									|| data.responseMessage.data == "52") {
								alert(getTypeName("NodeCode", data.responseMessage.data, "nodeCode", "nodeName"));
							}
						}

					}

					if (data.responseMessage.message) {
						message += "：" + data.responseMessage.message;
					}

					$.success(message);

					$(listId).trigger("reloadGrid");
					$(form).dialog("close");
					if (callback) {
						callback(data);
					}
				} else {
					$.error("操作失败: " + data.responseMessage.message);
				}
			});
}

$.del = function(url, param, callback) {
	if (confirm("是否要删除?")) {
		$.post(url, param, function(data) {
			if (data.responseMessage.success) {
				$.success("删除成功");
				$("#list").trigger("reloadGrid");
				if (callback) {
					callback(data);
				}
			} else {
				$.error("删除失败: " + data.responseMessage.message);
			}
		});
	}
};

$.fn.fillTask = function(autoId, sealSn, node, title, result, fetchType, lock, url) {
	var _this = this;
	$(_this).dialog("open");
	if (title) {
		$(_this).dialog("option", "title", title);
	}
	$(_this).getTask(
			url,
			{
				"bizInfo.id" : autoId,
				"sealSn" : sealSn,
				"node" : node,
				"query" : result,
				"fetchType" : fetchType,
				"lock" : lock
			},
			function(data) {
				$(_this).fillForm({
					bizInfo : data.bizInfo
				});
				if ($(_this).data("param") && $(_this).data("param").loadComplete) {
					$(_this).data("param").loadComplete(data);
				}
				if (data.urlList != null && data.urlList.length > 0) {
					wfStoreFancyBox.showAllThumbnailImageByUrl("img", data.urlList, "buttons");
				}
				if (data.apprFlag != null && data.apprFlag == false) {
					$("#apprDiv").hide();
				} else {
					$("#apprDiv").show();
					var xPeopleInfoList = data.xPeopleInfoList;
					$("#appr").empty();
					$(xPeopleInfoList).each(
							function(i, value) {
								$("#appr").append(
										"<option value='" + xPeopleInfoList[i].sid + "'>"
												+ xPeopleInfoList[i].peopleName + "（" + xPeopleInfoList[i].peopleCode
												+ "）</option>");
							});
				}
			});
};

$(function() {
	$(":submit,:button").button();
});
