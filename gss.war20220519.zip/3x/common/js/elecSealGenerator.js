/**
 * 创建于:2014-9-11<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 电子印章控件JS<br>
 * 电子印章控件CLSID：68FB412B-601F-40BF-B679-2A50FFF5BAF0
 * 
 * @author dqq
 * @author Rickychen
 * @version 1.0.0
 */

/**
    Json参数格式说明
	Json格式的属性示例如下：
	{
	  "seal”:
	    {“round”:[{“main”:1, ”rect”:”0,0,100,100”, “borderwidth”:6}],
		 ”text”:[{“content”:”文字”, ”rect”:”0,0,100,100”, “familyname”:”Arial”, “fontsize”:20,“bold”:0, “angle”:0, “offset”:0}],
	     ”image”:[{“path”:”C:/test.jpg”, ”rect”:”0,0,100,100”, “angle”:0}]
	    }
	}
	round表示圆形元素：
	main:是否印章主体圆的标志，印章大小由主体圆确定,0--非主体圆 1--主体圆
	rect:位置坐标,格式为”left,top,right,bottom”，下同
	borderwidth:圆边的宽度
	
	text表示文字元素:
	content:文字的内容
	rect:位置坐标
	familyname:字体类型
	fontsize:字体大小
	bold:粗体标志位
	angle:文字弯曲的角度0--360,如果文字水平此项必须设置为0
	offset:有角度的文字的左右偏移量
	
	image表示图片属性：
	path:图片元素的全路径，格式如：C:/test.jpg.
	rect:位置坐标
	angle:图片的旋转角度 
 */

//印章参数
var sealParam = "";
//印章图片保存路径
var sealPath = top.yzjgssRootPath + "//";

/**
 * @deprecated 已过时
 */
var sealTemplate = {
		/**
		 * 定义印章参数
		 * @returns {Array} 印章参数数组
		 */
		templateArr : function(){
			var arr = new Array();
			//圆形印章参数
			arr[0] = '{"seal":{"round":[{"main":1,"rect":"0,0,220,220","borderwidth":3}],"text":[{"content":"正文","rect":"0,0,220,220","familyname":"宋体","fontsize":20,"bold":0,"angle":210,"offset":0},{"content":"机构名称","rect":"0,110,220,220","familyname":"Arial","fontsize":10,"bold":0,"angle":0,"offset":0},{"content":"印章名称","rect":"0,140,220,220","familyname":"Arial","fontsize":15,"bold":0,"angle":0,"offset":0}],"image":[{"path":"C:/test.jpg","rect":"60,60,150,150","angle":0}]}}';
			//椭圆印章参数
			arr[1] = '{"seal":{"round":[{"main":1,"rect":"0,0,220,165","borderwidth":3}],"text":[{"content":"正文","rect":"0,0,220,165","familyname":"宋体","fontsize":20,"bold":0,"angle":200,"offset":0},{"content":"机构名称","rect":"0,80,220,165","familyname":"Arial","fontsize":10,"bold":0,"angle":0,"offset":0},{"content":"印章名称","rect":"0,100,220,165","familyname":"Arial","fontsize":15,"bold":0,"angle":0,"offset":0}],"image":[{"path":"C:/test.jpg","rect":"60,40,160,140","angle":0}]}}';
			return arr;
		},
		/**
		 * 选择印章模板
		 * @param v 0圆章 1椭圆章
		 */
		chooseTemplate : function(v){
			sealParam = this.templateArr()[v];
		},
		/**
		 * 设置印章模板参数
		 * @param templateParam 印章模板参数,json格式数据
		 */
		setTemplateparam : function(templateParam){
			sealParam = templateParam;
		},
		/**
		 * 设置印章正文内容
		 * @param content 印章正文参数
		 */
		setSealContent : function(content){
			var sealObj = JSON.parse(sealParam);
			sealObj.seal.text[0].content = content;
			sealParam = JSON.stringify(sealObj);
		},
		/**
		 * 设置印章机构名称
		 * @param content 印章机构名称
		 */
		setOrgContent : function(content){
			var sealObj = JSON.parse(sealParam);
			sealObj.seal.text[1].content = content;
			sealParam = JSON.stringify(sealObj);
		},
		/**
		 * 设置印章名称
		 * @param name 印章名称
		 */
		setSealName : function(name){
			var sealObj = JSON.parse(sealParam);
			sealObj.seal.text[2].content = name;
			sealParam = JSON.stringify(sealObj);
		},
		/**
		 * 设置电子印章中心图案
		 * @param imgpath 中心图案图像路径
		 */
		setSealImg : function(imgpath){
			var sealObj = JSON.parse(sealParam);
			sealObj.seal.image[0].path = imgpath;
			sealParam = JSON.stringify(sealObj);
		},
		/**
		 * 如果电子印章无中心图案，则移除印章中心图案
		 */
		removeSealImg : function(){
			var sealObj = JSON.parse(sealParam);
			delete sealObj.seal.image;
			sealParam = JSON.stringify(sealObj);
		},
		/**
		 * 生成电子印章图片
		 * @param sealCtrlObj 电子印章控件
		 * @returns {String} 电子印章图片地址
		 */
		createSeal : function(sealCtrlObj){
			var random = new Date().getTime()+".jpg";
			SetSealProperty(sealCtrlObj,sealParam);
			SaveSealImage(sealCtrlObj,sealPath+random);
			return sealPath+random;
		}
};

/**
 * 设置电子印章属性
 * @param sealJson json数据格式
 */
function setSealProperty(sealJson){
	OCX_SealGenerator.setSealProperty(sealJson);
	OCX_SealGenerator.setScaling(63);//添加缩放比例
}

/**
 * 获取电子印章属性
 */
function getSealProperty(){
	return OCX_SealGenerator.getSealProperty().data;
}

/**
 * 保存生成的电子印章
 * @param imgPath 保存路径
 */
function saveSealImage(imgPath){
	OCX_SealGenerator.saveSealImage(imgPath);
}


/**
 * 生成电子印章图片
 * @param allPropJson 印章模板，即全量属性json串，包含可变参数key
 * @param editablePropJson 可变属性json串，key对应全量属性中的key
 * @returns 电子印章实体json串
 */
function generateElectronicSeal(allPropJson,editablePropJson){
	var elecSealJson = "";
	//var sealModel = JSON.parse(allPropJson);
	var sealModel = $.parseJSON(allPropJson);
	var editable = (new Function("return " + editablePropJson))();
	for(var i=0;i<sealModel.seal.text.length;i++){
		for(var key in editable){
			if(sealModel.seal.text[i].content == key){
				sealModel.seal.text[i].content = editable[key];
			}
		}
	}
	//allPropJson = JSON.stringify(sealModel);
	allPropJson = $.toJSON(sealModel);
	eval("var newAllPropJson = '"+allPropJson+"';");
	elecSealJson = newAllPropJson;
	OCX_SealGenerator.setScaling(63);//添加缩放比例
	OCX_SealGenerator.setSealProperty(newAllPropJson);
	return elecSealJson;
}

/**
 * 替换json可变参数
 * @param allPropJson 印章模板，即全量属性json串，包含可变参数key
 * @param editablePropJson 可变属性json串，key对应全量属性中的key
 * @returns 替换后的电子印章实体json串
 */
function replaceEditableProp(allPropJson,editablePropJson){
	var elecSealJson = "";
	var sealModel = $.parseJSON(allPropJson);
	var editable = (new Function("return " + editablePropJson))();
	for(var i=0;i<sealModel.seal.text.length;i++){
		for(var key in editable){
			if(sealModel.seal.text[i].content == key){
				sealModel.seal.text[i].content = editable[key];
			}
		}
	}
	allPropJson = $.toJSON(sealModel);
	eval("var newAllPropJson = '"+allPropJson+"';");
	elecSealJson = newAllPropJson;
	return elecSealJson;
}