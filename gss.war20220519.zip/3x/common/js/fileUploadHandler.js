/**
 * 创建于:2015-11-16<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * TODO 文件上传封装
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var fileUploadHandler = new Object();

// 常量
fileUploadHandler.fileType = ["jpg", "doc", "docx", "wps", "pdf", "rar", "zip"];
fileUploadHandler.divId = "file_upload_unit_id";
fileUploadHandler.fileListTableId = "file_list_unit_id";
fileUploadHandler.fileId = "file_list_file_id";
fileUploadHandler.uploadUrl = null;
fileUploadHandler.appendUrl = null;
fileUploadHandler.parentDivId = null;
fileUploadHandler.callback = null;

// 临时变量
fileUploadHandler.fileIndex = 0;
fileUploadHandler.storeId = null;

/**
 * 初始化文件上传插件
 * 
 * @param basePath：服务器路径如：http://localhost:8080/gss/
 * @param parentDivId：文件上传div父节点
 * @param callback({"storeId":storeId})
 */
fileUploadHandler.init = function(/* String */basePath,/* String */parentDivId,/* function */callback) {
	this.uploadUrl = basePath + "store/curlFileStoreAction_addAffixObject.action";
	this.appendUrl = basePath + "store/curlFileStoreAction_appendAffixObject.action";
	this.parentDivId = parentDivId;
	this.callback = callback;
	this.addHtmlToPage();
};

/**
 * 激活文件上传页面
 */
fileUploadHandler.active = function() {
	fileUploadHandler.resetCache();
	fileUploadHandler.addFile();
	$("#" + fileUploadHandler.divId).dialog("open");
};

fileUploadHandler.addHtmlToPage = function() {
	$("#" + fileUploadHandler.divId).remove();
	var div = '<div title="请选择需要上传的文件" id="'
			+ fileUploadHandler.divId
			+ '" style="overflow: hidden;"><font color="red">注意：</br> 1.只支持jpg/doc/docx/wps/pdf/zip/rar格式.</br>2.文件名不要超过85个字,文件大小不要超过20M.</font><table style="width:520px;height:390px;text-align:center;"><tr><td><div style="overflow: scroll;width:500px;height:380px;"><table id="'
			+ fileUploadHandler.fileListTableId + '"></table></div></td></tr></table></div>';
	$("#" + fileUploadHandler.parentDivId).append(div);

	$("#" + fileUploadHandler.divId).dialog({
		autoOpen : false,
		resizable : false,
		draggable : false,
		closeOnEscape : false,
		height : 480,
		width : 540,
		modal : true,
		buttons : {
			"增加文件" : fileUploadHandler.addFile,
			"上传" : fileUploadHandler.upload,
			"关闭" : fileUploadHandler.closeUploadDialog
		},
		open : function(event, ui) {
		    $(".ui-dialog-titlebar").show();
		},
		close : function() {
			var storeId = fileUploadHandler.storeId;
			fileUploadHandler.resetCache();
			fileUploadHandler.callback({
				"storeId" : storeId
			});
		}
	});
};

fileUploadHandler.addFile = function() {
	fileUploadHandler.fileIndex++;
	var id = fileUploadHandler.fileId + fileUploadHandler.fileIndex;
	var html = '<tr><td>'+ fileUploadHandler.fileIndex +'.<input id="' + id + '" type="file" upload="false" style="width: 400px"/></td><td id="' + id
			+ '_result" style="padding-left: 15px;color: red;"></td></tr>';
	$("#" + fileUploadHandler.fileListTableId).append(html);
};

fileUploadHandler.upload = function() {
	$('.ui-dialog-buttonpane').find('button:contains("上传")').attr("disabled", "disabled");
	var uploadIndex = 0;
	if (fileUploadHandler.filePathValidation()) {
		libcurlUpload();
	} else {
		alert("未选择文件或文件名超长或文件格式不符合[jpg/doc/docx/wps/pdf/zip/rar]");
		$('.ui-dialog-buttonpane').find('button:contains("上传")').removeAttr("disabled");
	}

	function libcurlUpload() {
		uploadIndex++;
		if (uploadIndex <= fileUploadHandler.fileIndex) {
			var id = fileUploadHandler.fileId + uploadIndex;
			var hasUpload = $("#" + id).attr("upload");
			var path = $("#" + id).val();
			if (path != null && path != undefined && path != "" && "false" == hasUpload) {
				var nameTemp = path.split("\\");
				var name = nameTemp[nameTemp.length - 1];
				var success = false;
				if (fileUploadHandler.storeId == null) {
					// 上传第一个文件
					success = OCX_Libcurl.HttpUpload(fileUploadHandler.uploadUrl, path, {"fileFileName":name}, uploadSuccess);
				} else {
					// 追加文件
					success = OCX_Libcurl.HttpUpload(fileUploadHandler.appendUrl, path, {"fileFileName":name, "storeId" : fileUploadHandler.storeId}, uploadSuccess);
				}
				if (!success) {
					$("#" + id + "_result").html("[×]");
				} else {
					return;
				}
			}

			// 此文件选择框没有文件或有文件上传不成功时，开启上传下一文件
			libcurlUpload();
		} else {
			$('.ui-dialog-buttonpane').find('button:contains("上传")').removeAttr("disabled");
		}
	}

	// 文件上传成功回调函数
	function uploadSuccess(data, seq, rurl, file, param) {
		var id = fileUploadHandler.fileId + uploadIndex;
		if (data.state == "normal") {
			if (fileUploadHandler.storeId == null) {
				fileUploadHandler.storeId = data.data;
			}
			$("#" + id).attr("upload", "true");
			$("#" + id).attr("disabled", "true");
			$("#" + id + "_result").css("color", "green");
			$("#" + id + "_result").html("[√]");
		} else {
			$("#" + id + "_result").html("[×]");
		}

		// 无论上传成功与否都开启上传下一文件
		libcurlUpload();
	}
};

fileUploadHandler.filePathValidation = function() {
	var hasFile = false, result = true;
	for ( var i = 1; i <= fileUploadHandler.fileIndex; i++) {
		var id = fileUploadHandler.fileId + i;
		var v = $("#" + id).val();
		var h = $("#" + id).attr("upload");
		if (v != null && v != undefined && "" != $.trim(v) && "false" == h) {
			hasFile = true;

			var t = v.split("\\");
			var fileName = t[t.length - 1];
			if(fileName.length > 85){
				result = false;
				break;
			}
			var name = t[t.length - 1].split(".");
			// 没有文件后缀名
			if (1 >= name.length) {
				result = false;
				break;
			}

			// 检查文件后缀名
			var rightType = false;
			for ( var j = 0; j < fileUploadHandler.fileType.length; j++) {
				if (name[name.length -1].toLowerCase() == fileUploadHandler.fileType[j]) {
					rightType = true;
					break;
				}
			}
			if (!rightType) {
				result = false;
				$("#" + id).focus();
				break;
			}
		}
	}
	return hasFile && result;
};

fileUploadHandler.closeUploadDialog = function() {
	$("#" + fileUploadHandler.divId).dialog("close");
};

fileUploadHandler.resetCache = function() {
	fileUploadHandler.fileIndex = 0;
	fileUploadHandler.storeId = null;
	$("#" + fileUploadHandler.fileListTableId).html("");
};


/**
 * 初始化Ajax文件上传插件
 * 采用Aja方式上传，客户端无需注册控件
 * @param basePath：服务器路径如：http://localhost:8080/gss/
 * @param parentDivId：文件上传div父节点
 * @param callback({"storeId":storeId})
 */
fileUploadHandler.initAjaxUpload = function(/* String */basePath,/* String */parentDivId,/* String */mediaType,/* function */callback) {
	fileUploadHandler.isUploadSuccess=false;
	this.uploadByAjax=true;
	fileUploadHandler.deleteCount = 0; 
	this.uploadUrl = basePath + "store/curlFileStoreAction_addAffixObject.action";
	this.appendUrl = basePath + "store/curlFileStoreAction_appendAffixObject.action";
	this.deleteDocObjectUrl = basePath + "store/curlFileStoreAction_deleteDocObject.action";
	this.parentDivId = parentDivId;
	this.mediaType=mediaType;
	this.callback = callback;
	this.addHtmlToPage();
};

/**
 * 激活文件上传页面
 */
fileUploadHandler.reactive = function(/* String */storeId) {
	fileUploadHandler.resetCache();
	fileUploadHandler.addFile();
	fileUploadHandler.storeId=storeId;
	$("#" + fileUploadHandler.divId).dialog("open");
};
/**
 * 激活文件上传页面
 */
fileUploadHandler.reactive = function(/* String */storeId,/* String */mediaType) {
	this.mediaType=mediaType;
	fileUploadHandler.resetCache();
	fileUploadHandler.addFile();
	fileUploadHandler.storeId=storeId;
	$("#" + fileUploadHandler.divId).dialog("open");
};



