/**
 * 创建于:2014-9-3<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 弹框提示工具JS<br>
 * 
 * @author RickyChen
 * @author 曾永理
 * @version 1.0.0
 */

/**
 * 弹框提示
 */
//require(["yzj/wf/dojo/tools/msgbox"]);
//function show(msg){
//	wf.msgBox.show({'content':msg,buttons:msgBox.Buttons.OK});
//}
/**
 * 重新封装dialog，修正重复buttonId的bug
 * @author 曾永理
 */
function show(content) {
	/*require(
			[ "dijit/Dialog", "dijit/form/Button" ],
			function(Dialog) {
				var buttonId = "id" + parseInt(Math.random() * 10000);
				content = content
						+ "<br/><br/><div align='center'><button dojoType='dijit.form.Button' hidefocus='true' id='"+ buttonId + "'>确定<tton></div>";
				var alertDialog = new Dialog({
					title : "提示",
					content : content,
					style : "align:center; width: 300px;",
					onHide : function() {
						this.destroyRecursive();
					}
				});
				alertDialog.startup();
				
				var alertButton = dijit.byId(buttonId);
				dojo.connect(alertButton, "onClick", function() {
					alertDialog.hide();
				});
				alertDialog.show();
			});
			*/
	alert(content);
}

/**
 * 确认框
 * 
 * @param content
 * @param callback
 */
function showConfirmDia(content, callback) {
	require([ 'dijit/ConfirmDialog' ], function(ConfirmDialog) {
		var dialog = new ConfirmDialog({
			title : "提示",
			content : content,
			style : "align:center; width: 300px",
			onHide : function() {
				this.destroyRecursive();
			},
			onExecute : function() {
				dialog.hide();
				callback();
			},
			onCancel : function() {
				dialog.hide();
			}
		});
		dialog.show();
	});
};