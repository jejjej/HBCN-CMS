/**
 * 创建于:2015-5-15<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 图片处理工具类
 * 
 * @author Rickychen
 * @version 1.0.0
 */

var imageUtils = new Object();

// -------------------展示单张图片 start-------------------------------
/**
 * 绑定图片编辑事件
 * 
 * @param imgShowParentDiv 图片展示父DIV
 */
imageUtils.bindImageEvent = function (imgShowParentDiv){
	//查看用印图像
	$("#"+imgShowParentDiv).dialog({autoOpen : false,caption : "图像",resizable : false,width:$(window).width()-50,height:$(window).height()-25,modal : true,buttons : {
		"放大" : function() { 
			imgZoom("chkprintPaperImg",1);
		},"缩小" : function() { 
			imgZoom("chkprintPaperImg",0);
		},"左旋转": function() { 
			rotationPicture(document.getElementById("chkprintPaperImg"), -90);
		},"右旋转": function() { 
			rotationPicture(document.getElementById("chkprintPaperImg"), 90);
		},"关闭" : function() { 
			$("#"+imgShowParentDiv).dialog("close"); 
		}
	},close:function(){
	},open:function(){
	}});
}

/**
 * 图片展示
 * 
 * @param storeId 文件存储ID
 * @param mediaType 文件下标
 * @param imgShowParentDiv 图片展示父DIV
 * @param imgShowDiv 图片展示DIV
 */
imageUtils.viewImage = function (storeId, mediaType, imgShowParentDiv, imgShowDiv) {
	try{
		var docObjects = this.fetchFile(storeId);
		if(docObjects == null || docObjects.length <= 0){
			alert("图像未生成");
			return;
		}
		
		var url = null;
		for(var i=0;i<docObjects.length;i++){
			var _mediatype = docObjects[i].propertyList.mediatype;
			if(_mediatype != null && _mediatype == mediaType){
				url = docObjects[i].fileUrl;
				break;
			}
		}

		url = url.replace(/\\/g,"/");
		if(url == null){
			alert("图像未生成");
			return;
		}
		var html = "<img  id='chkprintPaperImg'  style='position:absolute;width:100%;border:0;padding:0;margin:0;left:0px;top:0px;display:block;' src='"
				+ url+"'/>";
		document.getElementById(imgShowDiv).innerHTML = html;
		var img = document.getElementById("chkprintPaperImg");
		img.onload = function() {
			var printImgObj = img;
			var imageRealHeight = $(printImgObj).height();
			var rate = ($(window).height() - 100) / imageRealHeight;
			if (rate < 1) {
				printImgObj.style.width = parseInt(100 * rate) + "%";
			}
		};
		$("#"+imgShowParentDiv).dialog("open");
	}catch(e){
		alert(e.message);
	}finally{
		total_myangle = 0;//每次打开新图片时复原图片的原始角度为0
	}
}

/**
 * 图片展示
 * 
 * @param url 图片路径
 * @param imgShowParentDiv 图片展示父DIV
 * @param imgShowDiv 图片展示DIV
 */
imageUtils.viewImageByUrl = function (url, imgShowParentDiv, imgShowDiv) {
	try{
		var html = "<img  id='chkprintPaperImg'  style='position:absolute;width:100%;border:0;padding:0;margin:0;left:0px;top:0px;display:block;' src='"
			+ url +"'/>";
	document.getElementById(imgShowDiv).innerHTML = html;
	var img = document.getElementById("chkprintPaperImg");
	img.onload = function() {
		var printImgObj = img;
		var imageRealHeight = $(printImgObj).height();
		var rate = ($(window).height() - 100) / imageRealHeight;
		if (rate < 1) {
			printImgObj.style.width = parseInt(100 * rate) + "%";
		}
	};
	$("#"+imgShowParentDiv).dialog("open");
	}catch(e){
		alert(e.message);
	}finally{
		total_myangle = 0;//每次打开新图片时复原图片的原始角度为0
	}
}

//-------------------展示单张图片 end-------------------------------


//-------------------展示所有图片 start-------------------------------

imageUtils.store_id = null;
imageUtils.doc_objects = null;
imageUtils.img_index = 0;
imageUtils.img_seleted = "";
imageUtils.img_size = 0;

/**
 * 绑定用印图片编辑事件
 * 
 * @param imgShowParentDiv
 *            图片展示父DIV
 * @param imgShowDiv
 *            图片展示DIV
 */
imageUtils.bindShowImageListEvent = function(imgShowParentDiv, imgShowDiv) {
	$("#" + imgShowParentDiv).dialog({
		autoOpen : false,
		caption : "图像",
		resizable : false,
		width : $(window).width() - 50,
		height : $(window).height() - 25,
		modal : true,
		buttons : {
			"上一张" : function() {
				total_myangle = 0;// 每次打开新图片时复原图片的原始角度为0
				imageUtils.switchImage(imgShowParentDiv,imgShowDiv, "pre");
			},
			"下一张" : function() {
				total_myangle = 0;// 每次打开新图片时复原图片的原始角度为0
				imageUtils.switchImage(imgShowParentDiv,imgShowDiv, "next");
			},
			"放大" : function() {
				imgZoom(imageUtils.img_seleted, 1);
			},
			"缩小" : function() {
				imgZoom(imageUtils.img_seleted, 0);
			},
			"左旋转" : function() {
				rotationPicture(document.getElementById(imageUtils.img_seleted), -90);
			},
			"右旋转" : function() {
				rotationPicture(document.getElementById(imageUtils.img_seleted), 90);
			},
			"关闭" : function() {
				$("#" + imgShowParentDiv).dialog("close");
			}
		},
		close : function() {
			this.store_id = null;
			this.doc_objects = null;
		},
		open : function() {
		}
	});
}

/**
 * 展示storeId下所有的图片
 * 
 * @param storeId
 *            文件存储ID
 * @param imgShowParentDiv
 *            图片展示父DIV
 * @param imgShowDiv
 *            图片展示DIV
 */
imageUtils.viewImageList = function(storeId, imgShowParentDiv, imgShowDiv) {
	try {
		this.store_id = storeId;
		this.img_seleted = "";
		this.img_index = 0;
		this.doc_objects = this.fetchFile(storeId);
		this.img_size = this.doc_objects.length;
		this.switchImage(imgShowParentDiv, imgShowDiv, 'next');
	} catch (e) {
		alert(e.message);
	} finally {
		total_myangle = 0;// 每次打开新图片时复原图片的原始角度为0
	}
}

/**
 * 切换用印图片
 * 
 * @param imgShowParentDiv
 *            图片展示父DIV
 * @param imgShowDiv
 *            图片展示DIV
 * @param type
 *            标识(pre:前一张；next:下一张)
 */
imageUtils.switchImage = function(imgShowParentDiv, imgShowDiv, type) {
	if(this.img_seleted == ""){
		this.img_seleted = "imgSelected" + this.img_index;
	}else{
		if(type == 'pre'){
			if(this.img_index != 0){
				this.img_index = this.img_index - 1;
				this.img_seleted = "imgSelected" + this.img_index;
			}else{
				return;
			}
		}else if(type == 'next'){
			if(this.img_index != this.img_size-1){
				this.img_index = this.img_index + 1;
				this.img_seleted = "imgSelected" + this.img_index;
			}else{
				return;
			}
		}
	}
	
	if (this.doc_objects == null || this.doc_objects.length <= 0) {
		alert("图像未生成");
		return;
	}
	
	var url = this.doc_objects[this.img_index].fileUrl;
	if (url == null) {
		alert("图像未生成");
		return;
	}
	$("#" + imgShowParentDiv).dialog("close");
	var html = "<img id='"
			+ this.img_seleted
			+ "' style='position:absolute;width:100%;border:0;padding:0;margin:0;left:0px;top:0px;display:block;' src='"
			+ url + "'/>";
	document.getElementById(imgShowDiv).innerHTML = html;
	var img = document.getElementById(this.img_seleted);
	img.onload = function() {
		var printImgObj = img;
		var imageRealHeight = $(printImgObj).height();
		var rate = ($(window).height() - 100) / imageRealHeight;
		if (rate < 1) {
			printImgObj.style.width = parseInt(100 * rate) + "%";
		}
	};
	$("#" + imgShowParentDiv).dialog("open");
	return;
}
//-------------------展示所有图片 end-------------------------------


//--------------------图片下载 start-------------------------------------
/**
 * 获取文件
 * 
 * @param storeId
 *            文件存储Id
 */
imageUtils.fetchFile = function(storeId){
	var success = false;
	var docObjects = null;
	$.ajax({
		type : "post",
		url : ctx + "/store/curlFileStoreAction_findObject.action",
		dataType : "json",
		data: {
			"storeId" : storeId
		},
		async : false,
		success : function(response) {
			if (response.state == "normal") {
				success = true;
			}
			docObjects = response.data;
		},
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0"
					|| XMLHttpRequest.status != "200") {
				docObjects = '网络异常';
			}
		}
	});
	if(success){
		if(docObjects != null){
			return docObjects;
		}else{
			throw new Error("无相应文件信息");
		}
	}else{
		throw new Error(docObjects);
	}
}

//--------------------图片下载 end-------------------------------------