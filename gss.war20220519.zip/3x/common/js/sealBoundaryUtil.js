/**
 * 创建于:2015-02-03<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 印章边界坐标点计算<br>
 * 
 * @author LiuJun
 * @version 1.0.0
 */

// 原图显示时，红框四边分别离原点(左上角)的垂直距离
var MAX_MIN_USEABLE = false;
var X_MIN_DISTANCE;
var X_MAX_DISTANCE;
var Y_MIN_DISTANCE;
var Y_MAX_DISTANCE;

var SEAL_RADIUS = 130; // 每个点预留一个半径大约200mm的盖章边缘，像素约为130

var big_pic_point_list = null; // 原图边界顶点坐标数组
var small_pic_point_list = null; // 裁剪图边界顶点坐标数组
var img_point_info = new Object();

/**
 * TODO 获取原图显示时，红框四边分别离原点(左上角)的垂直距离<br>
 * @param machineNum	设备编号
 * @param defaultProp 默认用印区域参数，由配置分辨率配置
 * 必须先初始化
 */
function setMaxMinDistance(machineNum, defaultProp) {
	try {
		if(defaultProp == undefined) {
			defaultProp = "default_prop";
		}
		var machinePropObject = tool.getMachineProp(defaultProp, machineNum, false);
		X_MIN_DISTANCE = machinePropObject.xMinDistance;
		X_MAX_DISTANCE = machinePropObject.xMaxDistance;
		Y_MIN_DISTANCE = machinePropObject.yMinDistance;
		Y_MAX_DISTANCE = machinePropObject.yMaxDistance;
		MAX_MIN_USEABLE = true;
	} catch (e) {
		alert(e.message);
		return false;
	}
	return true;
}

/**
 * 计算四个角在原图上的坐标
 * 
 * @param imgWidth
 *            裁剪图宽度
 * @param imgHeight
 *            裁剪图高度
 */
function queryCornerPoints(imgWidth, imgHeight, maxWidth, maxHeight) {
	if (imgWidth > maxWidth * 0.95) {
		if (!MAX_MIN_USEABLE && !setMaxMinDistance()) {
			return;
		}
		// 裁剪未成功
		small_pic_point_list = big_pic_point_list = [[X_MIN_DISTANCE, Y_MIN_DISTANCE],
				[X_MAX_DISTANCE, Y_MIN_DISTANCE], [X_MAX_DISTANCE, Y_MAX_DISTANCE], [X_MIN_DISTANCE, Y_MAX_DISTANCE]];
	} else {
		// 每个点预留半个章的位置
		img_point_info.pointNW = OCX_XUSBVideo.getPositionInOriginal(0 + SEAL_RADIUS, 0 + SEAL_RADIUS).data.split(",");
		img_point_info.pointSW = OCX_XUSBVideo.getPositionInOriginal(0 + SEAL_RADIUS, imgHeight - SEAL_RADIUS).data.split(",");
		img_point_info.pointNE = OCX_XUSBVideo.getPositionInOriginal(imgWidth - SEAL_RADIUS, 0 + SEAL_RADIUS).data.split(",");
		img_point_info.pointSE = OCX_XUSBVideo.getPositionInOriginal(imgWidth - SEAL_RADIUS, imgHeight - SEAL_RADIUS).data.split(",");

		img_point_info.pointBase = OCX_XUSBVideo.getPositionInOriginal(0, 0).data.split(",");

		img_point_info.imgAngle = OCX_XUSBVideo.getAngelInOriginal().data;

		// 点的顺序为顺时针
		var origPointList = [img_point_info.pointNW, img_point_info.pointNE, img_point_info.pointSE,
				img_point_info.pointSW];
		generateBoundaryPoints(origPointList, img_point_info.imgAngle, img_point_info.pointBase);
	}
};

/**
 * 判断点是否在多边形内
 */
function isInPolygon(point, useCutImg) {
	var nCross = 0;

	var pointList = null;
	if (useCutImg) {
		pointList = small_pic_point_list;
	} else {
		pointList = big_pic_point_list;
	}
	var nCount = pointList.length;

	for ( var i = 0; i < nCount; i++) {
		var p1 = pointList[i];
		var p2 = pointList[(i + 1) % nCount];

		// 求解 y=p.y 与 p1p2 的交点
		if (p1[1] == p2[1]) // p1p2 与 y=p0.y平行
			continue;

		if (point[1] < Math.min(p1[1], p2[1])) // 交点在p1p2延长线上
			continue;
		if (point[1] >= Math.max(p1[1], p2[1])) // 交点在p1p2延长线上
			continue;

		// 求交点的 X 坐标
		// --------------------------------------------------------------
		var x = (point[1] - p1[1]) * (p2[0] - p1[0]) / (p2[1] - p1[1]) + Number(p1[0]);

		if (x > point[0])
			nCross++; // 只统计单边交点
	}

	// 单边交点为偶数，点在多边形之外 ---
	return (nCross % 2 == 1);
};

function generateBoundaryPoints(origPointList, angle, basePoint) {
	big_pic_point_list = getBoundaryPoints(origPointList);
	small_pic_point_list = translateBoundaryPointsToThumbPic(big_pic_point_list, angle, basePoint);
};

/**
 * 原图上的x、y坐标转换成显示图上的x、y坐标
 */
function translateDisplayValue(value, displaySize, orignalSize) {
	return Math.round(value * displaySize / orignalSize);
};

/**
 * 用canvas显示边界
 * 
 * @param parentDivId
 *            canvas层id
 * @param imgId
 *            图像id
 * @param useCutImg
 *            是否裁剪图
 */
function showBoundaryCanvas(parentDivId, imgId, useCutImg, origWidth, origHeight) {
	var img = document.getElementById(imgId);
	var displayWidth = img.width;
	var displayHeight = img.height;

	initSealCanvas(parentDivId, displayWidth, displayHeight);

	if (useCutImg) {
		// 裁剪图
		writePolygonBoundary("sealMaskCanvas", small_pic_point_list, displayWidth, displayHeight, origWidth, origHeight);
	} else {
		// 原图
		writePolygonBoundary("sealMaskCanvas", big_pic_point_list, displayWidth, displayHeight, origWidth, origHeight);
	}
};

/**
 * 用canvas在图片中绘制矩形
 * 
 * @param canvasDivId
 *            canvas层id
 * @param imgId
 *            图像id
 * @param pointList
 *            四个点的坐标，二维数组
 */
function drawRectangle(canvasDivId, imgId, pointList) {
	var img = document.getElementById(imgId);
	var displayWidth = img.width;
	var displayHeight = img.height;

	initSealCanvas(canvasDivId, displayWidth, displayHeight);

	writePolygonBoundary("sealMaskCanvas", pointList, displayWidth, displayHeight, displayWidth, displayHeight);
};

/**
 * 用canvas显示多边形
 * 
 * @param elementId
 *            canvas元素id
 * @param pointList
 *            顶点坐标列表
 */
function writePolygonBoundary(elementId, pointList, displayWidth, displayHeight, origWidth, origHeight) {
	var element = document.getElementById(elementId);
	if (element != undefined && element.getContext != undefined && pointList != undefined && pointList != null
			&& pointList.length > 2) {
		var length = pointList.length;
		var beginX = Math.round(pointList[length - 1][0] * displayWidth / origWidth);
		var beginY = Math.round(pointList[length - 1][1] * displayHeight / origHeight);
		var ctx = element.getContext("2d");

		ctx.strokeStyle = "red";
		ctx.lineWidth = 1;
		ctx.beginPath();
		ctx.moveTo(beginX, beginY);
		for ( var i = 0; i < length; ++i) {
			var nextX = Math.round(pointList[i][0] * displayWidth / origWidth);
			var nextY = Math.round(pointList[i][1] * displayHeight / origHeight);
			ctx.lineTo(nextX, nextY);
		}
		ctx.closePath();
		ctx.stroke();
	}
};

/**
 * 判断点是否在边界内
 */
function isInsideBoundary(x, y) {
	if (x < X_MIN_DISTANCE || x > X_MAX_DISTANCE || y < Y_MIN_DISTANCE || y > Y_MAX_DISTANCE) {
		return false;
	} else {
		return true;
	}
};

/**
 * 查询是否有越界点，如果有越界点，则转换成边界点
 * 
 * @param orignalPointList
 *            原图的四个点坐标数组，顺时针排序
 * @returns {Array} 新的数组，越界的点会被替换为边界点 (里面可能会含重复点)
 */
function getBoundaryPoints(orignalPointList) {
	var length = orignalPointList.length;
	var resultList = new Array();
	var beforePoint = null;
	var currentPoint = null;
	var nextPoint = null;
	for ( var i = 0; i < length; ++i) {
		if (isInsideBoundary(orignalPointList[i][0], orignalPointList[i][1])) {
			// 原来的坐标点在边界内，不做处理放入新数组中
			resultList.push(orignalPointList[i]);
		} else {
			// 边界外的点，计算其边界点
			beforePoint = orignalPointList[(i - 1 + length) % length]; // 上一个点
			currentPoint = orignalPointList[i]; // 当前坐标点
			nextPoint = orignalPointList[(i + 1) % length]; // 下一个点
			var point1 = null;
			var point2 = null;
			// FIXME 当点位于 左上角、右上角、左下角、右下角 时，判断不一定准确
			if (currentPoint[0] < X_MIN_DISTANCE) {
				point1 = getMiddlePointX(currentPoint, beforePoint, X_MIN_DISTANCE);
				point2 = getMiddlePointX(currentPoint, nextPoint, X_MIN_DISTANCE);
			} else if (currentPoint[0] > X_MAX_DISTANCE) {
				point1 = getMiddlePointX(currentPoint, beforePoint, X_MAX_DISTANCE);
				point2 = getMiddlePointX(currentPoint, nextPoint, X_MAX_DISTANCE);
			} else if (currentPoint[1] < Y_MIN_DISTANCE) {
				point1 = getMiddlePointY(currentPoint, beforePoint, Y_MIN_DISTANCE);
				point2 = getMiddlePointY(currentPoint, nextPoint, Y_MIN_DISTANCE);
			} else if (currentPoint[1] > Y_MAX_DISTANCE) {
				point1 = getMiddlePointY(currentPoint, beforePoint, Y_MAX_DISTANCE);
				point2 = getMiddlePointY(currentPoint, nextPoint, Y_MAX_DISTANCE);
			}
			if (point1 != null) {
				resultList.push(point1);
			}
			if (point2 != null) {
				resultList.push(point2);
			}
		}
	}
	return resultList;
};

/**
 * 取X方向越界边界点
 */
function getMiddlePointX(origPoint, distPoint, xBoundary) {
	var x = xBoundary;
	var y = null;
	var xoffset = distPoint[0] - origPoint[0];
	var yoffset = distPoint[1] - origPoint[1];
	if (xoffset != 0) {
		y = distPoint[1] - (((distPoint[0] - x) / xoffset) * yoffset);
		if (y < Y_MIN_DISTANCE) {
			return [x, Y_MIN_DISTANCE];
		} else if (y > Y_MAX_DISTANCE) {
			return [x, Y_MAX_DISTANCE];
		} else {
			return [x, y];
		}
	}
	return null; // 无中间点
};

/**
 * 取Y方向越界边界点
 */
function getMiddlePointY(origPoint, distPoint, yBoundary) {
	var x = null;
	var y = yBoundary;
	var xoffset = distPoint[0] - origPoint[0];
	var yoffset = distPoint[1] - origPoint[1];
	if (yoffset != 0) {
		x = distPoint[0] - (((distPoint[1] - y) / yoffset) * xoffset);
		if (x < X_MIN_DISTANCE) {
			return [X_MIN_DISTANCE, y];
		} else if (x > X_MAX_DISTANCE) {
			return [X_MAX_DISTANCE, y];
		} else {
			return [x, y];
		}
	}
	return null; // 无中间点
};

/**
 * 计算两点之间的距离
 */
function distanceCAL(point1, point2) {
	// var point1array = point1.split(",");
	// var point2array = point2.split(",");
	var x1 = eval(point1[0]); // 获取第一点的X坐标
	var y1 = eval(point1[1]); // 获取第一点的Y坐标
	var x2 = eval(point2[0]); // 获取第二点的X坐标
	var y2 = eval(point2[1]); // 获取第二点的Y坐标
	var calX = x2 - x1;
	var calY = y2 - y1;
	return Math.round(Math.pow((calX * calX + calY * calY), 0.5));
};

/**
 * 把大图上的坐标点转换成小图的坐标点
 * 
 * @param bigPicPoint
 *            大图的坐标点
 * @param thumbAngle
 *            小图的偏转角度
 * @param thumbBasePoint
 *            小图原点在大图上的坐标值
 * @returns {Array}
 */
function getThumbPicPoint(bigPicPoint, thumbAngle, thumbBasePoint) {
	var distance = distanceCAL(bigPicPoint, thumbBasePoint);
	var arc = Math.atan2(bigPicPoint[1] - thumbBasePoint[1], bigPicPoint[0] - thumbBasePoint[0]);
	var arcDiff = arc - (Math.PI * thumbAngle / 180);
	var y = Math.sin(arcDiff) * distance;
	var x = Math.cos(arcDiff) * distance;
	return [x, y];
};

/**
 * 大图坐标数组转换成小图坐标数组
 * 
 * @param pointList
 *            大图坐标数组
 * @returns {Array} 小图坐标数组
 */
function translateBoundaryPointsToThumbPic(pointList, angle, basePoint) {
	var length = pointList.length;
	var resultList = new Array();
	var tempPoint = null;
	for ( var i = 0; i < length; ++i) {
		if (tempPoint != null) {
			if (tempPoint[0] == pointList[i][0] && tempPoint[0] == pointList[i][1]) {
				continue;
			}
		}
		var point = getThumbPicPoint(pointList[i], angle, basePoint);
		tempPoint = pointList[i];
		resultList.push(point);
	}
	return resultList;
};

/**
 * 初始化canvas画布
 */
function initSealCanvas(parentDivId, displayWidth, displayHeight) {
	var sealCanvasDiv = document.getElementById(parentDivId);
	if (sealCanvasDiv.hasChildNodes()) {
		sealCanvasDiv.removeChild(sealCanvasDiv.childNodes[0]);
	}
	var canvas = document.createElement("canvas");
	canvas.setAttribute("id", "sealMaskCanvas");
	canvas.setAttribute("width", displayWidth);
	canvas.setAttribute("height", displayHeight);
	sealCanvasDiv.appendChild(canvas);
	window.G_vmlCanvasManager.initElement(canvas);
};

/**
 * 清除canvas图像
 */
function clearSealCanvas(parentDivId) {
	var sealCanvasDiv = document.getElementById(parentDivId);
	if (sealCanvasDiv.hasChildNodes()) {
		sealCanvasDiv.removeChild(sealCanvasDiv.childNodes[0]);
	}
};

/**
 * 在canvas上画直线
 * 
 * @param elementId
 *            canvas元素id
 * @param x1
 *            起始点x坐标
 * @param y1
 *            起始点y坐标
 * @param x2
 *            结束点x坐标
 * @param y2
 *            结束点y坐标
 */
function writeLine2D(elementId, x1, y1, x2, y2) {
	var element = document.getElementById(elementId);
	if (element != undefined && element.getContext != undefined) {
		var ctx = element.getContext("2d");

		ctx.strokeStyle = "red";
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.moveTo(x1, y1);
		ctx.lineTo(x2, y2);
		ctx.closePath();
		ctx.stroke();
	}
};

/**
 * 在canvas上写文字
 * 
 * @param elementId
 *            canvas元素id
 * @param text
 *            文字
 * @param x
 *            x坐标
 * @param y
 *            y坐标
 */
function writeText2D(elementId, text, x, y) {
	var element = document.getElementById(elementId);
	if (element != undefined && element.getContext != undefined) {
		var ctx = element.getContext("2d");

		ctx.fillStyle = "red";
		ctx.font = "14px sans-serif";
		ctx.fillText(text, x, y);
	}
};

/**
 * 在canvas上画圆
 * 
 * @param elementId
 *            canvas元素id
 * @param x
 *            中心点x坐标
 * @param y
 *            中心点y坐标
 * @param r
 *            圆半径
 */
function writeCircle(elementId, x, y, r) {
	var element = document.getElementById(elementId);
	if (element != undefined && element.getContext != undefined) {
		var ctx = element.getContext("2d");

		ctx.strokeStyle = "red";
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.arc(x, y, r, 0, 2 * Math.PI);
		ctx.stroke();
	}
};

