/**
 * 创建于:2015-5-12<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 下拉列表工具类
 * 
 * @author Rickychen
 * @version 1.0.0
 */

var selectUtils = new Object();
/**所有配置 */
//<交易码，list[印章配置信息]>
var allTradeCodeConfigs = new Map();
//<模板号，list[印章配置信息]>
var allTpCodeConfigs = new Map();
/**电子用印配置 */
//<交易码，list[印章配置信息]>
var elecTradeCodeConfigs = new Map();
//<模板号，list[印章配置信息]>
var elecTpCodeConfigs = new Map();
/**实物用印配置 */
//<交易码，list[印章配置信息]>
var mateTradeCodeConfigs = new Map();
//<模板号，list[印章配置信息]>
var mateTpCodeConfigs = new Map();

function initConfig(){
	
	var url = ctx + "/gss/sealconfig/sealConfigAction!listAll.action";
    var data = tool.ajaxRequest(url, null);
    if(data.success){
    	if(data.response.responseMessage.success){
    		var data_ = data.response.sealConfigs;
    		for ( var i = 0, len = data_.length; i < len; i++) {
				var sealConfig = data_[i];
				var _sealConfig = allTradeCodeConfigs.get(sealConfig.tradeCode);
				if(!_sealConfig) {//不存在则新建
					_sealConfig = [];
				}
				_sealConfig.push(sealConfig);
				allTradeCodeConfigs.put(sealConfig.tradeCode, _sealConfig);
				
				//tpConfigs
				var tpConfig = allTpCodeConfigs.get(sealConfig.billTplCode);
				if(!tpConfig){
					tpConfig = [];
				}
				tpConfig.push(sealConfig);
				allTpCodeConfigs.put(sealConfig.billTplCode, tpConfig);
			}
    	}else{
    		alert("初始化用印配置异常："+data.response.responseMessage.message);
    	}
    }else{
    	alert("初始化用印配置异常："+data.response);
    }
    
    url = ctx + "/gss/sealconfig/sealConfigAction!listElecMode.action";
    data = tool.ajaxRequest(url, null);
    if(data.success){
    	if(data.response.responseMessage.success){
    		var data_ = data.response.sealConfigs;
    		for ( var i = 0, len = data_.length; i < len; i++) {
				var sealConfig = data_[i];
				var _sealConfig = elecTradeCodeConfigs.get(sealConfig.tradeCode);
				if(!_sealConfig) {//不存在则新建
					_sealConfig = [];
				}
				_sealConfig.push(sealConfig);
				elecTradeCodeConfigs.put(sealConfig.tradeCode, _sealConfig);
				
				//tpConfigs
				var tpConfig = elecTpCodeConfigs.get(sealConfig.billTplCode);
				if(!tpConfig){
					tpConfig = [];
				}
				tpConfig.push(sealConfig);
				elecTpCodeConfigs.put(sealConfig.billTplCode, tpConfig);
			}
    	}else{
    		alert("初始化用印配置异常："+data.response.responseMessage.message);
    	}
    }else{
    	alert("初始化用印配置异常："+data.response);
    }
    
    url = ctx + "/gss/sealconfig/sealConfigAction!listMaterialMode.action";
    data = tool.ajaxRequest(url, null);
    if(data.success){
    	if(data.response.responseMessage.success){
    		var data_ = data.response.sealConfigs;
    		for ( var i = 0, len = data_.length; i < len; i++) {
				var sealConfig = data_[i];
				var _sealConfig = mateTradeCodeConfigs.get(sealConfig.tradeCode);
				if(!_sealConfig) {//不存在则新建
					_sealConfig = [];
				}
				_sealConfig.push(sealConfig);
				mateTradeCodeConfigs.put(sealConfig.tradeCode, _sealConfig);
				
				//tpConfigs
				var tpConfig = mateTpCodeConfigs.get(sealConfig.billTplCode);
				if(!tpConfig){
					tpConfig = [];
				}
				tpConfig.push(sealConfig);
				mateTpCodeConfigs.put(sealConfig.billTplCode, tpConfig);
			}
    	}else{
    		alert("初始化用印配置异常："+data.response.responseMessage.message);
    	}
    }else{
    	alert("初始化用印配置异常："+data.response);
    }
}
/**
 * 初始化流程名称下拉列表
 * 
 * @param selectId
 *                下拉框ID
 */
selectUtils.initWorkFlowIdSelect = function(selectId) {
    $("#" + selectId).empty();
    $("#" + selectId).append("<option value=''>---请选择---</option>");
    for ( var key in constants.WORK_FLOW_ID) {
	$("#" + selectId).append("<option value='" + key + "'>" + constants.WORK_FLOW_ID[key] + "</option>");
    }
};

/**
 * 初始化流程终审机构下拉列表
 * 
 * @param selectId
 *                下拉框ID
 * @param workFlowId
 *                流程名称ID
 */
selectUtils.initWorkFlowFinalAppr = function(selectId, workFlowId) {
    $("#" + selectId).empty();
    $("#" + selectId).append("<option value=''>---请选择---</option>");
    if (workFlowId == constants.KEY_ADMIN_SEAL_USE_APPLY) {
	for ( var key in constants.ADMIN_SEAL_USE_APPLY_FINAL_APPR) {
	    $("#" + selectId).append(
		    "<option value='" + key + "'>" + constants.ADMIN_SEAL_USE_APPLY_FINAL_APPR[key] + "</option>");
	}
    }
};

/**
 * 初始化印章业务种类下拉列表<br>
 * 根据配置决定加载本地印章种类还是加载印章管理系统中的印章种类
 * 
 * @param selectId：下拉框ID
 * @param sealMaterialType：印章材质类型，0：电子印章；1：机控印章
 */
selectUtils.initSealBizTypeByConfig = function(selectId, sealMaterialType) {
    try {
	var integration = GPCache.get(GPCache.G3X, constants.SMS_SWITCH_KEY);
	if (constants.SMS_SWITCH_TRUE == integration) {
	    // 对接印章管理系统
	    if (sealMaterialType == "0") {
	    	alert("【印章管理系统】无电子印章");
		} else {
			var data = smsInterface.querySealBizType();
			if (data.success) {
			    var sealList = data.response.pageBean.data;
			    if (sealList) {
					$("#" + selectId).empty();
					$("#" + selectId).append("<option value=''>---请选择---</option>");
					for ( var i = 0; i < sealList.length; i++) {
					    $("#" + selectId).append(
						    "<option value='" + sealList[i].type + "'>" + sealList[i].name + "</option>");
					    smsInterface.sealBizTypeCache[sealList[i].type] = sealList[i].name;
					}
			    } else {
					$("#" + selectId).empty();
					alert("【印章管理系统】中无任何印章种类信息！");
			    }
			} else {
			    alert("查询【印章管理系统】的印章种类列表失败：" + data.response);
			}
		}
	    this.sealBizTypeCache = smsInterface.sealBizTypeCache;
	} else if (constants.SMS_SWITCH_FALSE == integration) {
	    // 不对接印章管理系统
	    this.initSealBizType(selectId, sealMaterialType);
	} else {
	    alert("GSSParam.param.xml是否对接【印章管理系统】配置错误！");
	}
    } catch (e) {
	alert("初始化印章种类下拉列表失败:" + e.message);
    }
};

/**
 * 初始化印章业务种类下拉列表<br>
 * 只加载本地系统配置的印章种类<br>
 * 
 * @param selectId
 *                下拉框ID
 * @param sealMaterialType
 *                印章材质类型，0：电子印章；1：机控印章
 */
selectUtils.sealBizTypeCache = {};
selectUtils.initSealBizType = function(selectId, sealMaterialType) {
    var param = {
	"sealMaterialType" : sealMaterialType
    };
    var url = ctx + "/param/paramSealBizTypeAction_querySealBizTypeList.action";
    var data = tool.ajaxRequest(url, param);
    if (data.success) {
	if (data.response.webResponseJson.state == "normal") {
	    var paramSealBizTypeList = data.response.webResponseJson.data;
	    if (paramSealBizTypeList != null) {
		$("#" + selectId).empty();
		$("#" + selectId).append("<option value=''>---请选择---</option>");
		$(paramSealBizTypeList)
			.each(
				function(i, value) {
				    $("#" + selectId).append(
					    "<option value='" + paramSealBizTypeList[i].sealBizTypeId + "'>"
						    + paramSealBizTypeList[i].sealBizTypeName + "</option>");
				    selectUtils.sealBizTypeCache[paramSealBizTypeList[i].sealBizTypeId] = paramSealBizTypeList[i].sealBizTypeName;
				});
	    } else {
		$("#" + selectId).empty();
		alert("无此业务印章种类,请先新增此印章种类");
	    }
	} else {
	    alert("服务器响应失败");
	}
    } else {
	alert(data.response);
    }
};

/**
 * 初始化交易代码下拉列表
 * 
 * @param selectId
 *                下拉框ID
 * @param sealMaterialType
 *                印章材质类型，0：电子印章；1：机控印章
 */
selectUtils.initTradeCode = function(selectId, sealMaterialType) {
    var param = {
	"sealMaterialType" : sealMaterialType
    };
    var url = ctx + "/param/paramTradeCodeAction_queryTradeCodeListByOrgAndSealMaterialType.action";
    var data = tool.ajaxRequest(url, param);
    if (data.success) {
	if (data.response.webResponseJson.state == "normal") {
	    var paramTradeCodeListList = data.response.webResponseJson.data;
	    if (paramTradeCodeListList != null) {
		$("#" + selectId).empty();
		$("#" + selectId).append("<option value=''>---请选择---</option>");
		$(paramTradeCodeListList).each(
			function(i, value) {
			    $("#" + selectId).append(
				    "<option value='" + paramTradeCodeListList[i].tradeCode + "'>"
					    + paramTradeCodeListList[i].tradeCodeName + "</option>");
			});
	    } else {
		$("#" + selectId).empty();
		alert("无交易代码信息,请先新增交易代码信息");
	    }
	} else {
	    alert("服务器响应失败");
	}
    } else {
	alert(data.response);
    }
};

/**
 * 初始化分管行长下拉框
 */
selectUtils.initVicePresidentAppr = function(selectId) {
    var url = ctx + "/mechseal/task/adminApprAction_acquireVisePresidents.action";
    var data = tool.ajaxRequest(url);
    if (data.success) {
	if (data.response.responseMessage.success) {
	    var xPeopleInfoList = data.response.xPeopleInfoList;
	    if (xPeopleInfoList != null) {
		$("#" + selectId).empty();
		$(xPeopleInfoList).each(
			function(i, value) {
			    $("#" + selectId).append(
				    "<option value='" + xPeopleInfoList[i].sid + "'>" + xPeopleInfoList[i].peopleName
					    + "（" + xPeopleInfoList[i].peopleCode + "）</option>");
			});
	    } else {
		$("#" + selectId).empty();
		alert("无交易代码信息,请先新增人员信息");
	    }
	} else {
	    alert(data.response.responseMessage.message);
	}
    } else {
	alert(data.response);
    }
};

/**
 * 初始化行长下拉框
 */
selectUtils.initPresidentAppr = function(selectId) {
    var url = ctx + "/mechseal/task/adminApprAction_acquirePresidents.action";
    var data = tool.ajaxRequest(url);
    if (data.success) {
	if (data.response.responseMessage.success) {
	    var xPeopleInfoList = data.response.xPeopleInfoList;
	    if (xPeopleInfoList != null) {
		$("#" + selectId).empty();
		$(xPeopleInfoList).each(
			function(i, value) {
			    $("#" + selectId).append(
				    "<option value='" + xPeopleInfoList[i].sid + "'>" + xPeopleInfoList[i].peopleName
					    + "（" + xPeopleInfoList[i].peopleCode + "）</option>");
			});
	    } else {
		$("#" + selectId).empty();
		alert("无交易代码信息,请先新增人员信息");
	    }
	} else {
	    alert(data.response.responseMessage.message);
	}
    } else {
	alert(data.response);
    }
};

/**
 * 初始化交易代码下拉列表
 * 
 * @param selectId
 *                下拉框ID
 * @param type
 *                交易码配置用印类型，0：电子用印；1：实物用印 2:所有
 */
selectUtils.initTradeCodeConfig = function(selectId, type) {
	var url = ctx + "/gss/sealconfig/sealConfigAction!listAll.action";
	if(type==0){
		url = ctx + "/gss/sealconfig/sealConfigAction!listElecMode.action";
	}else if(type==1){
		url = ctx + "/gss/sealconfig/sealConfigAction!listMaterialMode.action";
	}else if(type==2){
		url = ctx + "/gss/sealconfig/sealConfigAction!listAll.action";
	}
    var data = tool.ajaxRequest(url, null);
    if(data.success){
    	if(data.response.responseMessage.success){
    		var data_ = data.response.sealConfigs;
    		var options = "<option value=''>--请选择--</option>";
    		var t = {};//去重变量
			for ( var i = 0, len = data_.length; i < len; i++) {
				var sealConfig = data_[i];
				if (t.hasOwnProperty(sealConfig.tradeCode) == false) {//没有这个属性，则追加
					var codeName = GPCache.get(GPCache.ESS, GPType.ESS_TRADE_CODE, sealConfig.tradeCode);
					options += ("<option value=\"" + sealConfig.tradeCode + "\">" + codeName + "</option>");
					t[sealConfig.tradeCode] = sealConfig.tradeCode;
				}
			}
			$("#"+selectId).html(options);
    		
    	}else{
    		alert("初始化用印配置异常："+data.response.responseMessage.message);
    	}
    }else{
    	alert("初始化用印配置异常："+data.response);
    }
};

/**
 * 初始化凭证配置
 * @param tradecode
 *                交易代码
 * @param selectId
 *                下拉框ID
 * @param type
 *             用印类型，0：电子用印；1：实物用印 2:所有
 */
selectUtils.initTemplateConfig = function(tradecode,selectId,type){
	var data_;
	if(type==0){
		data_ = elecTradeCodeConfigs.get(tradecode);
	}else if(type==1){
		data_ = mateTradeCodeConfigs.get(tradecode);
	}else if(type==2){
		data_ = allTradeCodeConfigs.get(tradecode);
	}
	var options = "<option value=''>--请选择--</option>";
	var t = {};//去重变量
	for ( var i = 0, len = data_.length; i < len; i++) {
		var sealConfig = data_[i];
		if (t.hasOwnProperty(sealConfig.billTplCode) == false) {//没有这个属性，则追加
			options += ("<option value=\"" + sealConfig.billTplCode + "\">" + sealConfig.billTplName + "</option>");
			t[sealConfig.billTplCode] = sealConfig.billTplCode;
		}
	}
	$("#"+selectId).html(options);
};

selectUtils.tradeInfo = {};
selectUtils.initTradeInfoConfig = function(selectId) {
	var url = ctx + "/gss/tradeInfo/tradeInfo_list.action";
    var data = tool.ajaxRequest(url, null);
    if(data.success){
		var data_ = data.response.responseMessage.data;
		var options = "<option value=''>--请选择--</option>";
		for ( var i = 0, len = data_.length; i < len; i++) {
		    if(data_[i].tradeCode == data_[i]['TradeInfo.tradeCode']){
                options += ("<option value=\"" + data_[i].tradeCode + "\">" + data_[i]['TradeInfo.tradeName'] + "</option>");
            }else{
                options += ("<option value=\"" + data_[i].tradeCode + "\">" + data_[i].tradeName + "</option>");
            }
		    selectUtils.tradeInfo[data_[i].tradeCode] = data_[i].tradeName;
		}
		$("#"+selectId).html(options);
    }else{
    	alert("初始化用印配置异常："+data.response);
    }
};


selectUtils.initTradeInfoConfig1 = function() {
	var url = ctx + "/gss/tradeInfo/tradeInfo_list.action";
    var data = tool.ajaxRequest(url, null);
    if(data.success){
		var data_ = data.response.responseMessage.data;
		for ( var i = 0, len = data_.length; i < len; i++) {
		    selectUtils.tradeInfo[data_[i].tradeCode] = data_[i].tradeName;
		}
    }else{
    	alert("初始化用印配置异常："+data.response);
    }
};

/**
 * 获取印章形状
 */
function mateSealShape(deviceNum,sealType) {
	$.ajax({
		type : "POST",
		url : top.ctx + "/mechseal/sealinstall/sealInstallConfigAction_findShape.action",
		data : {"sealInstallConfig.deviceNum" : deviceNum,"sealInstallConfig.sealType" : sealType},
		dataType : "json",
		async : false,
		success : function(data) {
			var sealShape = data.sealInstallConfig.shape;
			ocxbase_utils.sealImageHandler.shape = sealShape;
		}
	});
}

/**
 * 初始化印章类型配置
 * @param tradecode
 *                交易代码
 * @param selectId
 *                下拉框ID
 * @param type
 *             用印类型，0：电子用印；1：实物用印 2:所有
 */
selectUtils.initSealTypeConfigByTradeCode = function(tradecode,selectId,type){
	var data_;
	if(type==0){
		data_ = elecTradeCodeConfigs.get(tradecode);
	}else if(type==1){
		data_ = mateTradeCodeConfigs.get(tradecode);
	}else if(type==2){
		data_ = allTradeCodeConfigs.get(tradecode);
	}
	var options = "<option value=''>--请选择--</option>";
	var t = {};//去重变量
	for ( var i = 0, len = data_.length; i < len; i++) {
		var sealConfig = data_[i];
		if (t.hasOwnProperty(sealConfig.sealTypeId) == false) {//没有这个属性，则追加
			var sealTypeName = GPCache.get(GPCache.SMS, GPType.SMS_SEAL_TYPE, sealConfig.sealTypeId);
			mateSealShape(machine_num,sealConfig.sealTypeId);
			options += ("<option value=\"" + sealConfig.sealTypeId + "\">" + sealTypeName + "</option>");
			t[sealConfig.sealTypeId] = sealConfig.sealTypeId;
		}
	}
	$("#"+selectId).html(options);
};
/**
 * 初始化印章类型配置
 * @param templateCode
 *                模板编号
 * @param selectId
 *                下拉框ID
 * @param type
 *             用印类型，0：电子用印；1：实物用印 2:所有
 */
selectUtils.initSealTypeConfigByTemplateCode = function(templateCode,selectId,type){
	var data_;
	if(type==0){
		data_ = elecTpCodeConfigs.get(templateCode);
	}else if(type==1){
		data_ = mateTpCodeConfigs.get(templateCode);
	}else if(type==2){
		data_ = allTpCodeConfigs.get(templateCode);
	}
	var options = "<option value=''>--请选择--</option>";
	var t = {};//去重变量
	for ( var i = 0, len = data_.length; i < len; i++) {
		var sealConfig = data_[i];
		if (t.hasOwnProperty(sealConfig.sealTypeId) == false) {//没有这个属性，则追加
			var sealTypeName = GPCache.get(GPCache.SMS, GPType.SMS_SEAL_TYPE, sealConfig.sealTypeId);
			options += ("<option value=\"" + sealConfig.sealTypeId + "\">" + sealTypeName + "</option>");
			t[sealConfig.sealTypeId] = sealConfig.sealTypeId;
		}
	}
	$("#"+selectId).html(options);
};
$().ready(function(){
	//initConfig();
});
