/**
 * 创建于:2015-5-12<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 印章用印常量
 * 
 * @author Rickychen
 * @version 1.0.0
 */

var constants = new Object();

// ---------------审批模式------------------------

constants.MODULE_MAP = {
    "1" : "打印验证码",
    "2" : "打码用印",
    "3" : "远程审批用印",
    "4" : "快速用印",
    "5" : "多票据用印",
    "6" : "多次用印",
    "7" : "文件审批用印",
    "8" : "办公室公章用印"
};

/**
 * 审批模式业务名称
 */
constants.ADMIN_SEAL_USE_APPLY = "admin_seal_use_apply";
constants.ADMIN_BATCH_USE_APPLY = "admin_batch_use_apply";
constants.UNLOAD_SEAL = "unload_seal";

/**
 * 审批模式参数与名称的对应关系
 */
constants.APPROVAL_BIZ = {
    "*" : "通用业务",
    "admin_seal_use_apply" : "行政章文件审批用印",
    "admin_batch_use_apply" : "行政章文件审批批量用印",
    "unload_seal" : "印章卸载"
};

/**
 * 审批模式
 */
constants.NOT_NEED_APPROVAL = "none";
constants.LOCAL_APPROVAL_ONLY = "local";
constants.REMOTE_APPROVAL_ONLY = "remote";
constants.LOCAL_AND_REMOTE_APPROVAL = "local+remote";
constants.LOCAL_OR_REMOTE_APPROVAL = "local|remote";

/**
 * 审批模式与名称的对应关系
 */
constants.APPROVAL_MODE = {
    "none" : "无需审批",
    "local" : "仅现场审批",
    "remote" : "仅远程审批",
    "local+remote" : "现场且远程审批",
    "local|remote" : "现场或远程审批"
};

// ---------------工作流------------------------
/**
 * 流程名称
 */
constants.KEY_ADMIN_SEAL_USE_APPLY = "admin_seal_use_apply";
constants.WORK_FLOW_ID = {
    "admin_seal_use_apply" : "行政章文件审批用印"
};

/**
 * 行政章资料审核流程终审机构
 */
constants.ADMIN_SEAL_USE_APPLY_FINAL_APPR = {
    "1" : "部门经理",
    "2" : "支行行长",
    "3" : "分行行长",
    "4" : "总行行长"
};

constants.JUDGE = {
    "yes" : "是",
    "no" : "否"
};

/**
 * 行政章用印审核工作流前台jsp展示模式
 */
constants.APPR_MODE_LIST_NEXT_HANDLER = 0x001; // 下一处理人列表 即分管行长
constants.APPR_MODE_LIST_MULTI_HANDLER = 0x002;// 会签人员选项列表
constants.APPR_MODE_SELECT_APPR_MODE = 0x004;// 审核模式选择
constants.APPR_MODE_SELECT_PRESIDENT_APPR = 0x008;// 直接跳至行长审批选择
constants.APPR_MODE_SELECT_VICE_APPR = 0x010;// 分管行长审批
/**
 * 行政章用印审核工作流前台jsp按钮显示模式
 */
constants.APPR_BUTTON_MODE_0 = "0";// 显示同意
constants.APPR_BUTTON_MODE_1 = "1";// 显示同意+拒绝
constants.APPR_BUTTON_MODE_2 = "2";// 显示同意+拒绝+退回

// ---------------存储------------------------
/**
 * 文件类型
 */
constants.ADMIN_FILE_APPLY = "apply";

/**
 * 文件标记
 */
constants.ADMIN_SEAL_USE_TRUE = "isSeal";
constants.ADMIN_SEAL_USE_FALSE = "noSeal";

// ---------------参数类型------------------------
constants.sysConfigType = {
    "0" : "系统",
    "1" : "本地"
};

// ---------------后台GSSPARAM参数------------------------
constants.TRADE_CODE_TYPE_KEY = "tradeCodeType";
constants.TRADE_CODE_TYPE_ADMIN = "admin";
constants.TRADE_CODE_TYPE_BIZ = "biz";
constants.TRADE_CODE_TYPE_ALL = "all";

constants.SMS_SWITCH_KEY = "smsIntegrationSwitch";
constants.SMS_SWITCH_TRUE = "true";
constants.SMS_SWITCH_FALSE = "false";

constants.MMS_SWITCH_KEY = "mmsIntegrationSwitch";
constants.MMS_SWITCH_TRUE = "true";
constants.MMS_SWITCH_FALSE = "false";

// ------------------机构扩展属性-----------------
constants.orgExtProperty = {
		"office" : "办公室",
		"node1":"授信管理部",
		"node2":"风险合规部",
		"node3":"其他部门"
};

//-------------------授权机构适用类型---------------

constants.ADAPTERTYPE={
		"1":"授权中心所有机构可选",
		"2":"指定机构可选"
};

//-------------------授权中心配置类型----------------
constants.CONFIGTYPE={
		"1":"印章装卸授权配置",
		"2":"设备维护授权配置",
		"3":"用印授权配置"
};

// ---------------常量与开关------------------------
constants.booleanMap = {
    "true" : "是",
    "false" : "否"
};
/**
 * 打印验证码文件类型
 */
constants.printCodeFileType={
	"1":"本票",
	"2":"汇票",
	"3":"存单"
};
/**
 * 表单配置表单键类型
 */
constants.FORMCONFIGTYPE={
		"APP_SEALUSEAPP_DETAIL":"用印审批详情界面",
		"APP_SEALHANDLEAPP_DETAIL":"印章装卸审批详情界面",
		"APP_SEALUSELOG_QUERY":"用印日志查询界面",
		"APP_SEALUSELOG_DETAIL":"用印日志详情界面"
};
/**
 * 表单配置显示类型
 */
constants.FORMCONFIGSHOWTYPE={
	"text":"text",
	"input":"input",
	"select":"select",
	"checkbox":"checkbox",
	"datetime":"datetime",
	"attach":"attach",
	"hidden":"hidden"		
};
/**
 * 表单配置绑定参数类型
 */
constants.FORMCONFIGDATABINDTYPE={
		"APP_FORM_APPRMODE":"审批模式",
		"APP_FORM_FILELIST":"文件列表",
		"APP_FORM_MUTILDEPTS":"会签部门",
		"APP_FORM_SEALTYPE":"印章类型",
		"APP_FORM_VICEPRESIDENT":"分管行长"
};


/**
 * 打印验证码文件类型对应的验证码位置
 */
constants.printCodePositionMap={
	"1x":"40",
	"1y":"40",
	"2x":"30",
	"2y":"77",
	"3x":"25",
	"3y":"3"
};
/**
 * 印章类型
 */
var sealTypeList = {
    "0" : "电子印章",
    "1" : "机控印章"
};

/**
 * 普通用印，旋转印章开关 true：旋转 false： 不旋转
 */
var normal_use_seal_rotate = true;

/**
 * 快速用印，旋转印章开关 true：旋转 false： 不旋转
 */
var fast_use_seal_rotate = true;

/**
 * 快速用印，切换凭证图片开关
 */
var fast_switch_voucher_image = false;

/**
 * 远程审批用印，切换凭证图片开关
 */
var special_switch_voucher_image = false;

/**
 * 多票据用印，旋转印章开关
 */
var fast_batch_use_rotate = true;

/**
 * 多票据用印，切换凭证图片开关
 */
var fast_batch_use_switch_voucher_image = false;

/**
 * 多次用印，旋转印章开关
 */
var fast_use_several_rotate = true;

/**
 * 多次用印，切换凭证图片开关
 */
var fast_use_several_switch_voucher_image = false;