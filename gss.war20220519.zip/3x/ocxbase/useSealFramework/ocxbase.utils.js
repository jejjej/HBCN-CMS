/**
 * 创建于:2015-07-17<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 印控机用印工具包<br>
 * 1. 鼠标位置获取<br>
 * 2. 印章图片显示处理<br>
 * 3. 键盘快捷键<br>
 * 4. 时间格式化<br>
 * 5. ajax请求<br>
 * 6. 其他
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var ocxbase_utils = {

	// 盖章位置工具(单个印章)
	sealImageHandler : {
		ctx : top.ctx,
		sealImageId : "a_o_u_s_id",
		sealImageDivId : "a_o_u_s_d_id",
		sealImageDivParentId : null,
		voucherImgId : null,
		sealImageAngle : 0,
		imageClickCallback : null,
		shape : 1,

		mousePos : {
			x : null,
			y : null
		},

		posInPictrue : {
			x : null,
			y : null
		},

		/**
		 * TODO 初始化
		 * 
		 * @param sealImageDivParentId：印章图片父节点ID，印章图片追加到此节点下
		 * @param {String}voucherImgId：凭证图片ID
		 * @param {function}imageClickCallback(ret)：图片点击回调函数
		 *            ret.pos.x;ret.pos.y;ret.percent.x;ret.percent.y;
		 */
		init : function(/* String */sealImageDivParentId,/* String */voucherImgId,/* function */imageClickCallback) {
			this.sealImageDivParentId = sealImageDivParentId;
			this.voucherImgId = voucherImgId;
			this.imageClickCallback = imageClickCallback;
			this.addDivToJsp();
			this.bindImgClickEvent();
			ocxbase_utils.bindOnMouseMove(setMousePos);

			function setMousePos(pos) {
				ocxbase_utils.sealImageHandler.mousePos.x = pos.x;
				ocxbase_utils.sealImageHandler.mousePos.y = pos.y;
			}
			
			$( "#a_o_u_s_d_id").draggable({
		        stop: function() {
					var offset = $("#a_o_u_s_id").offset();
					offset.x = offset.left + 40;
					offset.y = offset.top + 40;
					var target = document.getElementById("voucherImg");
					ocxbase_utils.sealImageHandler.posInPictrue.x = offset.x
							- target.offsetParent.offsetLeft - target.offsetParent.offsetParent.offsetLeft;;
					ocxbase_utils.sealImageHandler.posInPictrue.y = offset.y
							- target.offsetParent.offsetTop - target.offsetParent.offsetParent.offsetTop;

					showSealImage(offset.x, offset.y,
							ocxbase_utils.sealImageHandler.sealImageAngle);

					$("#a_o_u_s_d_id").css("z-index","9000");
					// 用印位置百分比(整数，例：46——代表46%)
					var percent = {
						x : Math
								.round(multiply(ocxbase_utils.sealImageHandler.posInPictrue.x / target.offsetWidth, 100)),
						y : Math
								.round(multiply(ocxbase_utils.sealImageHandler.posInPictrue.y / target.offsetHeight, 100))
					};
					ocxbase_utils.sealImageHandler.imageClickCallback({
						pos : ocxbase_utils.sealImageHandler.posInPictrue,
						percent : percent
					});

					function showSealImage(/* String */x,/* String */y,/* String */angle) {
						document.getElementById(ocxbase_utils.sealImageHandler.sealImageId).src = ocxbase_utils.sealImageHandler.ctx
								+ "/3x/ocxbase/useSealFramework/ocxbase_seal_" + angle + ".png";
						$("#" + ocxbase_utils.sealImageHandler.sealImageDivId).css('left', x - 40);
						$("#" + ocxbase_utils.sealImageHandler.sealImageDivId).css('top', y - 40);
						$("#" + ocxbase_utils.sealImageHandler.sealImageDivId).css('display', "");
					}
				
				}
		    });
			$( "#a_o_u_s_d_id" ).draggable({ containment: "#voucherImg", scroll: false });
			$( "#a_o_u_s_d_id" ).draggable({ cursor: "Crosshair", cursorAt: { top: 40, left: 40 } });
		},
		
		addDivToJspNew : function(shape,relPx,t_tradecode, r) {
			$("#" + this.sealImageDivId).remove();
			var angle = "0";
			var url = ctx + "/mechseal/sealhandle/sealImageChangeAction_changeImageSize.action";
			var param = {
				"shape" : shape,
				"angle" : angle,
				"diameter" : parseInt(t_tradecode),
				"relDiameter" : r
			};
			var data = tool.ajaxRequest(url,param);
			if (data.success) {
				var div = '<div id="' + this.sealImageDivId
				+ '"style="position:absolute;width:' + relPx + 'px;height:' + relPx + 'px;z-index:1003;display:none;"><img id="'
				+ this.sealImageId + '" src="' + this.ctx
				+ '/3x/ocxbase/useSealFramework/ocxbase_seal_'+shape+'_0_'+r+'.png" alt="盖章位置"></img></div>';
					$("#" + this.sealImageDivParentId).append(div);
			} else {
				alert(data.response);
			}
		},
		
		initBak : function(/* String */sealImageDivParentId,/* String */voucherImgId,shape,relPx,t_tradecode, r,/* function */imageClickCallback) {
			this.sealImageDivParentId = sealImageDivParentId;
			this.voucherImgId = voucherImgId;
			this.t_tradecode = t_tradecode;
			this.relPx = relPx;
			this.shape = shape;
			this.radius = parseInt(r);
			this.r = parseInt(r);
			this.imageClickCallback = imageClickCallback;
			this.addDivToJspNew(shape,relPx,t_tradecode, parseInt(r));
			this.bindImgClickEventNew(t_tradecode, parseInt(r), relPx,shape);
			ocxbase_utils.bindOnMouseMove(setMousePos);

			function setMousePos(pos) {
				ocxbase_utils.sealImageHandler.mousePos.x = pos.x;
				ocxbase_utils.sealImageHandler.mousePos.y = pos.y;
			}
			
			$( "#a_o_u_s_d_id").draggable({
		        stop: function() {
					var offset = $("#a_o_u_s_id").offset();
					offset.x = offset.left + parseInt(relPx)/2;
					offset.y = offset.top + parseInt(relPx)/2;
					var target = document.getElementById("voucherImg");
					ocxbase_utils.sealImageHandler.posInPictrue.x = offset.x
							- target.offsetParent.offsetLeft - target.offsetParent.offsetParent.offsetLeft;;
					ocxbase_utils.sealImageHandler.posInPictrue.y = offset.y
							- target.offsetParent.offsetTop - target.offsetParent.offsetParent.offsetTop;

					showSealImage(offset.x, offset.y,shape,relPx, parseInt(r),
							ocxbase_utils.sealImageHandler.sealImageAngle);

					$("#a_o_u_s_d_id").css("z-index","9999");
					// 用印位置百分比(整数，例：46——代表46%)
					var percent = {
						x : Math
								.round(multiply(ocxbase_utils.sealImageHandler.posInPictrue.x / target.offsetWidth, 100)),
						y : Math
								.round(multiply(ocxbase_utils.sealImageHandler.posInPictrue.y / target.offsetHeight, 100))
					};
					ocxbase_utils.sealImageHandler.imageClickCallback({
						pos : ocxbase_utils.sealImageHandler.posInPictrue,
						percent : percent
					});

					function showSealImage(/* String */x,/* String */y,shape,relPx, r,/* String */angle) {
						$("#a_o_u_s_d_id").css("z-index","9999");
						document.getElementById(ocxbase_utils.sealImageHandler.sealImageId).src = ocxbase_utils.sealImageHandler.ctx
								+ "/3x/ocxbase/useSealFramework/ocxbase_seal_"+shape+"_"+ angle +"_"+r+ ".png";
						$("#" + ocxbase_utils.sealImageHandler.sealImageDivId).css('left', x - parseInt(relPx)/2);
						$("#" + ocxbase_utils.sealImageHandler.sealImageDivId).css('top', y - parseInt(relPx)/2);
						$("#" + ocxbase_utils.sealImageHandler.sealImageDivId).css('display', "");
					}
				
				}
		    });
			$( "#a_o_u_s_d_id" ).draggable({ containment: "#voucherImg", scroll: false });
			$( "#a_o_u_s_d_id" ).draggable({ cursor: "Crosshair", cursorAt: { top: parseInt(relPx)/2, left: parseInt(relPx)/2 } });
		},
		
		/**
		 * TODO 删除当前显示的印章图片
		 */
		clearSealImage : function() {
			ocxbase_utils.sealImageHandler.sealImageAngle = 0;
			$("#" + ocxbase_utils.sealImageHandler.sealImageDivId).css('display', 'none');
		},

		/**
		 * TODO 旋转印章图片角度
		 */
		rotateSealImage : function() {
			ocxbase_utils.sealImageHandler.sealImageAngle = (ocxbase_utils.sealImageHandler.sealImageAngle + 90) % 360;
			document.getElementById(ocxbase_utils.sealImageHandler.sealImageId).src = ocxbase_utils.sealImageHandler.ctx
					+ "/3x/ocxbase/useSealFramework/ocxbase_seal_"
					+ ocxbase_utils.sealImageHandler.sealImageAngle + ".png?_t=" + new Date().getTime();
		},

		/**
		 * TODO 获取印章角度
		 * 
		 * @returns {Number}
		 */
		getSealAngle : function() {
			return ocxbase_utils.sealImageHandler.sealImageAngle;
		},

		addDivToJsp : function() {
			$("#" + this.sealImageDivId).remove();
			var div = '<div id="' + this.sealImageDivId
					+ '"style="position:absolute;width:94px;height:94px;z-index:1003;display:none;"><img id="'
					+ this.sealImageId + '" src="' + this.ctx
					+ '/3x/ocxbase/useSealFramework/ocxbase_seal_0.png"alt="盖章位置"></img></div>';
			$("#" + this.sealImageDivParentId).append(div);
		},

		bindImgClickEvent : function() {
			$("#" + this.voucherImgId).attr("onclick", "");
			$("#" + this.voucherImgId).bind("click", imgOnclickEvent);

			function imgOnclickEvent(el) {
				ocxbase_utils.sealImageHandler.posInPictrue.x = ocxbase_utils.sealImageHandler.mousePos.x
						- el.target.offsetParent.offsetLeft - el.target.offsetParent.offsetParent.offsetLeft;;
				ocxbase_utils.sealImageHandler.posInPictrue.y = ocxbase_utils.sealImageHandler.mousePos.y
						- el.target.offsetParent.offsetTop - el.target.offsetParent.offsetParent.offsetTop;

				showSealImage(ocxbase_utils.sealImageHandler.mousePos.x, ocxbase_utils.sealImageHandler.mousePos.y,
						ocxbase_utils.sealImageHandler.sealImageAngle);

				// 用印位置百分比(整数，例：46——代表46%)
				var percent = {
					x : Math
							.round(multiply(ocxbase_utils.sealImageHandler.posInPictrue.x / el.target.offsetWidth, 100)),
					y : Math
							.round(multiply(ocxbase_utils.sealImageHandler.posInPictrue.y / el.target.offsetHeight, 100))
				};
				ocxbase_utils.sealImageHandler.imageClickCallback({
					pos : ocxbase_utils.sealImageHandler.posInPictrue,
					percent : percent
				});

				function showSealImage(/* String */x,/* String */y,/* String */angle) {
					document.getElementById(ocxbase_utils.sealImageHandler.sealImageId).src = ocxbase_utils.sealImageHandler.ctx
							+ "/3x/ocxbase/useSealFramework/ocxbase_seal_" + angle + ".png";
					$("#" + ocxbase_utils.sealImageHandler.sealImageDivId).css('left', x - 40);
					$("#" + ocxbase_utils.sealImageHandler.sealImageDivId).css('top', y - 40);
					$("#" + ocxbase_utils.sealImageHandler.sealImageDivId).css('display', "");
				}
			}
		},
		
		bindImgClickEventNew : function(t_tradecode, r, relPx,shape) {
			$("#" + this.voucherImgId).attr("onclick", "");
			$("#" + this.voucherImgId).unbind().bind("click", imgOnclickEvent);

			function imgOnclickEvent(el) {
				ocxbase_utils.sealImageHandler.posInPictrue.x = ocxbase_utils.sealImageHandler.mousePos.x
						- el.target.offsetParent.offsetLeft - el.target.offsetParent.offsetParent.offsetLeft;;
				ocxbase_utils.sealImageHandler.posInPictrue.y = ocxbase_utils.sealImageHandler.mousePos.y
						- el.target.offsetParent.offsetTop - el.target.offsetParent.offsetParent.offsetTop;

				showSealImage(ocxbase_utils.sealImageHandler.mousePos.x, ocxbase_utils.sealImageHandler.mousePos.y,shape,relPx, r,
						ocxbase_utils.sealImageHandler.sealImageAngle);

				// 用印位置百分比(整数，例：46——代表46%)
				var percent = {
					x : Math
							.round(multiply(ocxbase_utils.sealImageHandler.posInPictrue.x / el.target.offsetWidth, 100)),
					y : Math
							.round(multiply(ocxbase_utils.sealImageHandler.posInPictrue.y / el.target.offsetHeight, 100))
				};
				ocxbase_utils.sealImageHandler.imageClickCallback({
					pos : ocxbase_utils.sealImageHandler.posInPictrue,
					percent : percent
				});

				function showSealImage(/* String */x,/* String */y,shape,t_tradecode, r,/* String */angle) {
					$("#a_o_u_s_d_id").css("z-index","9999");
					document.getElementById(ocxbase_utils.sealImageHandler.sealImageId).src = ocxbase_utils.sealImageHandler.ctx
							+ "/3x/ocxbase/useSealFramework/ocxbase_seal_"+shape+"_"+ angle +"_"+r+".png";
					$("#" + ocxbase_utils.sealImageHandler.sealImageDivId).css('left', x - relPx/2);
					$("#" + ocxbase_utils.sealImageHandler.sealImageDivId).css('top', y - relPx/2);
					$("#" + ocxbase_utils.sealImageHandler.sealImageDivId).css('display', "");
				}
			}
		},
		
		/**
		 * TODO 外部扩展
		 */
		external : {
			imageClickCallback : function(ret) {
				var origX = 0;
				var origY = 0;
				if (use_cut_img) {
					origX = ret.pos.x * small_pic_width / display_pic_width;
					origY = ret.pos.y * small_pic_height / display_pic_height;
				} else {
					origX = ret.pos.x * big_pic_width / display_pic_width;
					origY = ret.pos.y * big_pic_height / display_pic_height;
				}
				if (!isInPolygon([origX, origY], use_cut_img)) {
					alert("该点未在边界内，请重新选择");
					$("#xPosition").val("");
					$("#yPosition").val("");
					OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_utils.external.imageClickCallback}-删除当前显示的印章图片");
					ocxbase_utils.sealImageHandler.clearSealImage();
					return;
				}

				// 用印位置字段数据库存储的为整数
				$("#xPosition").val(ret.percent.x);
				$("#yPosition").val(ret.percent.y);

				if (fast_use_seal_rotate) {
					$("#rotateSealImageId").css('display', '');
				}
			}
		}
	},

	// 盖章位置工具(多个印章)
	sealImageListHandler : {
		ctx : top.ctx,
		sealImageId : "a_o_u_s_l_id",
		sealImageDivId : "a_o_u_s_l_d_id",
		sealImageDivParentId : null,
		voucherImgId : null,
		imageClickCallback : null,
		useSealList : null,
		currentSealIndex : null,

		mousePos : {
			x : null,
			y : null
		},

		/**
		 * TODO 初始化
		 * 
		 * @param sealImageDivParentId：印章图片父节点ID，印章图片追加到此节点下
		 * @param {String}voucherImgId：凭证图片ID
		 * @param {function}imageClickCallback(ret)：图片点击回调函数
		 *            ret.pos.x;ret.pos.y;ret.percent.x;ret.percent.y;
		 */
		init : function(/* String */sealImageDivParentId,/* String */voucherImgId,/* function */imageClickCallback) {
			this.sealImageDivParentId = sealImageDivParentId;
			this.voucherImgId = voucherImgId;
			this.imageClickCallback = imageClickCallback;
			this.addDivToJsp();
			this.bindImgClickEvent();
			this.initUseSealArray();
			ocxbase_utils.bindOnMouseMove(setMousePos);

			function setMousePos(pos) {
				ocxbase_utils.sealImageListHandler.mousePos.x = pos.x;
				ocxbase_utils.sealImageListHandler.mousePos.y = pos.y;
			}
		},

		hasSealPosInList : function() {
			return (this.useSealList != null && this.useSealList.length > 0) ? true : false;
		},

		/**
		 * 初始化用印列表
		 */
		initUseSealArray : function() {
			if (typeof (ocxbase_utils.sealImageListHandler.useSealList) == "undefined"
					|| ocxbase_utils.sealImageListHandler.useSealList == null
					|| ocxbase_utils.sealImageListHandler.useSealList.length > 0) {
				ocxbase_utils.sealImageListHandler.useSealList = new Array();
				ocxbase_utils.sealImageListHandler.clearAllSealPic();
				ocxbase_utils.sealImageListHandler.currentSealIndex = 0;
			}
		},

		/**
		 * 添加新的盖章点
		 */
		addNewSealPoint : function(xpos, ypos, angle, displayX, displayY) {
			if (this.useSealList.length >= 10) {
				alert("一次盖章个数最多为【10】个。");
				return;
			}
			var sealPoint = new Object();
			sealPoint.percentX = xpos;// 用印百分比(小数，例：0.45——代表45%)
			sealPoint.percentY = ypos;
			sealPoint.angle = angle;
			sealPoint.index = this.currentSealIndex;
			sealPoint.displayX = displayX;
			sealPoint.displayY = displayY;

			this.drawNewSealPic(sealPoint); // 在界面上显示一个章
			this.useSealList.push(sealPoint);
			this.currentSealIndex++;
		},

		/**
		 * 删除最后一个盖章点
		 */
		removeLastSealPoint : function() {
			if (ocxbase_utils.sealImageListHandler.useSealList
					&& ocxbase_utils.sealImageListHandler.useSealList.length > 0) {
				var point = ocxbase_utils.sealImageListHandler.useSealList.pop();
				ocxbase_utils.sealImageListHandler.removeOneSealPic(point); // 界面上删除一个章的图片
				ocxbase_utils.sealImageListHandler.currentSealIndex--;
			}
		},

		/**
		 * 删除第一个盖章点
		 */
		removeFirstSealPoint : function() {
			if (this.useSealList.length > 0) {
				var point = this.useSealList.shift();
				this.removeOneSealPic(point); // 界面上删除一个章的图片
			}
		},

		/**
		 * 转换最后一个盖章点的角度
		 */
		rotateLastSealPoint : function() {
			if (ocxbase_utils.sealImageListHandler.useSealList
					&& ocxbase_utils.sealImageListHandler.useSealList.length > 0) {
				var sealCount = ocxbase_utils.sealImageListHandler.useSealList.length;
				if (sealCount > 0) {
					ocxbase_utils.sealImageListHandler.useSealList[sealCount - 1].angle = (ocxbase_utils.sealImageListHandler.useSealList[sealCount - 1].angle + 90) % 360;
					document.getElementById("sealImage"
							+ ocxbase_utils.sealImageListHandler.useSealList[sealCount - 1].index).src = ctx
							+ "/3x/ocxbase/useSealFramework/ocxbase_seal_"
							+ ocxbase_utils.sealImageListHandler.useSealList[sealCount - 1].angle+".png";
				}
			}
		},

		/**
		 * 清除显示的盖章点图片
		 */
		clearAllSealPic : function() {
			var sealPicList = window.document.getElementById(ocxbase_utils.sealImageListHandler.sealImageDivId);
			sealPicList.innerHTML = "";
		},

		/**
		 * 显示相应的盖章点图片
		 */
		drawNewSealPic : function(sealPoint) {
			var cssText = "position:absolute;width:94px;height:94px;z-index:3;left:" + (sealPoint.displayX - 40)
					+ "px;top:" + (sealPoint.displayY - 40) + "px;";
			var sealPicList = window.document.getElementById(ocxbase_utils.sealImageListHandler.sealImageDivId);
			var sealPicDiv = document.createElement("div");
			sealPicDiv.setAttribute("id", ocxbase_utils.sealImageListHandler.sealImageId + sealPoint.index);
			sealPicDiv.setAttribute("style", cssText);
			sealPicDiv.style.cssText = cssText;
			var sealPic = document.createElement("img");
			sealPic.setAttribute("id", "sealImage" + sealPoint.index);
			sealPic.setAttribute("src", ctx + "/3x/ocxbase/useSealFramework/ocxbase_seal_" + sealPoint.angle + ".png");
			sealPicDiv.appendChild(sealPic);
			sealPicList.appendChild(sealPicDiv);
		},

		/**
		 * 删除一个盖章点图片
		 */
		removeOneSealPic : function(sealPoint) {
			var sealPicList = window.document.getElementById(ocxbase_utils.sealImageListHandler.sealImageDivId);
			var sealDiv = window.document.getElementById(ocxbase_utils.sealImageListHandler.sealImageId
					+ sealPoint.index);
			if (typeof sealDiv != "undefined" && sealDiv != null) {
				sealPicList.removeChild(sealDiv);
			}
		},

		/**
		 * 重置用印位置
		 */
		resetUseSealPos : function() {
			$("#rotateSealImageId").css('display', 'none');
			$("#deleteLastSealId").css('display', 'none');
			$("#deleteAllSealId").css('display', 'none');
			this.initUseSealArray();
		},

		addDivToJsp : function() {
			$("#" + this.sealImageDivId).remove();
			var div = '<div id="' + this.sealImageDivId + '"></div>';
			$("#" + this.sealImageDivParentId).append(div);
		},

		bindImgClickEvent : function() {
			$("#" + this.voucherImgId).attr("onclick", "");
			$("#" + this.voucherImgId).bind("click", imgOnclickEvent);

			function imgOnclickEvent(el) {
				ocxbase_utils.sealImageListHandler.imageClickCallback(el);
			}
		},

		/**
		 * TODO 外部扩展
		 */
		external : {
			imageClickCallback : function(el) {
				var x = ocxbase_utils.sealImageListHandler.mousePos.x - el.target.offsetParent.offsetLeft
						- el.target.offsetParent.offsetParent.offsetLeft;
				var y = ocxbase_utils.sealImageListHandler.mousePos.y - el.target.offsetParent.offsetTop
						- el.target.offsetParent.offsetParent.offsetTop;

				var percent = {
					x : x / el.target.offsetWidth,
					y : y / el.target.offsetHeight
				};

				var orig_x = 0;
				var orig_y = 0;
				if (use_cut_img) {
					orig_x = x * small_pic_width / display_pic_width;
					orig_y = y * small_pic_height / display_pic_height;
				} else {
					orig_x = x * big_pic_width / display_pic_width;
					orig_y = y * big_pic_height / display_pic_height;
				}
				if (!isInPolygon([orig_x, orig_y], use_cut_img)) {
					alert("该点未在边界内，请重新选择");
					return;
				}
				ocxbase_utils.sealImageListHandler.addNewSealPoint(percent.x, percent.y, 0,
						ocxbase_utils.sealImageListHandler.mousePos.x, ocxbase_utils.sealImageListHandler.mousePos.y);

				// 显示旋转按钮
				if (fast_use_several_rotate) {
					$("#rotateSealImageId").css('display', '');
				}
				$("#deleteLastSealId").css('display', '');
				$("#deleteAllSealId").css('display', '');
			}
		}
	},

	// 下拉框热键
	selectHotKey : {

		/**
		 * TODO 绑定热键(数字键1/2/3/4/5/6)到指定的下拉列表中
		 * 
		 * @param selectId：列拉列表ID
		 */
		init : function(selectId) {
			document.onkeyup = function(e) {
				this.selectId = selectId;
				e = window.event || e;
				var selectObj = $("#" + this.selectId);
				var len = $('#' + this.selectId + ' option').length;
				switch (e.keyCode) {
					case 49 : // 数字键1
					case 97 : // 数字键盘1
						if (len > 0) {
							selectObj.attr('value', $('#' + this.selectId + ' option:eq(0)').val());
						}
						break;
					case 50 : // 数字键2
					case 98 : // 数字键盘2
						if (len > 1) {
							selectObj.attr('value', $('#' + this.selectId + ' option:eq(1)').val());
						}
						break;
					case 51 : // 数字键3
					case 99 : // 数字键盘3
						if (len > 2) {
							selectObj.attr('value', $('#' + this.selectId + ' option:eq(2)').val());
						}
						break;
					case 52 : // 数字键4
					case 100 : // 数字键盘4
						if (len > 3) {
							selectObj.attr('value', $('#' + this.selectId + ' option:eq(3)').val());
						}
						break;
					case 53 : // 数字键5
					case 101 : // 数字键盘5
						if (len > 4) {
							selectObj.attr('value', $('#' + this.selectId + ' option:eq(4)').val());
						}
						break;
					case 54 : // 数字键6
					case 102 : // 数字键盘6
						if (len > 5) {
							selectObj.attr('value', $('#' + this.selectId + ' option:eq(5)').val());
						}
						break;
					default :
						break;
				}
			}
		}
	},

	/**
	 * TODO ajax请求
	 * 
	 * @param url：ajax请求的url
	 * @param data：ajax请求的参数(Object)
	 * @returns {success:true|false,response:Object|String}
	 */
	ajaxRequest : function(url, data) {
		var result = {};
		result.success = false;
		result.response = "";
		$.ajax({
			type : "post",
			url : url,
			data : data,
			dataType : "json",
			async : false,
			complete : function(XMLHttpRequest, textStatus) {
				if (XMLHttpRequest.readyState == "0" || XMLHttpRequest.status != "200") {
					result.response = "服务器或网络异常";
				}
			},
			success : function(response) {
				result.success = true;
				result.response = response;
			}
		});
		return result;
	},

	/**
	 * TODO 生成操作结果
	 * 
	 * @param {boolean}success
	 * @param {Object|String}data
	 * @returns {___optResult0}
	 */
	genOptResult : function(/* boolean */success, /* Object|String */data) {
		var optResult = new Object();
		optResult.success = success;
		optResult.data = data;
		return optResult;
	},

	/**
	 * TODO 绑定鼠标移动事件
	 * 
	 * @param {function}mousePosCallback({pos.x,pos.y})：鼠标移动返回位置信息
	 */
	bindOnMouseMove : function(/* function */mousePosCallback) {
		document.onmousemove = currentPos;

		function currentPos(ev) {
			try {
				ev = ev || window.event;
				var pos = getPos(ev);
				mousePosCallback(pos);
			} catch (e) {
			}

			function getPos(ev) {
				if (ev.pageX || ev.pageY) {
					return {
						x : ev.pageX,
						y : ev.pageY
					};
				}
				return {
					x : ev.clientX + document.body.scrollLeft - document.body.clientLeft,
					y : ev.clientY + document.documentElement.scrollTop
				};
			}
		}
	},
	checkBlankPaper : function(imagePath, width, height,checkBlankPaperDistcut, callback) {
		var imageArea = "[{" + checkBlankPaperDistcut + ","
				+ checkBlankPaperDistcut*0.65 + ","
				+ (width -checkBlankPaperDistcut) + ","
				+ (height - checkBlankPaperDistcut*0.65) + "}]"; // 识别裁剪整张纸  --Guoliesheng 高比较小，乘上系数
		
		
		var disresult = OCX_ImageProcess.checkBlankArea(imagePath, imageArea).data;
		
		if (disresult < 0) {
			return ocxbase_utils.genOptResult(false, "白纸检测识别异常.");
		} else if (disresult >= 0 && disresult <= 150) { // >=0,
			// 为所有区域中差异值最小的值（有字的地方占用的像素点数）
			return ocxbase_utils.genOptResult(false, "识别出空白纸张，取消用印.");
		} else {
			return ocxbase_utils.genOptResult(true, "");
		}
	}
};


/**
 * 格式化时间
 * 
 * @param fmt
 * @returns 格式化后的时间
 */
Date.prototype.Format = function(fmt) {
	var o = {
		"M+" : this.getMonth() + 1, // 月份
		"d+" : this.getDate(), // 日
		"h+" : this.getHours(), // 小时
		"m+" : this.getMinutes(), // 分
		"s+" : this.getSeconds(), // 秒
		"q+" : Math.floor((this.getMonth() + 3) / 3), // 季度
		"S" : this.getMilliseconds()
	// 毫秒
	};
	if (/(y+)/.test(fmt))
		fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
	for ( var k in o)
		if (new RegExp("(" + k + ")").test(fmt))
			fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
	return fmt;
};

/**
 * 创建于:2015-07-10<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 印控机用印权限管理封装<br>
 * 依赖mmsInterface.js、smsInterface.js、tool.js、constants.js
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var ocxbase_Authorization = {

	/**
	 * TODO 印控机使用权限校验，包含工作时间以及使用权限
	 * 
	 * @param machineNum：印控机编号
	 * @param orgNo：机构号
	 * @returns {success:true|false,data:Object|String}
	 */
	checkUseMachinePower : function(machineNum, orgNo) {
		try {
			var ms = GPCache.get(GPCache.G3X, constants.MMS_SWITCH_KEY);
			ms = "false";
			if (ms == constants.MMS_SWITCH_FALSE) {
				// 不对接印控机管理系统
				OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkUseMachinePower}--不对接印控机管理系统");
				return ocxbase_utils.genOptResult(true, null);
			} else if (ms == constants.MMS_SWITCH_TRUE) {
				// 对接印控机管理系统
				OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkUseMachinePower}--对接印控机管理系统");
				var mr = mmsInterface.checkSealMachineSwitch(orgNo, machineNum);
				if (mr.success) {
					var wr = mmsInterface.checkMachineWorkTimeSwitch(orgNo);
					if (!wr.success) {
						// 不在设备使用时间范围内
						OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkUseMachinePower}--对接印控机管理系统--"+wr.data);
						return ocxbase_utils.genOptResult(false, wr.data);
					}

					return ocxbase_utils.genOptResult(true, null);
				} else {
					// 没有权限使用设备
					OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkUseMachinePower}--对接印控机管理系统--"+mr.data);
					return ocxbase_utils.genOptResult(false, mr.data);
				}
			} else {
				// 后台配置错误
				OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkUseMachinePower}--GSSParam.param.xml是否对接【印控机管理系统】配置错误");
				return ocxbase_utils.genOptResult(false, "GSSParam.param.xml是否对接【印控机管理系统】配置错误！");
			}
		} catch (e) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkUseMachinePower}--印控机使用权限校验--"+e.message);
			return ocxbase_utils.genOptResult(false, e.message);
		}
	},
	
	/**
	 * 获取印章配置信息
	 * @param machineNum 设备编号
	 * @param sealType 印章类型id
	 * @returns
	 */
	getSealInstallConfig: function(machineNum, sealType) {
		try {
			// 对接印控机管理系统   
			//无论是否对接SMS系统，都直接查询安装信息即可。有安装记录代表印章是可用的
			OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.getSealInstallConfigs}--获取印章安装配置信息");
			//根据用印印章类型查询设备内是否安装印章
			var ret = mmsInterface.getSealInstallConfig(machineNum, sealType);
			if (ret.success && ret.data) {
				return ocxbase_utils.genOptResult(true, ret.data);
			} else {
				OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.getSealInstallConfigs}--获取印章安装配置信息--"+ret.data);
				return ocxbase_utils.genOptResult(false, ret.data);
			}
		} catch (e) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.getSealInstallConfigs}--获取印章安装配置信息--"+e.message);
			return ocxbase_utils.genOptResult(false, e.message);
		}
	},
	
	/**
	 * TODO 印章使用权限校验<br>
	 * 有权限时返回印章在印控机中的编号，无权限时返回相应提示信息
	 * 
	 * @param machineNum：印控机编号
	 * @param tradeCode：交易代码
	 * @returns {success:true|false,data:Object|String}
	 */
	checkUseSealPower : function(machineNum, tradeCode) {
		var flagSMS = GPCache.get(GPCache.G3X, constants.SMS_SWITCH_KEY);
		if (flagSMS == constants.SMS_SWITCH_FALSE) {
			OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkUseSealPower}--不对接SMS，查询本地安装信息");
			// 不对接SMS，查询本地安装信息
			var param = {
				'machineCode' : machineNum,
				'tradeCode' : tradeCode
			};
			var url = ctx + "/mechseal/sealuse/mechSealUseAction_querySealNum.action";
			var data = tool.ajaxRequest(url, param);
			if (data.success) {
				var sealNum = data.response.webResponseJson.data;
				if (data.response.webResponseJson.state == "normal") {
					OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkUseSealPower}--本地安装信息-正常-sealNum:"+sealNum);
					return ocxbase_utils.genOptResult(true, sealNum);
				} else {
					OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkUseSealPower}--本地安装信息-该印章种类未绑定印控机中的印章位置-sealNum:"+sealNum);
					return ocxbase_utils.genOptResult(false, sealNum);
				}
			} else {
				OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkUseSealPower}--查询本地安装信息异常："+data.response);
				return ocxbase_utils.genOptResult(false, data.response);
			}
		} else if (flagSMS == constants.SMS_SWITCH_TRUE) {
			// 对接SMS，查询印章管理安装信息
			OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkUseSealPower}--对接SMS，查询印章管理安装信息");
			try {
				var sealNum = smsInterface.querySealNum(machineNum, tradeCode);
				OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkUseSealPower}--查询印章管理安装信息-sealNum:"+sealNum);
				return ocxbase_utils.genOptResult(true, sealNum);
			} catch (e) {
				OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkUseSealPower}--查询本地安装信息异常："+data.response);
				return ocxbase_utils.genOptResult(false, e.message);
			}
		}
	},
	/**
	 * TODO 印章使用权限校验<br>
	 * 有权限时返回印章在印控机中的编号，无权限时返回相应提示信息
	 * 
	 * @param machineNum：印控机编号
	 * @param tradeCode：交易代码
	 * @returns {success:true|false,data:Object|String}
	 */
	checkSealNoOil : function(machineNum, tradeCode) {
		var param = {
			'machineCode' : machineNum,
			'tradeCode' : tradeCode
		};
		var url = ctx + "/mechseal/sealuse/mechSealUseAction_querySealNoOil.action";
		var data = tool.ajaxRequest(url, param);
		if (data.success) {
			var sealNoOil = data.response.webResponseJson.data;
			if (data.response.webResponseJson.state == "normal") {
				OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkSealNoOil}--查询是否不蘸印油-sealNoOil:"+sealNoOil);
				return ocxbase_utils.genOptResult(true, sealNoOil);
			} else {
				OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkSealNoOil}--查询是否不蘸印油-该印章种类未设置是否蘸印油");
				return ocxbase_utils.genOptResult(false, sealNoOil);
			}
		} else {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_Authorization.checkSealNoOil}--查询是否不蘸印油："+data.response);
			return ocxbase_utils.genOptResult(false, data.response);
		}
	},
	
	/**
	 * 检查设备是否可用
	 * @param machineNum 设备编号
	 * @returns
	 */
	checkMachineEnable : function(machineNum) {
		var mr = mmsInterface.checkDeviceEnabled(machineNum);
		if (mr.success) {
			return ocxbase_utils.genOptResult(true, "");
		}else{
			return ocxbase_utils.genOptResult(false, mr.data);
		}
	}
};

/**
 * 创建于:2015-07-17<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 文件上传/获取封装<br>
 * 1. 文件上传控件<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var ocxbase_fileStore = {
	ctx : top.ctx,
	basePath : null,
	ocxInitSuccess : false,
	addUrl : null,
	appendUrl : null,
	fetchUrl : null,
	collectUrl : null,

	/**
	 * TODO 初始化控件
	 * 
	 * @param basePath：服务器路径如：http://localhost:8080/gss/
	 * @returns {success:true|false,data:String|Object}
	 */
	initOcx : function(basePath) {
		this.basePath = basePath;
		this.addUrl = this.basePath + "store/curlFileStoreAction_addObject.action";
		this.appendUrl = this.basePath + "store/curlFileStoreAction_appendObject.action";
		this.fetchUrl = this.basePath + "store/curlFileStoreAction_findObject.action";
		this.collectUrl = this.basePath + "store/curlFileStoreAction_collectObject.action";

		// 初始化文件上传控件
		if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, this.ctx + '/activex/api/', 'run')) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.initOcx}--初始化文件上传控件失败");
			return ocxbase_utils.genOptResult(false, "初始化文件上传控件失败");
		}

		OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.initOcx}--初始化文件上传控件成功");
		this.ocxInitSuccess = true;
		return ocxbase_utils.genOptResult(true, "");
	},
	
	/**
	 * TODO 上传新文件
	 * 
	 * @parma localFilePath：文件路径
	 * @param param:jsonObj：类型参数，文件标识key的名字：mediatype
	 * @returns {success:true|false,data:Object|String}
	 */
	addFile : function(/* String */localFilePath, /* jsonObj */param) {
		// 判断控件是否成功加载
		if (!this.ocxInitSuccess) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.addFile}--文件上传控件加载失败");
			return ocxbase_utils.genOptResult(false, "文件上传控件加载失败");
		}

		try {
			var url = this.addUrl;
			param["async"] = false;
			var resultJson = OCX_Libcurl.HttpUpload(url, localFilePath, param, function(){});
			if (resultJson != null && resultJson) {
				//var resultArr = (new Function("return " + resultJson))();
				if ("normal" == resultJson.state) {
					if (resultJson.data != null && resultJson.data) {
						// FIXME 将图片改为已上传或删除本地图片
						OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.addFile}--图片上传成功：" + resultJson.data);
						return ocxbase_utils.genOptResult(true, resultJson.data);
					}
				}
			}
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.addFile}--图片上传失败：" + resultJson.data);
			return ocxbase_utils.genOptResult(false, "图片上传失败:" + resultJson.data);
		} catch (e) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.addFile}--图片上传失败：" + e.message);
			return ocxbase_utils.genOptResult(false, "图片上传失败:" + e.message);
		}
	},
	
	/**
	 * TODO 追加文件
	 * 
	 * @parma localFilePath：文件路径
	 * @param param:jsonObj：类型参数，文件标识key的名字：mediatype
	 * @param storeId：存储ID
	 * @returns {success:true|false,data:Object|String}
	 */
	appendFile : function(/* String */localFilePath, /* jsonObj */param, /* String */storeId) {
		// 判断控件是否成功加载
		if (!this.ocxInitSuccess) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.appendFile}--文件上传控件加载失败");
			return ocxbase_utils.genOptResult(false, "文件上传控件加载失败");
		}

		try {
			var url = this.appendUrl;
			param["async"] = false;
			var resultJson = OCX_Libcurl.appendHttpUpload(url, localFilePath, param, storeId, function(){});
			if (resultJson != null && resultJson) {
				if ("normal" == resultJson.state) {
					if (resultJson.data != null && resultJson.data) {
						// FIXME 将图片改为已上传或删除本地图片
						OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.appendFile}--图片追加成功：" + resultJson.data);
						return ocxbase_utils.genOptResult(true, resultJson.data);
					}
				}
			}
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.appendFile}--文件追加失败：" + resultJson);
			return ocxbase_utils.genOptResult(false, "图片上传失败:" + resultJson);
		} catch (e) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.appendFile}--文件追加失败：" + e.message);
			return ocxbase_utils.genOptResult(false, "图片追加失败:" + e.message);
		}
	},
	
	collectFile : function(/* String */localFilePath, /* jsonObj */param) {
		// 判断控件是否成功加载
		if (!this.ocxInitSuccess) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.collectFile}--文件上传控件加载失败");
			return ocxbase_utils.genOptResult(false, "文件上传控件加载失败");
		}

		try {
			var url = this.collectUrl;
			param["async"] = false;
			var resultJson = OCX_Libcurl.HttpUpload(url, localFilePath, param, function(){});
			if (resultJson != null && resultJson) {
				if ("normal" == resultJson.state) {
					OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.collectFile}--图片上传成功：" + localFilePath);
					return ocxbase_utils.genOptResult(true, resultJson.data);
				}
			}
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.collectFile}--文件上传失败：" + resultJson);
			return ocxbase_utils.genOptResult(false, "图片上传失败:" + resultJson);
		} catch (e) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.collectFile}--文件上传失败：" + e.message);
			return ocxbase_utils.genOptResult(false, "图片追加失败:" + e.message);
		}
	},
	

	/**
	 * TODO 获取文件
	 * 
	 * @param storeId：存储ID
	 * @returns {success:true|false,data:Object|String}
	 */
	fetchFile : function(/* String */storeId) {
		var success = false;
		var urlList = null;
		$.ajax({
			type : "post",
			url : this.fetchUrl,
			dataType : "json",
			data : {
				"storeId" : storeId
			},
			async : false,
			success : function(response) {
				if (response.state == "normal") {
					success = true;
				}
				urlList = response.data;
			},
			complete : function(XMLHttpRequest, textStatus) {
				if (XMLHttpRequest.readyState == "0" || XMLHttpRequest.status != "200") {
					return ocxbase_utils.genOptResult(false, "服务器或网络异常");
				}
			}
		});
		if (success) {
			if (urlList != null && urlList) {
				OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.fetchFile}--获取文件成功：" + urlList);
				return ocxbase_utils.genOptResult(true, urlList);
			} else {
				OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.fetchFile}--不存在相应文件：" + storeId);
				return ocxbase_utils.genOptResult(false, "不存在相应文件");
			}
		} else {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_fileStore.fetchFile}--获取文件异常：" + urlList);
			return ocxbase_utils.genOptResult(false, urlList);
		}
	},
	
	transImg : function(sourcePath,destPath,width,height){
		var resultObj = OCX_Libcurl.transImg(sourcePath,destPath,width,height);
		if(resultObj.code == "1001"){
			return ocxbase_utils.genOptResult(true, resultObj.msg);
		}else{
			return ocxbase_utils.genOptResult(false, resultObj.msg);
		}
	}
};

/**
 * 配置文件助手
 */
var ocxbase_iniHelper = {
		
		iniPath : "c:/yinzhijie/gss.ini",
		//参数配置组
		configParam : {
			open_maincamera_delay : null,//打开主摄像头就绪后拍照延时
			closecapture_maincamera_dealy : null,//纸板关闭后主摄像头拍照延时
			overcapture_maincamera_delay : null,//用印结束后主摄像头拍照延时
			open_sidecamera_delay : null,//侧门摄像头拍照延时
			open_topcamera_delay : null,//顶部摄像头拍照延时
			queryStatus : null//
		},
		
		// 初始化
		init : function(){
			this.configParam.open_maincamera_delay = this.readIni("timeout","open_maincamera_delay", 500);
			this.configParam.closecapture_maincamera_dealy = this.readIni("timeout","closecapture_maincamera_dealy", 1000);
			this.configParam.overcapture_maincamera_delay = this.readIni("timeout","overcapture_maincamera_delay", 1000);
			this.configParam.open_sidecamera_delay = this.readIni("timeout","open_sidecamera_delay", 1000);
			this.configParam.open_topcamera_delay = this.readIni("timeout","open_topcamera_delay", 1000);
			this.configParam.queryStatus = this.readIni("timeout","queryStatus", 500);
		},
		
		/**
		 * 读取gss配置文件值
		 * @param key key值
		 * @param defaultValue 默认值
		 */
		readGssIni : function(key, defaultValue){
			var result = OCX_Tools.readIni(this.iniPath, "gss", key, defaultValue);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_iniHelper.readGssIni}--读取配置文件--key：" + key 
					+ "; value：" + result.data);
			return result.data;
		},
		
		/**
		 * 读取配置文件值
		 * @param group
		 * @param key
		 * @param defaultValue
		 * @returns
		 */
		readIni : function(group , key, defaultValue){
			var result = OCX_Tools.readIni(this.iniPath, group, key, defaultValue);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_iniHelper.readIni}--读取配置文件--key：" + key 
					+ "; value：" + result.data);
			return result.data;
		}
};

/**
 * 创建于:2015-07-10<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 印控机用印信息处理<br>
 * 1. 日志控件<br>
 * 2. 用印等待框<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */
var ocxbase_messageHandler = {
	ctx : top.ctx,
	ocxInitSuccess : false,

	/**
	 * TODO 初始化控件
	 * 
	 * @returns {success:true|false,data:String|Object}
	 */
	initOcx : function() {
		// 初始化日志控件
		if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, document.body, this.ctx + '/activex/api/', 'run')) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_iniHelper.readGssIni}--初始化日志控件失败");
			return ocxbase_utils.genOptResult(false, "初始化日志控件失败");
		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_iniHelper.readGssIni}--初始化日志控件成功");
		this.ocxInitSuccess = true;
		return ocxbase_utils.genOptResult(true, "");
	},

	/**
	 * TODO 绑定按钮click事件
	 * 
	 * @param btnId：按钮ID(ocxbase_messageHandler.btnId.***)
	 * @param event：事件
	 */
	bindClickEvent : function(/* String */btnId, /* function */event) {
		this.messageDialogHelper.bindClickEvent(btnId, event);
	},
	btnId : function() {
		return this.messageDialogHelper.btnId;
	},

	bindNextUseSealClickEvent : function(/* function */event) {
		this.bindClickEvent(this.btnId().nBtnId, event);
	},

	bindCompleteClickEvent : function(/* function */event) {
		this.bindClickEvent(this.btnId().cBtnId, event);
	},
	
	bindCancelClickEvent : function(/* function */event) {
		this.bindClickEvent(this.btnId().ceBtnId, event);
	},

	/**
	 * TODO 增加信息处理<br>
	 * 
	 * @param showDialog：是否显示等待框
	 * @param save：是否保存到本地日志
	 * @param msgType：信息类型"info","error"
	 * @param msg：信息内容
	 */
	addMessage : function(/* boolean */showWaittingDialog,/* boolean */saveLog,/* String */msgType,/* String */msg) {
		if (showWaittingDialog) {
			this.messageDialogHelper.showWaittingDialogAndMessage(msg);
		}
		if (saveLog) {
			this.logger.saveMessage(msgType, msg);
		}
	},

	/**
	 * TODO 处理错误信息
	 * 
	 * @param msg
	 */
	dealErrorMssage : function(/* String */msg) {
		this.addMessage(true, true, "error", msg);
	},

	/**
	 * TODO 展示提示信息
	 * 
	 * @param msg：信息内容
	 */
	showTipMessage : function(/* String */msg) {
		this.addMessage(true, false, "info", msg);
	},

	/**
	 * TODO 隐藏等待框
	 */
	hideWaittingDialog : function() {
		this.messageDialogHelper.hideWaittingDialogAndMessage();
	},

	/**
	 * TODO 显示按钮
	 * 
	 * @param btnTdId：按钮TD标签ID(ocxbase_messageHandler.btnTdId().***)
	 */
	showButton : function(/* String */btnTdId) {
		this.messageDialogHelper.showButton(btnTdId);
	},
	btnTdId : function() {
		return this.messageDialogHelper.btnTdId;
	},

	showAllButton : function() {
		ocxbase_messageHandler.showButton(ocxbase_messageHandler.btnTdId().cTdId);
		ocxbase_messageHandler.showButton(ocxbase_messageHandler.btnTdId().nTdId);
	},

	showCompleteButton : function() {
		ocxbase_messageHandler.showButton(ocxbase_messageHandler.btnTdId().cTdId);
	},
	
	showCancelButton : function() {
		ocxbase_messageHandler.showButton(ocxbase_messageHandler.btnTdId().ceTdId);
	},

	/**
	 * TODO 隐藏按钮
	 * 
	 * @param btnTdId：按钮TD标签ID(ocxbase_messageHandler.btnTdId.***)
	 */
	hideButton : function(/* String */btnTdId) {
		this.messageDialogHelper.hideButton(btnTdId);
	},

	/**
	 * TODO 隐藏消息框中的所有按钮
	 */
	hideAllButton : function() {
		ocxbase_messageHandler.hideButton(ocxbase_messageHandler.btnTdId().cTdId);
		ocxbase_messageHandler.hideButton(ocxbase_messageHandler.btnTdId().nTdId);
		ocxbase_messageHandler.hideButton(ocxbase_messageHandler.btnTdId().ceTdId);
	},

	// ----------------------内部处理器 start------------------------

	// 日志处理器
	logger : {
		appender : "gss",
		type : {
			info : "info",
			error : "error"
		},

		// 保存信息到本地log
		saveMessage : function(/* String */type,/* String */msg) {
			if (this.type.info == type) {
				OCX_Logger.info(LOGGER._3X,"{ocxbase.utilsocxbase_utils.saveMessage}--"+msg);
			} else if (this.type.error == type) {
				OCX_Logger.error(LOGGER._3X,"{ocxbase.utilsocxbase_utils.saveMessage}--"+msg);
			} else {
				OCX_Logger.error(LOGGER._3X,"{ocxbase.utilsocxbase_utils.saveMessage}--未定义的信息类型[" + type + "]：" + msg);
			}
		}
	},

	// 提示信息处理器
	messageDialogHelper : {
		waittingDialogId : "a_o_m_w_d_id",
		waittingDialogInit : false,

		waittingMsgId : "a_o_m_w_d_m_id",

		btnTdId : {
			// 结束用印TD
			cTdId : "a_o_m_com_t_id",
			// 下一笔TD
			nTdId : "a_o_m_next_t_id",
			//取消
			ceTdId : "a_o_m_cancel_t_id"
		},

		btnId : {
			// 结束用印按钮
			cBtnId : "a_o_m_com_b_id",
			// 下一笔按钮
			nBtnId : "a_o_m_next_b_id",
			//取消
			ceBtnId : "a_o_m_cancel_b_id"
		},

		// 初始化信息提示框
		initWaittingDialog : function() {
			$("#" + this.waittingDialogId).remove();
			var div = '<div id="'
					+ this.waittingDialogId
					+ '" style="overflow: hidden;"><table style="width: 350px;height: 250px;text-align:center;" ><tr><td colspan="3"><label id="'
					+ this.waittingMsgId + '" style="font-size:15px;color:blue;"></label></td></tr><tr><td id="'
					+ this.btnTdId.cTdId + '" style="display:none"><button id="' + this.btnId.cBtnId
					+ '">结束用印</button></td><td id="' + this.btnTdId.nTdId + '" style="display:none"><button id="'
					+ this.btnId.nBtnId + '">下一笔</button></td><td id="' + this.btnTdId.ceTdId + '" style="display:none;"><button id="'
					+ this.btnId.ceBtnId + '">返回主页</button></td></tr></table></div>';
			$("body").append(div);

			$("#" + this.waittingDialogId).dialog({
				autoOpen : false,
				resizable : false,
				draggable : false,
				closeOnEscape : false,
				height : 290,
				width : 390,
				modal : true,
				open : function(event, ui) {
					$(".ui-dialog-titlebar").hide();
					$(".ui-dialog-titlebar-close").hide();
				}
			});

			this.waittingDialogInit = true;
		},

		// 绑定按钮click事件
		bindClickEvent : function(/* String */btnId, /* function */event) {
			if (!this.waittingDialogInit) {
				this.initWaittingDialog();
			}

			for ( var key in this.btnId) {
				var value = this.btnId[key];
				if (value == btnId) {
					$("#" + btnId).attr("onclick", "");
					$("#" + btnId).bind("click", event);
					return;
				}
			}
			alert("messageDialogHelper中未定义[" + btnId + "]按钮，绑定click事件失败！");
		},

		// 显示按钮
		showButton : function(/* String */btnTdId) {
			for ( var key in this.btnTdId) {
				var value = this.btnTdId[key];
				if (value == btnTdId) {
					$("#" + btnTdId).css('display', "");
					return;
				}
			}
			alert("messageDialogHelper中未定义[" + btnTdId + "]，显示此按钮失败！");
		},

		// 隐藏按钮
		hideButton : function(/* String */btnTdId) {
			for ( var key in this.btnTdId) {
				var value = this.btnTdId[key];
				if (value == btnTdId) {
					$("#" + btnTdId).css('display', "none");
					return;
				}
			}
			alert("messageDialogHelper中未定义[" + btnTdId + "]，隐藏此按钮失败！");
		},

		// 显示等待dialog
		showWaittingDialogAndMessage : function(/* String */msg) {
			if (!this.waittingDialogInit) {
				this.initWaittingDialog();
			}
			$("#" + this.waittingDialogId).dialog("open");
			$("#" + this.waittingMsgId).html(msg);
		},

		// 隐藏等待dialog
		hideWaittingDialogAndMessage : function() {
			$("#" + this.waittingDialogId).dialog("close");
		}
	}

// ----------------------内部处理器 end--------------------------
};

var ocxbase_Finger = {
	
	ctx : top.ctx,
	ocxInitSuccess : false,

	/**
	 * TODO 初始化控件
	 * 
	 * @returns {success:true|false,data:String|Object}
	 */
	initOcx : function() {
		// 初始化指纹仪控件
		if (!ocxObject.initOcx(ocxObject.OCX_Finger, document.body, this.ctx + '/activex/api/', 'run')) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_Finger.initOcx}--初始化指纹仪控件失败");
			return ocxbase_utils.genOptResult(false, "初始化指纹仪控件失败");
		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Finger.initOcx}--初始化指纹仪控件成功");
		this.ocxInitSuccess = true;
		return ocxbase_utils.genOptResult(true, "");
	},
	
	/**
	 * 获取指纹特征
	 * @param iDevIndex 设备序号(从0开始)
	 * @param nTimeOut 超时时间(单位：毫秒)。
	 * @returns {success:true|false,data:String|Object}
	 *
	 */
	getFeature : function(iDevIndex,nTimeOut){
		var result = OCX_Finger.getFeature(iDevIndex,nTimeOut);
		if(result.code == "1001"){
			OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Finger.getFeature}--获取指纹特征成功");
			return ocxbase_utils.genOptResult(true, result.data);
		}else{
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_Finger.getFeature}--初始化指纹仪控件失败：" + result.msg);
			return ocxbase_utils.genOptResult(false, result.msg);
		}
	},
	
	/**
	 * 指纹模板与指纹特征比对。
	 * @param mb - 指纹模板数据，经过Base64编码后的字符串
	 * @param tz - 指纹特征数据，经过Base64编码后的字符串
	 * @param level - 安全等级，1-5级，级别越高，越安全，一般取3。
	 * @returns {success:true|false,data:String|Object}
	 */
	fingerMatch : function(mb, tz,level){
		var result = OCX_Finger.fingerMatch(mb, tz,level);
		if(result.code == "1001"){
			OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Finger.fingerMatch}--指纹比对通过");
			return ocxbase_utils.genOptResult(true, "比对通过");
		}else{
			OCX_Logger.erro(LOGGER._3X,"{ocxbase.utils.ocxbase_Finger.fingerMatch}--指纹比对失败");
			return ocxbase_utils.genOptResult(false, "比对失败");
		}
	},
	
	/**
	 * 4.获取指纹模板
	 * @param iDevIndex 设备序号(从0开始)
	 * @param nTimeOut 超时时间(单位：毫秒)。
	 * @returns {success:true|false,data:String|Object} 
	 */
	getTemplate : function(iDevIndex,nTimeOut) {
		var result = OCX_Finger.getTemplate(iDevIndex,nTimeOut);
		if(result.code == "1001"){
			OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Finger.fingerMatch}--获取指纹模板成功");
			return ocxbase_utils.genOptResult(true, result.data);
		}else{
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_Finger.fingerMatch}--获取指纹模板失败：" + result.msg);
			return ocxbase_utils.genOptResult(false, result.msg);
		}
	},
	
	/**
	 * 获取指纹模板时的图像。（调用该函数时，需要先调用GetTemplate函数）
	 * @param iImageIndex 图像序号，1-3
	 * @returns {success:true|false,data:String|Object} 
	 */
	getTemplateImage : function(iImageIndex) {
		var result = OCX_Finger.getTemplateImage(iImageIndex);
		if(result.code == "1001"){
			OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Finger.getTemplateImage}--获取指纹模板时的图像成功");
			return ocxbase_utils.genOptResult(true, result.data);
		}else{
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_Finger.getTemplateImage}--获取指纹模板时的图像失败：" + result.msg);
			return ocxbase_utils.genOptResult(false, result.msg);
		}
	},
	
	/**
	 * 将Base64编码的指纹图像数据，保存为BMP文件
	 * @param szFileName BMP文件名
	 * @param pImage 指纹图像数据，并且经过Base64编码后的字符串
	 * @returns {success:true|false,data:String|Object} 
	 */
	imageToBmpFile : function(szFileName, pImage) {
		var result = OCX_Finger.imageToBmpFile(szFileName, pImage);
		if(result.code == "1001"){
			OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Finger.imageToBmpFile}--指纹图像数据装维BMP文件成功：" + result.msg);
			return ocxbase_utils.genOptResult(true, result.msg);
		}else{
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_Finger.imageToBmpFile}--指纹图像数据装维BMP文件失败：" + result.msg);
			return ocxbase_utils.genOptResult(false, result.msg);
		}
	},
	
	/**
	 * 获取指纹模板
	 * @param iPort 串口号（1：串口1，2：串口2，3：串口3）
	 * @param nTimeOut 超时时间(单位：毫秒)
	 * @returns {success:true|false,data:String|Object} 
	 */
	getComTemplate : function(iPort, nTimeOut) {
		var result = OCX_Finger.getComTemplate(iPort, nTimeOut);
		if(result.code == "1001"){
			OCX_Logger.info(LOGGER._3X,"{ocxbase.utils.ocxbase_Finger.getComTemplate}--获取指纹模板成功：" + result.data);
			return ocxbase_utils.genOptResult(true, result.data);
		}else{
			OCX_Logger.error(LOGGER._3X,"{ocxbase.utils.ocxbase_Finger.getComTemplate}--获取指纹模板失败：" + result.msg);
			return ocxbase_utils.genOptResult(false, result.msg);
		}
	}
	
};
