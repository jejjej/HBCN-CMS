/**
 * 创建于:2015-12-17<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 印控机用印及摄像头拍照封装<br>
 * 1. 印控机用印封装<br>
 * 2. 印控机/摄像头连接封装
 * 3. 摄像头控件<br>
 * 4. 图片帮助控件<br>
 * 
 * @author yhx
 * @version 1.0.0
 */
//INI配置文件
var iniPath = "c:/yinzhijie/gss.ini";
/**
 * 创建于:2015-07-17<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 1. 印控机用印封装<br>
 * 2. 印控机/摄像头连接封装
 * 
 * @author RickyChen
 * @version 1.0.0
 */
var ocxbase_sealMachine = {
	ctx : top.ctx,
	ocxInitSuccess : false,
	machineConnected : false,
	machineNum : null,
	orgNo : null,
	interval_paperdoor : null,
	interval_getsealstatus : null,
	interval_sidedooropen : null,
	interval_sidedoorclose : null,

	/**
	 * TODO 初始化控件
	 * 
	 * @returns {success:true|false,data:Object|String}
	 */
	initOcx : function() {
		// 初始化印控机控件
		if (!ocxObject.initOcx(ocxObject.OCX_MachineOrder, document.body, this.ctx + '/activex/api/', 'run')) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.initOcx}--初始化印控机控件失败");
			return ocxbase_utils.genOptResult(false, "初始化印控机控件失败");
		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.initOcx}--初始化印控机控件成功");
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.initOcx}--开始加载延时参数配置");
		ocxbase_iniHelper.init();
		this.ocxInitSuccess = true;
		return ocxbase_utils.genOptResult(true, "");
	},

	/**
	 * TODO 连接印控机
	 * 
	 * @param orgNo：机构号
	 * @returns {success:true|false,data:String}
	 */
	connectMachine : function(orgNo) {
		this.orgNo = orgNo;

		// 初始化机器
		var initResult = this.initMachine();
		if (initResult.success === false) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.connectMachine}--初始化印控机失败");
			this.disconnectMachine();
			return initResult;
		}

		// 读取印控机编码
		try {
			this.machineNum = this._getMachineNum().data;
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.connectMachine}--读取印控机编码:" + this.machineNum);
		} catch (e) {
			this.disconnectMachine();
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.connectMachine}--读取印控机异常，断开与印控机连接:" + getOCXMsg(e.message.code));
			return ocxbase_utils.genOptResult(false, getOCXMsg(e.message.code));
		}

		// 检查印控机工作时间以及使用权限(如后台配置为与印控机管理系统对接)
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.connectMachine}--检查印控机工作时间以及使用权限");
		var checkResult = this.checkUseMachineAuthorization();
		if (!checkResult.success) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.connectMachine}--检查印控机工作时间以及使用权限异常，断开与印控机连接");
			this.disconnectMachine();
			return checkResult;
		}

		this.machineConnected = true;
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.connectMachine}--设备初始化成功");
		return ocxbase_utils.genOptResult(true, "设备初始化成功");
	},

	getMachineNum : function() {
		return this.machineNum;
	},

	/**
	 * TODO 打开纸板
	 * 
	 * @param doorCloseCallback({success:true|false,data:String})：纸板关闭回调函数
	 * @returns {success:true|false,data:String}
	 */
	openPaperDoor : function(/* function */doorCloseCallback) {
		var makeResult = this.makesureMachineConnected();
		if (!makeResult.success) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.openPaperDoor}--印控机连接异常");
			return makeResult;
		}

		var openResult = this._openPaperDoor(callback);
		if (false === openResult.success) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.openPaperDoor}--打开纸板异常");
			return ocxbase_utils.genOptResult(false, openResult.data);
		}

		return ocxbase_utils.genOptResult(true, null);

		function callback(result) {
			var obj;
			if ("1001" == result.code) {
				obj = ocxbase_utils.genOptResult(true, null);
			} else {
				obj = ocxbase_utils.genOptResult(false, getOCXMsg(result.code));
			}

			doorCloseCallback(obj);
		}
	},

	/**
	 * TODO 普通用印
	 * 
	 * @param tradeCode：交易代码
	 * @param across：是否盖骑缝true/false
	 * @param angle：盖章旋转角度
	 * @param x：2048*1536分辨率下像素坐标x
	 * @param y：2048*1536分辨率下像素坐标y
	 * @param callback({success:true|false,data:String|Object})：用印结束回调函数
	 * @returns {success:true|false,data:String}
	 */
	useSeal : function(/* String */tradeCode,/* boolean */across,/* int */angle,/* pixel */x, /* pixel */y, /* function */
	callback) {
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，交易代码为：[" + tradeCode + "]");
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，是否盖骑缝：[" + across + "]");
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，盖章旋转角度：[" + angle + "]");
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，2048*1536分辨率下像素坐标x：[" + x + "]");
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，2048*1536分辨率下像素坐标y：[" + y + "]");
		// 确保印控机已连接
		var makeResult = this.makesureMachineConnected();
		if (!makeResult.success) {
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，印控机连接状态检测[失败]");
			return makeResult;
		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，印控机连接状态检测[成功]");

		// 检查印控机工作时间以及使用权限(如后台配置为与印控机管理系统对接)
//		var checkResult = this.checkUseMachineAuthorization();
//		if (!checkResult.success) {
//			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，印控机使用权限校验[无权使用]");
//			this.disconnectMachine();
//			return checkResult;
//		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，印控机使用权限校验[可以使用]");
//		checkResult = this.checkMachineEnable();
//		if (!checkResult.success) {
//			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--检查印控机是否可用异常，断开与印控机连接");
//			this.disconnectMachine();
//			return checkResult;
//		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，印控机是否可用校验[可以使用]");
		
		// 校验印章使用权限(如后台配置为与印章管理系统对接)
		var sealPos;
		var checkResult = this.checkUseSealAuthorization(tradeCode);
		if (!checkResult.success) {
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，印章使用权限校验[无权使用]");
			return checkResult;
		} else {
			sealPos = checkResult.data;
		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，印章使用权限校验[可以使用],对应印控机印章位置为：" + sealPos);
		
		// 校验印章是否蘸印油
		var sealNoOil;
		var checkSealNoOilResult = this.checkSealNoOilAuthorization(tradeCode);
		if (checkSealNoOilResult.success) {
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，印章是否需要蘸印油：" + checkSealNoOilResult.data);
			if(checkSealNoOilResult.data == "false"){
				OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，印章是否需要蘸印油结果：无印油;");
				this.notSealOil();
			}
		}
		
		// 转换成800*600分辨率的像素坐标
		x = 800 - x / (ocxbase_xusbVideo.cameraInfo.width/800);
		y = y / (ocxbase_xusbVideo.cameraInfo.width/800);
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，800*600分辨率下像素坐标x：[" + Math.round(x) + "]");
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，800*600分辨率下像素坐标y：[" + Math.round(y) + "]");
		// 开始用印
		var startResult = this._startSeal(across, angle, Math.round(x), Math.round(y), sealPos, useSealCallBack);
		if (startResult.success === false) {
			this.setDisconnectAsUseSealError();
			var errMsg = startResult.data;
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印开始，用印调用失败，错误信息为:" + errMsg );
			return ocxbase_utils.genOptResult(false, errMsg);
		}
		return ocxbase_utils.genOptResult(true, null);

		// 用印结束回调函数
		function useSealCallBack(result) {
			var obj;
			if ("1001" == result.code) {
				var ret = {};
				ret.message = "用印成功";
				ret.sealPos = sealPos;
				obj = ocxbase_utils.genOptResult(true, ret);
			} else if ("9000" == result) {
				ocxbase_sealMachine.setDisconnectAsUseSealError();
				var d = {};
				d.errCode = "USE_SEAL_DISCONNECT";
				d.errMsg = getOCXMsg(result.code);
				obj = ocxbase_utils.genOptResult(false, d);
			} else {
				ocxbase_sealMachine.setDisconnectAsUseSealError();
				var d = {};
				d.errCode = "USE_SEAL_ERROR";
				d.errMsg = getOCXMsg(result.code);
				obj = ocxbase_utils.genOptResult(false, d);
			}
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.useSeal}--用印结束，回调用印结束回调函数");
			callback(obj);
			return;
		}
	},
	
	/**
	 * TODO 普通用印
	 * 
	 * @param sealType：印章类型
	 * @param across：是否盖骑缝true/false
	 * @param angle：盖章旋转角度
	 * @param x：2048*1536分辨率下像素坐标x
	 * @param y：2048*1536分辨率下像素坐标y
	 * @param callback({success:true|false,data:String|Object})：用印结束回调函数
	 * @returns {success:true|false,data:String}
	 */
	startUseSeal : function(/* String */sealType,/* boolean */across,/* int */angle,/* pixel */x, /* pixel */y, /* function */
	callback) {
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，印章类型为：[" + sealType + "]");
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，是否盖骑缝：[" + across + "]");
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，盖章旋转角度：[" + angle + "]");
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，"
				+ocxbase_xusbVideo.cameraInfo.width+"*"+ocxbase_xusbVideo.cameraInfo.height
				+"分辨率下像素坐标x：[" + x + "]");
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，"
				+ocxbase_xusbVideo.cameraInfo.width+"*"+ocxbase_xusbVideo.cameraInfo.height
				+"分辨率下像素坐标y：[" + y + "]");
		// 确保印控机已连接
		var makeResult = this.makesureMachineConnected();
		if (!makeResult.success) {
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，印控机连接状态检测[失败]");
			return makeResult;
		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，印控机连接状态检测[成功]");

		// 检查印控机工作时间以及使用权限(如后台配置为与印控机管理系统对接)
		var checkResult = this.checkUseMachineAuthorization();
		if (!checkResult.success) {
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，印控机使用权限校验[无权使用]");
			this.disconnectMachine();
			return checkResult;
		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，印控机使用权限校验[可以使用]");
		/*checkResult = this.checkMachineEnable();
		if (!checkResult.success) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--检查印控机是否可用异常，断开与印控机连接");
			this.disconnectMachine();
			return checkResult;
		}*/
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，印控机是否可用校验[可以使用]");
		
		var sealInstallConfigRet = this.getSealInstallConfig(sealType);
		if (!sealInstallConfigRet.success || !sealInstallConfigRet.data) {
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，印章安装信息不存在.");
			this.disconnectMachine();
			sealInstallConfigRet.data = "该印章类型未找到印章安装信息.";
			return sealInstallConfigRet;
		}
		
		var sealPos = sealInstallConfigRet.data.sealNum;
		var hasSealOil = sealInstallConfigRet.data.hasSealOil;
		// 校验印章是否蘸印油  1蘸印油  0不蘸印油
		if (hasSealOil=="0" || hasSealOil=="false") {
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，印章是否需要蘸印油结果：无印油;");
			this.notSealOil();
		}
		//校验本地是否存在某号印章
		var hassealResult = this.hasSealInTheMachine(sealPos);
		if(!hassealResult.success){
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，校验设备内印章是否存在，错误信息为:" + hassealResult.data );
			return ocxbase_utils.genOptResult(false, hassealResult.data);
		}
		
		// 转换成800*600分辨率的像素坐标
		x = 800 - x / (ocxbase_xusbVideo.cameraInfo.width/800);
		y = y / (ocxbase_xusbVideo.cameraInfo.width/800);
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，800*600分辨率下像素坐标x：[" + Math.round(x) + "]");
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，800*600分辨率下像素坐标y：[" + Math.round(y) + "]");
		// 开始用印
		var startResult = this._startSeal(across, angle, Math.round(x), Math.round(y), sealPos, useSealCallBack);
		if (startResult.success === false) {
			this.setDisconnectAsUseSealError();
			var errMsg = startResult.data;
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印开始，用印调用失败，错误信息为:" + errMsg );
			return ocxbase_utils.genOptResult(false, errMsg);
		}
		return ocxbase_utils.genOptResult(true, null);

		// 用印结束回调函数
		function useSealCallBack(result) {
			var obj;
			if ("1001" == result.code) {
				var ret = {};
				ret.message = "用印成功";
				ret.sealPos = sealPos;
				obj = ocxbase_utils.genOptResult(true, ret);
			} else if ("9000" == result) {
				ocxbase_sealMachine.setDisconnectAsUseSealError();
				var d = {};
				d.errCode = "USE_SEAL_DISCONNECT";
				d.errMsg = getOCXMsg(result.code);
				obj = ocxbase_utils.genOptResult(false, d);
			} else {
				ocxbase_sealMachine.setDisconnectAsUseSealError();
				var d = {};
				d.errCode = "USE_SEAL_ERROR";
				d.errMsg = getOCXMsg(result.code);
				obj = ocxbase_utils.genOptResult(false, d);
			}
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.startUseSeal}--用印结束，回调用印结束回调函数");
			callback(obj);
			return;
		}
	},


	/**
	 * TODO 多次用印<br>
	 * 一直凭证盖多个章
	 * 
	 * @param list：用印信息
	 *            list[i].tradeCode；list[i].across；list[i].angle；list[i].x；list[i].y；
	 * @param callback({success:true|false,data:Object|String})：用印结束回调函数
	 * @returns {success:true|false,data:Object|String}
	 */
	severalUseSeal : function(/* Array */list,/* function */callback) {
		// 确保印控机已连接
		var makeResult = this.makesureMachineConnected();
		if (!makeResult.success) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.severalUseSeal}--印控机连接异常");
			return makeResult;
		}

		if (!list || !list instanceof Array || list.length < 1) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.severalUseSeal}--盖章请求数据有误");
			return ocxbase_utils.genOptResult(false, "盖章请求数据有误");
		}

		var m = list.pop();
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.severalUseSeal}--用印");
		return this.startUseSeal(m.sealType, m.across, m.angle, m.x, m.y, useSealCompleteCallback);
		
		// 一次用印结束回调函数
		function useSealCompleteCallback(obj) {
			if (obj.success && list.length > 0) {
				var m = list.pop();
				var ret = ocxbase_sealMachine
						.startUseSeal(m.sealType, m.across, m.angle, m.x, m.y, useSealCompleteCallback);
				if (!ret.success) {
					callback(ret);
					return;
				}
			} else {
				// 用印结束或用印异常回调
				callback(obj);
				return;
			}
		}
	},

	/**
	 * TODO 打开电子锁
	 * 
	 * @returns {success:true|false,data:String}
	 */
	openElecLock : function() {
		var makeResult = this.makesureMachineConnected();
		if (!makeResult.success) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.openElecLock}--印控机连接异常");
			return makeResult;
		}

		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.openElecLock}--打开侧门");
		var openResult = OCX_MachineOrder.openBackDoor();
		if ("1001" != openResult.code) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.openElecLock}--打开侧门异常:" + getOCXMsg(openResult.code));
			return ocxbase_utils.genOptResult(false, getOCXMsg(openResult.code));
		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.openElecLock}--电子锁已经打开");
		return ocxbase_utils.genOptResult(true, "电子锁已经打开");
	},

	/**
	 * TODO 断开与印控机的连接
	 */
	disconnectMachine : function() {
		try {
			this.closeMachine();
			this.machineConnected = false;
		} catch (e) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.openElecLock}--断开与印控机的连接异常" + e.message);
		}
	},

	getLastUseSealStatus : function() {
		// FIXME 印控机内尚无判断章是否盖章凭证上的API
		return ocxbase_utils.genOptResult(true, true);
	},

	setDisconnectAsUseSealError : function() {
		ocxbase_sealMachine.machineConnected = false;
	},

	makesureMachineConnected : function() {
		if (!this.ocxInitSuccess) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.makesureMachineConnected}--印控机控件未加载成功");
			return ocxbase_utils.genOptResult(false, "印控机控件未加载成功");
		}
		if (!this.machineConnected) {
			return this.connectMachine();
		}
		return ocxbase_utils.genOptResult(true, null);
	},

	checkUseMachineAuthorization : function() {
		return ocxbase_Authorization.checkUseMachinePower(this.machineNum, this.orgNo);
	},
	
	checkMachineEnable : function(){
		return ocxbase_Authorization.checkMachineEnable(this.machineNum);
	},

	checkUseSealAuthorization : function(tradeCode) {
		return ocxbase_Authorization.checkUseSealPower(this.machineNum, tradeCode);
	},
	
	checkSealNoOilAuthorization : function(tradeCode) {
		return ocxbase_Authorization.checkSealNoOil(this.machineNum, tradeCode);
	},
	
	getSealInstallConfig : function(sealType) {
		return ocxbase_Authorization.getSealInstallConfig(this.machineNum, sealType);
	},



	/**
	 * 初始化设备
	 * 
	 * @returns 0 成功，其他 失败, 见方法machineOrder.getReturnCodeMsg
	 */
	initMachine : function() {
		// 定义控件,需根据控件的定义修改
		var initResult, i;

		var commType = OCX_Tools.readIni(iniPath, "gss", "commType", "0").data;
		OCX_Logger.info(LOGGER._3X,"{ocxbase_sealMachine.initMachine}-- 读取配置参数：commType:("+commType+")");
		OCX_MachineOrder.setCommType(commType);
		if (OCX_MachineOrder.openCom().data != "1"){
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.initMachine}--印控机初始化设备[initMachine][OpenCom][失败]openCom().data:"+OCX_MachineOrder.openCom().data);
			return ocxbase_utils.genOptResult(false, "设备连接失败，请重新连接设备");
		};
		
		if(OCX_MachineOrder.queryPaperDoor().data != "2"){
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.initMachine}--印控机初始化设备[initMachine][QueryPaperDoor][失败]OCX_MachineOrder.queryPaperDoor().data:"+OCX_MachineOrder.queryPaperDoor().data);
			OCX_MachineOrder.closeCom();
			return ocxbase_utils.genOptResult(false, "纸板打开失败，请检查纸板门状态");
		};
		for (i = 0; i < 3; i++) {
			initResult = OCX_MachineOrder.getCalParam().data;
			if (initResult == "1"){
				break;
			};
		};
		if (initResult != "1") {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.initMachine}--印控机初始化设备[initMachine][GetCalParam][失败]OCX_MachineOrder.getCalParam().data:"+initResult);
			OCX_MachineOrder.closeCom();
			return ocxbase_utils.genOptResult(false, "取校准参数失败，请联系维护人员进行校准参数");
		};

		for (i = 0; i < 3; i++) {
			initResult = OCX_MachineOrder.queryMachineNumOne().data
					+ OCX_MachineOrder.queryMachineNumTwo().data;
			if (initResult != "11") {
				break;
			};
		};
		initResult = OCX_MachineOrder.queryMachineNumOne().data
					+ OCX_MachineOrder.queryMachineNumTwo().data;
		if (initResult == "11") {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.initMachine}--印控机初始化设备[initMachine][QueryMachineNumOne&&QueryMachineNumTwo][失败]");
			OCX_MachineOrder.closeCom();
			return ocxbase_utils.genOptResult(false, "设备未连接，请连接设备");
		};
		if (OCX_MachineOrder.openLight().data != 1){
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.initMachine}--印控机初始化设备[initMachine][OpenLight][失败]");
			OCX_MachineOrder.closeCom();
			return ocxbase_utils.genOptResult(false, "打开照明灯失败");
		};
		
		// 判断设备状态
		var machineStatus = OCX_MachineOrder.queryError();
		if("1011" != machineStatus.code){
		    OCX_MachineOrder.closeCom();
		    return ocxbase_utils.genOptResult(false, machineStatus.data);
		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.initMachine}--印控机初始化设备成功");
		return ocxbase_utils.genOptResult(true, "初始化设备成功");
	},
	
	/**
	 * 取章申请初始化设备
	 * 
	 * @returns 0 成功，其他 失败, 见方法machineOrder.getReturnCodeMsg
	 */
	initMachineForTakeSeal : function() {
		// 定义控件,需根据控件的定义修改
		var initResult, i;

		var commType = OCX_Tools.readIni(iniPath, "gss", "commType", "0").data;
		OCX_MachineOrder.setCommType(commType);
		if (OCX_MachineOrder.openCom().data != "1"){
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.initMachineForTakeSeal}--印控机初始化设备[initMachine][OpenCom][失败]openCom().data:"+OCX_MachineOrder.openCom().data);
			return ocxbase_utils.genOptResult(false, "设备连接失败，请重新连接设备");
		};
		
		for (i = 0; i < 3; i++) {
			initResult =OCX_MachineOrder.queryMachineSN();
			if (initResult.code == "1001") {
				break;
			};
		};
		if (initResult.code != "1001") {
			OCX_Logger.error(LOGGER._3X,"印控机初始化设备[initMachine][queryMachineSN][失败]");
			OCX_MachineOrder.closeCom();
			return ocxbase_utils.genOptResult(false, "设备未连接，请连接设备");
		};
		this.machineNum = initResult.data;
		var chipSoftVersion = OCX_MachineOrder.queryChipSoftVersion().data;
		return ocxbase_utils.genOptResult(true, chipSoftVersion);
	},
	
	/**
	 * 打开纸板
	 * 
	 * @param callbackPaperDoorIn
	 *                纸板门关闭回调函数，回调参数0 成功，其他失败，详见machineOrder.getReturnCodeMsg
	 * @returns 0 成功，其他 失败, 见方法machineOrder.getReturnCodeMsg
	 */
	_openPaperDoor : function(callbackPaperDoorIn) {
		var initResult = OCX_MachineOrder.queryMachineNumOne().data + OCX_MachineOrder.queryMachineNumTwo().data;
		if (initResult == "11") {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._openPaperDoor}--印控机打开纸板失败，设备未连接，查询状态为:" + initResult);
			return ocxbase_utils.genOptResult(false, "设备未连接，请连接设备");
		};
		var isOpen = OCX_MachineOrder.openPaperDoor();
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._openPaperDoor}--印控机打开纸板动作执行，返回代码为[" + isOpen.code + "]，返回值为[" + isOpen.data + "]");
		function queryDoorStatus() {
			var status = OCX_MachineOrder.queryPaperDoor().data;
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._openPaperDoor}--印控机打开纸板状态监控，当前状态为[" + status + "]");
			if (status == "2") {// 关闭
				OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._openPaperDoor}--印控机打开纸板状态监控[纸板已关闭]，准备回调打开纸板回调函数。");
				callbackPaperDoorIn(OCXResult(OCX_MachineOrder, "1001", ""));
			} else if (status == "1") {// 未关闭
				OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._openPaperDoor}--印控机打开纸板状态监控[纸板未关闭]，继续检测纸板状态。");
				window.setTimeout(queryDoorStatus, ocxbase_iniHelper.configParam.queryStatus);
			} else {// 异常
				OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._openPaperDoor}--印控机打开纸板状态监控[纸板状态异常]，准备回调打开纸板回调函数。");
				callbackPaperDoorIn(OCXResult(OCX_MachineOrder, "9420", ""));
			};
		};
		if (isOpen.code == "1001") {// 启动定时器监测纸板门是否关闭
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._openPaperDoor}--印控机打开纸板成功,启动纸板状态检测定时器(1000ms).");
			this.interval_paperdoor = window.setTimeout(queryDoorStatus, ocxbase_iniHelper.configParam.queryStatus);
			return ocxbase_utils.genOptResult(true, "打开纸板成功");
		} else {			
			return ocxbase_utils.genOptResult(false, "打开纸板失败");
		};
	},

	/**
	 * 查询机器号
	 * 
	 * @returns 8位字符串，机器生产序列号
	 * @throws 1003，错误；1016，未设置值。
	 */
	_getMachineNum : function() {
		var machineNum;
		var machineOrderVer = OCX_Tools.readIni(iniPath, "gss", "machineOrderVer", "2").data;
		if (machineOrderVer == "1"){
			// 老版控件
			machineNum = OCX_MachineOrder.queryMachineNumTwo().data;
		}else{
			// 新版控件
			machineNum = OCX_MachineOrder.queryMachineSN().data;
		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._getMachineNum}--查询机器号[getMachineNum][QueryMachineNumTwo][" + machineNum + "]");
		if (machineNum == "1" || machineNum == "-1") {
			throw new Error(OCXResult(OCX_MachineOrder, "9221", "").msg);
		} else if (machineNum == "0" || machineNum == "-2") {
			throw new Error(OCXResult(OCX_MachineOrder, "9221", "").msg);
		} else {
			return ocxbase_utils.genOptResult(true, machineNum);
		};
	},

	/**
	 * 开始用印
	 * 
	 * @param isAcrossPageSeal
	 *                骑缝盖章模式 true/false
	 * @param sealAngle
	 *                旋转角度 1~360
	 * @param xPos
	 *                用印X坐标(800×600分辨率下的像素坐标，右上角为坐标原点)
	 * @param yPos
	 *                用印Y坐标(800×600分辨率下的像素坐标，右上角为坐标原点)
	 * @param sealNum
	 *                印章号 1~6
	 * @param callback
	 *                回调函数 0 用印完成，其他用印异常，详见方法machineOrder.getReturnCodeMsg
	 */
	_startSeal : function(isAcrossPageSeal, sealAngle, xPos, yPos, sealNum, callback) {
		try{
			var orderResult = OCX_MachineOrder.queryMachineNumOne().data
					+ OCX_MachineOrder.queryMachineNumTwo().data;
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--开始用印[startSeal][QueryMachineNumOne&&QueryMachineNumTwo][" + orderResult + "]");
			if (orderResult == "11") {
				OCX_MachineOrder.closeCom();
				return ocxbase_utils.genOptResult(false, "设备未连接，请连接设备");
			};
			// 设置本次盖骑缝章,本次有效
			if(isAcrossPageSeal){
				var setAcross = OCX_MachineOrder.setAcrossPageSeal();
				OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--开始用印[startSeal][SetAcrossPageSeal][" + setAcross.data + "]");
				if (setAcross.code != "1001"){
					OCX_MachineOrder.closeCom();
					return ocxbase_utils.genOptResult(false, setAcross.msg);
				};
			};
			
			// 设置旋转角度
			var setAngle = OCX_MachineOrder.setAngle(sealAngle);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--开始用印[startSeal][SetAngle][" + setAngle.code + "]");
			if (setAngle.code != "1001"){
				OCX_MachineOrder.closeCom();
				return ocxbase_utils.genOptResult(false, setAngle.msg);
			};
			// 设置印章号
			var sendSeal;
			for ( var i = 0; i < 3; i++) {
				sendSeal = OCX_MachineOrder.sendSealNum(sealNum).data;
				OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--开始用印[startSeal][SendSealNum][" + sendSeal + "]");
				if (sendSeal == 1 || sendSeal == 3) {
					break;
				};
			};
			if (sendSeal != 1 && sendSeal != 3){
				OCX_MachineOrder.closeCom();
				return ocxbase_utils.genOptResult(false, "设置印章失败");
			};
			
			/*for (i = 0; i < 3; i++) {
				initResult = OCX_MachineOrder.getCalParamEx(sealNum).data;
				if (initResult == "1"){
					break;
				};
			};
			if (initResult != "1") {
				OCX_Logger.error("印控机初始化设备[initMachine][GetCalParam][失败]OCX_MachineOrder.getCalParam().data:"+initResult, "gsshd");
				OCX_MachineOrder.closeCom();
				return ocxbase_utils.genOptResult(false, "取校准参数失败，请联系维护人员进行校准参数");
			};*/
			
			// 根据像素坐标计算盖章坐标
			var calMachPos = OCX_MachineOrder.calMachinePos(xPos, yPos).data;
			//var calMachPos = OCX_MachineOrder.calMachinePosEx(sealNum,xPos, yPos).data;
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--开始用印[startSeal][calMachinePos][" + calMachPos + "]");
			if(calMachPos != null && calMachPos != ""){
				var points = calMachPos.split(",");
				if(points.length == 2){
					xPos  = points[0];
					yPos = points[1];
					OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--根据像素坐标转换为盖章X坐标(0.1毫米)："+xPos);
					OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--根据像素坐标转换为盖章Y坐标(0.1毫米)："+yPos);
				}else{
					OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--开始用印[startSeal][calMachinePos][返回非正常格式]");
					OCX_MachineOrder.closeCom();
					return ocxbase_utils.genOptResult(false, "印章机控件计算盖章坐标失败");
				};
			}else{
				OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--开始用印[startSeal][calMachinePos][返回空值]");
				OCX_MachineOrder.closeCom();
				return ocxbase_utils.genOptResult(false, "印章机控件计算盖章坐标失败");
			};
			var reStr;
			reStr = OCX_MachineOrder.sendX(xPos);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--开始用印[startSeal][SendX]["+reStr+"]");
			if (reStr.code != "1001"){
				OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--开始用印[startSeal][SendX][失败]");
				OCX_MachineOrder.closeCom();
				return ocxbase_utils.genOptResult(false, reStr.msg);
			};
			reStr = OCX_MachineOrder.sendY(yPos);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--开始用印[startSeal][SendY]["+reStr+"]");
			if (reStr.code != "1001"){
				OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--开始用印[startSeal][SendY][失败]");
				OCX_MachineOrder.closeCom();
				return ocxbase_utils.genOptResult(false, reStr.msg);
			};
			reStr = OCX_MachineOrder.sealStart();
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--开始用印[startSeal][SealStart]["+reStr.code+"]");
			if (reStr.code != "1001"){
				OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--开始用印[startSeal][SealStart][失败]");
				OCX_MachineOrder.closeCom();
				return ocxbase_utils.genOptResult(false, reStr.msg);
			};
			function querySealStatus() {
				var status = OCX_MachineOrder.sealQuery().data;
				OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--正在用印[startSeal][SealQuery]["+status+"]");
				if (status == "0") {// 用印完成
					OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--用印完成，准备调用回调函数");
					callback(OCXResult(OCX_MachineOrder, "1001", ""));
				} else if (status == "2" || status == "1") {// 用印中
					OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--正在用印,继续检测用印状态(延时"+ocxbase_iniHelper.configParam.queryStatus+"ms)");
					window.setTimeout(querySealStatus, ocxbase_iniHelper.configParam.queryStatus);
				} else if (status == "4") {// 用印异常
					OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--用印异常，准备回调回调函数");
					OCX_MachineOrder.closeCom();
					callback(OCXResult(OCX_MachineOrder, "9421", ""));
				} else if(status == "3"){
					OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--用印通讯异常，准备回调回调函数");
					OCX_MachineOrder.closeCom();
			    	callback(OCXResult(OCX_MachineOrder, "9000", ""));
				}else {// 异常
					OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--用印其他异常，准备回调回调函数");
					OCX_MachineOrder.closeCom();
					callback(OCXResult(OCX_MachineOrder, "9421", ""));
				};
			};
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--开始用印,准备检测用印状态(延时"+ocxbase_iniHelper.configParam.queryStatus+"ms)");
			this.interval_paperdoor = window.setTimeout(querySealStatus, ocxbase_iniHelper.configParam.queryStatus);
			return ocxbase_utils.genOptResult(true, "用印成功");
		}catch(e){
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--机控用印异常："+e.message);
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine._startSeal}--开始用印[startSeal][catch][JS异常:"+e.message+"]");
			window.clearInterval(this.interval_paperdoor);
			OCX_MachineOrder.closeCom();
			return ocxbase_utils.genOptResult(false, "机控用印异常");
		};
	},

	/**
	 * 关闭设备
	 * 
	 * @returns 无
	 */
	closeMachine : function() {
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.closeMachine}--关闭设备[closeMachine][关闭设备]");
		OCX_MachineOrder.closeLight();
		OCX_MachineOrder.closeCom();
	},


	/**
	 * 打开侧门
	 * 
	 * @param doorCloseCallBack
	 *                侧门关闭回调函数
	 * @returns 0:成功；其他失败
	 */
	openSideDoor : function(doorCloseCallBack,doorOpenCallBack){
	    	// FIXME 侧门一直不打开时有bug
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.openSideDoor}--查询后门锁状态");
		var status = OCX_MachineOrder.queryBackDoor();
		if(status.code == "1067"){
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.openSideDoor}--后门锁已打开");
			doorOpenCallBack();
			this.interval_sidedoorclose = window.setTimeout(waitSideDoorClose,ocxbase_iniHelper.configParam.queryStatus);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.openSideDoor}--打开侧门成功");
			return ocxbase_utils.genOptResult(true, "打开侧门成功");
		}else if(status.code == "9000"){
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.openSideDoor}--查询后门锁状态通讯异常");
			return ocxbase_utils.genOptResult(false, status.msg);
		}else if(status.code == "1068"){
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.openSideDoor}--后门锁状态为未打开");
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.openSideDoor}--开始打开电子锁");
			var openResult = OCX_MachineOrder.openBackDoor();
			if(openResult.code == "1001"){
				OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.openSideDoor}--后门锁已打开");
				this.interval_sidedooropen = window.setTimeout(waitSideDoorOpen,ocxbase_iniHelper.configParam.queryStatus);
				OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.openSideDoor}--打开侧门成功");
			}
			return ocxbase_utils.genOptResult(true, openResult.msg);
		};
		var _count = 0;
		function waitSideDoorOpen(){
			_count++;
			var status = OCX_MachineOrder.queryBackDoor();
			if(status.code != "1067"){
				if(_count >= 40){
					_count = 0;
					return;
				}
				this.interval_sidedooropen = window.setTimeout(waitSideDoorOpen,ocxbase_iniHelper.configParam.queryStatus);
			}else{
				doorOpenCallBack();
				_count = 0;
				window.clearTimeout(this.interval_sidedooropen);
				this.interval_sidedoorclose = window.setTimeout(waitSideDoorClose,ocxbase_iniHelper.configParam.queryStatus);
			}
		};
		
		function waitSideDoorClose(){
			var status = OCX_MachineOrder.queryBackDoor();
			if(status.code != "1068"){
				window.setTimeout(waitSideDoorClose,ocxbase_iniHelper.configParam.queryStatus);
			}else{
				window.clearTimeout(this.interval_sidedoorclose);
//				console.log("侧门已关闭");
				doorCloseCallBack();
			}
		};
	},
	
	/**
	 * 检测侧门状态
	 * @param openCallBack 门打开回调
	 * @param closeCallBack 门关闭回调
	 * @param errorCallBack 异常回调
	 */
	querySideDoor : function(openCallBack,closeCallBack,errorCallBack){
		setTimeout(waitSideDoorOpen_, ocxbase_iniHelper.configParam.queryStatus);
		var _count = 0;
		var error_count = 0;//异常计数
		/**
		 * 查询侧门开门状态
		 */
		function waitSideDoorOpen_(){
//			console.log("查询侧门打开状态");
			_count++;
			var status = OCX_MachineOrder.queryBackDoor();
			if(status.code == "1068"){//未打开
				if(_count >= 40){//大于20秒不再查询 即40次
					window.clearTimeout(this.interval_sidedooropen);
					_count = 0;
//					console.log("开始查询侧门关闭状态");
					this.interval_sidedoorclose = window.setTimeout(waitSideDoorClose_,ocxbase_iniHelper.configParam.queryStatus);
					return;
				}
				this.interval_sidedooropen = window.setTimeout(waitSideDoorOpen_,ocxbase_iniHelper.configParam.queryStatus);
			}else if(status.code == "9000"){//通讯异常
				error_count++;
				if(error_count>=20){//20次认为设备连接异常
					window.clearTimeout(this.interval_sidedooropen);
					_count = 0;
					error_count = 0;
					if(null!=errorCallBack && typeof errorCallBack == "function"){
						errorCallBack(ocxbase_utils.genOptResult(false, "设备通信异常，请检查连接"));
					}
				}else{
					this.interval_sidedooropen = window.setTimeout(waitSideDoorOpen_,ocxbase_iniHelper.configParam.queryStatus);
				}
			}else if(status.code == "1067"){//已打开
				if(null!=openCallBack && typeof openCallBack == "function"){
//					console.log("调用侧门打开回调");
					openCallBack();
				}
				_count = 0;
				error_count = 0;
				window.clearTimeout(this.interval_sidedooropen);
				this.interval_sidedoorclose = window.setTimeout(waitSideDoorClose_,ocxbase_iniHelper.configParam.queryStatus);
			}
		};
		/**
		 * 查询侧门关门状态
		 */
		function waitSideDoorClose_(){
//			console.log("查询侧门关闭状态");
			var status = OCX_MachineOrder.queryBackDoor();
			if(status.code == "1068"){//未打开
				window.clearTimeout(this.interval_sidedoorclose);
//				console.log("调用侧门关闭回调");
				closeCallBack();
			}else if(status.code == "9000"){//通讯异常
				error_count++;
				if(error_count>=20){//20次认为设备连接异常
					window.clearTimeout(this.interval_sidedoorclose);
					_count = 0;
					error_count = 0;
					if(null!=errorCallBack && typeof errorCallBack == "function"){
						errorCallBack(ocxbase_utils.genOptResult(false, "设备通信异常，请检查连接"));
					}
				}else{
					this.interval_sidedoorclose = window.setTimeout(waitSideDoorClose_,ocxbase_iniHelper.configParam.queryStatus);
				}
			}else if(status.code == "1067"){//已打开
				this.interval_sidedoorclose = window.setTimeout(waitSideDoorClose_,ocxbase_iniHelper.configParam.queryStatus);
			}
			
		};
	},
	
	/**
	 * 检测纸板开门状态
	 * @param openCallBack 门打开回调
	 * @param errorCallBack 异常回调
	 */
	queryPaperDoorOpen : function(openCallBack,errorCallBack){
		var error_count = 0;
		if("2"==OCX_MachineOrder.queryPaperDoor().data){//未开门
//			console.log("纸板门已关闭");
			return ocxbase_utils.genOptResult(false, "");
		}else{
			setTimeout(waitPaperDoorOpen_, ocxbase_iniHelper.configParam.queryStatus);
		}
		
		/**
		 * 查询纸板开门状态
		 */
		function waitPaperDoorOpen_(){
			var status = OCX_MachineOrder.queryPaperDoor().data;
			if(status == "2"){//未打开
				window.setTimeout(waitPaperDoorOpen_,ocxbase_iniHelper.configParam.queryStatus);
			}else if(status == "1"){//已打开
				if(null!=openCallBack && typeof openCallBack == "function"){
					openCallBack();
				}
				error_count = 0;
			}else{//通讯异常
				error_count++;
				if(error_count>=20){//20次认为设备连接异常
					error_count = 0;
					if(null!=errorCallBack && typeof errorCallBack == "function"){
						errorCallBack(ocxbase_utils.genOptResult(false, "设备通信异常，请检查连接"));
					}
				}else{
					window.setTimeout(waitPaperDoorOpen_,ocxbase_iniHelper.configParam.queryStatus);
				}
			}
		};
		
		return ocxbase_utils.genOptResult(true, "");//已开门
	},
	
	/**
	 * 检测纸板关门状态
	 * @param closeCallBack 门关闭回调
	 * @param errorCallBack 异常回调
	 */
	queryPaperDoorClose : function(closeCallBack,errorCallBack){
		var error_count = 0;
		if("1"==OCX_MachineOrder.queryPaperDoor().data){//未关门
//			console.log("纸板门已打开");
			return ocxbase_utils.genOptResult(false, "");
		}else{
			setTimeout(waitPaperDoorClose_, ocxbase_iniHelper.configParam.queryStatus);
		}
		
		/**
		 * 查询纸板关门状态
		 */
		function waitPaperDoorClose_(){
			var status = OCX_MachineOrder.queryPaperDoor().data;
			if(status == "2"){//未打开
				if(null!=closeCallBack && typeof closeCallBack == "function"){
					closeCallBack();
				}
				error_count = 0;
			}else if(status == "1"){//已打开
				window.setTimeout(waitPaperDoorClose_,ocxbase_iniHelper.configParam.queryStatus);
			}else{//通讯异常
				error_count++;
				if(error_count>=20){//20次认为设备连接异常
					error_count = 0;
					if(null!=errorCallBack && typeof errorCallBack == "function"){
						errorCallBack(ocxbase_utils.genOptResult(false, "设备通信异常，请检查连接"));
					}
				}else{
					window.setTimeout(waitPaperDoorClose_,ocxbase_iniHelper.configParam.queryStatus);
				}
			}
		};
		return ocxbase_utils.genOptResult(true, "");//已关门
	},

	/**
	 * 判断印控机里面是否存在此号章
	 * 
	 * @param sealNum
	 *                章号
	 * @returns 0:有章；E1026:无章；其他:异常
	 */
	hasSealInTheMachine : function(sealNum){    
		var sealInfo = OCX_MachineOrder.getSealInfo();
		if(sealInfo.code == "1001"){
			var sealInfoList = sealInfo.data.split(",");
			for(var i=0;i<sealInfoList.length;i++){
				var seal = sealInfoList[i].split(":");
				if(seal.length == 2 && seal[1] == sealNum){
					OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.hasSealInTheMachine}--章槽内有此印章");
					return ocxbase_utils.genOptResult(true, "章槽内有此印章");					
				}
			}
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.hasSealInTheMachine}--章槽内无此印章");
			return ocxbase_utils.genOptResult(false, "章槽内无此印章");
		}else{
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_sealMachine.hasSealInTheMachine}--获取印章信息异常");
			return ocxbase_utils.genOptResult(false, "异常");
		}
	},
	/**
	 * 打开侧门
	 * @returns {success:true|false,data:String}
	 */
	openBackDoor : function(){
		var result = OCX_MachineOrder.openBackDoor();
		if(result.code == "1001"){
			return ocxbase_utils.genOptResult(true, "打开电子锁成功");
		}else{
			return ocxbase_utils.genOptResult(false, "打开电子锁失败");
		}
	},
	/**
	 * 查询印章信息
	 * @returns {success:true|false,data:String}
	 */
	getSealInfo : function(){
		var result = OCX_MachineOrder.getSealInfo();
		if(result.code == "1001"){
			return ocxbase_utils.genOptResult(true, result.data);
		}else{
			return ocxbase_utils.genOptResult(false, "查询章槽安装详情失败");
		}
	},
	
	/**
	 * 设置印章不蘸印油，在每次发选择章号命令前发送不要蘸印油接口命令，机器就不会蘸印油盖章，只有一次有效，下次必须设定才能生效，默认不发命令是蘸印油的
	 * @returns {success:true|false,data:String}
	 */
	
	notSealOil : function(){
		var result = OCX_MachineOrder.notSealOil();
		if(result.code == "1001"){
			return ocxbase_utils.genOptResult(true, result.msg);
		}else{
			return ocxbase_utils.genOptResult(false, result.msg);
		}
	},
	/**
	 * 打开侧门照明
	 */
	sealStartForLG : function(){
		OCX_MachineOrder.setOutLayLight();
	},
	/**
	 * 关闭侧门照明
	 */
	closeOutLayLight : function(){
		OCX_MachineOrder.closeOutLayLight();
	},
	/**
	 * 查询用印是否完成
	 * @returns {success:true|false,data:String}
	 */
	sealQuery : function(){
		var result =  OCX_MachineOrder.sealQuery();
		if(result.code == "1004" && result.code == "1005"){
			return ocxbase_utils.genOptResult(true, result.msg);
		}else{
			return ocxbase_utils.genOptResult(false, result.msg);
		}
	},
	clearSealImage : function(imagePath){
		if(!(/^\s*$/g.test(imagePath))){
			OCX_MachineOrder.deletedir(imagePath);
		}
	}
};

/**
 * 印控机摄像头连接管理
 */
var ocxbase_machineAndCameraConnProxy = {

	/**
	 * TODO 连接印控机与打开摄像头<br>
	 * 连接成功后会检验是否存在异常用印日志<br>
	 * 
	 * @param readyCallback({success:true|false,data:String|Object})：连接结果回调函数
	 * @returns {success:true|false,data:String|Object}
	 */
	connect : function(readyCallback) {
		// 连接印控机
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_machineAndCameraConnProxy.connect}--连接印控机");
		var m = ocxbase_sealMachine.connectMachine(top.loginPeopleInfo.orgNo);
		if (!m.success) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_machineAndCameraConnProxy.connect}--连接印控机失败");
			return m;
		}

		// 打开摄像头
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_machineAndCameraConnProxy.connect}--打开摄像头");
		var x = ocxbase_xusbVideo.openCamera(cameraReadyCallback);
		if (!x.success) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_machineAndCameraConnProxy.connect}--打开摄像头失败");
			return x;
		}

		return ocxbase_utils.genOptResult(true, null);

		// 摄像头就绪
		function cameraReadyCallback() {
			// 检测是否存在异常用印日志
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_machineAndCameraConnProxy.connect.cameraReadyCallback}--检测是否存在异常用印日志");
			var lastResult = ocxbase_sealMachine.getLastUseSealStatus();
			if (!lastResult.success) {
				OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_machineAndCameraConnProxy.connect.cameraReadyCallback}--getLastUseSealStatus() 失败");
				ocxbase_sealMachine.disconnectMachine();
				readyCallback(lastResult);
				return;
			} else {
				OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_machineAndCameraConnProxy.connect.cameraReadyCallback}--开始嗅探并处理异常用印日志");
				var sniffResult = ocxbase_exceptionLogHandler.startSniffing(ocxbase_sealMachine.getMachineNum(), lastResult.data);
				if (!sniffResult.success) {
					OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_machineAndCameraConnProxy.connect.cameraReadyCallback}--处理异常用印日志异常");
					ocxbase_sealMachine.disconnectMachine();
					readyCallback(sniffResult);
					return;
				}
			}

			readyCallback(ocxbase_utils.genOptResult(true, "设备已就绪"));
			return;
		}
	},

	/**
	 * 断开印控机/摄像头的连接
	 */
	disconnect : function() {
		ocxbase_sealMachine.disconnectMachine();
		ocxbase_xusbVideo.closeCamera();
		ocxbase_sealMachine.clearSealImage(ocxbase_xusbVideo.imagePath);
	}
};

/**
 * 创建于:2015-07-17<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 摄像头拍照封装<br>
 * 1. 摄像头控件<br>
 * 2. 图片帮助控件<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */
var ocxbase_xusbVideo = {
	ctx : top.ctx,
	ocxInitSuccess : false,

	cameraId : "main",
	cameraIsReady : false,
	cameraReadyCallback : null,
	cameraInfo : {
		width : null,
		height : null
	},

	lastImagePath : {
		cutImagePath : null,
		srcImagePath : null
	},
	
	lastImageName : {
		cutImageName : null,
		srcImageName : null
	},

	imagePath : "c:\\yinzhijie\\resources\\3x\\img\\",
	/**
	 * 默认用印区域  
	 *     "default_prop" 300万像素
	 *     "default_500prop" 500万像素
	 *     "default_800prop" 800万像素
	 */
	defaultProp : null,

	/**
	 * TODO 初始化控件
	 * 
	 * @returns {success:true|false,data:Object|String}
	 */
	initOcx : function() {
		// 初始化拍照控件
		if (!ocxObject.initOcx(ocxObject.OCX_XUSBVideo, document.body, this.ctx + '/activex/api/', 'run')) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.initOcx}--初始化拍照控件失败");
			return ocxbase_utils.genOptResult(false, "初始化拍照控件失败");
		}

		// 初始化图片处理控件
		if (!ocxObject.initOcx(ocxObject.OCX_ImgHelper, document.body, this.ctx + '/activex/api/', 'run')) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.initOcx}--初始化图片处理控件");
			return ocxbase_utils.genOptResult(false, "初始化图片处理控件失败");
		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.initOcx}--初始化控件成功");
		this.ocxInitSuccess = true;
		return ocxbase_utils.genOptResult(true, "");
	},

	/**
	 * TODO 打开摄像头
	 * 
	 * @returns {success:true|false,data:Object|String}
	 */
	openCamera : function(callback) {
		if (this.cameraIsReady) {
			this.closeCamera();
		}

		this.resetProps();
		this.cameraReadyCallback = callback;

		if (!this.ocxInitSuccess) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openCamera}--拍照控件未初始化");
			return ocxbase_utils.genOptResult(false, "拍照控件未初始化");
		}


		var openResult = this._openCamera();
		if (false === openResult.success) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openCamera}--内部摄像头打开失败");
			return openResult;
		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openCamera}--内部摄像头打开成功");
		return ocxbase_utils.genOptResult(true, "内部摄像头打开成功");
	},
	
	/**
	 * 
	 * @param callback
	 * @returns
	 */
	openSideCamera : function(callback) {
		if (this.cameraIsReady) {
			this.closeCamera();
		}
		
		this.resetProps();
		this.cameraReadyCallback = callback;

		if (!this.ocxInitSuccess) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openSideCamera}--拍照控件未初始化");
			return ocxbase_utils.genOptResult(false, "拍照控件未初始化");
		}
		
		var openResult = this._openSideCamera();
		if (false === openResult.success) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo._openSideCamera}--侧门摄像头打开失败");
			return openResult;
		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openSideCamera}--侧门摄像头打开成功");
		return ocxbase_utils.genOptResult(true, "侧门摄像头打开成功");
	},
	
	openLeftSideCamera : function(callback) {
		if (this.cameraIsReady) {
			this.closeCamera();
		}
		
		this.resetProps();
		this.cameraReadyCallback = callback;

		if (!this.ocxInitSuccess) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openLeftSideCamera}--拍照控件未初始化");
			return ocxbase_utils.genOptResult(false, "拍照控件未初始化");
		}
		
		var openResult = this._openLeftSideCamera();
		if (false === openResult.success) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo._openLeftSideCamera}--左杠摄像头打开失败");
			return openResult;
		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openLeftSideCamera}--左杠摄像头打开成功");
		return ocxbase_utils.genOptResult(true, "左杠摄像头打开成功");
	},
	
	openRightSideCamera : function(callback) {
		if (this.cameraIsReady) {
			this.closeCamera();
		}
		
		this.resetProps();
		this.cameraReadyCallback = callback;

		if (!this.ocxInitSuccess) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openRightSideCamera}--拍照控件未初始化");
			return ocxbase_utils.genOptResult(false, "拍照控件未初始化");
		}
		
		var openResult = this._openRightSideCamera();
		if (false === openResult.success) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo._openRightSideCamera}--右杆摄像头打开失败");
			return openResult;
		}
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openRightSideCamera}--右杠摄像头打开成功");
		return ocxbase_utils.genOptResult(true, "右杠摄像头打开成功");
	},

	/**
	 * TODO 拍照
	 * 
	 * @param cut：裁剪标识
	 * @return {success:true|false,data:Object|String}
	 *         data.cutImagePath;data.srcImagePath
	 */
	captureImage : function(/* boolean */cut,/*String*/state) {
		if (!this.cameraIsReady) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.captureImage}--内部摄像头打开失败");
			return ocxbase_utils.genOptResult(false, "内部摄像头尚未就绪");
		}

		var imgName = this.cameraId + (new Date()).Format("yyyyMMddhhmmssS");
		if ("start" == state) {
			this.lastImageName.cutImageName = imgName + "_before.jpg";
			this.lastImagePath.cutImagePath = this.imagePath + "\\" + this.lastImageName.cutImageName;
			this.lastImageName.srcImageName = imgName + "_src_before.jpg";
			this.lastImagePath.srcImagePath = this.imagePath + "\\" + this.lastImageName.srcImageName;
		} else if ("end" == state) {
			this.lastImageName.cutImageName = imgName + "_after.jpg";
			this.lastImagePath.cutImagePath = this.imagePath + "\\" + this.lastImageName.cutImageName;
			this.lastImageName.srcImageName = imgName + "_src_after.jpg";
			this.lastImagePath.srcImagePath = this.imagePath + "\\" + this.lastImageName.srcImageName;
		}else{
			this.lastImageName.cutImageName = imgName + ".jpg";
			this.lastImagePath.cutImagePath = this.imagePath + "\\" + this.lastImageName.cutImageName;
			this.lastImageName.srcImageName = imgName + "_src.jpg";
			this.lastImagePath.srcImagePath = this.imagePath + "\\" + this.lastImageName.srcImageName;
		}
		this.lastImagePath.transImagePath = this.imagePath + "\\" + imgName + "_T.jpg";
		var cutFlag = (cut) ? 1 : 0;
		var captureResult = this._captureImage(this.lastImagePath.cutImagePath, this.lastImagePath.srcImagePath,
				cutFlag);
		var resultObj;
		if(cutFlag ==="1"){
			resultObj = ocxbase_fileStore.transImg(this.lastImagePath.cutImagePath, this.lastImagePath.transImagePath, 900, 675);
		}else{
			resultObj = ocxbase_fileStore.transImg(this.lastImagePath.srcImagePath, this.lastImagePath.transImagePath, 900, 675);
		}
		if (resultObj.success) {
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.captureImage}--内部摄像头拍照成功");
			return ocxbase_utils.genOptResult(true, this.lastImagePath);
		} else {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.captureImage}--内部摄像头拍照失败");
			return ocxbase_utils.genOptResult(false, "内部摄像头拍照失败");
		}
	},

	/**
	 * TODO 获取最后一次拍照的图像地址
	 * 
	 * @returns {cutImagePath,srcImagePath}
	 */
	getLastImagePath : function() {
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getLastImagePath}--最后一次拍照的图像地址："+this.lastImagePath);
		return this.lastImagePath;
	},
	
	/**
	 * TODO 获取最后一次拍照的图像名称
	 * 
	 * @returns {cutImageName,srcImageName}
	 */
	getLastImageName : function() {
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getLastImageName}--最后一次拍照的原图图像名称："+this.lastImageName.srcImageName);
		OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getLastImageName}--最后一次拍照的裁剪图图像名称："+this.lastImageName.cutImageName);
		return this.lastImageName;
	},

	/**
	 * TODO 获取最后一次拍照裁剪后的图像尺寸
	 * 
	 * @returns {success:true|false,data:Object|String}<br>
	 *          data.width;data.height
	 */
	getLastCutImageSize : function() {
		if (!this.cameraIsReady) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getLastCutImageSize}--内部摄像头尚未就绪");
			return ocxbase_utils.genOptResult(false, "内部摄像头尚未就绪");
		}
		if (!this.lastImagePath.cutImagePath) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getLastCutImageSize}--图像不存在");
			return ocxbase_utils.genOptResult(false, "图像不存在");
		}
		var imageSize = OCX_ImgHelper.getImageSize(this.lastImagePath.cutImagePath).data;
		if (imageSize) {
			var size = imageSize.split("*");
			if (size.length == 2 && size[0] && size[1]) {
				var img = new Object();
				img.width = size[0];
				img.height = size[1];
				return ocxbase_utils.genOptResult(true, img);
			} else {
				OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getLastCutImageSize}--图像处理控件获取图像宽高失败[" + imageSize + "]");
				return ocxbase_utils.genOptResult(false, "图像处理控件获取图像宽高失败[" + imageSize + "]");
			}
		} else {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getLastCutImageSize}--图像处理控件未获取到图像宽高[" + imageSize + "]");
			return ocxbase_utils.genOptResult(false, "图像处理控件未获取到图像宽高[" + imageSize + "]");
		}
	},
	
	/**
	 * TODO 获取本地图像尺寸
	 * 
	 * @returns {success:true|false,data:Object|String}<br>
	 *          data.width;data.height
	 */
	getImageSize : function(imgPath_) {
		if (!this.cameraIsReady) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getImageSize}--内部摄像头尚未就绪");
			return ocxbase_utils.genOptResult(false, "内部摄像头尚未就绪");
		}
		if (imgPath_ == null || imgPath_ == "") {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getImageSize}--图像不存在");
			return ocxbase_utils.genOptResult(false, "图像不存在");
		}
		var imageSize = OCX_ImgHelper.getImageSize(imgPath_).data;
		if (imageSize) {
			var size = imageSize.split("*");
			if (size.length == 2 && size[0] && size[1]) {
				var img = new Object();
				img.width = size[0];
				img.height = size[1];
				return ocxbase_utils.genOptResult(true, img);
			} else {
				OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getImageSize}--图像处理控件获取图像宽高失败[" + imageSize + "]");
				return ocxbase_utils.genOptResult(false, "图像处理控件获取图像宽高失败[" + imageSize + "]");
			}
		} else {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getImageSize}--图像处理控件未获取到图像宽高[" + imageSize + "]");
			return ocxbase_utils.genOptResult(false, "图像处理控件未获取到图像宽高[" + imageSize + "]");
		}
	},

	/**
	 * TODO 计算最后一次拍照裁剪后图像上的坐标在原图上的坐标
	 * 
	 * @param x：在裁剪后图像上的x坐标(像素)
	 * @param y：在裁剪后图像上的y坐标(像素)
	 * @returns {success:true|false,data:Object|String}<br>
	 *          data.x;data.y
	 */
	getLastCutInSrcPosition : function(/* int */x,/* int */y) {
		if (!this.cameraIsReady) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getLastCutInSrcPosition}--内部摄像头尚未就绪");
			return ocxbase_utils.genOptResult(false, "内部摄像头尚未就绪");
		}
		var posInSrc = OCX_XUSBVideo.getPositionInOriginal(x, y).data;
		if (posInSrc) {
			var points = posInSrc.split(",");
			if (points.length == 2) {
				var posObj = {};
				posObj.x = points[0];
				posObj.y = points[1];
				return ocxbase_utils.genOptResult(true, posObj);
			} else {
				OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getLastCutInSrcPosition}--获取原图坐标数据异常[" + posInSrc + "]");
				return ocxbase_utils.genOptResult(false, "获取原图坐标数据异常[" + posInSrc + "]");
			}
		} else {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getLastCutInSrcPosition}--拍照控件获取原图盖章坐标失败[" + posInSrc + "]");
			return ocxbase_utils.genOptResult(false, "拍照控件获取原图盖章坐标失败[" + posInSrc + "]");
		}
	},

	/**
	 * TODO 获取最后一次拍照裁剪后图像的角度
	 * 
	 * @returns {success:true|false,data:Object|String}
	 */
	getLastCutImageAngle : function() {
		if (!this.cameraIsReady) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getLastCutImageAngle}--内部摄像头尚未就绪");
			return ocxbase_utils.genOptResult(false, "内部摄像头尚未就绪");
		}
		var cutAngle = Math.round(OCX_XUSBVideo.getAngelInOriginal().data);
		if (cutAngle != null && cutAngle != undefined) {
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getLastCutImageAngle}--获取裁剪后图像角度成功");
			return ocxbase_utils.genOptResult(true, cutAngle);
		} else {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getLastCutImageAngle}--获取裁剪后图像角度失败[" + cutAngle + "]");
			return ocxbase_utils.genOptResult(false, "获取裁剪后图像角度失败[" + cutAngle + "]");
		}
	},

	/**
	 * TODO 图像尺寸是否为2048×1536
	 * 
	 * @returns true/false
	 */
	imageIs2048_1536 : function(width, height) {
		return (width == 2048 && height == 1536) ? true : false;
	},
	
	/**
	 * 图像尺寸是否与开启的摄像头尺寸一致
	 * @param width_
	 * @param height_
	 * @returns
	 */
	imageMateWidthHeight : function(width_,height_){
		return (this.cameraInfo.width == width_ && this.cameraInfo.height == height_) ? true : false;
	},

	/**
	 * TODO 判断最后一次拍照是否裁剪成功
	 * 
	 * @returns true/false
	 */
	lastImageCutSuccess : function() {
		var cutSize = this.getLastCutImageSize();
		if (cutSize.success) {
			return (this.imageMateWidthHeight(cutSize.data.width, cutSize.data.height)) ? false : true;
		} else {
			return false;
		}
	},

	/**
	 * TODO 关闭摄像头
	 */
	closeCamera : function() {
		OCX_XUSBVideo.close();
		this.cameraIsReady = false;
	},

	setCameraReady : function() {
		this.cameraIsReady = true;
	},

	resetProps : function() {
		this.cameraIsReady = false;
		this.lastImagePath = {};
		this.cameraReadyCallback = null;
	},
	
	/**
	 * 获取指定摄像头/分辨率序号的分辨率
	 * 
	 * @param cameraIndex
	 *            摄像头序号
	 * @param infoIndex
	 *            分辨率序号
	 * @returns obj(code,data,msg)
	 *          obj.code:"1001",成功,返回分辨率对象;"9201",设备未连接任何摄像头;"9202",摄像头序号超出范围;"9203",分辨率序号超出范围;
	 *          obj.data:控件原始返回值; obj.msg:提示信息;
	 */
	getVideoWidthAndHeight : function(cameraIndex, infoIndex) {
		var deviceCount = OCX_XUSBVideo.getDevicesCount().data;
		var videoInfoCount = OCX_XUSBVideo.getVideoInfoCount(cameraIndex).data;
		if (0 >= deviceCount || 0 >= videoInfoCount) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getVideoWidthAndHeight}--设备未连接任何摄像头");
			return ocxbase_utils.genOptResult(false, "设备未连接任何摄像头");
		}
		if (0 > cameraIndex || deviceCount - 1 < cameraIndex) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getVideoWidthAndHeight}--摄像头序号超出范围：" + cameraIndex);
			return OCXResult(OCX_XUSBVideo, "9202", "");
			return ocxbase_utils.genOptResult(false, "摄像头序号超出范围");
		}
		if (0 > infoIndex || videoInfoCount < infoIndex) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.getVideoWidthAndHeight}--分辨率序号超出范围：" + infoIndex);
			return OCXResult(OCX_XUSBVideo, "9203", "");
			return ocxbase_utils.genOptResult(false, "分辨率序号超出范围");
		}

		var videoInfo = new Object();
		videoInfo.width = OCX_XUSBVideo.getVideoInfoWidth(cameraIndex, infoIndex).data;
		videoInfo.height = OCX_XUSBVideo.getVideoInfoHeight(cameraIndex, infoIndex).data;
		return ocxbase_utils.genOptResult(true, videoInfo);
	},
	// TODO
	/**
	 * 打开摄像头
	 * 
	 * @returns obj(code,data,msg) obj.code:"1001",成功; "9204":"未读到摄像头配置信息或配置为空",
	 *          "9205":"摄像头序号配置错误", "9206":"绑定摄像头失败", "9207":"打开摄像头失败",
	 *          "9208":"打开摄像头异常", "9209":"摄像头分辨率配置错误", "9210":"摄像头连接异常",
	 *          obj.data:控件原始返回值; obj.msg:提示信息;
	 */
	_openCamera : function() {
		try {
			var cameraNum = OCX_XUSBVideo.getDevicesCount().data;
			var cameraIndex = OCX_Tools.readIni(iniPath, "gss", "cameraIndex", "").data;
			var infoNum = OCX_XUSBVideo.getVideoInfoCount(cameraIndex).data;
			var infoIndex = OCX_Tools.readIni(iniPath, "gss", "cameraInfoIndex", "").data;
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo._openCamera}--摄像头个数：" + cameraNum);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo._openCamera}--摄像头分辨率最大ID：" + infoNum);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo._openCamera}--gss.ini中摄像头配置的序号：" + cameraIndex);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo._openCamera}--gss.ini中摄像头配置的分辨率序号：" + infoIndex);

			if (cameraNum == null || cameraNum == undefined || cameraNum == ""
					|| infoNum == null || infoNum == undefined || infoNum == "") {// 未读到摄像头参数
				return ocxbase_utils.genOptResult(false, "摄像头连接异常");
			};
			if (cameraIndex == null || cameraIndex == undefined
					|| cameraIndex == "" || infoIndex == null
					|| infoIndex == undefined || infoIndex == "") {// 未读到配置信息或配置为空
				return ocxbase_utils.genOptResult(false, "未读到摄像头配置信息或配置为空");
			};
			if (cameraNum - 1 < parseInt(cameraIndex)) { // 配置的摄像头ID大于最大ID
				return ocxbase_utils.genOptResult(false, "摄像头序号配置错误");
			};

			if (infoNum - 1 < parseInt(infoIndex)) { // 配置的像素ID大于最大ID
				return ocxbase_utils.genOptResult(false, "摄像头分辨率配置错误");
			};

			OCX_XUSBVideo.close(); // 先关闭
			//OCX_XUSBVideo.setRectShowMode(1); // 设置剪裁框
			var rBind = OCX_XUSBVideo.bindDevice(cameraIndex, infoIndex).data;

			// cameraIndex和infoIndex参数无误并且已连接设备返回false的话，很可能是摄像头未在电脑上注册
			if (!rBind) { // 绑定设备id和分辨率id
				return ocxbase_utils.genOptResult(false, "绑定摄像头失败");
			};

			OCX_XUSBVideo.setRectShowMode(0);

			if (!OCX_XUSBVideo.open().data) {
				return ocxbase_utils.genOptResult(false, "打开摄像头失败");
			};
			this.cameraInfo.width = OCX_XUSBVideo.getVideoInfoWidth(cameraIndex, infoIndex).data;
			this.cameraInfo.height = OCX_XUSBVideo.getVideoInfoHeight(cameraIndex, infoIndex).data;
			
			if(this.cameraInfo.width == "2048" && this.cameraInfo.height == "1536") {
				this.defaultProp = "default_prop";
			} else if(this.cameraInfo.width == "2592" && this.cameraInfo.height == "1944") {
				this.defaultProp = "default_500prop";
			} else if(this.cameraInfo.width == "3264" && this.cameraInfo.height == "2448") {
				this.defaultProp = "default_800prop";
			}
			
			return ocxbase_utils.genOptResult(true, "打开摄像头成功");

		} catch (e) {
			return ocxbase_utils.genOptResult(false, "打开摄像头异常");
		};
	},
	// TODO
	/**
	 * 打开高拍仪摄像头
	 * 
	 * @returns obj(code,data,msg) obj.code:"1001",成功; "9204":"未读到摄像头配置信息或配置为空",
	 *          "9205":"摄像头序号配置错误", "9206":"绑定摄像头失败", "9207":"打开摄像头失败",
	 *          "9208":"打开摄像头异常", "9209":"摄像头分辨率配置错误", "9210":"摄像头连接异常",
	 *          obj.data:控件原始返回值; obj.msg:提示信息;
	 */
	openC2400Camera : function() {
		try {
			var cameraNum = OCX_XUSBVideo.getDevicesCount().data;
			var C2400VIDEO = OCX_Tools.readIni(iniPath, "gss", "C2400VIDEO", "").data;
			var infoNum = OCX_XUSBVideo.getVideoInfoCount(C2400VIDEO).data;
			var c2400InfoIndex = OCX_Tools.readIni(iniPath, "gss", "c2400InfoIndex",
					"").data;
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openC2400Camera}--摄像头个数：" + cameraNum);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openC2400Camera}--摄像头分辨率最大ID：" + infoNum);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openC2400Camera}--gss.ini中摄像头配置的序号：" + C2400VIDEO);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openC2400Camera}--gss.ini中摄像头配置的分辨率序号：" + c2400InfoIndex);

			if (cameraNum == null || cameraNum == undefined || cameraNum == ""
					|| infoNum == null || infoNum == undefined || infoNum == "") {// 未读到摄像头参数
				return ocxbase_utils.genOptResult(false, "摄像头连接异常");
			}
			;
			if (C2400VIDEO == null || C2400VIDEO == undefined || C2400VIDEO == ""
					|| c2400InfoIndex == null || c2400InfoIndex == undefined
					|| c2400InfoIndex == "") {// 未读到配置信息或配置为空
				return ocxbase_utils.genOptResult(false, "未读到摄像头配置信息或配置为空");
			}
			;
			if (cameraNum - 1 < parseInt(C2400VIDEO)) { // 配置的摄像头ID大于最大ID
				return ocxbase_utils.genOptResult(false, "摄像头序号配置错误");
			}
			;

			if (infoNum - 1 < parseInt(c2400InfoIndex)) { // 配置的像素ID大于最大ID
				return ocxbase_utils.genOptResult(false, "摄像头分辨率配置错误");
			}
			;

			OCX_XUSBVideo.close(); // 先关闭
			//OCX_XUSBVideo.setRectShowMode(1); // 设置剪裁框
			var rBind = OCX_XUSBVideo.bindDevice(C2400VIDEO, c2400InfoIndex).data;
			// cameraIndex和infoIndex参数无误并且已连接设备返回false的话，很可能是摄像头未在电脑上注册
			if (!rBind) { // 绑定设备id和分辨率id
				return ocxbase_utils.genOptResult(false, "绑定摄像头失败");
			}
			;
			OCX_XUSBVideo.setRectShowMode(0);
			if (!OCX_XUSBVideo.open().data) {
				return ocxbase_utils.genOptResult(false, "打开摄像头失败");
			}
			return ocxbase_utils.genOptResult(true, "打开摄像头成功");

		} catch (e) {
			return ocxbase_utils.genOptResult(false, "打开摄像头异常");
		}
		;
	},

	/**
	 * 打开侧面摄像头
	 * 
	 * @returns 0 成功, -1 摄像头序号或分辨率ID未配置, -2 摄像头序号配置错误, -3 绑定摄像头失败, -4 打开摄像头失败, -5
	 *          打开摄像头异常, -6
	 */
	_openSideCamera : function() {
		try {
			var cameraNum = OCX_XUSBVideo.getDevicesCount().data;
			var cameraIndex = OCX_Tools.readIni(iniPath, "gss", "sideCameraIndex", "").data;
			var infoNum = OCX_XUSBVideo.getVideoInfoCount(cameraIndex).data;
			var infoIndex = OCX_Tools.readIni(iniPath, "gss", "sideCameraInfoIndex","").data;
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openSideCamera}--摄像头个数：" + cameraNum);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openSideCamera}--摄像头分辨率最大ID：" + infoNum);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openSideCamera}--gss.ini中摄像头配置的序号：" + cameraIndex);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openSideCamera}--gss.ini中摄像头配置的分辨率序号：" + infoIndex);
			if (cameraNum == null || cameraNum == undefined || cameraNum == ""
					|| infoNum == null || infoNum == undefined || infoNum == "") {// 未读到摄像头参数
				return ocxbase_utils.genOptResult(false, "摄像头连接异常");
			};
			if (cameraIndex == null || cameraIndex == undefined
					|| cameraIndex == "" || infoIndex == null
					|| infoIndex == undefined || infoIndex == "") {// 未读到配置信息或配置为空
				return ocxbase_utils.genOptResult(false, "未读到摄像头配置信息或配置为空");
			};
			if (parseInt(cameraNum) - 1 < parseInt(cameraIndex)) {
				// 配置的摄像头ID大于最大ID
				return ocxbase_utils.genOptResult(false, "摄像头序号配置错误");
			};
			if (parseInt(infoNum) - 1 < parseInt(infoIndex)) { 
				// 配置的像素ID大于最大ID
				return ocxbase_utils.genOptResult(false, "摄像头分辨率配置错误");
			};
			OCX_XUSBVideo.close(); // 先关闭
			// cameraCtrl.RectShowMode = 1; // 设置剪裁框
			
			var rBind = OCX_XUSBVideo.bindDevice(cameraIndex, infoIndex).data;

			// cameraIndex和infoIndex参数无误并且已连接设备返回false的话，很可能是摄像头未在电脑上注册
			if (!rBind) { // 绑定设备id和分辨率id
				return ocxbase_utils.genOptResult(false, "绑定摄像头失败");
			};
			OCX_XUSBVideo.setRectShowMode(0);
			// cameraCtrl.RectShowMode = 5;

			if (!OCX_XUSBVideo.open().data) {
				return ocxbase_utils.genOptResult(false, "打开摄像头失败");
			};
			return ocxbase_utils.genOptResult(true, "打开摄像头成功");

		} catch (e) {
			return ocxbase_utils.genOptResult(false, "打开摄像头异常");
		};
	},
	
	/**
	 * 打开左杆摄像头（中行一体机专用）
	 */
	_openLeftSideCamera : function() {
		try {
			var cameraNum = OCX_XUSBVideo.getDevicesCount().data;
			var cameraIndex = OCX_Tools.readIni(iniPath, "gss", "leftSideCameraIndex", "").data;
			var infoNum = OCX_XUSBVideo.getVideoInfoCount(cameraIndex).data;
			var infoIndex = OCX_Tools.readIni(iniPath, "gss", "leftSideCameraInfoIndex","").data;
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openLeftSideCamera}--摄像头个数：" + cameraNum);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openLeftSideCamera}--摄像头分辨率最大ID：" + infoNum);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openLeftSideCamera}--gss.ini中摄像头配置的序号：" + cameraIndex);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openLeftSideCamera}--gss.ini中摄像头配置的分辨率序号：" + infoIndex);
			if (cameraNum == null || cameraNum == undefined || cameraNum == ""
					|| infoNum == null || infoNum == undefined || infoNum == "") {// 未读到摄像头参数
				return ocxbase_utils.genOptResult(false, "摄像头连接异常");
			};
			if (cameraIndex == null || cameraIndex == undefined
					|| cameraIndex == "" || infoIndex == null
					|| infoIndex == undefined || infoIndex == "") {// 未读到配置信息或配置为空
				return ocxbase_utils.genOptResult(false, "未读到摄像头配置信息或配置为空");
			};
			if (parseInt(cameraNum) - 1 < parseInt(cameraIndex)) {
				// 配置的摄像头ID大于最大ID
				return ocxbase_utils.genOptResult(false, "摄像头序号配置错误");
			};
			if (parseInt(infoNum) - 1 < parseInt(infoIndex)) { 
				// 配置的像素ID大于最大ID
				return ocxbase_utils.genOptResult(false, "摄像头分辨率配置错误");
			};
			OCX_XUSBVideo.close(); // 先关闭
			// cameraCtrl.RectShowMode = 1; // 设置剪裁框
			
			var rBind = OCX_XUSBVideo.bindDevice(cameraIndex, infoIndex).data;

			// cameraIndex和infoIndex参数无误并且已连接设备返回false的话，很可能是摄像头未在电脑上注册
			if (!rBind) { // 绑定设备id和分辨率id
				return ocxbase_utils.genOptResult(false, "绑定摄像头失败");
			};
			OCX_XUSBVideo.setRectShowMode(0);
			// cameraCtrl.RectShowMode = 5;

			if (!OCX_XUSBVideo.open().data) {
				return ocxbase_utils.genOptResult(false, "打开摄像头失败");
			};
			return ocxbase_utils.genOptResult(true, "打开摄像头成功");

		} catch (e) {
			return ocxbase_utils.genOptResult(false, "打开摄像头异常");
		};
	},
	/**
	 * 打开右杆摄像头（中行一体机专用）
	 */
	_openRightSideCamera : function() {
		try {
			var cameraNum = OCX_XUSBVideo.getDevicesCount().data;
			var cameraIndex = OCX_Tools.readIni(iniPath, "gss", "rightSideCameraIndex", "").data;
			var infoNum = OCX_XUSBVideo.getVideoInfoCount(cameraIndex).data;
			var infoIndex = OCX_Tools.readIni(iniPath, "gss", "rightSideCameraInfoIndex","").data;
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openRightSideCamera}--摄像头个数：" + cameraNum);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openRightSideCamera}--摄像头分辨率最大ID：" + infoNum);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openRightSideCamera}--gss.ini中摄像头配置的序号：" + cameraIndex);
			OCX_Logger.info(LOGGER._3X,"{ocxbase.useSeal.ocxbase_xusbVideo.openRightSideCamera}--gss.ini中摄像头配置的分辨率序号：" + infoIndex);
			if (cameraNum == null || cameraNum == undefined || cameraNum == ""
					|| infoNum == null || infoNum == undefined || infoNum == "") {// 未读到摄像头参数
				return ocxbase_utils.genOptResult(false, "摄像头连接异常");
			};
			if (cameraIndex == null || cameraIndex == undefined
					|| cameraIndex == "" || infoIndex == null
					|| infoIndex == undefined || infoIndex == "") {// 未读到配置信息或配置为空
				return ocxbase_utils.genOptResult(false, "未读到摄像头配置信息或配置为空");
			};
			if (parseInt(cameraNum) - 1 < parseInt(cameraIndex)) {
				// 配置的摄像头ID大于最大ID
				return ocxbase_utils.genOptResult(false, "摄像头序号配置错误");
			};
			if (parseInt(infoNum) - 1 < parseInt(infoIndex)) { 
				// 配置的像素ID大于最大ID
				return ocxbase_utils.genOptResult(false, "摄像头分辨率配置错误");
			};
			OCX_XUSBVideo.close(); // 先关闭
			// cameraCtrl.RectShowMode = 1; // 设置剪裁框
			
			var rBind = OCX_XUSBVideo.bindDevice(cameraIndex, infoIndex).data;

			// cameraIndex和infoIndex参数无误并且已连接设备返回false的话，很可能是摄像头未在电脑上注册
			if (!rBind) { // 绑定设备id和分辨率id
				return ocxbase_utils.genOptResult(false, "绑定摄像头失败");
			};
			OCX_XUSBVideo.setRectShowMode(0);
			// cameraCtrl.RectShowMode = 5;

			if (!OCX_XUSBVideo.open().data) {
				return ocxbase_utils.genOptResult(false, "打开摄像头失败");
			};
			return ocxbase_utils.genOptResult(true, "打开摄像头成功");

		} catch (e) {
			return ocxbase_utils.genOptResult(false, "打开摄像头异常");
		};
	},

	// TODO
	/**
	 * 拍照
	 * 
	 * @param filePath
	 *            照片保存路径
	 * @param srcImagePath
	 *            原图保存路径
	 * @param isCut
	 *            是否剪裁 0 否， 1 是
	 * @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
	 *          obj.data:控件原始返回值; obj.msg:提示信息;
	 */
	_captureImage : function(filePath, srcImagePath, isCut) {
		OCX_XUSBVideo.setDeskew(isCut);
		var result =  OCX_XUSBVideo.captureImage(filePath, srcImagePath);
		if(result.code ==1001){
			return ocxbase_utils.genOptResult(true , "拍照成功");
		}else{
			return ocxbase_utils.genOptResult(false , "拍照失败");
		}
	},

	getSideCameraWidthAndHeight : function() {
		var cameraIndex = OCX_Tools.readIni(iniPath, "gss", "sideCameraIndex", "").data;
		var infoIndex = OCX_Tools.readIni(iniPath, "gss", "sideCameraInfoIndex", "").data;
		return this.getVideoWidthAndHeight(cameraIndex, infoIndex);
	},

	/**
	 * 获取剪裁区域
	 */
	_getCropRect : function() {
	    var pLeft, pTop, pRight, pBottom;
	    pLeft = 0;
	    pTop = 0;
	    pRight = 0;
	    pBottom = 0;
	    if (OCX_XUSBVideo.getCropRect(pLeft, pTop, pRight, pBottom).code =="1001") {
		return ocxbase_utils.genOptResult(true , pLeft + "," + pTop + "," + pRight + "," + pBottom);
	    } else {
	    	return OCXResult(OCX_XUSBVideo, "9200","");
	    	return ocxbase_utils.genOptResult(false , "");
	    }
	},
	getVideoCore : function(){
		var result = OCX_XUSBVideo.getVideoCore();
		if(result.code == "1001"){
			return ocxbase_utils.genOptResult(true , result.data);
		}else{
			return ocxbase_utils.genOptResult(false , "异常");
		}
	}
};

// 摄像头控件就绪事件
function deviceReady() {
	OCX_Logger.info(LOGGER._3X,"打开的摄像头已就绪");
	var readytime = null;
	if(ocxbase_iniHelper && ocxbase_iniHelper.configParam.open_maincamera_delay!=null){
		readytime = ocxbase_iniHelper.configParam.open_maincamera_delay;
	}else{
		readytime = ocxbase_iniHelper.readIni("timeout","open_maincamera_delay", 500);
	}
	setTimeout(function() {
		// 用timeout等待感光稳定后再设置摄像头就绪
		ocxbase_xusbVideo.setCameraReady();
		if(null != ocxbase_xusbVideo.cameraReadyCallback && 
				typeof ocxbase_xusbVideo.cameraReadyCallback == 'function'){
			ocxbase_xusbVideo.cameraReadyCallback();
		}
	}, readytime);
};

// 摄像头控件设备连接事件
function deviceConnect(nConnectStatus) {
	// FIXME
};
