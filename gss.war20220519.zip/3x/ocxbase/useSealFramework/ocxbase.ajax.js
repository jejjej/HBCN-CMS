/**
 * 创建于:2015-10-21<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 印控机用印业务信息处理<br>
 * 1. 用印申请单<br>
 * 2. 图像存储<br>
 * 3. 其他<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var ocxbase_bizInfoAjax = {

	// 业务信息和用印日志处理器
	bizInfo : {
		/**
		 * TODO 创建开始用印
		 * 
		 * @param url：ajax响应url
		 * @returns {success:true|false,data:Object|String}
		 */
		createStartUseMechSeal : function(url,formid) {
			var param = $('#'+formid).serializeArray();
			var data = tool.ajaxRequest(url, param);
			if (data.success) {
				var addResult = data.response.webResponseJson.data;
				if (data.response.webResponseJson.state == "normal") {
					if (data.response.mechSealUseApplyInfo && data.response.mechSealUseApplyInfo.autoId != null
							&& data.response.mechSealUseApplyInfo.autoId != "") {
						$("#bizId").val(data.response.mechSealUseApplyInfo.autoId);
					}else if(data.response.useSealBizInfo && data.response.useSealBizInfo.autoId != null
							&& data.response.useSealBizInfo.autoId != ""){
						$("#bizId").val(data.response.useSealBizInfo.autoId);
					}
					if (data.response.mechSealUseLog && data.response.mechSealUseLog.autoId != null
							&& data.response.mechSealUseLog.autoId != "") {
						$("#logId").val(data.response.mechSealUseLog.autoId);
					}else if(data.response.useSealLog && data.response.useSealLog.autoId != null
							&& data.response.useSealLog.autoId != ""){
						$("#logId").val(data.response.useSealLog.autoId);
					}
					return ocxbase_utils.genOptResult(true, null);
				} else {
					return ocxbase_utils.genOptResult(false, addResult);
				}
			} else {
				return ocxbase_utils.genOptResult(false, "更新用印结果服务器响应失败：" + data.response);
			}
		},
		/**
		 * 创建开始用印
		 */
		createStartUseSeal : function(url,eleid,callback) {
			var param = $(eleid).serializeArray();
			var data = tool.ajaxRequest(url, param);
			if (data.success) {
				if (data.response.responseMessage.success) {
					if(callback!=null && typeof callback == "function"){
						callback(data.response);
					}
					return ocxbase_utils.genOptResult(true, null);
				} else {
					return ocxbase_utils.genOptResult(false, data.response.responseMessage.message);
				}
			} else {
				return ocxbase_utils.genOptResult(false, "更新用印结果服务器响应失败：" + data.response);
			}
		},
		
		addUseSealLog : function(url) {
			var param = $('#bizInfo').serializeArray();
			var data = tool.ajaxRequest(url, param);
			if (data.success) {
				if (data.response.responseMessage.success) {
					$("#bizId").val(data.response.bizInfo.autoId);
					$("#logId").val(data.response.useSealLogInfo.autoId);
					return ocxbase_utils.genOptResult(true, null);
				} else {
					return ocxbase_utils.genOptResult(false, addResult);
				}
			} else {
				return ocxbase_utils.genOptResult(false, "更新用印结果服务器响应失败：" + data.response);
			}
		},

		/**
		 * TODO 更新用印结果<br>
		 * 
		 * @param url：ajax响应url
		 * @returns {success:true|false,data:Object|String}
		 */
		updateUseMechSealResult : function(url,formid) {
			var param = $('#'+formid).serialize();
			var data = tool.ajaxRequest(url, param);
			if (data.success) {
				var updateResult = data.response.webResponseJson.data;
				if (data.response.webResponseJson.state == "normal") {
					return ocxbase_utils.genOptResult(true, null);
				} else {
					return ocxbase_utils.genOptResult(false, updateResult);
				}
			} else {
				return ocxbase_utils.genOptResult(false, "更新用印结果服务器响应失败：" + data.response);
			}
		},
		
		updateUseSealResult : function(url,id,callback) {
			var param = $(id).serialize();
			var data = tool.ajaxRequest(url, param);
			if (data.success) {
				if (data.response.responseMessage.success) {
					if(callback!=null && typeof callback == "function"){
						callback(data.response);
					}
					return ocxbase_utils.genOptResult(true, null);
				} else {
					return ocxbase_utils.genOptResult(false, data.response.responseMessage.message);
				}
				
			} else {
				return ocxbase_utils.genOptResult(false, "更新用印结果服务器响应失败：" + data.response);
			}
		},
		
		updateUseSealLog : function(url) {
			var param = $('#bizInfo').serialize();
			var data = tool.ajaxRequest(url, param);
			if (data.success) {
				if (data.response.responseMessage.success) {
					return ocxbase_utils.genOptResult(true, null);
				} else {
					return ocxbase_utils.genOptResult(false, updateResult);
				}
			} else {
				return ocxbase_utils.genOptResult(false, "更新用印结果服务器响应失败：" + data.response);
			}
		},
	
	/**
	 * TODO 更新检查结果<br>
	 * 
	 * @param url：ajax响应url
	 * @returns {success:true|false,data:Object|String}
	 */
	updateSealCheckResult : function(url) {
		var param = $('#sealCheckInfo').serialize();
		var data = tool.ajaxRequest(url, param);
		if (data.success) {
			var updateResult = data.response.webResponseJson.data;
			var message = data.response.webResponseJson.message;
			if (data.response.webResponseJson.state == "normal") {
				return ocxbase_utils.genOptResult(true, message);
			} else {
				return ocxbase_utils.genOptResult(false, updateResult);
			}
		} else {
			return ocxbase_utils.genOptResult(false, "更新用印结果服务器响应失败：" + data.response);
		}
	}
},

	// 凭证图像上传处理器
	storeInfo : {
		/**
		 * TODO 上传凭证图像
		 * 
		 * @param url：图像地址
		 * @param type：'add'、'append'
		 */
		uploadVoucherImg : function(url, type) {
			var ret = null;
			if ("add" == type) {
				ret = ocxbase_fileStore.addFile(url, {});
			} else if ("append" == type) {
				var storeId = $("#storeId").val();
				ret = ocxbase_fileStore.appendFile(url, {}, storeId);
			}

			if (ret.success) {
				$("#storeId").val(ret.data);
			}
			return ret;
		},
		uploadVoucherImage : function(id, url, type) {
			var ret = null;
			if ("add" == type) {
				ret = ocxbase_fileStore.addFile(url, {});
			} else if ("append" == type) {
				var storeId = $(id).val();
				ret = ocxbase_fileStore.appendFile(url, {}, storeId);
			}

			if (ret.success) {
				$(id).val(ret.data);
			}
			return ret;
		}
	},

	// 用印实时审批结果处理器
	approvalHandler : {
		wait_approving : "wait_approving", // 用印审核默认值
		approval_result : "wait_approving",// 用印审核结果，pass/refuse/approving
		endApprovalCallback : null,
		taskLockedCallback : null,
		approvalResultAjaxParam : {
			url : null,
			param : null
		},

		/**
		 * TODO 开启等待审批结果线程
		 * 
		 * @param url:获取审批结果请求url
		 * @param param:获取审批结果参数
		 * @param callback({success:true|false,data:Object|String}):审批结果回调函数
		 */
		startWaitApproalResultThread : function(url, param, callback,lockcallback) {
			// 设置参数
			this.approvalResultAjaxParam.url = url;
			this.approvalResultAjaxParam.param = param;
			this.endApprovalCallback = callback;
			this.taskLockedCallback = (typeof lockcallback == "function")?lockcallback:null;

			// 等待审核结果
			this.waitApprovalResult();

			// 处理审核结果
			this.dealApprovalResult();
		},

		// 循环获取审核结果，直到审核完毕
		waitApprovalResult : function() {
			// 重置审核结果
			ocxbase_bizInfoAjax.approvalHandler.approval_result = ocxbase_bizInfoAjax.approvalHandler.wait_approving;

			var approving = false;

			var ajaxReq = ocxbase_bizInfoAjax.approvalHandler.approvalResultAjaxParam;
			var result = getApprovalResult(ajaxReq.url, ajaxReq.param);
			if (result == sealUseConstants.WAITTING_APPROVAL) {
				approving = true;
			} else {
				approving = false;
			}
			
			if (approving) {
				if(this.taskLockedCallback != null && (typeof this.taskLockedCallback=="function")){
					this.taskLockedCallback();//查询任务是否锁定
				}
				// 向服务器获取审核结果的请求频率，在此加timeout可缓解服务器的压力，可适当调整timeout时间
				setTimeout("ocxbase_bizInfoAjax.approvalHandler.waitApprovalResult()", 2000);
			} else {
				ocxbase_bizInfoAjax.approvalHandler.approval_result = result;
			}

			// 获取审核的状态,审核状态approving:001/pass:002/refuse:003/审批超时:009/用印取消:010
			function getApprovalResult(url, param) {
				try {
					var data = tool.ajaxRequest(url, param);
					if (data.success) {
						return data.response.webResponseJson.data;
					} else {
						return "服务器响应失败：" + data.response;
					}
				} catch (e) {
					return e.message;
				}
			}
		},

		// 处理审核结果
		dealApprovalResult : function() {
			if (ocxbase_bizInfoAjax.approvalHandler.approval_result == ocxbase_bizInfoAjax.approvalHandler.wait_approving) {
				// 向本地全局变量获取审核结果的请求频率，可适当调整timeou的时间来调节处理审核结果的时间
				setTimeout("ocxbase_bizInfoAjax.approvalHandler.dealApprovalResult()", 2000);
			} else if (ocxbase_bizInfoAjax.approvalHandler.approval_result == sealUseConstants.APPROVAL_PASS) {//通过
				ocxbase_bizInfoAjax.approvalHandler.endApprovalCallback(ocxbase_utils.genOptResult(true, null));
			} else if (ocxbase_bizInfoAjax.approvalHandler.approval_result == sealUseConstants.APPROVAL_REFUSE) {//拒绝
				ocxbase_bizInfoAjax.approvalHandler
						.endApprovalCallback(ocxbase_utils.genOptResult(false, "用印申请审核不通过!"));
			} else if (ocxbase_bizInfoAjax.approvalHandler.approval_result == sealUseConstants.APPROVAL_TIMEOUT) {//已超时
				ocxbase_bizInfoAjax.approvalHandler
				.endApprovalCallback(ocxbase_utils.genOptResult(false, "用印申请已超时!"));
			} else if (ocxbase_bizInfoAjax.approvalHandler.approval_result == sealUseConstants.USE_SEAL_CANCEL) {//已取消
				ocxbase_bizInfoAjax.approvalHandler
				.endApprovalCallback(ocxbase_utils.genOptResult(false, "用印申请已取消!"));
			} else {
				ocxbase_bizInfoAjax.approvalHandler.endApprovalCallback(ocxbase_utils.genOptResult(false, "审核失败:"
						+ ocxbase_bizInfoAjax.approvalHandler.approval_result));
			}
		}
	}

};