/**
 * 创建于:2015-07-10<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * TODO 设备用印异常日志重传JS<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var deviceExceptionLogHandler = {
	ctx : null,

	init : function(/* String */ctx) {
		this.ctx = ctx;
	},

	// 设置操作结果
	genOptResult : function(/* boolean */success, /* String */data) {
		var optResult = new Object();
		optResult.success = success;
		optResult.data = data;
		return optResult;
	},

	// 设备处理器
	machineHandler : {
		// 设备编号
		machineSn : null,

		// 构造函数
		init : function() {
			return this.setMachineSn();
		},

		// 设置设备编号
		setMachineSn : function() {
			try {
				this.machineSn = ocxbase_sealMachine._getMachineNum().data;
				return deviceExceptionLogHandler.genOptResult(true, null);
			} catch (e) {
				return deviceExceptionLogHandler.genOptResult(false, getOCXMsg(e.message.code));
			}
		},

		// 获取设备编号
		getMachineSn : function() {
			return this.machineSn;
		},

		// 判断上一笔是否用印成功
		useSealSuccess : function() {
			// FIXME 印控机内尚无判断章是否盖章凭证上的API
			return deviceExceptionLogHandler.genOptResult(true, true);
		}
	},

	// 异常用印日志处理单元
	exceptionRecordHandler : {
		hasExceptionRecord : false,

		// 异常日志定义
		exceptionRecord : {
			logName : null,
			logId : null,
			storeId : null,
			exceptionLogStatus : null
		},
		
		// 构造函数
		init : function(/* String */machineSn) {
			return this.sendQueryExceptionRecordCmd(machineSn);
		},

		// 向后台发送查询异常用印记录指令
		sendQueryExceptionRecordCmd : function(/* String */machineSn) {
			var url = deviceExceptionLogHandler.ctx + "/3xbase/useSealErrorAction_findErrorRecord.action";
			var data = {
				"useSealError.machineSn" : machineSn
			};
			var result = tool.ajaxRequest(url, data);
			if (result.success) {
				if (result.response.responseMessage.success) {
					if (!tool.isNull(result.response.useSealError)) {
						var logName = result.response.useSealError.logName;
						var logId = result.response.useSealError.logId;
						var storeId = result.response.useSealError.storeId;
						var exceptionLogStatus = result.response.useSealError.exceptionLogStatus;
						this.setExceptionRecord(logName, logId, storeId, exceptionLogStatus);
						this.hasExceptionRecord = true;
					}

					return deviceExceptionLogHandler.genOptResult(true, null);
				} else {
					return deviceExceptionLogHandler.genOptResult(false, result.response.responseMessage.message);
				}
			} else {
				return deviceExceptionLogHandler.genOptResult(false, result.response);
			}
		},

		// 设置异常日志
		setExceptionRecord : function(/* String */logName, /* String */logId, /* String */storeId, /* String */
		exceptionLogStatus) {
			this.exceptionRecord.logName = logName;
			this.exceptionRecord.logId = logId;
			this.exceptionRecord.storeId = storeId;
			this.exceptionRecord.exceptionLogStatus = exceptionLogStatus;
		},

		// 向后台发送异常用印日志已处理指令
		sendExceptionRecordHandledCmd : function(/* boolean */useSealSuccess) {
			var url = deviceExceptionLogHandler.ctx + "/3xbase/useSealErrorAction_updateErrorRecord.action";
			var data = {
				"useSealError.isSuccess" : useSealSuccess,
				"useSealError.logName" : this.exceptionRecord.logName,
				"useSealError.logId" : this.exceptionRecord.logId,
				"useSealError.storeId" : this.exceptionRecord.storeId
			};
			var result = tool.ajaxRequest(url, data);
			if (!result.success) {
				return deviceExceptionLogHandler.genOptResult(false, result.response);
			} else if (!result.response.responseMessage.success) {
				return deviceExceptionLogHandler.genOptResult(false, result.response.responseMessage.message);
			} else {
				return deviceExceptionLogHandler.genOptResult(true, null);
			}
		}
	},

	imageHandler : {
		// 凭证图像
		voucherImage : {
			imageFilePath : top.yzjgssRootPath + "\\yzjgss\\resources\\3x\\img\\",
			cutImagePath : null,
			srcImagePath : null,
			storeId : null,
			exceptionLogStatus : null
		},

		init : function(/* String */storeId, /* String */exceptionLogStatus) {
			this.voucherImage.storeId = storeId;
			this.voucherImage.exceptionLogStatus = exceptionLogStatus;
			return deviceExceptionLogHandler.genOptResult(true, null);
		},

		// 拍取印控机内的凭证图像
		captureImage : function() {
			var name = this.voucherImage.imageFilePath + '\\' + (new Date()).Format("yyyyMMddhhmmssS");
			this.voucherImage.cutImagePath = name + ".jpg";
			this.voucherImage.srcImagePath = name + "_src.jpg";
			var captureResult = ocxbase_xusbVideo._captureImage(this.voucherImage.cutImagePath, this.voucherImage.srcImagePath,
					0);
			if (captureResult.success) {
				return deviceExceptionLogHandler.genOptResult(true, this.voucherImage);
			} else {
				return deviceExceptionLogHandler.genOptResult(false, "拍照失败");
			}
		},

		// 追加图像到当前storeId里面
		appendImageToCurrStoreId : function() {
			try {
				var param = {
					"mediatype" : this.voucherImage.exceptionLogStatus
				};
				var storeId = fileStore.appendFile(this.voucherImage.cutImagePath, param, this.voucherImage.storeId);
				return deviceExceptionLogHandler.genOptResult(true, storeId);
			} catch (e) {
				return this.getOptResult(false, "凭证图像上传失败");
			}
		}
	},

	// 开始嗅探异常用印日志
	startSniffing : function() {
		// 初始化设备处理器
		var machInit = this.machineHandler.init();
		if (!machInit.success) {
			return machInit;
		}
		var useSealResult = this.machineHandler.useSealSuccess();
		if (!useSealResult.success) {
			return useSealResult;
		}
		var isSuccess = useSealResult.data;

		// 初始化异常日志处理器
		var machineSn = this.machineHandler.getMachineSn();
		var exceInit = this.exceptionRecordHandler.init(machineSn);
		if (!exceInit.success) {
			return exceInit;
		}

		// 如果存在异常用印日志则拍照上传
		if (this.exceptionRecordHandler.hasExceptionRecord) {
			// 初始化图片处理器
			var storeId = this.exceptionRecordHandler.exceptionRecord.storeId;
			var exceptionLogStatus = this.exceptionRecordHandler.exceptionRecord.exceptionLogStatus;
			var imageInit = this.imageHandler.init(storeId, exceptionLogStatus);
			if (!imageInit.success) {
				return imageInit;
			}

			var capResult = this.imageHandler.captureImage();
			if (!capResult.success) {
				return capResult;
			}

			var appendResult = this.imageHandler.appendImageToCurrStoreId();
			if (!appendResult.success) {
				return appendResult;
			}

			var sendResult = this.exceptionRecordHandler.sendExceptionRecordHandledCmd(isSuccess);
			if (!sendResult.success) {
				return sendResult;
			}
		}

		return this.genOptResult(true, null);
	}
};
