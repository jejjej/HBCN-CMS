/**
 * 创建于:2015-07-10<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 设备用印异常日志重传JS<br>
 * 前提：1.成功连接印控机；2.摄像头成功打开
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var ocxbase_exceptionLogHandler = {
	ctx : $.getContextPath(),
	
	/**
	 * 自定义异常处理url及data
	 */
	exceptionData :{
		queryUrl : null,
		queryData : null,
		dealUrl : null,
		dealData : null
	},
	
	setExceptionData : function(queryurl,queryData,dealUrl,dealData){
		this.exceptionData.queryUrl = queryurl;
		this.exceptionData.queryData = queryData;
		this.exceptionData.dealUrl = dealUrl;
		this.exceptionData.dealData = dealData;
	},
	
	/**
	 * TODO 开始嗅探并处理异常用印日志
	 * 
	 * @param machineNum：印控机编号
	 * @param lastUseSuccess：最后一次用印是否成功true/false
	 * @returns {success:true|false,data:Object|String}
	 */
	startSniffing : function(/* String */machineNum, /* boolean */lastUseSuccess) {
		// 初始化异常日志处理器
		var exceInit = this.exceptionRecordHandler.init(machineNum);
		if (!exceInit.success) {
			return exceInit;
		}

		// 如果存在异常用印日志则拍照上传
		if (this.exceptionRecordHandler.hasExceptionRecord) {
			// 初始化图片处理器
			var storeId = this.exceptionRecordHandler.exceptionRecord.storeId;
			var exceptionLogStatus = this.exceptionRecordHandler.exceptionRecord.exceptionLogStatus;
			var imageInit = this.imageHandler.init(storeId, exceptionLogStatus);
			if (!imageInit.success) {
				return imageInit;
			}

			var capResult = this.imageHandler.captureImage();
			if (!capResult.success) {
				return capResult;
			}
			var appendResult = null;
			if(null==storeId || ""==storeId){//解决异常记录暂没有上传的文件，此处直接添加非追加
				appendResult = this.imageHandler.addImage();
				if(appendResult.success){
					this.exceptionRecordHandler.setExceptionRecord(
							this.exceptionRecordHandler.exceptionRecord.logName,
							this.exceptionRecordHandler.exceptionRecord.logId, 
							appendResult.data, 
							this.exceptionRecordHandler.exceptionRecord.exceptionLogStatus);
				}
			}else{
				appendResult = this.imageHandler.appendImageToCurrStoreId();
			}
			if (!appendResult.success) {
				return appendResult;
			}

			var sendResult = this.exceptionRecordHandler.sendExceptionRecordHandledCmd(lastUseSuccess);
			if (!sendResult.success) {
				return sendResult;
			}
		}

		return ocxbase_utils.genOptResult(true, null);
	},

	// ----------------------内部处理器 start------------------------

	// 异常用印日志处理单元
	exceptionRecordHandler : {
		hasExceptionRecord : false,

		// 异常日志定义
		exceptionRecord : {
			logName : null,
			logId : null,
			storeId : null,
			exceptionLogStatus : null
		},

		// 构造函数
		init : function(/* String */machineSn) {
			return this.sendQueryExceptionRecordCmd(machineSn);
		},

		// 向后台发送查询异常用印记录指令
		sendQueryExceptionRecordCmd : function(/* String */machineSn) {
			var url = ocxbase_exceptionLogHandler.ctx + "/3xbase/useSealErrorAction_findErrorRecord.action";
			var data = {
				"useSealError.machineSn" : machineSn
			};
			if(null != ocxbase_exceptionLogHandler.exceptionData.queryUrl){
				url = ocxbase_exceptionLogHandler.exceptionData.queryUrl;
			}
			if(null != ocxbase_exceptionLogHandler.exceptionData.queryData){
				data = ocxbase_exceptionLogHandler.exceptionData.queryData;
			}
			var result = ocxbase_utils.ajaxRequest(url, data);
			if (result.success) {
				if (result.response.responseMessage.success) {
					if (result.response.useSealError != null && result.response.useSealError) {
						var logName = result.response.useSealError.logName;
						var logId = result.response.useSealError.logId;
						var storeId = result.response.useSealError.storeId;
						var exceptionLogStatus = result.response.useSealError.exceptionLogStatus;
						this.setExceptionRecord(logName, logId, storeId, exceptionLogStatus);
						this.hasExceptionRecord = true;
					}

					return ocxbase_utils.genOptResult(true, null);
				} else {
					return ocxbase_utils.genOptResult(false, result.response.responseMessage.message);
				}
			} else {
				return ocxbase_utils.genOptResult(false, result.response);
			}
		},

		// 设置异常日志
		setExceptionRecord : function(/* String */logName, /* String */logId, /* String */storeId, /* String */
		exceptionLogStatus) {
			this.exceptionRecord.logName = logName;
			this.exceptionRecord.logId = logId;
			this.exceptionRecord.storeId = storeId;
			this.exceptionRecord.exceptionLogStatus = exceptionLogStatus;
		},

		// 向后台发送异常用印日志已处理指令
		sendExceptionRecordHandledCmd : function(/* boolean */useSealSuccess) {
			var url = ocxbase_exceptionLogHandler.ctx + "/3xbase/useSealErrorAction_updateErrorRecord.action";
			var data = {
				"useSealError.isSuccess" : useSealSuccess,
				"useSealError.logName" : this.exceptionRecord.logName,
				"useSealError.logId" : this.exceptionRecord.logId,
				"useSealError.storeId" : this.exceptionRecord.storeId
			};
			if(null != ocxbase_exceptionLogHandler.exceptionData.dealUrl){
				url = ocxbase_exceptionLogHandler.exceptionData.dealUrl;
			}
			if(null != ocxbase_exceptionLogHandler.exceptionData.dealData){
				data = ocxbase_exceptionLogHandler.exceptionData.dealData;
			}
			var result = ocxbase_utils.ajaxRequest(url, data);
			if (!result.success) {
				return ocxbase_utils.genOptResult(false, result.response);
			} else if (!result.response.responseMessage.success) {
				return ocxbase_utils.genOptResult(false, result.response.responseMessage.message);
			} else {
				return ocxbase_utils.genOptResult(true, null);
			}
		}
	},

	// 图像处理单元
	imageHandler : {
		// 凭证图像
		voucherImage : {
			imageFilePath : top.yzjgssRootPath + "\\yzjgss\\resources\\3x\\img\\",
			cutImagePath : null,
			srcImagePath : null,
			storeId : null,
			exceptionLogStatus : null
		},

		init : function(/* String */storeId, /* String */exceptionLogStatus) {
			this.voucherImage.storeId = storeId;
			this.voucherImage.exceptionLogStatus = exceptionLogStatus;
			return ocxbase_utils.genOptResult(true, null);
		},

		// 拍取印控机内的凭证图像
		captureImage : function() {
			var name = this.voucherImage.imageFilePath + '\\' + (new Date()).Format("yyyyMMddhhmmssS");
			this.voucherImage.cutImagePath = name + ".jpg";
			this.voucherImage.srcImagePath = name + "_src.jpg";
			var captureResult = ocxbase_xusbVideo._captureImage(this.voucherImage.cutImagePath, this.voucherImage.srcImagePath,
					0);
			if (captureResult.success) {
				return ocxbase_utils.genOptResult(true, this.voucherImage);
			} else {
				return ocxbase_utils.genOptResult(false, "拍照失败");
			}
		},

		// 追加图像到当前storeId里面
		appendImageToCurrStoreId : function() {
			var param = {
				"mediatype" : this.voucherImage.exceptionLogStatus
			};
			return ocxbase_fileStore.appendFile(this.voucherImage.cutImagePath, param, this.voucherImage.storeId);
		},
		
		// 新增图像
		addImage : function() {
			var param = {
				"mediatype" : this.voucherImage.exceptionLogStatus
			};
			return ocxbase_fileStore.addFile(this.voucherImage.cutImagePath, param);
		}
	}

// ----------------------内部处理器 end--------------------------
};
