/**
 * 创建于:2015-08-24<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 同步线程池封装<br>
 * 所有线程同步执行，顺序为：线程池中先进栈先执行<br>
 * 主线程池发生异常则中止执行并跳至异常线程池，异常线程不管执行成功与否都会轮询所有异常线程<br>
 * 线程包含以下三种类型:<br>
 * 1. 主线程<br>
 * 2. 异常线程<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var ocxbase_synThreadPool = {
	isRunning : false,
	mainPool : new Array(),
	exPool : new Array(),

	threadType : {
		main : "main",
		exception : "ex"
	},

	/**
	 * TODO 添加线程
	 * 
	 * @param threadType：ocxbase_synThreadPool.threadType
	 * @param thread：子线程xxxThread(data,completeCallback)
	 *            参数1{Object}：{success:true/false,data:Object|String}<br>
	 *            参数2{function}：completeCallback({success:true/false,data:Object|String})<br>
	 * @returns {success:true|false,data:Object|String}
	 */
	addThread : function(/* String */threadType, /* Function */thread) {
		if (this.threadType.main == threadType) {
			this.mainPool.push(thread);
		} else if (this.threadType.exception == threadType) {
			this.exPool.push(thread);
		} else {
			return ocxbase_utils.genOptResult(false, "未定义的线程类型");
		}

		return ocxbase_utils.genOptResult(true, null);
	},

	/**
	 * TODO 轮询线程池中的线程
	 * 
	 * @param firstThreadParam：第一个线程执行的参数{success:true/false,data:Object|String}
	 *            success：上一线程执行结果 data：上一线程传递而来的数据
	 * @returns {success:true/false,data:Object|String}：false线程配置错误开启失败|正在运行中，else开启成功
	 */
	run : function(/* Object */firstThreadParam) {
		if (!this.isRightConfiguration()) {
			return ocxbase_utils.genOptResult(false, "线程配置不正确");
		}

		if (!this.isRunable()) {
			return ocxbase_utils.genOptResult(false, "线程正在运行中");
		}

		this.threadStart();

		// 逐个轮询主线程
		var m = 0;
		var mainPoolCallback = function(lastThreadResult) {
			if (lastThreadResult.success) {
				m++;
				if (mainPool[m]) {
					mainPool[m].call(this, lastThreadResult.data, mainPoolCallback);
				} else {
					this.threadEnd();
				}
			} else {
				// 主线程发生异常，跳至异常线程
				if (exPool[0]) {
					exPool[0].call(this, lastThreadResult.data, exPoolCallback);
				}
			}
		};

		// 准备线程或主线程发生异常时，逐个轮询异常线程
		var e = 0;
		var exPoolCallback = function(lastThreadResult) {
			// 异常线程不管执行成功与否都轮询所有异常线程
			e++;
			if (exPool[e]) {
				exPool[e].call(this, lastThreadResult.data, exPoolCallback);
			} else {
				this.threadEnd();
			}
		};

		// 从第一个准备线程开始
		this.mainPool[0].call(this, firstThreadParam, mainPoolCallback);
	},

	isRightConfiguration : function() {
		return (this.mainPool && this.mainPool instanceof Array && this.mainPool.length > 0 && this.exPool
				&& this.exPool instanceof Array && this.exPool.length > 0) ? true : false;
	},

	isRunable : function() {
		return (!this.isRunning) ? true : false;
	},

	threadStart : function() {
		this.isRunning = true;
	},

	threadEnd : function() {
		this.isRunning = false;
	},

	reset : function() {
		this.mainPool = new Array();
		this.exPool = new Array();
		this.isRunning = false;
	}
};