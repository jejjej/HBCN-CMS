/**
 * 创建于:2015-07-17<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 图片识别处理<br>
 * 1. 版本识别控件<br>
 * 2. 电子印章打印控件(识别验证码)<br>
 * 3. 图片帮助控件<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var ocxbase_imageProcessing = {
	ctx : $.getContextPath(),
	ocxInitSuccess : false,
	regDPI : 200,//识别图像所需图像dpi
	cameraDPI : {
		dpi300 : 144,
		dpi500 : 182.2,
		dpi800 : 229.5
	},
	/**
	 * 凭证号及验证码是否识别
	 */
	regParam : {
		regVerCode : false,//验证码识别
		regBillNo : false//凭证号识别
	},
	
	/**
	 * TODO 初始化控件
	 * 
	 * @returns {success:true|false,data:Object|String}
	 */
	initOcx : function() {
		// 初始化版面识别控件
		if (!ocxObject.initOcx(ocxObject.OCX_DocRecog, document.body, this.ctx + '/activex/api/', 'run')) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.initOcx}--初始化版面识别控件失败");
			return ocxbase_utils.genOptResult(false, "初始化版面识别控件失败");
		}

		// 初始化电子印章打印控件(用于识别验证码)
		if (!ocxObject.initOcx(ocxObject.OCX_ElecSealPrint, document.body, this.ctx + '/activex/api/', 'run')) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.initOcx}--初始化验证码识别控件失败");
			return ocxbase_utils.genOptResult(false, "初始化验证码识别控件失败");
		}

		// 初始化图片处理控件
		if (!ocxObject.initOcx(ocxObject.OCX_ImgHelper, document.body, this.ctx + '/activex/api/', 'run')) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.initOcx}--初始化图片处理控件失败");
			return ocxbase_utils.genOptResult(false, "初始化图片处理控件失败");
		}
		//初始化电子印章控件 用于识别
		if (!ocxObject.initOcx(ocxObject.OCX_ElecMoulage, document.body, this.ctx + '/activex/api/', 'run')) {
			OCX_Logger.error(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.initOcx}--初始化电子印章控件失败");
			return ocxbase_utils.genOptResult(false, "初始化电子印章控件失败");
		}

		this.ocxInitSuccess = true;
		OCX_Logger.info(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.initOcx}--初始化控件成功");
		return ocxbase_utils.genOptResult(true, "");
	},

	// 识别结果
	recognitionResult : {
		voucherInfo : null, // voucherRecognizer.voucherInfo 版面识别信息
		verificationCodeInfo : null, // verificationCodeRecognizer.verificationCodeInfo 验证码信息
		billCodeInfo : null,//凭证号信息
		errorMsg : null
	},
	
	sealConfigResult : null,//凭证配置信息
	
	clearResult : function(){
		this.recognitionResult.voucherInfo = null;
		this.recognitionResult.verificationCodeInfo = null;
		this.recognitionResult.billCodeInfo = null;
		this.recognitionResult.errorMsg = null;
		this.sealConfigResult = null;
	},

	/**
	 * TODO 获取识别结果
	 * 
	 * @returns ocxbase_imageProcessing.recognitionResult
	 */
	getRecognitionResult : function() {
		return this.recognitionResult;
	},
	
	getSealConfig : function(){
		return this.sealConfigResult;
	},
	
	setRegVerCode : function(){
		this.regParam.regVerCode = true;
	},
	
	setRegBillNo : function(){
		this.regParam.regBillNo = true;
	},

	/**
	 * TODO 识别凭证和验证码<br>
	 * 返回结果中无论success的值是true还是false，凭证和验证码识别的结果都会在data中一起返回
	 * 
	 * @param machine：设备编号
	 * @param imagePath：图像全路径
	 * @returns {success:true|false,data:Object|String}
	 *          data:ocxbase_imageProcessing.recognitionResult
	 */
	recognizeVoucher : function(/* String */machineNum, /* String */imagePath) {
		// 判断控件是否成功加载
		if (!this.ocxInitSuccess) {
			this.recognitionResult.errorMsg = "版面识别或验证码识别控件加载失败";
			OCX_Logger.error(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--" + this.recognitionResult);
			return ocxbase_utils.genOptResult(false, this.recognitionResult);
		}
		this.clearResult();
		
		// 识别凭证
		var vouInit = this.voucherRecognizer.init(imagePath);
		if (!vouInit.success) {
			this.recognitionResult.errorMsg = vouInit.data;
			OCX_Logger.error(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--凭证识别初始化失败：" + this.recognitionResult.errorMsg);
			return ocxbase_utils.genOptResult(false, this.recognitionResult);
		}
		var loadResult = this.voucherRecognizer.loadVoucherTemplate();
		if (!loadResult.success) {
			this.recognitionResult.errorMsg = loadResult.data;
			OCX_Logger.error(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--加载凭证模板失败：" + this.recognitionResult.errorMsg);
			return ocxbase_utils.genOptResult(false, this.recognitionResult);
		}
		var regResult = this.voucherRecognizer.recognizeVoucher();
		if (regResult.success) {
			OCX_Logger.info(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--凭证识别成功");
			this.recognitionResult.voucherInfo = regResult.data;
		} else {
			this.recognitionResult.errorMsg = regResult.data;
			OCX_Logger.error(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--凭证识别失败:" + this.recognitionResult.errorMsg);
			return ocxbase_utils.genOptResult(false, this.recognitionResult);
		}
		var rotResult = this.voucherRecognizer.rotateImage();
		if (rotResult.success) {
			OCX_Logger.info(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--旋正凭证图片成功");
			this.recognitionResult.voucherInfo = rotResult.data;
		} else {
			this.recognitionResult.errorMsg = rotResult.data;
			OCX_Logger.error(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--旋正凭证图片失败:" + this.recognitionResult.errorMsg);
			return ocxbase_utils.genOptResult(false, this.recognitionResult);
		}

		// 查询凭证用印信息
		var voucherInfo = this.recognitionResult.voucherInfo;
//		var useSealInfo = this.ajaxUint.queryVoucherUseSealInfo(machineNum, voucherInfo.code);
		var useSealInfo = this.ajaxUint.queryBillConfigInfo(voucherInfo.code);
		if (!useSealInfo.success) {
			this.recognitionResult.errorMsg = useSealInfo.data;
			OCX_Logger.error(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--查询用印配置信息失败:" + this.recognitionResult.errorMsg);
			return ocxbase_utils.genOptResult(false, this.recognitionResult);
		}else{
			OCX_Logger.info(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--查询用印配置信息成功");
			this.sealConfigResult = useSealInfo.data;
		}
		var recongPath = this.recognitionResult.voucherInfo.revolvedImg.replace(".jpg","_reg.jpg");
		var transResult = OCX_Moulage.TransDpi(this.recognitionResult.voucherInfo.revolvedImg,recongPath,
				this.voucherRecognizer.cameradpi,this.regDPI);//转换为识别图所需的dpi图像
		if(transResult.code != "1001"){
			this.recognitionResult.errorMsg = "转换图像DPI失败";
			OCX_Logger.error(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--转换凭证图像dpi失败：" + this.recognitionResult.errorMsg);
			return ocxbase_utils.genOptResult(false, this.recognitionResult);
		}
		// 识别验证码
		if(this.regParam.regVerCode){
			var verInit = this.verificationCodeRecognizer.init(recongPath,
					useSealInfo.data.codePos.startX, useSealInfo.data.codePos.startY, useSealInfo.data.codePos.endX, useSealInfo.data.codePos.endY);
			if (!verInit.success) {
				this.recognitionResult.errorMsg = verInit.data;
				OCX_Logger.error(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--验证码识别器初始化失败:" + this.recognitionResult.errorMsg);
				return ocxbase_utils.genOptResult(false, this.recognitionResult);
			}
			var verResult = this.verificationCodeRecognizer.regVerificationCode();
			if (verResult.success) {
				OCX_Logger.info(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--识别验证码成功");
				this.recognitionResult.verificationCodeInfo = verResult.data;
			} else {
				this.recognitionResult.errorMsg = verResult.data;
				OCX_Logger.error(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--识别验证码失败:" + this.recognitionResult.errorMsg);
				return ocxbase_utils.genOptResult(false, this.recognitionResult);
			}
		}
		//识别凭证号
		if(this.regParam.regBillNo){
			var billInit = this.billNoRecognizer.init(recongPath, 
					useSealInfo.data.billNoPos.startX, useSealInfo.data.billNoPos.startY, useSealInfo.data.billNoPos.endX, useSealInfo.data.billNoPos.endY);
			if (!billInit.success) {
				this.recognitionResult.errorMsg = billInit.data;
				OCX_Logger.error(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--凭证号识别器初始化失败:" + this.recognitionResult.errorMsg);
				return ocxbase_utils.genOptResult(false, this.recognitionResult);
			}
			var billResult = this.billNoRecognizer.regBillNo();
			if (verResult.success) {
				OCX_Logger.info(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--识别凭证号成功");
				this.recognitionResult.billCodeInfo = billResult.data;
			} else {
				this.recognitionResult.errorMsg = billResult.data;
				OCX_Logger.error(LOGGER._3X,"{ocxbase.image.ocxbase_imageProcessing.recognizeVoucher}--识别凭证号失败:" + this.recognitionResult.errorMsg);
				return ocxbase_utils.genOptResult(false, this.recognitionResult);
			}
		}
		
		// 返回识别成功
		return ocxbase_utils.genOptResult(true, this.recognitionResult);
	},

	// ----------------------内部处理器 start------------------------

	// 版面识别器
	voucherRecognizer : {
		cameradpi : null,
		imagePath : null, // 图像路径
		voucherTemplatePath : null, //凭证模板路径
		templatePath : {
			camera300 : top.yzjgssRootPath+"\\yzjgss\\template\\3x\\recog\\reg300\\reg.xml", // 300w像素凭证模板路径
			camera500 : top.yzjgssRootPath+"\\yzjgss\\template\\3x\\recog\\reg500\\reg.xml", // 500w像素凭证模板路径
			camera800 : top.yzjgssRootPath+"\\yzjgss\\template\\3x\\recog\\reg800\\reg.xml" //  800w像素凭证模板路径
		},
		
		// 识别出来的凭证信息
		voucherInfo : {
			name : null, // 凭证xml模板页名称'[交易代码]_[业务类型]_[角度]'  凭证模板号_角度
			code : null, // 凭证代码'[交易代码]_[业务类型]' 凭证模板号
			revolvedImg : null, // 旋正后的图像
			direction : null
		},

		init : function(/* String */imagePath) {
			this.imagePath = imagePath;
			this.voucherInfo.name = null;
			this.voucherInfo.code = null;
			this.voucherInfo.revolvedImg = null;
			this.voucherInfo.direction = null;
			if(ocxbase_xusbVideo.cameraInfo.width == "2048"){
				this.voucherTemplatePath = this.templatePath.camera300;
				this.cameradpi = ocxbase_imageProcessing.cameraDPI.dpi300;
			}
			if(ocxbase_xusbVideo.cameraInfo.width == "2592"){
				this.voucherTemplatePath = this.templatePath.camera500;
				this.cameradpi = ocxbase_imageProcessing.cameraDPI.dpi500;
			}
			if(ocxbase_xusbVideo.cameraInfo.width == "3264"){
				this.voucherTemplatePath = this.templatePath.camera800;
				this.cameradpi = ocxbase_imageProcessing.cameraDPI.dpi800;
			}
			
			return ocxbase_utils.genOptResult(true, "");
		},

		// 加载凭证模板
		loadVoucherTemplate : function() {
			// FIXME 是否需要重复加载待验证
//			console.log("加载模板路径为："+this.voucherTemplatePath);
			var setResult = OCX_DocRecog.setTemplate(this.voucherTemplatePath).data;
			if (setResult == "0") {
				return ocxbase_utils.genOptResult(true, "");
			} else {
				return ocxbase_utils.genOptResult(false, "凭证模板文件加载失败，请重试！");
			}
		},
		
		// 识别凭证
		recognizeVoucher : function() {
			// 识别凭证
			var recogResult = OCX_DocRecog.recognize(this.imagePath).data;
			if (recogResult < 0) {
				return ocxbase_utils.genOptResult(false, "凭证图片识别失败，请重试！");
			}

			// 获取凭证名称
			var voucherName = OCX_DocRecog.getDocName().data;
			if (voucherName == null || voucherName == "") {
				return ocxbase_utils.genOptResult(false, "识别凭证类型失败，请重试！");
			} else {
				this.voucherInfo.name = voucherName;
			}

			// 识别凭证的方向
			if (this.voucherInfo.name.indexOf("_0") != -1) {
				this.voucherInfo.direction = 0;
				this.voucherInfo.code = this.voucherInfo.name.replace("_0", "");
			} else if (this.voucherInfo.name.indexOf("_90") != -1) {
				this.voucherInfo.direction = 90;
				this.voucherInfo.code = this.voucherInfo.name.replace("_90", "");
			} else if (this.voucherInfo.name.indexOf("_180") != -1) {
				this.voucherInfo.direction = 180;
				this.voucherInfo.code = this.voucherInfo.name.replace("_180", "");
			} else if (this.voucherInfo.name.indexOf("_270") != -1) {
				this.voucherInfo.direction = 270;
				this.voucherInfo.code = this.voucherInfo.name.replace("_270", "");
			}

			return ocxbase_utils.genOptResult(true, this.voucherInfo);
		},

		// 旋正凭证图片
		rotateImage : function() {
			var revolvedImg = this.imagePath.replace(".jpg", "") + "-revolve.jpg";
			var rotateResult = OCX_ImgHelper.rotateImage(this.imagePath, revolvedImg, 0 - this.voucherInfo.direction).data;
			if (rotateResult == 0) {
				this.voucherInfo.revolvedImg = revolvedImg;
				return ocxbase_utils.genOptResult(true, this.voucherInfo);
			} else {
				return ocxbase_utils.genOptResult(false, "图像处理控件旋转图像失败！");
			}
		}
	},

	// ajax请求器
	ajaxUint : {
		// 查询用印差异参数
		queryVoucherUseSealInfo : function(/* String */machineNum,/* String */
		voucherInfoCode) {
			var param = {
				'machineNum' : machineNum,
				'voucherCode' : voucherInfoCode
			};
			var url = ocxbase_imageProcessing.ctx
					+ "/mechseal/sealuse/applyUseMechSealAction_findBizUseSealInfo.action";
			var data = ocxbase_utils.ajaxRequest(url, param);
			if (data.success) {
				var useSealInfo = data.response.webResponseJson.data;
				if (data.response.webResponseJson.state == "normal") {
					var info = eval('(' + useSealInfo.diffParamJson + ')');
					var result = {};
					// FIXME 验证码尺寸(245*120)(单位：px)
					result.startX = info.recogCodeXposition;
					result.startY = info.recogCodeYposition;
					result.endX = info.recogCodeXposition + 245;
					result.endY = info.recogCodeYposition + 120;
					return ocxbase_utils.genOptResult(true, result);
				} else {
					return ocxbase_utils.genOptResult(false, useSealInfo);
				}
			} else {
				return ocxbase_utils.genOptResult(false, "服务器响应失败：" + data.response);
			}
		},
		
		/**
		 * 根据模板编号查询模板配置信息
		 */
		queryBillConfigInfo : function(billNo){
			var param = {'sealConfig.billTplCode' : billNo};
			var url = ocxbase_imageProcessing.ctx
						+ "/3xbase/usesealCommonAction_querySealConfig.action";
			var data = ocxbase_utils.ajaxRequest(url, param);
			if (data.success) {
				var useSealInfo = data.response.responseMessage.data;
				if(data.response.responseMessage.success){
					var info = eval('(' + useSealInfo.position + ')');
					var result = {
							sealPos:{},//用印位置
							billNoPos:{},//票据号位置
							codePos:{},//识别码位置
							billName : null,//凭证名称
							sealType : null,//印章类型
							sealTypeName : null//印章类型名称
						};
					result.sealPos.startX = info.sealPos.startX;
					result.sealPos.startY = info.sealPos.startY;
					
					result.billNoPos.startX = info.billNoPos.startX;
					result.billNoPos.startY = info.billNoPos.startY;
					result.billNoPos.endX = info.billNoPos.endX;
					result.billNoPos.endY = info.billNoPos.endY;
					
					result.codePos.startX = info.codePos.startX;
					result.codePos.startY = info.codePos.startY;
					result.codePos.endX = info.codePos.endX;
					result.codePos.endY = info.codePos.endY;
					
					result.billName = useSealInfo.billTplName;
					result.sealType = useSealInfo.sealTypeId;
					result.sealTypeName = useSealInfo.sealTypeName;
					return ocxbase_utils.genOptResult(true, result);
				}else{
					return ocxbase_utils.genOptResult(false, data.response.responseMessage.message);
				}
			} else {
				return ocxbase_utils.genOptResult(false, "服务器响应失败：" + data.response);
			}
		}
		
	},

	// 验证码识别器
	verificationCodeRecognizer : {
		imagePath : null, // 图像路径
		// 验证码信息
		verificationCodeInfo : {
			startX : null,
			startY : null,
			endX : null,
			endY : null,
			code : null
		},

		init : function(/* String */imagePath,/* int */startX,/* int */
		startY,/* int */endX,/* int */endY) {
			this.imagePath = imagePath;
			this.verificationCodeInfo.startX = startX;
			this.verificationCodeInfo.startY = startY;
			this.verificationCodeInfo.endX = endX;
			this.verificationCodeInfo.endY = endY;
			this.verificationCodeInfo.code = null;
			return ocxbase_utils.genOptResult(true, "");
		},

		// 识别验证码
		regVerificationCode : function() {
			var code = "";
			var bl = 200/ocxbase_imageProcessing.voucherRecognizer.cameradpi;
//			console.log("识别图像地址："+this.imagePath);
			code = OCX_Moulage.VerifyCodeReg(this.imagePath, Math.round(this.verificationCodeInfo.startX*bl), Math
					.round(this.verificationCodeInfo.startY*bl), Math.round(this.verificationCodeInfo.endX*bl), Math
					.round(this.verificationCodeInfo.endY*bl),0).data;
//			console.log(Math.round(this.verificationCodeInfo.startX*bl)+","+Math
//					.round(this.verificationCodeInfo.startY*bl)+"=="+Math.round(this.verificationCodeInfo.endX*bl)+","+Math
//					.round(this.verificationCodeInfo.endY*bl));
//			console.log("验证码："+code);
			this.verificationCodeInfo.code = code;
			return ocxbase_utils.genOptResult(true, this.verificationCodeInfo);
		}
	},
	
	// 凭证号识别器
	billNoRecognizer : {
		imagePath : null, // 水平图像路径

		// 凭证号信息
		billCodeInfo : {
			startX : null,
			startY : null,
			endX : null,
			endY : null,
			code : null
		},

		init : function(/* String */imagePath,/* int */startX,/* int */
		startY,/* int */endX,/* int */endY) {
			this.imagePath = imagePath;
			this.billCodeInfo.startX = startX;
			this.billCodeInfo.startY = startY;
			this.billCodeInfo.endX = endX;
			this.billCodeInfo.endY = endY;
			this.billCodeInfo.code = null;
			return ocxbase_utils.genOptResult(true, "");
		},

		// 识别凭证号
		regBillNo : function() {
			var code = "43216789";
			code = OCX_Moulage.CertSNCodeReg(this.imagePath,Math.round(this.billCodeInfo.startX), Math
					.round(this.billCodeInfo.startY), Math.round(this.billCodeInfo.endX), Math
					.round(this.billCodeInfo.endY),0).data;
			this.billCodeInfo.code = code;
			return ocxbase_utils.genOptResult(true, this.billCodeInfo);
		}
	}

// ----------------------内部处理器 end--------------------------
};