/**
 * 创建于:2014-9-20<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 独立打印控件测试脚本
 * 
 * @author 黄有坚
 * @version 1.0
 */

//印章打印
function printSeal(){
	var picPath = window.document.getElementById("printPic").value;
	var x = parseInt(window.document.getElementById("sealX").value);
	var y = parseInt(window.document.getElementById("sealY").value);
	var w = parseInt(window.document.getElementById("sealW").value);
	var h = parseInt(window.document.getElementById("sealH").value);
	if (!picPath) {
		showResult("印章打印", "未选择文件");
		alert("印章打印: 未选择文件");
		return;
	};
	if (isNaN(x) || isNaN(y) || isNaN(w) || isNaN(h)) {
		showResult("印章打印","参数无效");
		alert("印章打印: 参数无效");
		return;
	};
	if(OCX_ElecSealPrint.startPrintPic(picPath, x, y, w, h)) {
		showResult("开始打印", "打印已经开始了，请耐心等候打印...");
	} else {
		showResult("开始打印", "打印发生错误");
	};
}

//防伪码打印
function printRegString(){	
	var str = window.document.getElementById("regStr").value;
	var x = parseInt(window.document.getElementById("regStrX").value);
	var y = parseInt(window.document.getElementById("regStrY").value);
	var w = parseInt(window.document.getElementById("regStrW").value);
	var h = parseInt(window.document.getElementById("regStrH").value);
	if (!str) {
		showResult("防伪码打印", "未输入防伪码");
		alert("防伪码打印: 未输入防伪码");
		return;
	};
	if (isNaN(x) || isNaN(y) || isNaN(w) || isNaN(h)) {
		showResult("防伪码打印","参数无效");
		alert("防伪码打印: 参数无效");
		return;
	};
	if(OCX_ElecSealPrint.startPrintStr(str, x, y, w, h)) {
		showResult("开始打印", "打印已经开始了，请耐心等候打印...");
	} else {
		showResult("开始打印", "打印发生错误");
	};
}

//防伪码识别
function scanRegString(){	
	var file = window.document.getElementById("regStrPic").value;
	var l = parseInt(window.document.getElementById("regStrL").value);
	var r = parseInt(window.document.getElementById("regStrR").value);
	var t = parseInt(window.document.getElementById("regStrT").value);
	var b = parseInt(window.document.getElementById("regStrB").value);

	if (!file) {
		showResult("防伪码识别", "未选择文件");
		alert("防伪码识别: 未选择文件");
		return;
	};
	if (isNaN(l) || isNaN(r) || isNaN(t) || isNaN(b)) {
		showResult("防伪码识别","参数无效");
		alert("防伪码识别: 参数无效");
		return;
	};

	var str = OCX_ElecSealPrint.regString(file, t, l, b, r);
	showResult("防伪码识别", "识别出来为：" + str.data);
}

//事件onPrintError
function onPrintError(errorcode){
	alert(OCX_ElecSealPrint.getErrorMessage(errorcode));
}

//事件onPrintFinish
function onPrintFinish(){
	alert("打印完成");
}

function displayImg(fileInput){
	var file = fileInput.value;
	if (!file) {
		window.document.getElementById("seal").src = "../img/nophoto.jpg";
	} else {
		window.document.getElementById("seal").src = file;
	}
}
