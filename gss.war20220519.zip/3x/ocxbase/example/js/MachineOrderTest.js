/**
 * 创建于:2014-9-26<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 印控机测试脚本
 * 
 * @author 黄有坚
 * @version 1.0
 */

var testTimes = 0;
//INI配置文件
var iniPath = top.yzjgssRootPath + "/yzjgss/config/3x/gss.ini";
var imgPath= top.yzjgssRootPath +"/yzjgss/resources/3x/img";

//====用时=====
var dateStart=null;//开始时间
var dateEnd=null;//结束时间
var timeLast=null;//持续时间
//是否一体化用印
var isIntegrateSealUse=false;

/**
 * 初始化设备
 */
function initMachine() {
	showResult("初始化设备",_initMachine().msg);
}

/**
 * 打开纸板
 */
function openPaperDoor() {
	showResult("打开纸板：",_openPaperDoor(checkPaperDoor).msg);
}

function checkPaperDoor(checkresult) {
	showResult("监测纸板", getOCXMsg(checkresult.code));
	if(isIntegrateSealUse){
		openCamera();
	}
}

function queryBackDoor(){
	showResult("查询侧门状态：",getOCXMsg(OCX_MachineOrder.queryBackDoor().code));
}

function openBackDoor(){
	showResult("打开侧门：",getOCXMsg(OCX_MachineOrder.openBackDoor().code));
}

/**
 * 开始用印
 */
function startSeal() {
	var angle = window.document.getElementById("angle").value;
	var xPos = window.document.getElementById("xPos").value;
	var yPos = window.document.getElementById("yPos").value;
	var sealNum = window.document.getElementById("sealNum").value;
	showResult("开始用印", _startSeal(false,angle, xPos,yPos, sealNum, waitSeal).msg);
}

function waitSeal(status) {
	showResult("监测用印" , getOCXMsg(status.code));
	if(isIntegrateSealUse){
		capture();
	}
}

/**
 * 关闭设备
 */
function closeMachine() {
	_closeMachine();
	showResult("关闭设备","设备已关闭");
}

function MachineTest(){
	showResult("压力测试","功能未完善，敬请期待！");
}
//一体化打印
function integrateSealUse(){
	isIntegrateSealUse=true;
	openPaperDoor();
}

function openCamera(){
	showResult("打开摄像头", "");
	_openCamera(startSeal);
}

/**
 * 关闭摄像头
 */
function closeCamera() {
	OCX_XUSBVideo.close();
    showResult("关闭摄像头", "成功");
}

/**
 * 拍照
 */
function capture() {
	var path = imgPath;
	var name = (new Date()).format("yyyyMMddhhmmssS");
	var filename = path + "\\" + name + ".jpg";
	var src_filename = path + "\\" + name + "_src.jpg";
	if (_captureImage(filename, src_filename, 1).code == "1001") {
//		try {
//			window.open("file:///" + filename, "_blank", "", "");
//		} catch (e) {
//		}

		isIntegrateSealUse=false;
		showResult("拍照成功", filename);
	} else{
		isIntegrateSealUse=false;
		showResult("拍照失败", "");
	}
}


/** ************************************基本场景应用****************************************** */

var interval_paperdoor;

var interval_getsealstatus;

var interval_sidedooropen;

var interval_sidedoorclose;


/**
 * 初始化设备
 * 
 * @returns 0 成功，其他 失败, 见方法machineOrder.getReturnCodeMsg
 */
function _initMachine() {
	// 定义控件,需根据控件的定义修改
	var initResult=null, i;

	var commType = OCX_Tools.readIni(iniPath, "gss", "commType", "0").data;
	OCX_MachineOrder.setCommType(commType);
	if (OCX_MachineOrder.openCom().data != "1"){
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._initMachine}--印控机初始化设备[initMachine][OpenCom][失败]openCom().data:"+OCX_MachineOrder.openCom().data);
		return OCXResult(OCX_MachineOrder, "9211", "");
	};
	if(OCX_MachineOrder.queryPaperDoor().data != "2"){
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._initMachine}--印控机初始化设备[initMachine][QueryPaperDoor][失败]OCX_MachineOrder.queryPaperDoor().data:"+OCX_MachineOrder.queryPaperDoor().data);
		OCX_MachineOrder.closeCom();
		return OCXResult(OCX_MachineOrder, "9223", "");
	};
	for (i = 0; i < 3; i++) {
		initResult = OCX_MachineOrder.getCalParam().data;
		if (initResult == "1")
			break;
	};
	if (initResult != "1") {
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._initMachine}--印控机初始化设备[initMachine][GetCalParam][失败]OCX_MachineOrder.getCalParam().data:"+initResult);
		OCX_MachineOrder.closeCom();
		return OCXResult(OCX_MachineOrder, "9212", "");
	};
	// initResult = machineorder.MachineLoginIn();
	// if (initResult != "1"){
	// machineorder.CloseCom();
	// return false;
	// }

	for (i = 0; i < 3; i++) {
		initResult = OCX_MachineOrder.queryMachineNumOne().data
				+ OCX_MachineOrder.queryMachineNumTwo().data;
		if (initResult != "11") {
			break;
		};
	};
	initResult = OCX_MachineOrder.queryMachineNumOne().data
				+ OCX_MachineOrder.queryMachineNumTwo().data;
	if (initResult == "11") {
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._initMachine}--印控机初始化设备[initMachine][QueryMachineNumOne&&QueryMachineNumTwo][失败]");
		OCX_MachineOrder.closeCom();
		return OCXResult(OCX_MachineOrder, "9213", "");
	};
	if (OCX_MachineOrder.openLight().data != 1){
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._initMachine}--印控机初始化设备[initMachine][OpenLight][失败]");
		OCX_MachineOrder.closeCom();
		return OCXResult(OCX_MachineOrder, "9222", "");
	};
	
	// 判断设备状态
	var machineStatus = OCX_MachineOrder.queryError();
	if("1011" != machineStatus.code){
	    OCX_MachineOrder.closeCom();
	    return machineStatus;
	}
	
	return OCXResult(OCX_MachineOrder, "1001", "");
};

/**
 * 打开纸板
 * 
 * @param callbackPaperDoorIn
 *                纸板门关闭回调函数，回调参数0 成功，其他失败，详见machineOrder.getReturnCodeMsg
 * @returns 0 成功，其他 失败, 见方法machineOrder.getReturnCodeMsg
 */
function _openPaperDoor(callbackPaperDoorIn) {
	OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._openPaperDoor}--印控机打开纸板[openPaperDoor]函数调用开始时间"+(new Date()).toTimeString());
	var initResult = OCX_MachineOrder.queryMachineNumOne().data
			+ OCX_MachineOrder.queryMachineNumTwo().data;
	if (initResult == "11") {
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._openPaperDoor}--印控机打开纸板[openPaperDoor][QueryMachineNumOne&&QueryMachineNumTwo][失败]");
		return OCXResult(OCX_MachineOrder, "9213", "");
	};
	OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._openPaperDoor}--印控机打开纸板[openPaperDoor]开始打开纸板时间："+(new Date()).toTimeString());
	dateStart=new Date();
	var isOpen = OCX_MachineOrder.openPaperDoor();
	dateEnd=new Date();
	OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._openPaperDoor}--印控机打开纸板[openPaperDoor][OpenDoordata][" + isOpen.data + "]"+(isOpen.code == "1001"?"打开成功":"打开失败")+"。结束打开纸板时间："+(new Date()).toTimeString()+"。总用时："+(dateEnd.getTime()-dateStart.getTime())/1000+"秒");
	function queryDoorStatus() {
		var status = OCX_MachineOrder.queryPaperDoor().data;
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._openPaperDoor}--印控机打开纸板[openPaperDoor][QueryPaperDoor][" + status + "]");
		if (status == "2") {// 关闭
			callbackPaperDoorIn(OCXResult(OCX_MachineOrder, "1001", ""));
		} else if (status == "1") {// 未关闭
			window.setTimeout(queryDoorStatus, 1000);
		} else {// 异常
			callbackPaperDoorIn(OCXResult(OCX_MachineOrder, "9420", ""));
		};
	};
	if (isOpen.code == "1001") {// 启动定时器监测纸板门是否关闭
		interval_paperdoor = window.setTimeout(queryDoorStatus, 1000);
		return isOpen;
	} else {
		return isOpen;
	};
};

/**
 * 开始用印
 * 
 * @param isAcrossPageSeal
 *                骑缝盖章模式 true/false
 * @param sealAngle
 *                旋转角度 1~360
 * @param xPos
 *                用印X坐标(800×600分辨率下的像素坐标，右上角为坐标原点)
 * @param yPos
 *                用印Y坐标(800×600分辨率下的像素坐标，右上角为坐标原点)
 * @param sealNum
 *                印章号 1~6
 * @param callback
 *                回调函数 0 用印完成，其他用印异常，详见方法machineOrder.getReturnCodeMsg
 */
function _startSeal(isAcrossPageSeal, sealAngle, xPos, yPos, sealNum, callback) {
	try{
		OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._startSeal}--印控机开始用印[_startSeal]函数调用开始时间"+(new Date()).toTimeString());
		var orderResult = OCX_MachineOrder.queryMachineNumOne().data
				+ OCX_MachineOrder.queryMachineNumTwo().data;
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][QueryMachineNumOne&&QueryMachineNumTwo][" + orderResult + "]");
		if (orderResult == "11") {
			OCX_MachineOrder.closeCom();
			return OCXResult(OCX_MachineOrder, "9213", "");
		};
		// 设置本次盖骑缝章,本次有效
		if(isAcrossPageSeal){
			var setAcross = OCX_MachineOrder.setAcrossPageSeal();
			OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SetAcrossPageSeal][" + setAcross.data + "]");
			if (setAcross.code != "1001"){
				OCX_MachineOrder.closeCom();
				return setAcross;
			};
		};
		
		// 设置旋转角度
		var setAngle = OCX_MachineOrder.setAngle(sealAngle);
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SetAngle][" + setAngle.code + "]");
		if (setAngle.code != "1001"){
			OCX_MachineOrder.closeCom();
			return setAngle;
		};
		// 设置印章号
		var sendSeal=null;
		for ( var i = 0; i < 3; i++) {
			sendSeal = OCX_MachineOrder.sendSealNum(sealNum).data;
			OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SendSealNum][" + sendSeal + "]");
			if (sendSeal == 1 || sendSeal == 3) {
				break;
			};
		};
		if (sendSeal != 1 && sendSeal != 3){
			OCX_MachineOrder.closeCom();
			return OCXResult(OCX_MachineOrder, "9217", "");
		};
		
		// 根据像素坐标计算盖章坐标
		var calMachPos = OCX_MachineOrder.calMachinePos(xPos, yPos).data;
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][calMachinePos][" + calMachPos + "]");
		if(calMachPos != null && calMachPos != ""){
			var points = calMachPos.split(",");
			if(points.length == 2){
				xPos  = points[0];
				yPos = points[1];
				OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._startSeal}--根据像素坐标转换为盖章X坐标(0.1毫米)："+xPos);
				OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._startSeal}--根据像素坐标转换为盖章Y坐标(0.1毫米)："+yPos);
			}else{
				OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][calMachinePos][返回非正常格式]");
				OCX_MachineOrder.closeCom();
				return OCXResult(OCX_MachineOrder, "9224", "");
			};
		}else{
			OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][calMachinePos][返回空值]");
			OCX_MachineOrder.closeCom();
			return OCXResult(OCX_MachineOrder, "9224", "");
		};
		var reStr;
		reStr = OCX_MachineOrder.sendX(xPos);
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SendX]["+reStr+"]");
		if (reStr.code != "1001"){
			OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SendX][失败]");
			OCX_MachineOrder.closeCom();
			return reStr;
		};
		reStr = OCX_MachineOrder.sendY(yPos);
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SendY]["+reStr+"]");
		if (reStr.code != "1001"){
			OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SendY][失败]");
			OCX_MachineOrder.closeCom();
			return reStr;
		};
		OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal]开始用印。时间"+(new Date()).toTimeString());
		dateStart=new Date();
		reStr = OCX_MachineOrder.sealStart();
		dateEnd=new Date();
		OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SealStart]["+reStr.code+"]结束用印时间："+(new Date()).toTimeString()+"。总用时："+(dateEnd.getTime()-dateStart.getTime())/1000+"秒");
		if (reStr.code != "1001"){
			OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._startSeal}--开始用印[startSeal][SealStart][失败]");
			OCX_MachineOrder.closeCom();
			return reStr;
		};
		
		function querySealStatus() {
			var status = OCX_MachineOrder.sealQuery().data;
			OCX_Logger.error(LOGGER._3X,"{MachineOrderTest.querySealStatus}--开始用印[startSeal][SealQuery]["+status+"]");
			if (status == "0") {// 用印完成
				callback(OCXResult(OCX_MachineOrder, "1001", ""));
			} else if (status == "2" || status == "1") {// 用印中
				window.setTimeout(querySealStatus, 500);
			} else if (status == "4") {// 用印异常
				OCX_MachineOrder.closeCom();
				callback(OCXResult(OCX_MachineOrder, "9421", ""));
			} else if(status == "3"){
				OCX_MachineOrder.closeCom();
		    	callback(OCXResult(OCX_MachineOrder, "9000", ""));
			}else {// 异常
				OCX_MachineOrder.closeCom();
				callback(OCXResult(OCX_MachineOrder, "9421", ""));
			};
		};
		
		interval_paperdoor = window.setTimeout(querySealStatus, 500);
		return OCXResult(OCX_MachineOrder, "1001", "");
	}catch(e){
		OCX_Logger.info(LOGGER._3X,"{MachineOrderTest.querySealStatus}--机控用印异常："+e.message);
		OCX_Logger.error(LOGGER._3X,"{MachineOrderTest.querySealStatus}--开始用印[startSeal][catch][JS异常:"+e.message+"]");
		window.clearInterval(interval_paperdoor);
		OCX_MachineOrder.closeCom();
		return OCXResult(OCX_MachineOrder, "9422", "");
	};
};


/**
 * 关闭设备
 * 
 * @returns 无
 */
function _closeMachine() {
	OCX_Logger.error(LOGGER._3X,"{MachineOrderTest._closeMachine}--关闭设备[closeMachine][关闭设备]");
	OCX_MachineOrder.closeLight();
	OCX_MachineOrder.closeCom();
	isIntegrateSealUse=false;
};


//TODO
/**
* 打开摄像头
* 
* @returns obj(code,data,msg) obj.code:"1001",成功; "9204":"未读到摄像头配置信息或配置为空",
*          "9205":"摄像头序号配置错误", "9206":"绑定摄像头失败", "9207":"打开摄像头失败",
*          "9208":"打开摄像头异常", "9209":"摄像头分辨率配置错误", "9210":"摄像头连接异常",
*          obj.data:控件原始返回值; obj.msg:提示信息;
*/
function _openCamera(callbackCameraOpen) {
	try {
		OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._openCamera}--印控机打开摄像头[_openCamera]函数调用开始时间"+(new Date()).toTimeString());
		var cameraNum = OCX_XUSBVideo.getDevicesCount().data;
		var cameraIndex = OCX_Tools.readIni(iniPath, "gss", "cameraIndex", "").data;
		var infoNum = OCX_XUSBVideo.getVideoInfoCount(cameraIndex).data;
		var infoIndex = OCX_Tools.readIni(iniPath, "gss", "cameraInfoIndex", "").data;
		OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._openCamera}--摄像头个数：" + cameraNum);
		OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._openCamera}--摄像头分辨率最大ID：" + infoNum);
		OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._openCamera}--gss.ini中摄像头配置的序号：" + cameraIndex);
		OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._openCamera}--gss.ini中摄像头配置的分辨率序号：" + infoIndex);
		if (cameraNum == null || cameraNum == undefined || cameraNum == ""
				|| infoNum == null || infoNum == undefined || infoNum == "") {// 未读到摄像头参数
			return OCXResult(OCX_XUSBVideo, "9210", "");
		};
		if (cameraIndex == null || cameraIndex == undefined
				|| cameraIndex == "" || infoIndex == null
				|| infoIndex == undefined || infoIndex == "") {// 未读到配置信息或配置为空
			return OCXResult(OCX_XUSBVideo, "9204", "");
		};
		if (cameraNum - 1 < parseInt(cameraIndex)) { // 配置的摄像头ID大于最大ID
			return OCXResult(OCX_XUSBVideo, "9205", "");
		};

		if (infoNum - 1 < parseInt(infoIndex)) { // 配置的像素ID大于最大ID
			return OCXResult(OCX_XUSBVideo, "9209", "");
		};

		OCX_XUSBVideo.close(); // 先关闭
		OCX_XUSBVideo.setRectShowMode(1); // 设置剪裁框
		var rBind = OCX_XUSBVideo.bindDevice(cameraIndex, infoIndex).data;

		// cameraIndex和infoIndex参数无误并且已连接设备返回false的话，很可能是摄像头未在电脑上注册
		if (!rBind) { // 绑定设备id和分辨率id
			return OCXResult(OCX_XUSBVideo, "9206", "");
		};

		OCX_XUSBVideo.setRectShowMode(5);
		OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._openCamera}--印控机打开摄像头[_openCamera]开始打开摄像头。时间"+(new Date()).toTimeString());
		dateStart=new Date();
		if (!OCX_XUSBVideo.open().data) {
			dateEnd=new Date();
			OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._openCamera}--印控机打开摄像头[_openCamera]打开摄像头失败。结束打开摄像头时间："+(new Date()).toTimeString()+"。总用时："+(dateEnd.getTime()-dateStart.getTime())/1000+"秒");
			return OCXResult(OCX_XUSBVideo, "9207", "");
		};
		dateEnd=new Date();
		OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._openCamera}--印控机打开摄像头[_openCamera]打开摄像头成功。结束打开摄像头时间："+(new Date()).toTimeString()+"。总用时："+(dateEnd.getTime()-dateStart.getTime())/1000+"秒");
		
		 callbackCameraOpen();
		 return OCXResult(OCX_XUSBVideo, "1001", "");
	} catch (e) {
		return OCXResult(OCX_XUSBVideo, "9208", "");
	};
};

//TODO
/**
* 拍照
* 
* @param filePath
*            照片保存路径
* @param srcImagePath
*            原图保存路径
* @param isCut
*            是否剪裁 0 否， 1 是
* @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
*          obj.data:控件原始返回值; obj.msg:提示信息;
*/
function _captureImage(filePath, srcImagePath, isCut) {
	OCX_XUSBVideo.setDeskew(isCut);
	OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._captureImage}--印控机剪裁图片[_captureImage]开始裁剪图片。时间"+(new Date()).toTimeString());
	dateStart=new Date();
	var capResult=OCX_XUSBVideo.captureImage(filePath, srcImagePath);
	dateEnd=new Date();
	OCX_Logger.info(LOGGER._3X,"{MachineOrderTest._captureImage}--印控机剪裁图片[_captureImage]结束裁剪图片。结束时间："+(new Date()).toTimeString()+"。总用时："+(dateEnd.getTime()-dateStart.getTime())/1000+"秒");
	
	return capResult;
};


