/**
 *
 * 创建于:2014-9-26<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 版面识别控件测试脚本
 * @author 黄有坚
 * @version 1.0.0
 */

/**
 * 设置模板
 */
function setTemplate() {
	var template = document.getElementById("model").value;
	if (template == "") {
		showResult("设置模板", "请先选择模板后再设置");
		return;
	}
	if (OCX_DocRecog.setTemplate(template).code == "1001")
		showResult("设置模板", "设置成功");
	else
		showResult("设置模板", "设置失败");
}

/**
 * 版面识别
 */
function docRecog() {
	var doc = document.getElementById("doc").value;
	if (doc == "") {
		showResult("版面识别", "请先选择要识别的图片");
		return;
	}
	var result = OCX_DocRecog.docRecognize(doc);
	if (result.code != "1001") {
		showResult("版面识别", "识别失败");
	} else {
		showResult("版面识别", "识别成功，确信值为[" + result.data + "]");
	}
}

/**
 * 获取文档编号
 */
function getDocNo() {
	showResult("取文档编号", "识别出来的文档编号为[" + OCX_DocRecog.getDocNO().data + "]");
}

/**
 * 获取文档名称
 */
function getDocName() {
	showResult("取文档名称", "识别出来的文档名称为[" + OCX_DocRecog.getDocName().data + "]");
}