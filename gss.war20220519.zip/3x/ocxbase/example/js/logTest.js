/**
 * 创建于:2015-01-13<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 日志控件测试脚本
 *
 * @author 刘鋆
 * @version 1.0
 */


function logOnce() {
	var logLevel = window.document.getElementById("logLevel").value;
	var appender = window.document.getElementById("appender").value;
	var message = window.document.getElementById("message").value;
	logText(logLevel, appender, message, 1);
}

function logNTimes() {
	var logLevel = window.document.getElementById("logLevel").value;
	var appender = window.document.getElementById("appender").value;
	var message = window.document.getElementById("message").value;
	var times = window.document.getElementById('times').value;
	var times_n = parseInt(times);
	if (isNaN(times_n) || times_n <= 0) {
		showResult("记录多次", "测试次数无效");
		return;
	}
	logText(logLevel, appender, message, times_n);
}

function logText(logLevel, appender, message, times) {
	if (typeof(appender) == "undefined" || appender == "") {
		showResult("日志记录", "appender不能为空");
		return;
	}
	if (isNaN(times) || times <= 0) {
		showResult("日志记录", "测试次数无效");
		return;
	}
	try {
		switch (logLevel) {
			case "trace":
				for (var i = 0; i < times; i++)
					
					var asd = OCX_Logger.trace(LOGGER._3X,"{logTest.logText}--[" + i + "]:" + message);
					
				break;
			case "debug":
				for (var i = 0; i < times; i++)
					OCX_Logger.debug(LOGGER._3X,"{logTest.logText}--[" + i + "]:" + message);
				break;
			case "info":
				for (var i = 0; i < times; i++)
					var asd = OCX_Logger.info(LOGGER._3X,"{logTest.logText}--[" + i + "]:" + message);				
				break;
			case "warn":
				for (var i = 0; i < times; i++)
					OCX_Logger.warn(LOGGER._3X,"{logTest.logText}--[" + i + "]:" + message);
				break;
			case "error":
				for (var i = 0; i < times; i++)
					OCX_Logger.error(LOGGER._3X,"{logTest.logText}--[" + i + "]:" + message);
				break;
			case "fatal":
				for (var i = 0; i < times; i++)
					OCX_Logger.fatal(LOGGER._3X,"{logTest.logText}--fatal[" + i + "]:" + message);
				break;
		}
		showResult("日志记录", "记录" + logLevel + "日志完毕，记录[" + times + "]次");
	} catch (e) {
		showResult("日志记录", "记录发生异常");
	}
}

