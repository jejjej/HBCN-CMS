/**
 * 创建于:2015-2-10<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 电子印章生成测试脚本
 * 
 * @author 刘鋆
 * @version 1.0
 */


function setProperty() {
	var property = window.document.getElementById("property").value;
	if (property) {
		OCX_SealGenerator.setSealProperty(property);
		showResult("设置属性", "成功");
	} else {
		showResult("设置属性", "属性不能为空");
	};
};

function generatSeal() {
	var path = window.document.getElementById("path").value;
	if (path) {
		var ret = OCX_SealGenerator.saveSealImage(path);
		// TODO　返回值无效
		//if (ret == 0) {
			showResult("保存印章", "成功");
		//} else {
		//	showResult("保存印章", "失败");
		//};
	} else {
		showResult("保存印章", "路径不能为空");
	};
};


function setScaling() {
	var value = window.document.getElementById("scale").value;
	var scale = parseInt(value);
	if (!isNaN(scale) && scale >= 10 && scale <= 200) {
		OCX_SealGenerator.setScaling(scale);
		showResult("设置缩放", "成功，缩放值为"+scale);
	} else {
		showResult("设置缩放", "失败，缩放值无效，有效值为10到200");
	};
};

