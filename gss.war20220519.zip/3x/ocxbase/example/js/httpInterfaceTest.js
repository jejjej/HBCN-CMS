/**
 * 创建于:2015-01-13<br>
 * 版权所有(C) 2015 深圳市银之杰科技股份有限公司<br>
 * 文件上传控件测试脚本
 *
 * @author 刘鋆
 * @version 1.0
 */

/**
 * 文件上传
 */
function upload() {
	//var url = "http://192.168.3.3:8080/gssdemo/elecseal/storeAction_addObject.action";
	var url = window.document.getElementById("urlPath").value;
	var filepath = window.document.getElementById("filePath").value;
	if (typeof(url) == "undefined" || url == "" /*|| !IsURL(url)*/ ) {
		showResult("文件上传", "无效的服务器地址");
		return;
	}
	if (typeof(filepath) == "undefined" || filepath == "") {
		showResult("文件上传", "未选择上传文件");
		return;
	}

	var resultJson = httpInterface.uploadFile(url, filepath, "");
	showResult("文件上传", "完毕，回应数据为  ："+resultJson);
}

