/**
 * 创建于:2015-06-17<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 阻塞队列<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var blockQueue = new Object();

/**
 * 任务队列
 */
blockQueue.queue_list = {};

/**
 * 当前任务id
 */
blockQueue.curr_task_index = 1;

/**
 * 下一任务id
 */
blockQueue.next_task_index = 1;

/**
 * 队列长度
 */
blockQueue.queue_size = 0;

/**
 * 追加一个任务到队列尾部<br>
 * 任务执行按先进先执行的顺序
 * 
 * @param callback
 *                任务函数
 */
blockQueue.addTask = function(/* function */callback) {
    this.queue_size++;

    this.queue_list[this.queue_size] = {
	callback : callback
    };
};

/**
 * 当前任务已结束<br>
 * <b>任务结束时内部逻辑中必须调用此函数</b>
 */
blockQueue.thisTaskCompleted = function() {
    this.curr_task_index = this.next_task_index;
};

/**
 * 运行队列中的任务
 */
blockQueue.run = function() {
    // 判断队列中是否有任务
    if (!blockQueue.hasTask()) {
	return;
    }

    // 任务全部结束
    if (blockQueue.allTaskFinish()) {
	blockQueue.resetTask();
	return;
    }

    // 开始下一任务
    if (blockQueue.readyStartNewTask()) {
	blockQueue.setNextTask();

	blockQueue.queue_list[blockQueue.curr_task_index].callback.call();
    }

    setTimeout("blockQueue.run()", 500);
}

/**
 * 设置下一任务
 */
blockQueue.setNextTask = function() {
    if (this.next_task_index <= this.queue_size) {
	this.next_task_index++;
    }
};

/**
 * 判断是否开始执行下一任务
 * 
 * @returns true/false
 */
blockQueue.readyStartNewTask = function() {
    return (this.curr_task_index == this.next_task_index) ? true : false;
};

/**
 * 判断全部任务是否已经结束
 * 
 * @return ture/false
 */
blockQueue.allTaskFinish = function() {
    return (this.curr_task_index > this.queue_size) ? true : false;
};

/**
 * 判断队列中是否有任务
 */
blockQueue.hasTask = function() {
    return (this.queue_size > 0) ? true : false;
};

/**
 * 重置任务
 */
blockQueue.resetTask = function() {
    this.curr_task_index = 1;
    this.next_task_index = 1;
};

/**
 * 清除队列
 */
blockQueue.clearQueue = function() {
    this.queue_list = {};
    this.queue_size = 0;
    this.curr_task_index = 1;
    this.next_task_index = 1;
};
