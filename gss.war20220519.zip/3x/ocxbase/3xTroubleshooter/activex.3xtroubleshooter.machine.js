/**
 * 创建于:2015-06-17<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * G3400印控机操作js封装<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var machine = new Object();

/**
 * 盖章像素坐标，800×600分辨率，坐标原点为左上角<br>
 * 单位：px
 */
machine.use_seal_pixel_pos = [ 400, 300 ];

//INI配置文件
machine.iniPath = top.yzjgssRootPath + "/yzjgss/config/3x/gss.ini";

/**
 * 盖章像素坐标(400*300)对应的毫米坐标范围<br>
 * [[xMin,xMax],[yMin,yMax]]单位：0.1毫米
 */
machine.use_seal_mm_pos = [ [ 700, 1800 ], [ 900, 2000 ] ];

/**
 * 印控机信息<br>
 * machine_info.driver_version<br>
 * machine_info.machine_num<br>
 * machine_info.test_use_seal_num<br>
 * machine_info.slot_pos_1<br>
 * machine_info.slot_pos_2<br>
 * machine_info.slot_pos_3<br>
 * machine_info.slot_pos_4<br>
 * machine_info.slot_pos_5<br>
 * machine_info.slot_pos_6<br>
 */
machine.machine_info = null;

/**
 * 设备校验结果
 */
machine.machine_is_qualified = true;

/**
 * 构造函数
 * 
 * {messageHandler.generateMsgObj} 返回信息
 */
machine.init = function() {
    // 重置缓存
    this.resetProps();

    // 初始化设备
    var initResult = this.initMachine();
    if (!initResult.success) {
	return initResult;
    }

    // 读取设备信息
    this.setMachineInfo();

    return messageHandler.generateMsgObj(true, "设备初始化成功", null, messageHandler.type_log);
};

/**
 * 获取印控机信息
 * 
 * @returns {machine.machine_info} 印控机信息
 */
machine.getMachineInfo = function() {
    return this.machine_info;
};

/**
 * 测试印控机<br>
 * 依赖于xusbVideo.js，执行此方法前必须先打开摄像头
 * 
 * @param callBack(boolean)
 *                测试结束回调函数
 * @returns {messageHandler.generateMsgObj} 返回信息
 */
machine.testMachine = function(/* function */callBack) {
    // 检验单片机版本
    var versionResult = this.checkDriverVersion();
    if (!versionResult.success) {
	this.machine_is_qualified = false;
    }

    // 测试印控机校准情况
    var checkPosResult = this.checkChangeUseSealPos();
    if (!checkPosResult.success) {
	this.machine_is_qualified = false;
    }

    // 打开纸板
    var openResult = _openPaperDoor(openPaperDoorCallBack);
    if (openResult.code == "1001") {
	return messageHandler.generateMsgObj(true, "请放入小于A4纸尺寸的凭证后关闭纸板...", null, messageHandler.type_tip);
    } else {
	this.machine_is_qualified = false;
	return messageHandler.generateMsgObj(false, null, getOCXMsg(openResult.code), messageHandler.type_fail);
    }

    // 纸板关闭回调函数
    function openPaperDoorCallBack(result) {
	// 等待挡板和灯光稳定
	setTimeout(function() {
	    if ("1001" == result.code) {
		// 拍照
		xusbVideo.captureImage(function(success) {
		    if (success) {
			var getPosResult = xusbVideo.getCenterPositionInOriginal();
			if (getPosResult.success) {
			    // 用印像素坐标
			    var x = getPosResult.data.x;
			    var y = getPosResult.data.y;

			    // 用印
			    var startResult = machine.useSeal(x, y, function(useResult) {
				if (useResult) {
				    messageHandler.generateMsgObj(true, "用折叠凭证的方式找出凭证的中心，请确认章是否盖在凭证中心...", null,
					    messageHandler.type_tip);
				    messageHandler
					    .generateMsgObj(true, "盖章不准时请确认以下几点：", null, messageHandler.type_info);
				    messageHandler.generateMsgObj(true, "1. 单片机驱动版本是否符合要求", null,
					    messageHandler.type_info);
				    messageHandler.generateMsgObj(true, "2. 校准分辨率是否为2048*1536", null,
					    messageHandler.type_info);
				    messageHandler.generateMsgObj(true, "3. 凭证是否裁剪成功（拍照属性Proc Amp一般为默认值，曝光值按实际情况调整）",
					    null, messageHandler.type_info);
				    messageHandler.generateMsgObj(true,
					    "&nbsp;&nbsp;&nbsp;&nbsp;凭证图片路径"+top.yzjgssRootPath+"\\yzjgss\\resources\\3x\\img\\", null,
					    messageHandler.type_info);
				}
				callBack(useResult && machine.machine_is_qualified);
			    });
			    if (!startResult.success) {
				this.machine_is_qualified = false;
				callBack(this.machine_is_qualified);
			    }
			    return;
			}
		    }

		    this.machine_is_qualified = false;
		    callBack(this.machine_is_qualified);
		});
	    } else {
		this.machine_is_qualified = false;
		messageHandler.generateMsgObj(false, null, getOCXMsg(result.code),
			messageHandler.type_fail);
		callBack(this.machine_is_qualified);
	    }
	}, 1500);
    }
};

/**
 * 初始化设备
 * 
 * @returns {messageHandler.generateMsgObj} 返回信息
 */
machine.initMachine = function() {
    var initResult = _initMachine();
    if (initResult.code != "1001") {
	return messageHandler.generateMsgObj(false, null, getOCXMsg(initResult.code),
		messageHandler.type_fail);
    }

    return messageHandler.generateMsgObj(true, "设备初始化成功！", null, messageHandler.type_log);
};

/**
 * 设置印控机信息
 */
machine.setMachineInfo = function() {
    var machineInfo = new Object();

    // 读取单片机软件版本
    var dVersion = OCX_MachineOrder.queryChipSoftVersion().data;
    if ("0" == dVersion) {
	machineInfo.driver_version = "未设置";
    } else if ("1" == dVersion) {
	machineInfo.driver_version = "查询单片机软件版本异常";
    } else {
	machineInfo.driver_version = dVersion;
    }

    // 读取机器序列号
    try {
	var machineNum = getMachineNum().data;
	machineInfo.machine_num = machineNum;
    } catch (e) {
	var err = getOCXMsg(e.message.code);
	machineInfo.machine_num = err;
    }

    // 读取印章安装情况
    machineInfo.test_use_seal_num = null;
    machineInfo.slot_pos_1 = "未安装";
    machineInfo.slot_pos_2 = "未安装";
    machineInfo.slot_pos_3 = "未安装";
    machineInfo.slot_pos_4 = "未安装";
    machineInfo.slot_pos_5 = "未安装";
    machineInfo.slot_pos_6 = "未安装";
    var sealInfo = OCX_MachineOrder.getSealInfo();
    if ("1001" == sealInfo.code) {
	var installInfo = sealInfo.data.split(",");
	for ( var i = 0; i < installInfo.length; i++) {
	    var sealNum = installInfo[i].split(":");
	    if (sealNum.length == 2) {
		machineInfo.test_use_seal_num = sealNum[1];
		if (sealNum[0] == 1) {
		    machineInfo.slot_pos_1 = sealNum[1];
		} else if (sealNum[0] == 2) {
		    machineInfo.slot_pos_2 = sealNum[1];
		} else if (sealNum[0] == 3) {
		    machineInfo.slot_pos_3 = sealNum[1];
		} else if (sealNum[0] == 4) {
		    machineInfo.slot_pos_4 = sealNum[1];
		} else if (sealNum[0] == 5) {
		    machineInfo.slot_pos_5 = sealNum[1];
		} else if (sealNum[0] == 6) {
		    machineInfo.slot_pos_6 = sealNum[1];
		}
	    }
	}
    }

    this.machine_info = machineInfo;
};

/**
 * 用印
 * 
 * @param x
 *                2048*1536分辨率下像素坐标x
 * @param y
 *                2048*1536分辨率下像素坐标y
 * @param callBack(boolean)
 *                用印结束回调函数
 * @returns {messageHandler.generateMsgObj} 返回信息
 */
machine.useSeal = function(/* pixel */x, /* pixel */y, /* function */callBack) {
    // 检测印控机内是否有印章
    if (this.machine_info.test_use_seal_num == null) {
	return messageHandler.generateMsgObj(false, null, "无可用的印章", messageHandler.type_fail);
    }

    // 转换像素坐标
    x = 800 - x / 2.56;
    y = y / 2.56;

    // 开始用印
    var startResult = _startSeal(false, 0, Math.round(x), Math.round(y),
	    this.machine_info.test_use_seal_num, useSealCallBack);
    //alert("startResult.code:"+startResult.code)
    if (startResult.code == "1001") {
	return messageHandler.generateMsgObj(true, "", null, messageHandler.type_log);
    } else {
	var errMsg = getOCXMsg(startResult.code);
	return messageHandler.generateMsgObj(false, null, errMsg, messageHandler.type_fail);
    }
    // 用印结束回调函数
    function useSealCallBack(status) {
	if ("1001" == status.code) {
	    messageHandler.generateMsgObj(true, "用印成功。", null, messageHandler.type_pass);
	    callBack(true);
	} else {
	    messageHandler.generateMsgObj(false, null, "用印异常。", messageHandler.type_fail);
	    callBack(false);
	}

	// 打开纸板
	OCX_MachineOrder.openPaperDoor(function() {
	});
    }
};

/**
 * 打开电子锁
 * 
 * @returns {messageHandler.generateMsgObj} 返回信息
 */
machine.openElecLock = function() {
    var openResult = OCX_MachineOrder.openBackDoor();
    if ("1001" != openResult.code) {
	return messageHandler.generateMsgObj(false, null, getOCXMsg(openResult.code),
		messageHandler.type_fail);
    }

    return messageHandler.generateMsgObj(true, "电子锁已经打开。", null, messageHandler.type_pass);
};

/**
 * 测试像素转换为毫米盖章坐标是否在规定范围内<br>
 * 
 * @returns {messageHandler.generateMsgObj} 返回信息
 */
machine.checkChangeUseSealPos = function() {
    var calMachPos = OCX_MachineOrder.calMachinePos(800 - this.use_seal_pixel_pos[0], this.use_seal_pixel_pos[1]).data;
    if (calMachPos != null && calMachPos != "") {
	var points = calMachPos.split(",");
	if (2 == points.length) {
	    if (this.use_seal_mm_pos[0][0] <= points[0] && points[0] <= this.use_seal_mm_pos[0][1]
		    && this.use_seal_mm_pos[1][0] <= points[1] && points[1] <= this.use_seal_mm_pos[1][1]) {
		return messageHandler.generateMsgObj(true, "印控机已校准！", null, messageHandler.type_pass);
	    } else {
		return messageHandler.generateMsgObj(false, null, "印控机未校准或者校准的分辨率不是2048×1536！\r\n" + "用印坐标为["
			+ points[0] + "*" + points[1] + "]，单位（0.1毫米）", messageHandler.type_fail);
	    }
	}
    }

    return messageHandler.generateMsgObj(false, null, "控件根据像素坐标计算盖章坐标失败！", messageHandler.type_fail);
};

/**
 * 检验单片机驱动版本<br>
 * 如果在gss.ini中配置的driverVersion有相应版本号，检测时按配置的为准<br>
 * 如果未配置版本号则不校验单片机版本号
 * 
 * @returns {messageHandler.generateMsgObj} 返回信息
 */
machine.checkDriverVersion = function() {
    var driverVersion = OCX_Tools.readIni(machine.iniPath, "gss", "driverVersion", "").data;
    if (null != driverVersion && undefined != driverVersion && "" != driverVersion) {
	if (this.machine_info.driver_version == driverVersion) {
	    return messageHandler.generateMsgObj(true, "单片机驱动版本符合[" + driverVersion + "]", null,
		    messageHandler.type_pass);
	} else {
	    return messageHandler.generateMsgObj(false, null, "单片机驱动版本不符合[" + driverVersion + "]",
		    messageHandler.type_fail);
	}
    } else {
	// 未配置版本号时不检测此项
	return messageHandler.generateMsgObj(true, "gss.ini中未配置固定单片机版本", null, messageHandler.type_log);
    }
};

/**
 * 关闭印控机
 */
machine.closeMachine = function() {
    try {
    	_closeMachine();
    } catch (e) {
    }
};

/**
 * 重置变量
 */
machine.resetProps = function() {
    this.machine_info = null;
    this.machine_is_qualified = true;
};



var interval_paperdoor;

var interval_getsealstatus;

var interval_sidedooropen;

var interval_sidedoorclose;


/**
 * 初始化设备
 * 
 * @returns 0 成功，其他 失败, 见方法machineOrder.getReturnCodeMsg
 */
function _initMachine() {
	// 定义控件,需根据控件的定义修改
	var initResult, i;

	var commType = OCX_Tools.readIni(machine.iniPath, "gss", "commType", "0").data;
	OCX_MachineOrder.setCommType(commType);
	if (OCX_MachineOrder.openCom().data != "1"){
		OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._initMachine}--印控机初始化设备[initMachine][OpenCom][失败]openCom().data:"+OCX_MachineOrder.openCom().data);
		return OCXResult(OCX_MachineOrder, "9211", "");
	};
	if(OCX_MachineOrder.queryPaperDoor().data != "2"){
		OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._initMachine}--印控机初始化设备[initMachine][QueryPaperDoor][失败]OCX_MachineOrder.queryPaperDoor().data:"+OCX_MachineOrder.queryPaperDoor().data);
		OCX_MachineOrder.closeCom();
		return OCXResult(OCX_MachineOrder, "9223", "");
	};
	for (i = 0; i < 3; i++) {
		initResult = OCX_MachineOrder.getCalParam().data;
		if (initResult == "1")
			break;
	};
	if (initResult != "1") {
		OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._initMachine}--印控机初始化设备[initMachine][GetCalParam][失败]OCX_MachineOrder.getCalParam().data:"+initResult);
		OCX_MachineOrder.closeCom();
		return OCXResult(OCX_MachineOrder, "9212", "");
	};
	// initResult = machineorder.MachineLoginIn();
	// if (initResult != "1"){
	// machineorder.CloseCom();
	// return false;
	// }

	for (i = 0; i < 3; i++) {
		initResult = OCX_MachineOrder.queryMachineNumOne().data
				+ OCX_MachineOrder.queryMachineNumTwo().data;
		if (initResult != "11") {
			break;
		};
	};
	initResult = OCX_MachineOrder.queryMachineNumOne().data
				+ OCX_MachineOrder.queryMachineNumTwo().data;
	if (initResult == "11") {
		OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._initMachine}--印控机初始化设备[initMachine][QueryMachineNumOne&&QueryMachineNumTwo][失败]");
		OCX_MachineOrder.closeCom();
		return OCXResult(OCX_MachineOrder, "9213", "");
	};
	if (OCX_MachineOrder.openLight().data != 1){
		OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._initMachine}--印控机初始化设备[initMachine][OpenLight][失败]");
		OCX_MachineOrder.closeCom();
		return OCXResult(OCX_MachineOrder, "9222", "");
	};
	
	// 判断设备状态
	var machineStatus = OCX_MachineOrder.queryError();
	if("1011" != machineStatus.code){
	    OCX_MachineOrder.closeCom();
	    return machineStatus;
	}
	
	return OCXResult(OCX_MachineOrder, "1001", "");
};

/**
 * 打开纸板
 * 
 * @param callbackPaperDoorIn
 *                纸板门关闭回调函数，回调参数0 成功，其他失败，详见machineOrder.getReturnCodeMsg
 * @returns 0 成功，其他 失败, 见方法machineOrder.getReturnCodeMsg
 */
function _openPaperDoor(callbackPaperDoorIn) {
	var initResult = OCX_MachineOrder.queryMachineNumOne().data
			+ OCX_MachineOrder.queryMachineNumTwo().data;
	if (initResult == "11") {
		OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._openPaperDoor}--印控机打开纸板[openPaperDoor][QueryMachineNumOne&&QueryMachineNumTwo][失败]");
		return OCXResult(OCX_MachineOrder, "9213", "");
	};
	var isOpen = OCX_MachineOrder.openPaperDoor();
	OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._openPaperDoor}--印控机打开纸板[openPaperDoor][OpenPaperDoor][" + isOpen.data + "]");
	function queryDoorStatus() {
		var status = OCX_MachineOrder.queryPaperDoor().data;
		OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._openPaperDoor}--印控机打开纸板[openPaperDoor][QueryPaperDoor][" + status + "]");
		if (status == "2") {// 关闭
			callbackPaperDoorIn(OCXResult(OCX_MachineOrder, "1001", ""));
		} else if (status == "1") {// 未关闭
			window.setTimeout(queryDoorStatus, 1000);
		} else {// 异常
			callbackPaperDoorIn(OCXResult(OCX_MachineOrder, "9420", ""));
		};
	};
	if (isOpen.code == "1001") {// 启动定时器监测纸板门是否关闭
		interval_paperdoor = window.setTimeout(queryDoorStatus, 1000);
		return isOpen;
	} else {
		return isOpen;
	};
};

/**
 * 查询机器号
 * 
 * @returns 8位字符串，机器生产序列号
 * @throws 1003，错误；1016，未设置值。
 */
function getMachineNum() {
	var machineNum;
	var machineOrderVer = OCX_Tools.readIni(machine.iniPath, "gss", "machineOrderVer", "2").data;
	if (machineOrderVer == "1"){
		// 老版控件
		machineNum = OCX_MachineOrder.queryMachineNumTwo().data;
	}else{
		// 新版控件
		machineNum = OCX_MachineOrder.queryMachineSN().data;
	}
	OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine.getMachineNum}--查询机器号[getMachineNum][QueryMachineNumTwo][" + machineNum + "]");
	if (machineNum == "1" || machineNum == "-1") {
		throw new Error(OCXResult(OCX_MachineOrder, "9221", ""));
	} else if (machineNum == "0" || machineNum == "-2") {
		throw new Error(OCXResult(OCX_MachineOrder, "9221", ""));
	} else {
		return OCXResult(OCX_MachineOrder, "1001", machineNum);
	};
};

/**
 * 开始用印
 * 
 * @param isAcrossPageSeal
 *                骑缝盖章模式 true/false
 * @param sealAngle
 *                旋转角度 1~360
 * @param xPos
 *                用印X坐标(800×600分辨率下的像素坐标，右上角为坐标原点)
 * @param yPos
 *                用印Y坐标(800×600分辨率下的像素坐标，右上角为坐标原点)
 * @param sealNum
 *                印章号 1~6
 * @param callback
 *                回调函数 0 用印完成，其他用印异常，详见方法machineOrder.getReturnCodeMsg
 */
function _startSeal(isAcrossPageSeal, sealAngle, xPos, yPos, sealNum, callback) {
	try{
		var orderResult = OCX_MachineOrder.queryMachineNumOne().data
				+ OCX_MachineOrder.queryMachineNumTwo().data;
		OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._startSeal}--开始用印[startSeal][QueryMachineNumOne&&QueryMachineNumTwo][" + orderResult + "]");
		if (orderResult == "11") {
			OCX_MachineOrder.closeCom();
			return OCXResult(OCX_MachineOrder, "9213", "");
		};
		// 设置本次盖骑缝章,本次有效
		if(isAcrossPageSeal){
			var setAcross = OCX_MachineOrder.setAcrossPageSeal();
			OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._startSeal}--开始用印[startSeal][SetAcrossPageSeal][" + setAcross.data + "]");
			if (setAcross.code != "1001"){
				OCX_MachineOrder.closeCom();
				return setAcross;
			};
		};
		
		// 设置旋转角度
		var setAngle = OCX_MachineOrder.setAngle(sealAngle);
		OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._startSeal}--开始用印[startSeal][SetAngle][" + setAngle.code + "]");
		if (setAngle.code != "1001"){
			OCX_MachineOrder.closeCom();
			return setAngle;
		};
		// 设置印章号
		var sendSeal;
		for ( var i = 0; i < 3; i++) {
			sendSeal = OCX_MachineOrder.sendSealNum(sealNum).data;
			OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._startSeal}--开始用印[startSeal][SendSealNum][" + sendSeal + "]");
			if (sendSeal == 1 || sendSeal == 3) {
				break;
			};
		};
		if (sendSeal != 1 && sendSeal != 3){
			OCX_MachineOrder.closeCom();
			return OCXResult(OCX_MachineOrder, "9217", "");
		};
		
		// 根据像素坐标计算盖章坐标
		var calMachPos = OCX_MachineOrder.calMachinePos(xPos, yPos).data;
		OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._startSeal}--开始用印[startSeal][calMachinePos][" + calMachPos + "]");
		if(calMachPos != null && calMachPos != ""){
			var points = calMachPos.split(",");
			if(points.length == 2){
				xPos  = points[0];
				yPos = points[1];
				OCX_Logger.info(LOGGER._3X,"{activex.3xtroubleshooter.machine._startSeal}--根据像素坐标转换为盖章X坐标(0.1毫米)："+xPos);
				OCX_Logger.info(LOGGER._3X,"{activex.3xtroubleshooter.machine._startSeal}--根据像素坐标转换为盖章Y坐标(0.1毫米)："+yPos);
			}else{
				OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._startSeal}--开始用印[startSeal][calMachinePos][返回非正常格式]");
				OCX_MachineOrder.closeCom();
				return OCXResult(OCX_MachineOrder, "9224", "");
			};
		}else{
			OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._startSeal}--开始用印[startSeal][calMachinePos][返回空值]");
			OCX_MachineOrder.closeCom();
			return OCXResult(OCX_MachineOrder, "9224", "");
		};
		var reStr;
		reStr = OCX_MachineOrder.sendX(xPos);
		OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._startSeal}--开始用印[startSeal][SendX]["+reStr+"]");
		if (reStr.code != "1001"){
			OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._startSeal}--开始用印[startSeal][SendX][失败]");
			OCX_MachineOrder.closeCom();
			return reStr;
		};
		reStr = OCX_MachineOrder.sendY(yPos);
		OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._startSeal}--开始用印[startSeal][SendY]["+reStr+"]");
		if (reStr.code != "1001"){
			OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._startSeal}--开始用印[startSeal][SendY][失败]");
			OCX_MachineOrder.closeCom();
			return reStr;
		};
		reStr = OCX_MachineOrder.sealStart();
		OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._startSeal}--开始用印[startSeal][SealStart]["+reStr.code+"]");
		if (reStr.code != "1001"){
			OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._startSeal}--开始用印[startSeal][SealStart][失败]");
			OCX_MachineOrder.closeCom();
			return reStr;
		};
		
		function querySealStatus() {
			var status = OCX_MachineOrder.sealQuery().data;
			OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine.querySealStatus}--开始用印[startSeal][SealQuery]["+status+"]");
			if (status == "0") {// 用印完成
				callback(OCXResult(OCX_MachineOrder, "1001", ""));
			} else if (status == "2" || status == "1") {// 用印中
				window.setTimeout(querySealStatus, 500);
			} else if (status == "4") {// 用印异常
				OCX_MachineOrder.closeCom();
				callback(OCXResult(OCX_MachineOrder, "9421", ""));
			} else if(status == "3"){
				OCX_MachineOrder.closeCom();
		    	callback(OCXResult(OCX_MachineOrder, "9000", ""));
			}else {// 异常
				OCX_MachineOrder.closeCom();
				callback(OCXResult(OCX_MachineOrder, "9421", ""));
			};
		};
		
		interval_paperdoor = window.setTimeout(querySealStatus, 500);
		return OCXResult(OCX_MachineOrder, "1001", "");
	}catch(e){
		OCX_Logger.info(LOGGER._3X,"{activex.3xtroubleshooter.machine.querySealStatus}--机控用印异常："+e.message);
		OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine.querySealStatus}--开始用印[startSeal][catch][JS异常:"+e.message+"]");
		window.clearInterval(interval_paperdoor);
		OCX_MachineOrder.closeCom();
		return OCXResult(OCX_MachineOrder, "9422", "");
	};
};

/**
 * 关闭设备
 * 
 * @returns 无
 */
function _closeMachine() {
	OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.machine._closeMachine}--关闭设备[closeMachine][关闭设备]");
	OCX_MachineOrder.closeLight();
	OCX_MachineOrder.closeCom();
};
