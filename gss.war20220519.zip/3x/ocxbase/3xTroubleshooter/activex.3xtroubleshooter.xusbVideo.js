/**
 * 创建于:2015-06-17<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * XUSBVideo操作js封装<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var xusbVideo = new Object();

// 摄像头标识
xusbVideo.current_camera = null;
xusbVideo.main_camera = "main";
xusbVideo.vice_camera = "vice";
xusbVideo.environment_camera = "environment";
//INI配置文件
xusbVideo.iniPath = top.yzjgssRootPath + "/yzjgss/config/3x/gss.ini";

xusbVideo.camera_map = {
    "main" : "主摄像头",
    "vice" : "副摄像头",
    "environment" : "环境摄像头"
};

/**
 * 摄像头序号
 */
xusbVideo.camera_index = null;

/**
 * 分辨率序号
 */
xusbVideo.distinguishability_index = null;

/**
 * 标准分辨率
 */
xusbVideo.standard_distinguishability = {
    "main" : [ 2048, 1536 ],
    "vice" : [ 1024, 768 ],
    "environment" : [ 800, 600 ]
};

/**
 * 当前摄像头分辨率<br>
 * 
 * curr_camera_info.cameraId<br>
 * curr_camera_info.cameraName<br>
 * curr_camera_info.distinguishabilityCount<br>
 * curr_camera_info.cameraIndex<br>
 * curr_camera_info.distinguishabilityIndex<br>
 * curr_camera_info.distinguishabilityWidth<br>
 * curr_camera_info.distinguishabilityHeight<br>
 */
xusbVideo.curr_camera_info = null;

/**
 * 拍照路径
 */
xusbVideo.image_path = top.yzjgssRootPath + "\\yzjgss\\resources\\3x\\img\\";

/**
 * 摄像头打开后处于就绪状态，即是可拍照状态
 */
xusbVideo.curr_camera_ready = false;

/**
 * 等待打开摄像头次数
 */
xusbVideo.wait_open_camera_count = 0;

/**
 * 裁剪后的图片
 */
xusbVideo.cut_image_path = null;

/**
 * 裁剪前的图片
 */
xusbVideo.src_image_path = null;

/**
 * 构造函数
 * 
 * @param currentCamera
 *                摄像头标识 main/vice/environment
 * @returns {messageHandler.generateMsgObj} 返回信息
 */
xusbVideo.init = function(/* String */currentCamera) {
    // 关闭摄像头
    this.closeCamera();

    // 重置变量默认值
    this.resetProps();

    // 校验传入的参数是否合法
    if (this.main_camera != currentCamera && this.vice_camera != currentCamera && environment_camera != currentCamera) {
	return messageHandler.generateMsgObj(false, null, "摄像头标识参数传入错误", messageHandler.type_fail);
    }
    this.current_camera = currentCamera;

    // 读取摄像头配置
    var readResult = this.readCameraConfig();
    if (!readResult.success) {
	return readResult;
    }

    // 读取摄像头信息
    var setResult = this.setCameraInfo();
    if (!setResult.success) {
	return setResult;
    }

    return messageHandler.generateMsgObj(true, "摄像头初始化成功", null, messageHandler.type_log);
};

/**
 * 获取摄像头信息
 * 
 * @returns {xusbVideo.curr_camera_info} 摄像头信息
 */
xusbVideo.getCameraInfo = function() {
    return this.curr_camera_info;
};

/**
 * 测试摄像头拍照情况
 * 
 * @param callBack(boolean)
 *                测试结束回调函数
 * @returns {messageHandler.generateMsgObj} 返回信息
 */
xusbVideo.testCamera = function(/* function */callBack) {
    // 校验分辨率
    var distResult = this.checkCameraDistinguishability();
    if (!distResult.success) {
	return distResult;
    }

    // 打开摄像头
    var openResult = this.openCamera();
    if (!openResult.success) {
	return openResult;
    }

    // 拍照
    this.captureImage(callBack);

    return messageHandler.generateMsgObj(true, "", null, messageHandler.type_log);
};

/**
 * 读取摄像头配置
 * 
 * @returns {messageHandler.generateMsgObj} 返回信息
 */
xusbVideo.readCameraConfig = function() {
    // 识别摄像头序号以及分辨率序号标识
    var cameraIndex, cameraInfoIndex;
    if (this.current_camera == this.main_camera) {
	cameraIndex = "cameraIndex";
	cameraInfoIndex = "cameraInfoIndex";
    } else if (this.current_camera == this.vice_camera) {
	return messageHandler.generateMsgObj(false, null, "尚不支持校验副摄像头", messageHandler.type_fail);
    } else if (this.current_camera == this.environment_camera) {
	return messageHandler.generateMsgObj(false, null, "尚不支持校验环境摄像头", messageHandler.type_fail);
    }

    // 读取摄像头配置
    this.camera_index = OCX_Tools.readIni(xusbVideo.iniPath, "gss", cameraIndex, "").data;
    if (this.camera_index == "") {
	return messageHandler.generateMsgObj(false, null, "本地gss.ini文件中未配置摄像头序号", messageHandler.type_fail);
    }

    this.distinguishability_index = OCX_Tools.readIni(xusbVideo.iniPath, "gss", cameraInfoIndex, "").data;
    if (this.distinguishability_index == "") {
	return messageHandler.generateMsgObj(false, null, "本地gss.ini文件中未配置摄像头分辨率序号", messageHandler.type_fail);
    }

    return messageHandler.generateMsgObj(true, "读取摄像头本地gss.ini配置成功", null, messageHandler.type_info);
};

/**
 * 设置摄像头信息
 * 
 * @returns {messageHandler.generateMsgObj} 返回信息
 */
xusbVideo.setCameraInfo = function() {
    var cameraInfo = new Object();
    cameraInfo.cameraIndex = this.camera_index;
    cameraInfo.distinguishabilityIndex = this.distinguishability_index;
    var getResult = getVideoWidthAndHeight(cameraInfo.cameraIndex, cameraInfo.distinguishabilityIndex);
    if (getResult.code == "1001") {
	cameraInfo.distinguishabilityWidth = getResult.data.width;
	cameraInfo.distinguishabilityHeight = getResult.data.height;
    } else {
	return messageHandler.generateMsgObj(false, null, getOCXMsg(getResult.code), messageHandler.type_fail);
    }

    cameraInfo.cameraId = OCX_XUSBVideo.getDevicesID(cameraInfo.cameraIndex).data;
    cameraInfo.cameraName = OCX_XUSBVideo.getDevicesName(cameraInfo.cameraIndex).data;
    cameraInfo.distinguishabilityCount = OCX_XUSBVideo.getVideoInfoCount(cameraInfo.cameraIndex).data;
    this.curr_camera_info = cameraInfo;

    return messageHandler.generateMsgObj(true, "获取摄像头信息成功", null, messageHandler.type_log);
};

/**
 * 校验摄像头分辨率
 * 
 * @returns {messageHandler.generateMsgObj} 返回信息
 */
xusbVideo.checkCameraDistinguishability = function() {
    var standard = this.standard_distinguishability[this.current_camera];
    var cameraName = this.camera_map[this.current_camera];
    var currWidth = this.curr_camera_info.distinguishabilityWidth;
    var currHeight = this.curr_camera_info.distinguishabilityHeight;
    if (standard[0] == currWidth && standard[1] == currHeight) {
	return messageHandler.generateMsgObj(true, cameraName + "符合" + "[" + standard[0] + "*" + standard[1] + "]的分辨率",
		null, messageHandler.type_pass);
    } else {
	return messageHandler.generateMsgObj(false, null, cameraName + "不符合" + "[" + standard[0] + "*" + standard[1]
		+ "]的分辨率：" + currWidth + "*" + currHeight, messageHandler.type_fail);
    }
};

/**
 * 打开摄像头
 * 
 * @returns {messageHandler.generateMsgObj} 返回信息
 */
xusbVideo.openCamera = function() {
    if (this.current_camera == this.main_camera) {
	var openResult = _openCamera();
	if (openResult.code != "1001") {
	    var errorMessgae = getOCXMsg(openResult.code);
	    return messageHandler.generateMsgObj(false, null, errorMessgae, messageHandler.type_fail);
	}
    } else if (this.current_camera == this.vice_camera) {
	return messageHandler.generateMsgObj(false, null, "尚不支持校验副摄像头", messageHandler.type_fail);
    } else if (this.current_camera == this.environment_camera) {
	return messageHandler.generateMsgObj(false, null, "尚不支持校验环境摄像头", messageHandler.type_fail);
    }

    return messageHandler.generateMsgObj(true, this.camera_map[this.current_camera] + "打开成功", null,
	    messageHandler.type_pass);
};

/**
 * 摄像头就绪回调事件<br>
 * 方法名一致时自动回调
 */
function deviceReady() {
    setTimeout(function() {
	xusbVideo.curr_camera_ready = true;
    }, 2000);
};

/**
 * 拍照
 * 
 * @param callBack(boolean)
 *                拍照结束回调函数
 */
xusbVideo.captureImage = function(/* function */callBack) {
    if (this.curr_camera_ready) {
	var name = this.current_camera + (new Date()).Format("yyyyMMddhhmmssS");
	this.cut_image_path = this.image_path + "\\" + name + ".jpg";
	this.src_image_path = this.image_path + "\\" + name + "_src.jpg";
	var captureResult = _captureImage(this.cut_image_path, this.src_image_path, 1);
	if (captureResult.code == "1001") {
	    messageHandler.generateMsgObj(true, "拍照成功。", null, messageHandler.type_pass);
	    callBack(true);
	} else {
	    messageHandler.generateMsgObj(false, null, "拍照失败。", messageHandler.type_fail);
	    callBack(false);
	}
    } else {
	this.wait_open_camera_count++;
	if (this.wait_open_camera_count > 40) {
	    var standard = this.standard_distinguishability[this.current_camera];
	    var currWidth = this.curr_camera_info.distinguishabilityWidth;
	    var currHeight = this.curr_camera_info.distinguishabilityHeight;
	    messageHandler.generateMsgObj(false, null, "打开" + "[" + standard[0] + "*" + standard[1] + "]分辨率的摄像头失败！",
		    messageHandler.type_fail);
	    callBack(false);
	    return;
	}

	setTimeout("xusbVideo.captureImage(" + callBack + ")", 200);
    }
};

/**
 * 获取凭证的中心像素坐标在原图中的坐标<br>
 * 必须是可裁剪的小凭证
 * 
 * @returns {messageHandler.generateMsgObj} 返回信息
 */
xusbVideo.getCenterPositionInOriginal = function() {
    var imageSize = OCX_ImgHelper.getImageSize(this.cut_image_path).data;
    if (imageSize != null && imageSize != "") {
	var size = imageSize.split("*");
	if (size.length == 2) {
	    var x = size[0] / 2;
	    var y = size[1] / 2;
	    OCX_Logger.info(LOGGER._3X,"{activex.3xtroubleshooter.xusbVideo.getCenterPositionInOriginal}--凭证长[" + size[0] + "]  宽[" + size[1] + "]");
	    OCX_Logger.info(LOGGER._3X,"{activex.3xtroubleshooter.xusbVideo.getCenterPositionInOriginal}--凭证中心坐标[" + x + "," + y + "]");
	    var posInOriginal = OCX_XUSBVideo.getPositionInOriginal(x, y).data;
	    if (posInOriginal != null && posInOriginal != "") {
		var points = posInOriginal.split(",");
		if (points.length == 2) {
		    var pos = new Object();
		    pos.x = points[0];
		    pos.y = points[1];
		    OCX_Logger.info(LOGGER._3X,"{activex.3xtroubleshooter.xusbVideo.getCenterPositionInOriginal}--凭证中心在原图上的坐标[" + points[0] + "," + points[1] + "]");
		    return messageHandler.generateMsgObj(true, pos, null, messageHandler.type_log);
		} else {
		    return messageHandler.generateMsgObj(false, null, "拍照控件获取原图坐标失败", messageHandler.type_fail);
		}
	    } else {
		return messageHandler.generateMsgObj(false, null, "拍照控件未能获取原图坐标", messageHandler.type_fail);
	    }
	} else {
	    return messageHandler.generateMsgObj(false, null, "图片控件获取图像宽高失败:" + size, messageHandler.type_fail);
	}
    } else {
	return messageHandler.generateMsgObj(false, null, "图片控件未获取到图像宽高", messageHandler.type_fail);
    }
};

/**
 * 关闭摄像头
 * 
 * @returns {messageHandler.generateMsgObj} 返回信息
 */
xusbVideo.closeCamera = function() {
    try {
    	OCX_XUSBVideo.close();
    } catch (e) {
    }
};

/**
 * 重置变量
 */
xusbVideo.resetProps = function() {
    this.xusbVideo = null;
    this.camera_index = null;
    this.distinguishability_index = null;
    this.curr_camera_info = null;
    this.curr_camera_ready = false;
    this.wait_open_camera_count = 0;
    this.cut_image_path = null;
    this.src_image_path = null;
};


/** ************************************基本场景应用****************************************** */
//TODO
/**
* 获取指定摄像头/分辨率序号的分辨率
* 
* @param cameraIndex
*            摄像头序号
* @param infoIndex
*            分辨率序号
* @returns obj(code,data,msg)
*          obj.code:"1001",成功,返回分辨率对象;"9201",设备未连接任何摄像头;"9202",摄像头序号超出范围;"9203",分辨率序号超出范围;
*          obj.data:控件原始返回值; obj.msg:提示信息;
*/
function getVideoWidthAndHeight(cameraIndex, infoIndex) {
	var deviceCount = OCX_XUSBVideo.getDevicesCount().data;
	var videoInfoCount = OCX_XUSBVideo.getVideoInfoCount(cameraIndex).data;
	if (0 >= deviceCount || 0 >= videoInfoCount) {
		return OCXResult(OCX_XUSBVideo, "9201", "");
	}
	if (0 > cameraIndex || deviceCount - 1 < cameraIndex) {
		return OCXResult(OCX_XUSBVideo, "9202", "");
	}
	if (0 > infoIndex || videoInfoCount < infoIndex) {
		return OCXResult(OCX_XUSBVideo, "9203", "");
	}

	var videoInfo = new Object();
	videoInfo.width = OCX_XUSBVideo.getVideoInfoWidth(cameraIndex, infoIndex).data;
	videoInfo.height = OCX_XUSBVideo.getVideoInfoHeight(cameraIndex, infoIndex).data;
	return OCXResult(OCX_XUSBVideo, "1001", videoInfo);
}
//TODO
/**
* 打开摄像头
* 
* @returns obj(code,data,msg) obj.code:"1001",成功; "9204":"未读到摄像头配置信息或配置为空",
*          "9205":"摄像头序号配置错误", "9206":"绑定摄像头失败", "9207":"打开摄像头失败",
*          "9208":"打开摄像头异常", "9209":"摄像头分辨率配置错误", "9210":"摄像头连接异常",
*          obj.data:控件原始返回值; obj.msg:提示信息;
*/
function _openCamera() {
	try {
		var cameraNum = OCX_XUSBVideo.getDevicesCount().data;
		var cameraIndex = OCX_Tools.readIni(xusbVideo.iniPath, "gss", "cameraIndex", "").data;
		var infoNum = OCX_XUSBVideo.getVideoInfoCount(cameraIndex).data;
		var infoIndex = OCX_Tools.readIni(xusbVideo.iniPath, "gss", "cameraInfoIndex", "").data;
		OCX_Logger.info(LOGGER._3X,"{activex.3xtroubleshooter.xusbVideo._openCamera}--摄像头个数：" + cameraNum);
		OCX_Logger.info(LOGGER._3X,"{activex.3xtroubleshooter.xusbVideo._openCamera}--摄像头分辨率最大ID：" + infoNum);
		OCX_Logger.info(LOGGER._3X,"{activex.3xtroubleshooter.xusbVideo._openCamera}--gss.ini中摄像头配置的序号：" + cameraIndex);
		OCX_Logger.info(LOGGER._3X,"{activex.3xtroubleshooter.xusbVideo._openCamera}--gss.ini中摄像头配置的分辨率序号：" + infoIndex);

		if (cameraNum == null || cameraNum == undefined || cameraNum == ""
				|| infoNum == null || infoNum == undefined || infoNum == "") {// 未读到摄像头参数
			return OCXResult(OCX_XUSBVideo, "9210", "");
		};
		if (cameraIndex == null || cameraIndex == undefined
				|| cameraIndex == "" || infoIndex == null
				|| infoIndex == undefined || infoIndex == "") {// 未读到配置信息或配置为空
			return OCXResult(OCX_XUSBVideo, "9204", "");
		};
		if (cameraNum - 1 < parseInt(cameraIndex)) { // 配置的摄像头ID大于最大ID
			return OCXResult(OCX_XUSBVideo, "9205", "");
		};

		if (infoNum - 1 < parseInt(infoIndex)) { // 配置的像素ID大于最大ID
			return OCXResult(OCX_XUSBVideo, "9209", "");
		};

		OCX_XUSBVideo.close(); // 先关闭
		OCX_XUSBVideo.setRectShowMode(1); // 设置剪裁框
		var rBind = OCX_XUSBVideo.bindDevice(cameraIndex, infoIndex).data;

		// cameraIndex和infoIndex参数无误并且已连接设备返回false的话，很可能是摄像头未在电脑上注册
		if (!rBind) { // 绑定设备id和分辨率id
			return OCXResult(OCX_XUSBVideo, "9206", "");
		};

		OCX_XUSBVideo.setRectShowMode(5);

		if (!OCX_XUSBVideo.open().data) {
			return OCXResult(OCX_XUSBVideo, "9207", "");
		};
		return OCXResult(OCX_XUSBVideo, "1001", "");

	} catch (e) {
		return OCXResult(OCX_XUSBVideo, "9208", "");
	};
};



//TODO
/**
* 拍照
* 
* @param filePath
*            照片保存路径
* @param srcImagePath
*            原图保存路径
* @param isCut
*            是否剪裁 0 否， 1 是
* @returns obj(code,data,msg) obj.code:"1001",成功;"9200",失败;"9300",调用控件方法异常;
*          obj.data:控件原始返回值; obj.msg:提示信息;
*/
function _captureImage(filePath, srcImagePath, isCut) {
	OCX_XUSBVideo.setDeskew(isCut);
	return OCX_XUSBVideo.captureImage(filePath, srcImagePath);
};

