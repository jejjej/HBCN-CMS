/**
 * 创建于:2015-06-17<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * G3400印控机体检结果展示JS<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

var messageHandler = new Object();

// 显示校验结果信息ID
messageHandler.check_result_div_id = null;

// 信息类型
messageHandler.type_title = "title";
messageHandler.type_pass = "pass";
messageHandler.type_fail = "fail";
messageHandler.type_info = "info";
messageHandler.type_tip = "tip";
messageHandler.type_log = "log";

/**
 * 构造函数
 * 
 * @param checkResultDivId
 *                校验结果信息展示ID
 */
messageHandler.init = function(/* String */checkResultDivId) {
    this.check_result_div_id = checkResultDivId;
    document.getElementById(this.check_result_div_id).innerHTML = "";
};

/**
 * 组装返回信息<br>
 * 
 * @param success
 *                正常/异常
 * @param data
 *                正常时的数据
 * @param errorMessage
 *                异常时的数据
 * @param msgType
 *                信息类型
 */
messageHandler.generateMsgObj = function(/* boolean */success, /* Object */data, /* String */errorMessage, /* String */msgType) {
    try {
	// 处理异常信息
	if (success) {
	    this.addExaminationResult(msgType, data);
	    OCX_Logger.info(LOGGER._3X,"{activex.3xtroubleshooter.messageHandler.generateMsgObj}--"+data);
	} else {
	    this.addExaminationResult(msgType, errorMessage);
	    OCX_Logger.error(LOGGER._3X,"{activex.3xtroubleshooter.messageHandler.generateMsgObj}--"+errorMessage);
	}
    } catch (e) {
	// alert("记录日志信息异常："+e.message);
    }

    // 组装返回信息
    var obj = {};
    obj.success = success;
    obj.errorMessage = errorMessage;
    obj.data = data;
    obj.msgType = msgType;
    return obj;
};

/**
 * 展示校验结果信息
 * 
 * @param msgType
 *                信息类型
 * @param msg
 *                信息
 */
messageHandler.addExaminationResult = function(/* String */msgType, /* String */msg) {
    var div = document.createElement("div");
    div.className = "line";
    if (msgType == this.type_title) {
	div.innerHTML = "<br/><b>" + msg + "</b>";
    } else if (msgType == this.type_pass) {
	div.innerHTML = "<span class='green'>" + msg + "</span>";
    } else if (msgType == this.type_fail) {
	div.innerHTML = "<span class='red'>" + msg + "</span>";
    } else if (msgType == this.type_info) {
	div.innerHTML = msg;
    } else if (msgType == this.type_tip) {
	div.innerHTML = "<span class='tip'>" + msg + "</span>";
    } else {
	// 不显示
    }
    document.getElementById(this.check_result_div_id).appendChild(div);
};

/**
 * 展示检验中效果
 * 
 * @param divId
 *                效果展示的位置
 */
messageHandler.showItemCheckingEffect = function(/* String */divId) {
    document.getElementById(divId).innerHTML = "<font style='font-size:12px;color:red;'>检测中...</font>";
};

/**
 * 展示检验项通过效果
 * 
 * @param divId
 *                效果展示的位置
 */
messageHandler.showItemPassEffect = function(/* String */divId) {
    document.getElementById(divId).innerHTML = "[√]";
};

/**
 * 展示检验项不通过效果
 * 
 * @param divId
 *                效果展示的位置
 */
messageHandler.showItemFailEffect = function(/* String */divId) {
    document.getElementById(divId).innerHTML = "[×]";
    document.getElementById(divId).style.color = "red";
};
