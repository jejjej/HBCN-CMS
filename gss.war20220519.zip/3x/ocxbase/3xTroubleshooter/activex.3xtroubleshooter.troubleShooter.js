/**
 * 创建于:2015-06-17<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * G3400印控机体检JS<br>
 * 
 * @author RickyChen
 * @version 1.0.0
 */

/**
 * 初始化
 */
function initTroubleShooter() {
    // 初始化控件
    var ocxView = window.document.getElementById("ocxView");
    if (!ocxObject.initOcx(ocxObject.OCX_XUSBVideo, ocxView, '../../../activex/api/', 'run', 50, 50)) {
	alert("初始化拍照控件失败");
	return;
    }
    if (!ocxObject.initOcx(ocxObject.OCX_CommonTool, ocxView, '../../../activex/api/', 'run', 50, 50)) {
	alert("初始化日志控件失败");
	return;
    }
    if (!ocxObject.initOcx(ocxObject.OCX_MachineOrder, ocxView, '../../../activex/api/', 'run', 50, 50)) {
	alert("初始化印控机控件失败");
	return;
    }
    if (!ocxObject.initOcx(ocxObject.OCX_ImgHelper, ocxView, '../../../activex/api/', 'run', 50, 50)) {
	alert("初始化图片处理控件失败");
	return;
    }

    // 初始化消息处理器
    messageHandler.init("checkResult");

    // 初始化队列任务
    initTask();
};

/**
 * 初始化任务执行的逻辑顺序<br>
 */
function initTask() {
    // 锁住校验按钮
    blockQueue.addTask(lockCheckButton);
    
    // 添加主摄像头校验任务
    blockQueue.addTask(checkMainCamera);
    
    // 添加印控机校验任务
    blockQueue.addTask(checkMachine);
    
    // 添加电子锁校验任务
    blockQueue.addTask(openElecLock);
    
    // 释放校验按钮
    blockQueue.addTask(releaseCheckButton);
};

/**
 * 开始校验
 */
function startCheckTask() {
    blockQueue.run();
};

/**
 * 锁定开始校验按钮
 */
function lockCheckButton() {
    document.getElementById("checkBtn").disabled = "disabled";
    blockQueue.thisTaskCompleted();
};

/**
 * 校验主摄像头
 */
function checkMainCamera() {
    messageHandler.showItemCheckingEffect("xusbVideoResult");
    messageHandler.generateMsgObj(true, "检测主摄像头：", null, messageHandler.type_title);

    var initMainCameraResult = xusbVideo.init(xusbVideo.main_camera);
    if (initMainCameraResult.success) {
	var m = xusbVideo.getCameraInfo();
	messageHandler.generateMsgObj(true, "主摄像头信息：", null, messageHandler.type_info);
	messageHandler.generateMsgObj(true, "主摄像头ini中配置的序号：" + m.cameraIndex, null, messageHandler.type_info);
	messageHandler.generateMsgObj(true, "主摄像头ini中配置的分辨率序号：" + m.distinguishabilityIndex, null, messageHandler.type_info);
	messageHandler.generateMsgObj(true, "主摄像头ID：" + m.cameraId, null, messageHandler.type_info);
	messageHandler.generateMsgObj(true, "主摄像头名称：" + m.cameraName, null, messageHandler.type_info);
	messageHandler.generateMsgObj(true, "主摄像头分辨率数量：" + m.distinguishabilityCount, null, messageHandler.type_info);
	messageHandler.generateMsgObj(true, "主摄像头宽：" + m.distinguishabilityWidth, null, messageHandler.type_info);
	messageHandler.generateMsgObj(true, "主摄像头高：" + m.distinguishabilityHeight, null, messageHandler.type_info);
	var startResult = xusbVideo.testCamera(function(success) {
	    if (success) {
		messageHandler.showItemPassEffect("xusbVideoResult");
	    } else {
		messageHandler.showItemFailEffect("xusbVideoResult");
	    }

	    blockQueue.thisTaskCompleted();
	});
	if (!startResult.success) {
	    messageHandler.showItemFailEffect("xusbVideoResult");
	    blockQueue.thisTaskCompleted();
	}
    } else {
	messageHandler.showItemFailEffect("xusbVideoResult");
	blockQueue.thisTaskCompleted();
    }
}

/**
 * 校验印控机
 */
function checkMachine() {
    messageHandler.showItemCheckingEffect("machineResult");
    messageHandler.generateMsgObj(messageHandler.type_title, "检测印控机：", null, messageHandler.type_title);

    var initMachineResult = machine.init();
    if (initMachineResult.success) {
	var m = machine.getMachineInfo();
	messageHandler.generateMsgObj(true, "印控机信息:", null, messageHandler.type_info);
	messageHandler.generateMsgObj(true, "印控机编号：" + m.machine_num, null, messageHandler.type_info);
	messageHandler.generateMsgObj(true, "单片机驱动版本：" + m.driver_version, null, messageHandler.type_info);
	messageHandler.generateMsgObj(true, "印控机1号槽位：" + m.slot_pos_1 + "号章", null, messageHandler.type_info);
	messageHandler.generateMsgObj(true, "印控机2号槽位：" + m.slot_pos_2 + "号章", null, messageHandler.type_info);
	messageHandler.generateMsgObj(true, "印控机3号槽位：" + m.slot_pos_3 + "号章", null, messageHandler.type_info);
	messageHandler.generateMsgObj(true, "印控机4号槽位：" + m.slot_pos_4 + "号章", null, messageHandler.type_info);
	messageHandler.generateMsgObj(true, "印控机5号槽位：" + m.slot_pos_5 + "号章", null, messageHandler.type_info);
	messageHandler.generateMsgObj(true, "印控机6号槽位：" + m.slot_pos_6 + "号章", null, messageHandler.type_info);
	var startResult = machine.testMachine(function(success) {
	    if (success) {
		messageHandler.showItemPassEffect("machineResult");
	    } else {
		messageHandler.showItemFailEffect("machineResult");
	    }

	    blockQueue.thisTaskCompleted();
	});
	if (!startResult.success) {
	    messageHandler.showItemFailEffect("machineResult");
	    blockQueue.thisTaskCompleted();
	}
    } else {
	messageHandler.showItemFailEffect("machineResult");
	blockQueue.thisTaskCompleted();
    }
}

/**
 * 打开电子锁
 */
function openElecLock() {
    messageHandler.generateMsgObj(true, "打开电子锁：", null, messageHandler.type_title);
    machine.openElecLock();
    blockQueue.thisTaskCompleted();
}

/**
 * 释放开始校验按钮
 */
function releaseCheckButton() {
    setTimeout(function(){
	document.getElementById("checkBtn").disabled = "";
	blockQueue.thisTaskCompleted();
    },15000);
};

/**
 * 页面关闭响应事件
 */
function closePage() {
    try {
	machine.closeMachine();
	xusbVideo.closeCamera();
    } catch (e) {
	// alert(e.message);
    }
};