/**
 * 创建于:2017-04-17<br>
 * 版权所有(C) 2016 深圳市银之杰科技股份有限公司<br>
 * 授权中心配置
 * 
 * @author listen
 * @version 1.0.0
 */
/**
 * 默认表单键值
 */
var df_FormKey="APP_SEALUSEAPP_DETAIL";
/**
 * 默认显示类型值
 */
var df_ShowType="text";
/**
 * 默认表单绑定数据类型值
 */
var df_DataBindType="";

function initFormConfigDLG() {
	initFormKey();
	$("#formConfigDLG").dialog({
		autoOpen : false,
		resizable : false,
		height : 430,
		width : 500,
		modal : true,
		buttons : {
			"确定" : function() {
					sumbitAddConfig();
			},
			"重置" : function() {
				var id=$('#idItem').val();
				openModifyDLG(id);
				//exitDLG();
			}
		},
		close : function() {
			$("#modifyConfigForm")[0].reset();
			exitDLG();
		}
	});
	
	
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() - 2;
	pageHeaderHeight = pageHeaderHeight.substr(0, pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight - pageHeaderHeight  - 50 * 2;
	$("#formConfigsTable").jqGrid(
	{
		width : pageContentWidth,
		height : tableHeight + "px",
		url : ctx + "/gss/appMgt/formConfigAction!list.action",
		multiselect : false,
		rowNum : 20,
		rownumbers : true,
		rowList : [ 20, 50, 100 ],
		colNames : [ "表单类型", "显示名称","对应业务属性", "显示类型","排序",  "ModuleId","数据是否返回","备注","操作" ],
		colModel : [
				{
					name : "formKey",
					index : "formKey",
					align : "center",
					sortable : false,
					formatter : function(value, options, rData) {
						return constants.FORMCONFIGTYPE[value];
					}
				},
				{
					name : "showName",
					index : "showName",
					align : "center",
					sortable : false
				},
				{
					name : "name",
					index : "name",
					align : "center",
					sortable : false
				},
				{
					name : "showType",
					index : "showType",
					align : "center",
					sortable : false
				},
				{
					name : "orderId",
					index : "orderId",
					align : "center",
					sortable : false,
					width:50,
					formatter : function(value, options, rData) {
						return value;
					}
				},
				{
					name : "moduleId",
					index : "moduleId",
					align : "center",
					sortable : false
				},
				{
					name : "commitFlag",
					index : "commitFlag",
					align : "center",
					sortable : false,
					width : 90,
					formatter : function(value, options, rData) {
						if(value==1){
							return "是";
						}else{
							return "否";
						}
					}
				},
				{
					name : "memo",
					index : "memo",
					align : "center",
					sortable : false
				},
				{
					name : "autoId",
					index : "autoId",
					align : "center",
					sortable : false,
					formatter : function(value, options, rData) {
						return "<input type='button'  value='修改' onclick=openModifyDLG('"
								+ value
								+ "') /><input type='button' value='删除' onclick=delFormConfig('"
								+ value + "')  />";
					}
				}  ],
		pager : "#formConfigsTablePager"
	});

};


//查询数据
function queryList() {
	$("#formConfigsTable").jqGrid("search", "#formConfigQueryForm");
};
/**
 * 初始化表单类型
 */
function initFormKey(){
	var formKeyTypes = "";
	for (var key in constants.FORMCONFIGTYPE) {
		formKeyTypes += ("<option value=\"" + key + "\">" + constants.FORMCONFIGTYPE[key] + "</option>");
	};
	$("#ser_formKey").html(formKeyTypes);
	$("#formKeyList").html(formKeyTypes);
	formKeyTypes = "<option value=' '>全部</option>" + formKeyTypes;
	$("#ser_formKey").html(formKeyTypes);
	$('#formKeyItem').val(df_FormKey);
	$("#formKeyList").val(df_FormKey);
	$("#formKeyList").change(function(){
		var formKey= $(this).val();
		$('#formKeyItem').val(formKey);
	});
};

function initShowType(){
	var showTypes="";
	for(var key in constants.FORMCONFIGSHOWTYPE){
		showTypes+=("<option value=\"" + key + "\">" + constants.FORMCONFIGSHOWTYPE[key] + "</option>");
	}
	$("#showTypeList").html(showTypes);
	$("#showTypeItem").val(df_ShowType);
	$("#showTypeList").val(df_ShowType);
	$("#showTypeList").change(function(){
		var showType= $(this).val();
		$('#showTypeItem').val(showType);
	});
};

function initDataBindType(){
	var bindTypes="";
	for(var key in constants.FORMCONFIGDATABINDTYPE){
		bindTypes+=("<option value=\"" + key + "\">" + constants.FORMCONFIGDATABINDTYPE[key] + "</option>");
	}
	bindTypes = "<option value=''>无</option>" + bindTypes;
	$("#dataBindList").html(bindTypes);
	$('#dataBindIdItem').val(df_DataBindType);
	$('#dataBindList').val(df_DataBindType);
	$("#dataBindList").change(function(){
		var dataBindType= $(this).val();
		$('#dataBindIdItem').val(dataBindType);
	});
};

function openAddDLG(){
	initShowType();
	initDataBindType();
	$("#formConfigDLG").dialog("open");
};


function sumbitAddConfig(){
	if(validForm()){
		$('#moduleIdItem').removeAttr('disabled');
		$.post(ctx + "/gss/appMgt/formConfigAction!saveFormConfig.action", $(
				"#modifyConfigForm").serializeForm(), function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$.success("保存成功");
				exitDLG();
				$("#formConfigDLG").dialog("close");
				$("#formConfigsTable").trigger("reloadGrid");
			} else {
				alert("保存失败:" + data.responseMessage.message);
			}

		});
	}
};

function validForm(){
	var result=true;
	if($('#moduleIdItem').val()==""){
		$('#moduleIdMsg').text("*ModuleId不能为空!").css("color","red");
		result = false;
	}else{
		$('#moduleIdMsg').text("");
	}
	if($('#orderIdItem').val()==""){
		$('#orderIdMsg').text("*排序不能为空!").css("color","red");
		result = false;
	}else{
		if(isNaN($('#orderIdItem').val())){
			$('#orderIdMsg').text("*排序不能为非数字!").css("color","red");
			result = false;
		}else{
			$('#orderIdMsg').text("");
		}
	}
	return result;
}

function openModifyDLG(id) {
	$.ajax({
		type : "POST",
		url : ctx + "/gss/appMgt/formConfigAction!QueryFormConfigById.action",
		data : {
		    id : id
		},
		dataType : "json",
		async : false,
		success : function(data) {
			if (data && data.responseMessage && data.responseMessage.success) {
				$('#idItem').val(data.formConfigModel.autoId);
				$('#moduleIdItem').val(data.formConfigModel.moduleId);
				$('#moduleIdItem').attr("disabled",true);
				df_FormKey=data.formConfigModel.formKey;
				$('#formKeyList').attr("disabled",true);
				$('#showNameItem').val(data.formConfigModel.showName);
				$('#nameItem').val(data.formConfigModel.name);
				df_ShowType=data.formConfigModel.showType;
				$('#orderIdItem').val(data.formConfigModel.orderId);
				$('input[name="formConfigModel.commitFlag"][value="'+data.formConfigModel.commitFlag+'"]').attr("checked",true);
				$('#regexItem').val(data.formConfigModel.regex);
				df_DataBindType=data.formConfigModel.dataBindId;
				$('#extParamsItem').val(data.formConfigModel.extParams);
				$('#memoItem').val(data.formConfigModel.memo);
				openAddDLG();
			} else {
				alert("失败:" + data.responseMessage.message);
			}
		}
	});
}

function delFormConfig(id){
	var b = confirm("确定要删除该配置吗？");
	if (b) {
	$.ajax({
	type : "POST",
	url : ctx + "/gss/appMgt/formConfigAction!delFormConfig.action",
	data : {
	    id : id
	},
	dataType : "json",
	async : false,
	success : function(data) {
	    if (data && data.responseMessage && data.responseMessage.success) {
		$("#formConfigsTable").trigger("reloadGrid");
	    } else {
		alert("删除失败:" + data.responseMessage.message);
	    }
	}
    });
	}
};

function exitDLG(){
	df_FormKey="APP_SEALUSEAPP_DETAIL";
	df_ShowType="text";
	$('#idItem').val("");
	$('#moduleIdItem').val("");
	$('#moduleIdItem').attr('disabled', 'disabled');
	$('#moduleIdItem').attr("disabled",false);
	$('#formKeyList').attr("disabled",false);
	$('#formKeyList').removeAttr('disabled');
	$('#showNameItem').val("");
	$('#nameItem').val("");
	$('#orderIdItem').val("");
	$('input[name="formConfigModel.commitFlag"][value="0"]').attr("checked",true);
	$('#regexItem').val("");
	$('#extParamsItem').val("");
	$('#memoItem').val("");
}

