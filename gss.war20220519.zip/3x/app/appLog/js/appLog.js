
function appLogInit() {
    // 默认查询一个月以内
	var nowDate = new Date();
	var now = nowDate.pattern("yyyy-MM-dd HH:mm:ss");
	var oldDate = new Date(nowDate.setMonth((new Date().getMonth()-1)));
	var old = oldDate.pattern("yyyy-MM-dd HH:mm:ss");
	$("#ge_uploadTime").val(old);
	$("#le_uploadTime").val(now);
    // 列表
    $("#appLogList").jqGrid({
    	caption : "移动端日志查询",
    	autoLoad: false,
		url : ctx + "/gss/appMgt/appLog!list.action",
		rownumbers : true,
		altRows : true,// 就是隔行用不同的背景色区分开
		colNames : [ "异常类型 ","上传日期","操作系统类型", "操作系统版本 ","设备型号", "设备编号", "app版本", "日志文件" ],
		colModel : [ {
		    name : "excpType",
		    index : "excpType",
		    align : "center",
		    width : 60,
		    sortable : true,
			formatter:function(value, options, rData){
				if(value == "01"){
					return "闪退";
				}else if(value == "02"){
					return "其它";
				}
			}
		}, {
		    name : "uploadTime",
		    index : "uploadTime",
		    align : "center",
		    width : 95,
		    sortable : true
		}, {
		    name : "osType",
		    index : "osType",
		    align : "center",
		    width : 60,
		    sortable : true
		}, {
		    name : "osVersion",
		    index : "osVersion",
		    align : "center",
		    width : 85,
		    sortable : false
		}, {
		    name : "deviceType",
		    index : "deviceType",
		    align : "center",
		    width : 100,
		    sortable : false
		}, {
		    name : "deviceNum",
		    index : "deviceNum",
		    align : "center",
		    width : 100,
		    sortable : false
		}, {
		    name : "clientVersion",
		    index : "clientVersion",
		    width : 40,
		    align : "center",
		    sortable : false
		}, {
		    name : "localLogUrl",
		    index : "localLogUrl",
		    width : 60,
		    align : "center",
		    sortable : false,
		    formatter:function(value, options, rData){
				return "<a href='"+value+"' target='view_window'>右键目标另存为</a>";
		    	//return "<input type='button' value='日志' onclick=\"window.open('"+value+"')\"/>";
			}
		} ],
		pager : "#appLogListPager"
	    }).trigger("reloadGrid");
	    $("#appLogList").navGrid("#appLogListPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
		//excel : ctx + "/gss/usesealoptlog/useSealOptLogAction!report.action"
    });
	queryAppLogForTerm();
	
	$("#clearForm").click(function() {
		$("#appLogIterm")[0].reset();
	    // 默认查询一个月以内
		var nowDate1 = new Date();
		var now = nowDate1.pattern("yyyy-MM-dd HH:mm:ss");
		var oldDate = new Date(nowDate1.setMonth((new Date().getMonth()-1)));
		var old = oldDate.pattern("yyyy-MM-dd HH:mm:ss");
		$("#ge_uploadTime").val(old);
		$("#le_uploadTime").val(now);
	});
};


function queryAppLogForTerm() {
    $("#appLogList").jqGrid("search", "#appLogIterm");
};

/**
 * 选择查询机构
 */
function choseOrgNoCondition() {
    $("#orgNoCondition").dialogOrgTree("radio", top.loginPeopleInfo.orgSid, false, null, null, function(event, treeId, treeNode) {
		if (treeNode) {
			$("#orgNoCondition").val(treeNode.organizationName+"("+treeNode.organizationNo+")");
		    $("#operatorOrgNo_search").val(treeNode.organizationNo);
		}
    });
};
