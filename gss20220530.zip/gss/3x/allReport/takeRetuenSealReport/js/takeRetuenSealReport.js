


/**
 * 初始化Grid数据
 */
$(function() {
	initOrgNo();
	initPage();
	initSealType();
	initSealSeate();
	
	$("#ge_takeSealDateTime").blur(function(){
		var ge_returnSealDateTime = $("#ge_returnSealDateTime").val();
		var le_returnSealDateTime = $("#le_returnSealDateTime").val();
		if(ge_returnSealDateTime != "" || le_returnSealDateTime != ""){
			$("#ge_takeSealDateTime").val("");
			alert("取章时间条件与还章时间条件只能二选一：现在已选择还章时间条件！");
		}
	});
	
	$("#le_takeSealDateTime").blur(function(){
		var ge_returnSealDateTime = $("#ge_returnSealDateTime").val();
		var le_returnSealDateTime = $("#le_returnSealDateTime").val();
		if(ge_returnSealDateTime != "" || le_returnSealDateTime != ""){
			$("#le_takeSealDateTime").val("");
			alert("取章时间条件与还章时间条件只能二选一：现在已选择还章时间条件！");
		}
	});
	
	$("#ge_returnSealDateTime").blur(function(){
		var ge_takeSealDateTime = $("#ge_takeSealDateTime").val();
		var le_takeSealDateTime = $("#le_takeSealDateTime").val();
		if(ge_takeSealDateTime != "" || le_takeSealDateTime != ""){
			$("#ge_returnSealDateTime").val("");
			alert("取章时间条件与还章时间条件只能二选一：现在已选择取章时间条件！");
		}
	});
	
	$("#le_returnSealDateTime").blur(function(){
		var ge_takeSealDateTime = $("#ge_takeSealDateTime").val();
		var le_takeSealDateTime = $("#le_takeSealDateTime").val();
		if(ge_takeSealDateTime != "" || le_takeSealDateTime != ""){
			$("#le_returnSealDateTime").val("");
			alert("取章时间条件与还章时间条件只能二选一：现在已选择取章时间条件！");
		}
	});
});

function initSealType(){
	var params = {
			
	};
	$.post(ctx+"/report/takeRetuenSealReportAction_findSealType.action",params,function(data){
		if(data.responseMessage.success){
			var sealTypeMap=data.sealMap;
			var sealTypeContent = "<option value=' '>全部</option>";
			for ( var key in sealTypeMap) {
				sealTypeContent += "<option value='" + key + "'>" + sealTypeMap[key] + "</option>";
			}
			$("#sealType").html(sealTypeContent);
			
		}else{
			alert(res.responseMessage.message);
		}
	});
	
}

function initSealSeate(){
	var params = {
			
	};
	$.post(ctx+"/report/takeRetuenSealReportAction_findSealState.action",params,function(data){
		if(data.responseMessage.success){
			var sealStateMap=data.sealMap;
			var sealTypeContent = "<option value=' '>全部</option>";
			for ( var key in sealStateMap) {
				sealTypeContent += "<option value='" + key + "'>" + sealStateMap[key] + "</option>";
			}
			$("#sealState").html(sealTypeContent);
			
		}else{
			alert(res.responseMessage.message);
		}
	});
}

function initOrgNo() {
	var loginPeople = top.loginPeopleInfo;
	$("#sealOrg").val(loginPeople.orgNo);
	$("#sealOrgName").val(loginPeople.orgName+"("+loginPeople.orgNo+")");
}

function initPage(){
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() -2;
		pageHeaderHeight = pageHeaderHeight.substr(0,pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight -pageHeaderHeight + 6 - 50*2 ;
	$("#logPeopleManageList").jqGrid(
		{
			width : pageContentWidth,
			height : tableHeight,
			url : ctx + "/report/takeRetuenSealReportAction_list.action",
			multiselect : false,
			postData : {
				"queryBean.params.sealOrg" : top.loginPeopleInfo.orgNo
			},
			rowNum : 20,
			rownumbers : true,
			sortname : "takeSealDateTime",
			sortorder : "desc",
			rowList : [ 20, 50, 100 ],
			colNames : ["印章所属机构", "印章类型", "印章名称","取章人", "取章时间", "取章用途", "还章时间", "备注", "实物印章状态" ],
			colModel : [
					{
						name : "sealOrgName",
						index : "sealOrgName",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "sealType",
						index : "sealType",
						align : "center",
						width : 60,
						sortable : false
					},
					{
						name : "sealName",
						index : "sealName",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "takeSealPeopleName",
						index : "takeSealPeopleName",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "takeSealDateTime",
						index : "takeSealDateTime",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "takeSealUse",
						index : "takeSealUse",
						align : "center",
						width : 60,
						sortable : false
					},
					{
						name : "returnSealDateTime",
						index : "returnSealDateTime",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "memo",
						index : "memo",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
							return value;
						}
					},
					{
						name : "sealState",
						index : "sealState",
						align : "center",
						width : 60,
						sortable : false,
						formatter : function(value, options, rData) {
//							if(value=='0'){
//								return '正常';
//							}else if(value=='1'){
//								return '未还';
//							}else{
//								return '未还销毁';
//							}
							return value;
						}
					}],
			pager : "#logPeopleManagePager",
			caption : "取章还章列表"
		}).trigger("reloadGrid");
	
	$("#logPeopleManageList").navGrid("#logPeopleManagePager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true,
		excel : false
	}).navButtonAdd('#logPeopleManagePager',{
		caption:"导出excel",
		buttonicon:"ui-icon-excel", 
		onClickButton:function(){
			var ge_returnSealDateTime = $('#ge_returnSealDateTime').val();
			var le_returnSealDateTime = $('#le_returnSealDateTime').val();
			var ge_takeSealDateTime = $('#ge_takeSealDateTime').val();
			var le_takeSealDateTime = $('#le_takeSealDateTime').val();
			if(ge_takeSealDateTime > le_returnSealDateTime){
				alert("“取章时间”开始时间不能大于结束时间！")
				return;
			}
			if(ge_returnSealDateTime > le_returnSealDateTime){
				alert("“还章时间”开始时间不能大于结束时间！")
				return;
			}
			if(ge_takeSealDateTime != '' || le_takeSealDateTime != ''){
				if(ge_returnSealDateTime != '' || le_returnSealDateTime != ''){
					alert("“取章时间”条件与“还章时间”条件只能二选一");
					return;
				}
			}
			if(ge_takeSealDateTime != ''){
				if(le_takeSealDateTime == ''){
					alert("时间范围请填写完整：“取章时间”结束时间不能为空！");
					return;
				}
			}else{
				if(le_takeSealDateTime != ''){
					alert("时间范围请填写完整：“取章时间”开始时间不能为空！");
					return;
				}
			}
			if(ge_returnSealDateTime != ''){
				if(le_returnSealDateTime == ''){
					alert("时间范围请填写完整：“还章时间”结束时间不能为空！");
					return;
				}
			}else{
				if(le_returnSealDateTime != ''){
					alert("时间范围请填写完整：“还章时间”开始时间不能为空！");
					return;
				}
			}
			if(ge_returnSealDateTime == '' && le_returnSealDateTime == '' && ge_takeSealDateTime == '' && le_takeSealDateTime == ''){
				alert("请必须选择“取章时间”条件或“还章时间”条件做导出必要条件");
				return;
			}
			
			$.ajax({
				type : "post",
				url : ctx + "/report/transferPowerReportAction_findSum.action",
				dataType : "json",
				async : false,
				success : function(response) {
					var data = response.data;
					var n = true;
					if(ge_returnSealDateTime!='' || le_returnSealDateTime!=''){
						if(MonthsBetw(ge_returnSealDateTime,le_returnSealDateTime) > 60){
						    alert('导出时还章时间不能超出5年');
							n = false;
							return;
						} 
					}
					if(n){
						if(ge_takeSealDateTime!='' || le_takeSealDateTime!=''){
							if(MonthsBetw(ge_takeSealDateTime,le_takeSealDateTime) > 60){
							    alert('导出时取章时间不能超出5年');
								return;
							}
						} 
					}
					
					
					var str = '<form id="postForm" action="'+ ctx +'/report/takeRetuenSealReportAction_report.action" method="post" style="display:hidden;">'+
					                '<input type="hidden" id="sealOrg" name="sealOrg" value="'+ $('#sealOrg').val() +'" />'+
					                '<input type="hidden" id="ge_takeSealDateTime" name="ge_takeSealDateTime" value="'+ $('#ge_takeSealDateTime').val() +'" />'+
					                '<input type="hidden" id="le_takeSealDateTime" name="le_takeSealDateTime" value="'+ $('#le_takeSealDateTime').val() +'" />'+
					                '<input type="hidden" id="ge_returnSealDateTime" name="ge_returnSealDateTime" value="'+ $('#ge_returnSealDateTime').val() +'" />'+
					                '<input type="hidden" id="le_returnSealDateTime" name="le_returnSealDateTime" value="'+ $('#le_returnSealDateTime').val() +'" />'+
					                '<input type="hidden" id="takeSealPeopleName" name="takeSealPeopleName" value="'+ $('#takeSealPeopleName').val() +'" />'+
					                '<input type="hidden" id="sealName" name="sealName" value="'+ $('#sealName').val() +'" />'+
					          '</form>';
                   
					$("#div1").html("");
					$("#div1").html(str);
					$("#postForm").submit();
					
					
					
//					$.ajaxFileUpload({url : ctx + "/report/takeRetuenSealReportAction_report.action"+
//		//			        "?queryBean.params.sealOrg=" + $('#sealOrg').val()+
//		                  	"?queryBean.params.ge_takeSealDateTime=" +  $('#ge_takeSealDateTime').val()+
//							"&queryBean.params.le_takeSealDateTime=" +  $('#le_takeSealDateTime').val()+
//							"&queryBean.params.ge_returnSealDateTime=" +  $('#ge_returnSealDateTime').val()+
//							"&queryBean.params.le_returnSealDateTime=" +  $('#le_returnSealDateTime').val(),
//		//					"&queryBean.params.sealType_int=" +   $('#sealType').find("option:selected").val()+
//		//					"&queryBean.params.sealState_int=" +   $('#sealState').find("option:selected").val()+
//		//					"&queryBean.params.like_takeSealPeopleName=" +  $('#takeSealPeopleName').val()+
//		//					"&queryBean.params.like_sealName=" +  $('#sealName').val(),
//					        
//					dataType : 'json',
//					success : function(res, status){}
//					})
				}
			})
			
			
		}
	}) ;
}


function MonthsBetw(date1, date2) {
	date1 = date1.split("-");
	date2 = date2.split("-");
	var year1 = parseInt(date1[0]),
	month1 = parseInt(date1[1].slice(0,1)=='0'?date1[1].slice(1,2):date1[1]),
	year2 = parseInt(date2[0]),
	month2 = parseInt(date2[1].slice(0,1)=='0'?date2[1].slice(1,2):date2[1]),
	months = (year2 - year1) * 12 + (month2 - month1);
	return months;
}

function submitForm(){
	update();
}

function deletePeopleUseSeal(sid){
	if(!confirm('确定删除？')){
		return;
	}
	var params = {
			'peopleUseSealInfo.sid':sid
	};
	$.post(ctx+"/peopleUseSeal/peopleUseSealInfoAction_delete.action",params,function(data){
		if(data.responseMessage.success){
			alert("删除成功");
			queryData();
		}else{
			alert(res.responseMessage.message);
		}
	});
}


/**
 * 查询数据，执行查询
 */
function queryData() {
	var ge_takeSealDateTime = $("#ge_takeSealDateTime").val();
	var le_takeSealDateTime = $("#le_takeSealDateTime").val();
	if(ge_takeSealDateTime == ""){
		if(le_takeSealDateTime != ""){
			alert("取章时间开始时间不能为空！")
			return;
		}
	}else{
		if(le_takeSealDateTime == ""){
			alert("取章时间结束时间不能为空！")
			return;
		}
	}
	if(ge_takeSealDateTime > le_takeSealDateTime){
		alert("取章时间开始时间不能大于结束时间！")
		return;
	}
	var ge_returnSealDateTime = $("#ge_returnSealDateTime").val();
	var le_returnSealDateTime = $("#le_returnSealDateTime").val();
	if(ge_returnSealDateTime == ""){
		if(le_returnSealDateTime != ""){
			alert("还章时间开始时间不能为空！")
			return;
		}
	}else{
		if(le_returnSealDateTime == ""){
			alert("还章时间结束时间不能为空！")
			return;
		}
	}
	if(ge_returnSealDateTime > le_returnSealDateTime){
		alert("还章时间开始时间不能大于结束时间！")
		return;
	}
	$("#logPeopleManageList").jqGrid("search", "#queryForm");
}

/**
 * 重置查询条件
 */
function resetMethod() {
	$("#queryForm")[0].reset();
//	initOrgNo();
}

/**
 * 选择机构
 */
function checkOrganizationItem(organizationNo){
	var organizationSid = top.loginPeopleInfo.orgSid;
	$("#sealOrg").radioOrgTree(true,organizationSid,0,false,function(event, treeId, treeNode){
		if(treeNode){
			$("#sealOrg").val(treeNode.organizationNo);
//			$("#"+organizationNo).val(treeNode.organizationNo);
			$("#"+organizationNo).val(treeNode.organizationName+"("+treeNode.organizationNo+")");
		}
	});
}