/**
 * 
 * 创建于:2014-9-11<br>
 * 版权所有(C) 2014 深圳市银之杰科技股份有限公司<br>
 * 人员登录日志查询
 * 
 * @author guoshixuan
 * @version 1.0
 */

/**
 * 初始化Grid数据
 */
var login_People = null;
$(function() {
	initPeopleType();
	login_People = top.loginPeopleInfo;
	initPage();
	
	$("#ge_startDate").blur(function(){
		var ge_endDate = $("#ge_endDate").val();
		var le_endDate = $("#le_endDate").val();
		if(ge_endDate != "" || le_endDate != ""){
			$("#ge_startDate").val("");
			alert("开始日期条件与结束日期条件只能二选一：现在已选择结束日期条件！");
		}
	});
	
	$("#le_startDate").blur(function(){
		var ge_endDate = $("#ge_endDate").val();
		var le_endDate = $("#le_endDate").val();
		if(ge_endDate != "" || le_endDate != ""){
			$("#le_startDate").val("");
			alert("开始日期条件与结束日期条件只能二选一：现在已选择结束日期条件！");
		}
	});
	
	$("#ge_endDate").blur(function(){
		var ge_startDate = $("#ge_startDate").val();
		var le_startDate = $("#le_startDate").val();
		if(ge_startDate != "" || le_startDate != ""){
			$("#ge_endDate").val("");
			alert("开始日期条件与结束日期条件只能二选一：现在已选择开始日期条件！");
		}
	});
	
	$("#le_endDate").blur(function(){
		var ge_startDate = $("#ge_startDate").val();
		var le_startDate = $("#le_startDate").val();
		if(ge_startDate != "" || le_startDate != ""){
			$("#le_endDate").val("");
			alert("开始日期条件与结束日期条件只能二选一：现在已选择开始日期条件！");
		}
	});
});

function initPeopleType(){
	$.ajax({
		type : "post",
		url : ctx + "/transferPowerInfoAction_isSavePeople.action",
		data : {
			
		},
		dataType : "json",
		async : false,
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0" || XMLHttpRequest.status != "200") {
				//result.response = "服务器或网络异常";
			}
		},
		success : function(response) {
			peopleType=response.apprOrManager;
			if(peopleType!='1'){//登录人不是保管人
				$("#reserveBtn").attr("disabled", "disabled");
			}
		}
	});
}

function initPage(){
	var pageHeaderHeight = $(".pageHeader").css("height");
	var pageContentWidth = $(".pageContent").width() -2;
		pageHeaderHeight = pageHeaderHeight.substr(0,pageHeaderHeight.length - 2);
	var tableHeight = document.documentElement.clientHeight -pageHeaderHeight + 6 - 50*2 ;
	$("#AddTransferPowerInfoDLG").dialog({autoOpen: false,caption:"预约强制转授权", resizable: false,height: 250- (enableSupervisePeople=="false"?50:0),width: 380,modal: true,buttons: {
			"保存": function() {
				var applicationFormNo = $("#applicationFormNo").val();
				var startDate = $("#_startDate").val();
				if(startDate==null || startDate==""){
					showMsg("开始日期不能为空");
					return ;
				}
				var startTime = $("#startTime").val();
				if(startTime==null || startTime==""){
					showMsg("开始时间不能为空");
					return ;
				}
				var endDate = $("#_endDate").val();
				if(endDate==null || endDate==""){
					showMsg("结束日期不能为空");
					return ;
				}
				var endTime = $("#endTime").val();
				if(endTime==null || endTime==""){
					showMsg("结束时间不能为空");
					return ;
				}
				var revicePeopleNo = $("#revicePeopleNo").val();
				if(revicePeopleNo==null || revicePeopleNo==""){
					showMsg("接收人不能为空");
					return ;
				}
				/*var revicePeoplePassword = $("#revicePeoplePassword").val();
				if(revicePeoplePassword==null || revicePeoplePassword==""){
					showMsg("接收人密码不能为空");
					return ;
				}
				if(enableSupervisePeople=="true"){
					var supervisePeopleNo = $("#supervisePeopleNo").val();
					if(supervisePeopleNo==null || supervisePeopleNo==""){
						showMsg("监交人不能为空");
						return ;
					}
					var supervisePeoplePassword = $("#supervisePeoplePassword").val();
					if(supervisePeoplePassword==null || supervisePeoplePassword==""){
						showMsg("监交人密码不能为空");
						return ;
					}
				}*/ 
//				 a.transferpeopleorgno,a.revicepeopleorgno
				var param = {
						"transferPowerInfo.applicationFormNo" : applicationFormNo,
						"transferPowerInfo.startDate" : startDate,
						"transferPowerInfo.startTime" : startTime,
						"transferPowerInfo.endDate" : endDate,
						"transferPowerInfo.endTime" : endTime,
						"transferPowerInfo.revicePeopleNo" : revicePeopleNo,
						"transferPowerInfo.transferPeopleOrgNo" : $("#revicePeopleNo").find("option:selected").attr('test'),
						"transferPowerInfo.revicePeopleOrgNo" : login_People.orgNo
						/*"transferPowerInfo.supervisePeoplePwd" : supervisePeoplePassword*/
					};
				$.post(ctx + "/transferPowerInfoAction_reserve.action", param, function(
						data) {
					var obj = $.parseJSON(data);
					showMsg(obj.data.msg);
					if (obj.data.ok == true) {
						refresh();
						$("#AddTransferPowerInfoDLG").dialog("close");
					}
					return;
				});
				
			},"重置": function() {//2按钮
				var applicationFormNo_ = $("#applicationFormNo").val();
				$(this).find("form")[0].reset();
				$("#applicationFormNo").val(applicationFormNo_);
			}
		},close: function() {
			$("#_startDate").val("");
			$("#startTime").val("00:00:00");
			$("#_endDate").val("");
			$("#endTime").val("00:00:00");
			$("#revicePeoplePassword").val("");
			$("#supervisePeoplePassword").val("");
			$("#revicePeopleNo").empty();
			$("#supervisePeopleNo").empty(); 
			$("#msg").html("");
		}
	});
	$("#transferPowerInfoList").jqGrid(
		{
			width : pageContentWidth,
			height : tableHeight,
			url : ctx + "/transferPowerInfoAction_showListPage.action",
			multiselect : false,
			rowNum : 20,
			rownumbers:true,
			rowList : [ 20, 50, 100 ],
			colNames : ["申请编号", "电子锁权限转入方", "电子锁权限转出方", "开始时间", "结束时间",/*"撤销时间",*/"状态","操作"],
			colModel : [
					{
						name : "applicationFormNo",
						index : "applicationFormNo",
						align : "center",
						width : 80,
						sortable : false
					},
					{
						name : "revicePeopleName",
						index : "revicePeopleName",
						align : "center",
						width : 80,
						sortable : false,
						formatter : function(value, options, rData) {
							var revicePeopleName;
							if(rData.revicePeopleNo!=null){
								revicePeopleName =rData.revicePeopleName+ "("+rData.revicePeopleNo+")";
							}
							return revicePeopleName;
						}
					},{
						name : "transferPeopleNo",
						index : "transferPeopleNo",
						align : "center",
						width : 80,
						sortable : false,
						formatter : function(value, options, rData) {
							var revicePeopleName;
							if(rData.revicePeopleNo!=null){
								revicePeopleName =rData.transferPeopleName+ "("+rData.transferPeopleNo+")";
							}
							return revicePeopleName;
						}
					},{
						name : "startTime",
						index : "startTime",
						align : "center",
						width : 80,
						sortable : false,
						formatter : function(value, options, rData) {
							var startTime = "";
							if(rData.startDate!=null){
								startTime += rData.startDate;
							}
							if(rData.startTime!=null){
								startTime += " "+rData.startTime;
							}
							return startTime;
						}
					},
					{
						name : "endTime",
						index : "endTime",
						align : "center",
						width : 80,
						sortable : false,
						formatter : function(value, options, rData) {
							var endTime = "";
							if(rData.endDate!=null){
								endTime += rData.endDate;
							}
							if(rData.endTime!=null){
								endTime += " "+rData.endTime;
							}
							return endTime;
						}
					},
					/*{
						name : "cannelDate",
						index : "cannelDate",
						align : "center",
						width : 80,
						sortable : false,
						formatter : function(value, options, rData) {
							var endTime = "";
							if(rData.cannelDate!=null){
								endTime += rData.cannelDate;
							}
							if(rData.cannelTime!=null){
								endTime += " "+rData.cannelTime;
							}
							return endTime;
						}
					},*/
					{
						name : "status",
						index : "status",
						align : "center",
						width : 80,
						formatter : function(value, options, rData) {
							var status = "";
							if(rData.status==0){
								status = "预约";
							}else if(rData.status==1){
								status = "进行中";
							}else if(rData.status==2){
								status = "正常结束";
							}else if(rData.status==3){
//								status = "提前收回";
								status = "撤还";
							}else if(rData.status==4){
								status = "撤销";
							}
							return status;
						}
					},{
					    name : "id",
					    index : "id",
					    width : 76,
					    align : "center",
					    sortable : false,
					    formatter : function(value, options, rData) {
					    	if(rData.status == 0 ){
					    		return "<input type='button' id='cancelBtn' style='color:#333;' onclick='cannel(\"" + value + "," + rData.status + "\");' value='撤销' />&nbsp;";
								/*"<input type='button' id='takeBackBtn' disabled='disabled' style='color:#333;' onclick='takeBack(\""+ value + "," + rData.status + "\");' value='提前收回' />&nbsp;";*/
					    	}
					    	if(rData.transferPeopleNo==login_People.peopleCode){
					    		return;
					    	}
					    	if(rData.status == 1){
					    		return "<input type='button' id='takeBackBtn' style='color:#333;' onclick='takeBack(\""+ value + "," + rData.status + "\");' value='撤还' />&nbsp;";
					    	}else{
					    		return;
//					    		return "<input type='button' id='cancelBtn'disabled='disabled' style='color:#333;' onclick='cannel(\"" + value + "," + rData.status + "\");' value='撤还' />&nbsp;";
								/*"<input type='button' id='takeBackBtn' disabled='disabled' style='color:#333;' onclick='takeBack(\""+ value + "," + rData.status + "\");' value='提前收回' />&nbsp;";*/
					    	}
					    }
					}],
			pager : "#transferPowerInfoPager",
			caption : "我的转授权信息列表"
		}).trigger("reloadGrid");
	$("#transferPowerInfoList").navGrid("#transferPowerInfoPager", {
		edit : false,
		add : false,
		del : false,
		search : false,
		refresh : true
	});
}
//显示信息
function showMsg(msg) {
	$("#msg").html(msg);
}

/**
 * 查询数据，执行查询
 */
function queryData() {
	var ge_startDate = $("#ge_startDate").val();
	var le_startDate = $("#le_startDate").val();
	if(ge_startDate == ""){
		if(le_startDate != ""){
			alert("开始日期开始时间不能为空！")
			return;
		}
	}else{
		if(le_startDate == ""){
			alert("开始日期结束时间不能为空！")
			return;
		}
	}
	if(ge_startDate > le_startDate){
		alert("开始日期开始时间不能大于结束时间！")
		return;
	}
	var ge_endDate = $("#ge_endDate").val();
	var le_endDate = $("#le_endDate").val();
	if(ge_endDate == ""){
		if(le_endDate != ""){
			alert("结束日期开始时间不能为空！")
			return;
		}
	}else{
		if(le_endDate == ""){
			alert("结束日期结束时间不能为空！")
			return;
		}
	}
	if(ge_endDate > le_endDate){
		alert("结束日期开始时间不能大于结束时间！")
		return;
	}
	$("#transferPowerInfoList").jqGrid("search", "#transferPowerQueryForm");
}

/**
 * 重置查询条件
 */
function resetQuery() {
	$("#ge_startDate").val("");
	$("#le_startDate").val("");
	$("#transferPowerQueryForm")[0].reset();
}

//显示预约界面
function showReservePage() {
	/*if(enableSupervisePeople=="true"){
		top.showPage(ctx + "/transferPowerInfoAction_showReservePage.action", null,
				"预约", 420, 308);
	} else {
		top.showPage(ctx + "/transferPowerInfoAction_showReservePage.action", null,
				"预约", 420, 258);
	}*/
	$.ajax({
		type : "post",
		url : ctx + "/transferPowerInfoAction_showReservePage.action",
		data : "",
		dataType : "json",
		async : false,
		complete : function(XMLHttpRequest, textStatus) {
			if (XMLHttpRequest.readyState == "0" || XMLHttpRequest.status != "200") {
				//result.response = "服务器或网络异常"; a.transferpeopleorgno,a.revicepeopleorgno
			}
		},
		success : function(response) {
			$.each(response.sameOrgPeopleInfos, function(key, val) {
				$("#revicePeopleNo").append("<option title="+response.sameOrgPeopleInfos[key].peopleCode+"  test="+response.sameOrgPeopleInfos[key].orgNo+" value=" + response.sameOrgPeopleInfos[key].peopleCode+ " >" + response.sameOrgPeopleInfos[key].peopleName + "</option>");
			})
			$.each(response.sameOrgPeopleInfos, function(key, val) {
				$("#supervisePeopleNo").append("<option title="+response.sameOrgPeopleInfos[key].peopleCode+" value=" + response.sameOrgPeopleInfos[key].peopleCode+ " >" + response.sameOrgPeopleInfos[key].peopleCode + "</option>");
			})
			$("#applicationFormNo").val(response.applicationFormNo);
			$("#applicationFormNo").attr("disabled","true");
			$("#AddTransferPowerInfoDLG").dialog("open");
		}
	});
}
// 取消
function cannel(id) {
	var arr = id.split(',');
	if (arr[1] != 0 ){
		top.wfAlert("不是预约状态无法撤销");
		return;
	}
	if (confirm("确定要撤销吗？")) {
		var url = ctx + "/transferPowerInfoAction_cancel.action";
		var param = {
			"transferPowerInfo.id" : arr[0]
		};
		$.post(url, param, function(data) {
			var obj = $.parseJSON(data);
			top.wfAlert(obj.data.msg);
			refresh();
			return;
		});
	}
}
// 提前收回
function takeBack(id) {
	var arr = id.split(',');
	if (arr[1] != 1 ){
		top.wfAlert("不是进行中状态无法提前收回");
		return;
	}
	if (confirm("确定要提前收回吗？")) {
		var url = ctx + "/transferPowerInfoAction_takeBack.action";
		var param = {
			"transferPowerInfo.id" : arr[0]
		};
		$.post(url, param, function(data) {
			var obj = $.parseJSON(data);
			top.wfAlert(obj.data.msg);
			refresh();
			return;
		});
	}
}

function refresh(){
	$("#transferPowerInfoList").jqGrid("search", "#transferPowerQueryForm");
}